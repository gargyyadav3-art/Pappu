# PEACE CHECKER BOT

A multi-service Telegram email:password checker bot built with `pyTelegramBotAPI`.

## How to host (any server)

1. **Install Python 3.11+**

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set your bot token** (get one from [@BotFather](https://t.me/BotFather))
   ```bash
   export BOT_TOKEN="123456:ABC-your-real-bot-token"
   ```
   *(On Windows: `set BOT_TOKEN=...`)*

4. **Run the bot**
   ```bash
   python main.py
   ```

The bot will start polling and a small Flask status web server runs on port `5000`.

## 24/7 uptime tips

The bot already has a self-restart wrapper at the top of `main.py` — if it crashes,
it relaunches itself instantly. For true always-on hosting, run it under a process
manager such as `systemd`, `pm2`, `supervisor`, `screen`, or `tmux`, e.g.:

```bash
# simple one-liner (Linux)
while true; do python main.py; sleep 1; done
```

## Files included

| File | Purpose |
|---|---|
| `main.py` | The bot itself (entry point) |
| `web_app.py` | Tiny Flask status / dashboard web app |
| `translations.py` | DE / EN button & message strings |
| `user_stats.py` | User stats helpers |
| `requirements.txt` | Python dependencies |
| `pyproject.toml` | Project metadata |
| `templates/`, `static/` | Web dashboard files |
| `force_join_config.json` | Force-join channel list (starts empty) |
| `allowed_groups.json` | Allowed group chat IDs (starts empty) |
| `redeem_codes.json` | Redeem-key inventory |
| `replit.md` | Project notes |

## Admin

The admin Telegram user ID is hardcoded near the top of `main.py` as
`ADMIN_ID`. Change it to your own numeric Telegram ID before running.
