# Skyline Hotmail Checker Telegram Bot + Web App

## Overview
A Telegram bot AND web application that checks Hotmail/Outlook, T-Online, Freenet, and Online.de email accounts for linked services. Users upload combo files (email:password) and the bot validates accounts and searches their inboxes for registrations on various platforms.

## Architecture
- **Language:** Python 3.11
- **Telegram Bot:** pyTelegramBotAPI (telebot)
- **Web Framework:** Flask (runs alongside bot on port 5000)
- **Database:** SQLite (`bot_database.db`) + JSON (`users_database.json`)
- **Entry Point:** `main.py` (starts both Telegram bot and Flask web server)
- **Web Server:** `web_app.py` (Flask routes, templates, API endpoints)
- **Templates:** `templates/` (index.html, login.html, dashboard.html)
- **Static:** `static/style.css`
- **Translations:** `translations.py` (DE/EN multi-language support)
- **User Statistics:** `user_stats.py` (per-user tracking, JSON-backed)

## Key Features
- Account validation: Microsoft OAuth for Hotmail/Outlook, IMAP for T-Online/Freenet/Online.de
- Service checking across 70+ platforms (Social, Gaming, Streaming, AI, Shopping, Finance)
- TikTok Full Capture (VIP Forever only)
- Instagram Full Capture (VIP only)
- Dedicated inbox buttons (19 Services): RYD, Limehome, Lime, Amazon, PayPal, Uber, Lieferando, Booking.com, Zalando, PAYBACK (with points extraction), Deutsche Bahn, DHL, Otto, eBay, Netflix, Spotify, Check24, SHEIN, FlixBus
- Combo Generator, Combo Cleaner, Mail Extractor
- VIP/membership system with redeem keys
- Admin panel (ban/unban, VIP management, broadcast, key generation, group management, user logs)
- **Multi-Language:** German (DE) and English (EN) with per-user language preference
- **User Statistics:** Per-user tracking of scans, hits, inbox checks, combos checked; Admin panel with User Stats and Top Users views

## Multi-Language System
- `translations.py` — Contains `TRANSLATIONS` dict with all UI strings in DE and EN
- `user_languages.json` — Persists per-user language preferences
- `t(user_id, key, **kwargs)` — Translation helper function used throughout bot
- Users select language via 🌐 button in main menu → inline keyboard (🇩🇪 Deutsch / 🇬🇧 English)
- All button labels, messages, and prompts adapt to selected language
- Default language: German (DE)

## User Statistics System
- `user_stats.py` — Tracks per-user: total_scans, total_hits, total_bads, total_combos_checked, inbox_checks, inbox_hits, service_checks, last_active, first_seen
- `user_stats.json` — Persisted stats data
- Admin Panel buttons: 👤 User Stats (all users overview), 🏆 Top Users (leaderboard with medals)
- `record_scan()` called after regular scans complete
- `record_inbox()` called after inbox checks (Einzeln, Mehrere, RYD, Limehome, all service buttons)

## Inbox Search Accuracy
- `KNOWN_SERVICE_SENDERS` dict maps service names → exact sender email addresses
- All Hotmail inbox queries use quoted `from:"sender@domain.com"` for exact matching
- `INBOX_SERVICES` config uses exact sender addresses in hotmail_queries for all service buttons
- Prevents false positives from Outlook partial-match search behavior

## Web Application
- **Landing Page** (`/`): Feature overview, service list, call-to-action
- **Login** (`/login`): VIP key authentication
- **Dashboard** (`/dashboard`): All tools available via web interface
  - Single Account Check (`/api/single-check`)
  - Custom Inbox (`/api/custom-inbox`) — single or multi mode
  - Service Inbox (`/api/inbox-check`) — all 9 predefined services
  - Combo Generator (`/api/combo-gen`)
  - Combo Cleaner (`/api/combo-clean`)
  - Mail Extractor (`/api/mail-extract`)
  - File downloads (`/api/download/<id>`) — secure with per-user ownership

## Email Provider Support
- **Hotmail/Outlook:** Microsoft OAuth → Outlook Search API for inbox checking
- **T-Online (@t-online.de):** IMAP login (imap.t-online.de:993) → IMAP SEARCH
- **Freenet (@freenet.de):** IMAP login (imap.freenet.de:993) → IMAP SEARCH
- **Online.de (@online.de):** IMAP login (imap.online.de:993) → IMAP SEARCH
- Auto-detection via `check_account_auto()` function

## Environment Variables
- `BOT_TOKEN` — Telegram Bot API token (secret)
- `ADMIN_ID` — Telegram user ID of the bot admin (8139020487)

## Dependencies
- `pytelegrambotapi` — Telegram Bot API wrapper
- `flask` — Web framework for the web interface
- `requests` — HTTP requests for Microsoft OAuth and service checks
- Standard library: `imaplib`, `email`, `sqlite3`, `json`, `threading`, `concurrent.futures`

## Workflow
- `Start application` — runs `python main.py` (starts bot + web server on port 5000)
