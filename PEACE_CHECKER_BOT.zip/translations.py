TRANSLATIONS = {
    "de": {
        "welcome": "⚡ <b>PEACE CHECKER</b> {admin_badge}\n\nWillkommen <b>{first_name}</b>! ✨\n\n🆔 ID: <code>{uid}</code>\n👑 Mitgliedschaft: <b>{vip_status}</b>{trial_note}\n\n📋 Drücke einen Button um zu starten!\n\n💎 {signature}",
        "welcome_gift": "🎁 <b>WILLKOMMENSGESCHENK!</b>\n\nDu hast <b>1 Stunde GRATIS VIP</b> als neues Mitglied erhalten!\n\n✅ Unbegrenzte Scans\n✅ TikTok Full Capture\n✅ Alle Premium-Features\n\n⏰ Läuft in 1 Stunde ab — viel Spaß! 🚀\n\n💎 {signature}",
        "banned": "❌ <b>Du wurdest vom Admin gesperrt {signature}</b>",
        "maintenance": "🔧 <b>WARTUNGSMODUS</b>\n\nDer Bot wird gerade gewartet.\nBitte versuche es später!\n\n💎 {signature}",
        "key_required": "🔒 <b>KEY ERFORDERLICH</b>\n\nDu brauchst einen gültigen Key um den Bot zu nutzen.\n\n🔑 Kaufe einen Key beim Admin und löse ihn unter\n<b>👑 Mitgliedschaft → 🔑 Key einlösen</b> ein.\n\n💎 {signature}",
        "reload": "🔄 <b>Bot neu geladen!</b> {admin_badge}\n\nWillkommen zurück <b>{first_name}</b>! ✨\n\n🆔 ID: <code>{uid}</code>\n👑 Mitgliedschaft: <b>{vip_status}</b>\n⭐ Punkte: {points}\n\n✅ Alle Buttons aktualisiert!\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n💎 {signature}",
        "select_scan_mode": "⚡ <b>SCAN-MODUS WÄHLEN</b>\n\nWähle was geprüft werden soll:",
        "vip_only": "👑 <b>Nur für VIP!</b>\n\nMulti Scan ist nur für VIP-Mitglieder verfügbar.",
        "multi_scan_prompt": "📦 <b>Multi Scan Modus</b>\n\nSende mehrere Combo-Dateien (bis zu 5)",
        "rate_limit": "⏳ <b>Rate Limit!</b>\n\nFree-Nutzer können einmal pro Stunde scannen.\n⏰ Nächster Scan in: <b>{remaining}</b>\n\n💎 Upgrade auf VIP für unbegrenzte Scans!",
        "my_stats": "📊 <b>Deine Statistiken</b>\n\n👤 <b>User Info:</b>\n• ID: <code>{uid}</code>\n• Username: @{username}\n• Status: {status}\n• Beigetreten: {joined}\n\n📈 <b>Scan-Verlauf:</b>\n• Scans gesamt: {total_scans}\n• Hits gesamt: {total_hits}\n\n⏰ <b>Letzter Scan:</b>\n{last_scan}\n\n💎 <b>Erstellt von {signature}</b>",
        "access_denied": "❌ <b>Zugriff verweigert!</b>",
        "admin_panel": "🔧 <b>ADMIN PANEL</b>\n\nWähle eine Option:",
        "send_combo": "📁 <b>Sende deine Combo-Datei</b>\n\nFormat: <code>email:passwort</code>",
        "no_valid_lines": "❌ Keine gültigen Zeilen gefunden.",
        "scan_started": "🔍 <b>{mode} gestartet!</b>\n\n📥 Accounts: <b>{total}</b>\n\n⏳ Bitte warten...",
        "scan_progress": "🔍 <b>Scan läuft...</b>\n\n📊 Fortschritt: <b>{checked}/{total}</b>\n✅ Hits: <b>{hits}</b> | ❌ Bad: <b>{bads}</b>",
        "scan_complete": "📊 <b>SCAN {status}</b>\n\n📊 <b>Gecheckt:</b> {checked}/{total}\n✅ <b>Hits:</b> {hits}\n❌ <b>Bad:</b> {bads}\n⚠️ <b>Fehler:</b> {errors}",
        "hit_found": "━━━━━━━━━━━━━━━━━━━━\n🎯 <b>HIT #{num}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n📧 Email: <code>{email}</code>\n🔑 Passwort: <code>{password}</code>\n\n🔗 <b>Verknüpfte Services:</b>\n{services}\n\n━━━━━━━━━━━━━━━━━━━━\n💎 {signature}",
        "inbox_hit": "━━━━━━━━━━━━━━━━━━━━\n📬 <b>INBOX HIT #{num}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n📧 Email: <code>{email}</code>\n🔑 Passwort: <code>{password}</code>\n\n🔗 <b>Gefundene Services:</b>\n{services}\n\n━━━━━━━━━━━━━━━━━━━━\n💎 {signature}",
        "inbox_started": "🔍 <b>Inbox Check läuft...</b>\n\n📬 Services: <b>{services}</b>\n📊 Fortschritt: <b>{checked}/{total}</b>\n✅ Hits: <b>{hits}</b> | ❌ Bad: <b>{bads}</b> | 📭 Kein Match: <b>{no_match}</b>",
        "inbox_complete": "━━━━━━━━━━━━━━━━━━━━\n📬 <b>INBOX SCAN {status}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n🔎 <b>Services:</b> {services}\n📊 <b>Gecheckt:</b> {checked}/{total}\n✅ <b>Linked (Hit):</b> {hits}\n📭 <b>Login OK, kein Match:</b> {no_match}\n❌ <b>Bad (Login fehlgeschlagen):</b> {bads}\n⚠️ <b>Fehler:</b> {errors}\n\n💎 {signature}",
        "combo_format": "📁 Format muss sein: <code>email:passwort</code>",
        "enter_service_single": "📬 <b>Einzeln Inboxen</b>\n\nGib den Service-Namen ein, nach dem gesucht werden soll.\n\nBeispiel: <code>netflix</code>, <code>instagram</code>, <code>ryd</code>\n\nDanach sende deine Combo-Datei.",
        "enter_service_multi": "📬 <b>Mehrere Inboxen</b>\n\nGib die Service-Namen kommagetrennt ein.\n\nBeispiel: <code>netflix, instagram, ryd, amazon</code>\n\nDanach sende deine Combo-Datei.",
        "send_combo_for_service": "✅ Service: <b>{services}</b>\n\n📁 Sende jetzt deine Combo-Datei.\nFormat: <code>email:passwort</code>",
        "stopped": "⏹ GESTOPPT",
        "completed": "ABGESCHLOSSEN",
        "language_changed": "✅ Sprache auf <b>Deutsch</b> geändert!",
        "choose_language": "🌐 <b>Sprache wählen / Choose Language</b>",
        "btn_start_scan": "📋 Start Scan",
        "btn_multi_scan": "📦 Multi Scan",
        "btn_my_stats": "📊 Meine Stats",
        "btn_membership": "👑 Mitgliedschaft",
        "btn_referral": "🔗 Mein Referral",
        "btn_support": "📞 Support",
        "btn_admin": "🔧 Admin Panel",
        "btn_reload": "🔄 Neu laden",
        "btn_language": "🌐 Sprache",
        "btn_combo_cleaner": "🧹 Combo Cleaner",
        "btn_mail_extractor": "📧 Mail Extractor",
        "btn_single_inbox": "📬 Einzeln Inboxen",
        "btn_multi_inbox": "📬 Mehrere Inboxen",
        "btn_combo_gen": "🔀 Combo Generator",
        "btn_scan_history": "📜 Scan Verlauf",
        "membership_admin": "🔧 <b>ADMIN MITGLIEDSCHAFT</b>\n\n👤 <b>Name:</b> {first_name}\n🆔 <b>User:</b> {username}\n🏷️ <b>Rolle:</b> Administrator\n✅ <b>Status:</b> Aktiv\n⏰ <b>Gültig bis:</b> {expiry}\n\n🎁 <b>Deine Rechte:</b>\n✅ Alle Bot-Features\n✅ Admin Panel\n✅ Unbegrenzte Scans\n✅ TikTok Full Capture\n✅ Nutzerverwaltung\n✅ VIP/Ban Kontrolle\n\n💎 <b>{signature}</b>",
        "membership_vip": "👑 <b>VIP MITGLIEDSCHAFT</b>\n\n👤 <b>Name:</b> {first_name}\n🆔 <b>User:</b> {username}\n✅ <b>Status:</b> Aktives VIP\n⏰ <b>Gültig bis:</b> {expiry}\n\n🎁 <b>Deine Features:</b>\n✅ Unbegrenzte Scans\n✅ Alle Scan-Modi\n✅ TikTok Full Capture\n✅ Priority Support\n\n🔑 <b>Key einlösen:</b> Drücke unten\n\n💎 <b>{signature}</b>",
        "membership_free": "⭐ <b>FREE MITGLIEDSCHAFT</b>\n\n👤 <b>Name:</b> {first_name}\n🆔 <b>User:</b> {username}\n📊 <b>Status:</b> Free User\n\n⚠️ <b>Einschränkungen:</b>\n• 1 Scan pro Stunde\n• Kein Multi Scan\n• Kein TikTok Capture\n\n💎 Upgrade auf VIP für alle Features!\n\n🔑 <b>Key einlösen:</b> Drücke unten\n\n💎 <b>{signature}</b>",
        "user_stats_title": "👤 <b>NUTZER-STATISTIKEN</b>",
        "user_stats_entry": "👤 <code>{uid}</code> (@{username})\n   📊 Scans: {scans} | ✅ Hits: {hits} | 📬 Inbox: {inbox}\n   ⏰ Zuletzt: {last_active}",
        "user_stats_empty": "📊 Noch keine Nutzer-Statistiken vorhanden.",
        "top_users": "🏆 <b>TOP NUTZER</b>\n\n{entries}\n\n💎 {signature}",
    },
    "en": {
        "welcome": "⚡ <b>PEACE CHECKER</b> {admin_badge}\n\nWelcome <b>{first_name}</b>! ✨\n\n🆔 ID: <code>{uid}</code>\n👑 Membership: <b>{vip_status}</b>{trial_note}\n\n📋 Press a button to get started!\n\n💎 {signature}",
        "welcome_gift": "🎁 <b>WELCOME GIFT!</b>\n\nYou received <b>1 Hour FREE VIP</b> as a new member!\n\n✅ Unlimited scans\n✅ TikTok Full Capture\n✅ All premium features\n\n⏰ Expires in 1 hour — enjoy! 🚀\n\n💎 {signature}",
        "banned": "❌ <b>You are banned by admin {signature}</b>",
        "maintenance": "🔧 <b>MAINTENANCE MODE</b>\n\nThe bot is currently under maintenance.\nPlease try again later!\n\n💎 {signature}",
        "key_required": "🔒 <b>KEY REQUIRED</b>\n\nYou need a valid key to use the bot.\n\n🔑 Buy a key from the admin and redeem it under\n<b>👑 Membership → 🔑 Redeem Key</b>.\n\n💎 {signature}",
        "reload": "🔄 <b>Bot reloaded!</b> {admin_badge}\n\nWelcome back <b>{first_name}</b>! ✨\n\n🆔 ID: <code>{uid}</code>\n👑 Membership: <b>{vip_status}</b>\n⭐ Points: {points}\n\n✅ All buttons updated!\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n💎 {signature}",
        "select_scan_mode": "⚡ <b>SELECT SCAN MODE</b>\n\nChoose what to check:",
        "vip_only": "👑 <b>VIP Feature Only!</b>\n\nMulti Scan is available for VIP members only.",
        "multi_scan_prompt": "📦 <b>Multi Scan Mode</b>\n\nSend multiple combo files (up to 5)",
        "rate_limit": "⏳ <b>Rate Limit!</b>\n\nFree users can scan once per hour.\n⏰ Next scan available in: <b>{remaining}</b>\n\n💎 Upgrade to VIP for unlimited scans!",
        "my_stats": "📊 <b>Your Statistics</b>\n\n👤 <b>User Info:</b>\n• ID: <code>{uid}</code>\n• Username: @{username}\n• Status: {status}\n• Joined: {joined}\n\n📈 <b>Scan History:</b>\n• Total Scans: {total_scans}\n• Total Hits: {total_hits}\n\n⏰ <b>Last Scan:</b>\n{last_scan}\n\n💎 <b>Created by {signature}</b>",
        "access_denied": "❌ <b>Access Denied!</b>",
        "admin_panel": "🔧 <b>ADMIN PANEL</b>\n\nSelect an option:",
        "send_combo": "📁 <b>Send your combo file</b>\n\nFormat: <code>email:password</code>",
        "no_valid_lines": "❌ No valid lines found.",
        "scan_started": "🔍 <b>{mode} started!</b>\n\n📥 Accounts: <b>{total}</b>\n\n⏳ Please wait...",
        "scan_progress": "🔍 <b>Scanning...</b>\n\n📊 Progress: <b>{checked}/{total}</b>\n✅ Hits: <b>{hits}</b> | ❌ Bad: <b>{bads}</b>",
        "scan_complete": "📊 <b>SCAN {status}</b>\n\n📊 <b>Checked:</b> {checked}/{total}\n✅ <b>Hits:</b> {hits}\n❌ <b>Bad:</b> {bads}\n⚠️ <b>Errors:</b> {errors}",
        "hit_found": "━━━━━━━━━━━━━━━━━━━━\n🎯 <b>HIT #{num}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n📧 Email: <code>{email}</code>\n🔑 Password: <code>{password}</code>\n\n🔗 <b>Linked Services:</b>\n{services}\n\n━━━━━━━━━━━━━━━━━━━━\n💎 {signature}",
        "inbox_hit": "━━━━━━━━━━━━━━━━━━━━\n📬 <b>INBOX HIT #{num}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n📧 Email: <code>{email}</code>\n🔑 Password: <code>{password}</code>\n\n🔗 <b>Found Services:</b>\n{services}\n\n━━━━━━━━━━━━━━━━━━━━\n💎 {signature}",
        "inbox_started": "🔍 <b>Inbox Check running...</b>\n\n📬 Services: <b>{services}</b>\n📊 Progress: <b>{checked}/{total}</b>\n✅ Hits: <b>{hits}</b> | ❌ Bad: <b>{bads}</b> | 📭 No Match: <b>{no_match}</b>",
        "inbox_complete": "━━━━━━━━━━━━━━━━━━━━\n📬 <b>INBOX SCAN {status}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n🔎 <b>Services:</b> {services}\n📊 <b>Checked:</b> {checked}/{total}\n✅ <b>Linked (Hit):</b> {hits}\n📭 <b>Login OK, no match:</b> {no_match}\n❌ <b>Bad (Login failed):</b> {bads}\n⚠️ <b>Errors:</b> {errors}\n\n💎 {signature}",
        "combo_format": "📁 Format must be: <code>email:password</code>",
        "enter_service_single": "📬 <b>Single Inbox</b>\n\nEnter the service name to search for.\n\nExample: <code>netflix</code>, <code>instagram</code>, <code>ryd</code>\n\nThen send your combo file.",
        "enter_service_multi": "📬 <b>Multiple Inboxes</b>\n\nEnter service names separated by commas.\n\nExample: <code>netflix, instagram, ryd, amazon</code>\n\nThen send your combo file.",
        "send_combo_for_service": "✅ Service: <b>{services}</b>\n\n📁 Now send your combo file.\nFormat: <code>email:password</code>",
        "stopped": "⏹ STOPPED",
        "completed": "COMPLETED",
        "language_changed": "✅ Language changed to <b>English</b>!",
        "choose_language": "🌐 <b>Choose Language / Sprache wählen</b>",
        "btn_start_scan": "📋 Start Scan",
        "btn_multi_scan": "📦 Multi Scan",
        "btn_my_stats": "📊 My Stats",
        "btn_membership": "👑 Membership",
        "btn_referral": "🔗 My Referral",
        "btn_support": "📞 Support",
        "btn_admin": "🔧 Admin Panel",
        "btn_reload": "🔄 Reload",
        "btn_language": "🌐 Language",
        "btn_combo_cleaner": "🧹 Combo Cleaner",
        "btn_mail_extractor": "📧 Mail Extractor",
        "btn_single_inbox": "📬 Single Inbox",
        "btn_multi_inbox": "📬 Multi Inbox",
        "btn_combo_gen": "🔀 Combo Generator",
        "btn_scan_history": "📜 Scan History",
        "membership_admin": "🔧 <b>ADMIN MEMBERSHIP</b>\n\n👤 <b>Name:</b> {first_name}\n🆔 <b>User:</b> {username}\n🏷️ <b>Role:</b> Administrator\n✅ <b>Status:</b> Active\n⏰ <b>Valid Until:</b> {expiry}\n\n🎁 <b>Your Permissions:</b>\n✅ All bot features\n✅ Admin Panel access\n✅ Unlimited scans\n✅ TikTok Full Capture\n✅ User management\n✅ VIP/Ban controls\n\n💎 <b>{signature}</b>",
        "membership_vip": "👑 <b>VIP MEMBERSHIP</b>\n\n👤 <b>Name:</b> {first_name}\n🆔 <b>User:</b> {username}\n✅ <b>Status:</b> Active VIP\n⏰ <b>Valid Until:</b> {expiry}\n\n🎁 <b>Your Features:</b>\n✅ Unlimited scans\n✅ All scan modes\n✅ TikTok Full Capture\n✅ Priority Support\n\n🔑 <b>Redeem Key:</b> Press below\n\n💎 <b>{signature}</b>",
        "membership_free": "⭐ <b>FREE MEMBERSHIP</b>\n\n👤 <b>Name:</b> {first_name}\n🆔 <b>User:</b> {username}\n📊 <b>Status:</b> Free User\n\n⚠️ <b>Limitations:</b>\n• 1 scan per hour\n• No Multi Scan\n• No TikTok Capture\n\n💎 Upgrade to VIP for all features!\n\n🔑 <b>Redeem Key:</b> Press below\n\n💎 <b>{signature}</b>",
        "user_stats_title": "👤 <b>USER STATISTICS</b>",
        "user_stats_entry": "👤 <code>{uid}</code> (@{username})\n   📊 Scans: {scans} | ✅ Hits: {hits} | 📬 Inbox: {inbox}\n   ⏰ Last: {last_active}",
        "user_stats_empty": "📊 No user statistics available yet.",
        "top_users": "🏆 <b>TOP USERS</b>\n\n{entries}\n\n💎 {signature}",
    }
}

user_languages = {}

LANG_FILE = "user_languages.json"

def load_languages():
    global user_languages
    try:
        with open(LANG_FILE, 'r') as f:
            user_languages = json.load(f)
            user_languages = {int(k): v for k, v in user_languages.items()}
    except:
        user_languages = {}

def save_languages():
    with open(LANG_FILE, 'w') as f:
        json.dump({str(k): v for k, v in user_languages.items()}, f)

def get_lang(user_id):
    return user_languages.get(user_id, "en")

def set_lang(user_id, lang):
    user_languages[user_id] = lang
    save_languages()

def t(user_id, key, **kwargs):
    lang = get_lang(user_id)
    translations = TRANSLATIONS.get(lang, TRANSLATIONS["en"])
    text = translations.get(key, TRANSLATIONS["en"].get(key, key))
    if kwargs:
        try:
            return text.format(**kwargs)
        except (KeyError, IndexError):
            return text
    return text

import json
load_languages()
