import json
import os
import threading
from datetime import datetime

STATS_FILE = "user_stats.json"
_stats_lock = threading.Lock()
_stats_data = {}

def _load_stats():
    global _stats_data
    try:
        if os.path.exists(STATS_FILE):
            with open(STATS_FILE, 'r') as f:
                _stats_data = json.load(f)
    except:
        _stats_data = {}

def _save_stats():
    try:
        with open(STATS_FILE, 'w') as f:
            json.dump(_stats_data, f, indent=2)
    except:
        pass

_load_stats()

def _ensure_user(user_id):
    uid = str(user_id)
    if uid not in _stats_data:
        _stats_data[uid] = {
            "username": "",
            "total_scans": 0,
            "total_hits": 0,
            "total_bads": 0,
            "total_combos_checked": 0,
            "inbox_checks": 0,
            "inbox_hits": 0,
            "service_checks": {},
            "last_active": None,
            "first_seen": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }
    return uid

def record_scan(user_id, username="", scan_type="scan", combos_count=0, hits=0, bads=0):
    with _stats_lock:
        uid = _ensure_user(user_id)
        if username:
            _stats_data[uid]["username"] = username
        _stats_data[uid]["total_scans"] += 1
        _stats_data[uid]["total_hits"] += hits
        _stats_data[uid]["total_bads"] += bads
        _stats_data[uid]["total_combos_checked"] += combos_count
        _stats_data[uid]["last_active"] = datetime.now().strftime("%Y-%m-%d %H:%M")
        _save_stats()

def record_inbox(user_id, username="", service_name="", combos_count=0, hits=0, bads=0):
    with _stats_lock:
        uid = _ensure_user(user_id)
        if username:
            _stats_data[uid]["username"] = username
        _stats_data[uid]["inbox_checks"] += 1
        _stats_data[uid]["inbox_hits"] += hits
        _stats_data[uid]["total_combos_checked"] += combos_count
        _stats_data[uid]["total_bads"] += bads
        _stats_data[uid]["last_active"] = datetime.now().strftime("%Y-%m-%d %H:%M")
        if service_name:
            svc_counts = _stats_data[uid].get("service_checks", {})
            svc_counts[service_name] = svc_counts.get(service_name, 0) + 1
            _stats_data[uid]["service_checks"] = svc_counts
        _save_stats()

def get_user_stats(user_id):
    with _stats_lock:
        uid = str(user_id)
        return _stats_data.get(uid, None)

def get_all_stats():
    with _stats_lock:
        return dict(_stats_data)

def get_top_users(limit=10, sort_by="total_scans"):
    with _stats_lock:
        users = []
        for uid, data in _stats_data.items():
            users.append((uid, data))
        users.sort(key=lambda x: x[1].get(sort_by, 0), reverse=True)
        return users[:limit]

def get_global_stats():
    with _stats_lock:
        total_scans = sum(d.get("total_scans", 0) for d in _stats_data.values())
        total_hits = sum(d.get("total_hits", 0) for d in _stats_data.values())
        total_inbox = sum(d.get("inbox_checks", 0) for d in _stats_data.values())
        total_inbox_hits = sum(d.get("inbox_hits", 0) for d in _stats_data.values())
        total_combos = sum(d.get("total_combos_checked", 0) for d in _stats_data.values())
        total_users = len(_stats_data)
        return {
            "total_users": total_users,
            "total_scans": total_scans,
            "total_hits": total_hits,
            "total_inbox": total_inbox,
            "total_inbox_hits": total_inbox_hits,
            "total_combos": total_combos,
        }
